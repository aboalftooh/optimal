package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.optimal.fleet.designsystem.OptimalIconSize
import com.optimal.fleet.designsystem.OptimalSemanticColors
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTypographyRoles


enum class OptimalStatusTone {
    Neutral,
    Info,
    Success,
    Warning,
    Danger,
}

private data class StatusVisual(
    val container: Color,
    val content: Color,
)

@Composable
private fun statusVisual(tone: OptimalStatusTone): StatusVisual =
    when (tone) {
        OptimalStatusTone.Neutral -> StatusVisual(
            container = MaterialTheme.colorScheme.surfaceVariant,
            content = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OptimalStatusTone.Info -> StatusVisual(
            container = OptimalSemanticColors.infoContainer,
            content = OptimalSemanticColors.info,
        )
        OptimalStatusTone.Success -> StatusVisual(
            container = OptimalSemanticColors.successContainer,
            content = OptimalSemanticColors.success,
        )
        OptimalStatusTone.Warning -> StatusVisual(
            container = OptimalSemanticColors.warningContainer,
            content = OptimalSemanticColors.warning,
        )
        OptimalStatusTone.Danger -> StatusVisual(
            container = OptimalSemanticColors.dangerContainer,
            content = OptimalSemanticColors.danger,
        )
    }

@Composable
fun OptimalStatusBadge(
    text: String,
    tone: OptimalStatusTone,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val visual = statusVisual(tone)
    StatusBadgeSurface(
        text = text,
        modifier = modifier,
        icon = icon,
        containerColor = visual.container,
        contentColor = visual.content,
    )
}

@Composable
internal fun StatusBadgeSurface(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    containerColor: Color,
    contentColor: Color,
) {
    Surface(
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.passiveChipMinHeight),
        shape = MaterialTheme.shapes.large,
        color = containerColor,
        contentColor = contentColor,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            contentColor.copy(alpha = 0.16f),
        ),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = OptimalSpacing.medium, vertical = OptimalSpacing.small),
            horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text, style = MaterialTheme.typography.labelMedium)
            icon?.let {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    modifier = Modifier.size(OptimalIconSize.small),
                )
            }
        }
    }
}


/** Shared semantic inline feedback surface for non-modal success/warning/error information. */
@Composable
fun OptimalInlineStatus(
    title: String,
    message: String,
    tone: OptimalStatusTone,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    actionModifier: Modifier = Modifier,
) {
    val visual = statusVisual(tone)
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = visual.container,
        contentColor = visual.content,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            visual.content.copy(alpha = 0.16f),
        ),
    ) {
        if (actionLabel != null && onAction != null) {
            OptimalAdaptiveLayout(
                modifier = Modifier.padding(OptimalSpacing.medium),
                compactContent = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
                    ) {
                        InlineStatusMessage(title, message, visual.content, icon)
                        OptimalTertiaryButton(
                            text = actionLabel,
                            onClick = onAction,
                            modifier = actionModifier.fillMaxWidth(),
                        )
                    }
                },
                regularContent = {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        InlineStatusMessage(
                            title = title,
                            message = message,
                            contentColor = visual.content,
                            icon = icon,
                            modifier = Modifier.weight(1f),
                        )
                        OptimalTertiaryButton(
                            text = actionLabel,
                            onClick = onAction,
                            modifier = actionModifier,
                        )
                    }
                },
            )
        } else {
            InlineStatusMessage(
                title = title,
                message = message,
                contentColor = visual.content,
                icon = icon,
                modifier = Modifier.padding(OptimalSpacing.medium),
            )
        }
    }
}

@Composable
private fun InlineStatusMessage(
    title: String,
    message: String,
    contentColor: Color,
    icon: ImageVector?,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon?.let {
            Icon(
                imageVector = it,
                contentDescription = null,
                modifier = Modifier.size(OptimalIconSize.standard),
            )
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.xSmall),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = contentColor,
            )
            Text(
                text = message,
                style = OptimalTypographyRoles.body,
                color = contentColor,
            )
        }
    }
}
