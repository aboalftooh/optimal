package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import com.optimal.fleet.designsystem.OptimalSemanticColors
import com.optimal.fleet.designsystem.OptimalSpacing

@Immutable
data class OptimalSegmentOption<T>(
    val value: T,
    val label: String,
    val testTag: String? = null,
)

@Composable
fun <T> OptimalSegmentedControl(
    options: List<OptimalSegmentOption<T>>,
    selected: T,
    onSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            options.forEach { option ->
                val active = option.value == selected
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = OptimalComponentDefaults.iconButtonMinSize)
                        .clip(MaterialTheme.shapes.medium)
                        .background(if (active) OptimalSemanticColors.brandContainer else Color.Transparent)
                        .selectable(
                            selected = active,
                            role = Role.Tab,
                            onClick = { onSelected(option.value) },
                        )
                        .then(if (option.testTag == null) Modifier else Modifier.testTag(option.testTag))
                        .padding(horizontal = OptimalSpacing.small, vertical = OptimalSpacing.medium),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = option.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
