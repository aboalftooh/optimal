package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.optimal.fleet.designsystem.OptimalElevation
import com.optimal.fleet.designsystem.OptimalSpacing

@Composable
fun OptimalBottomActionBar(
    primaryLabel: String,
    onPrimary: () -> Unit,
    modifier: Modifier = Modifier,
    primaryModifier: Modifier = Modifier,
    primaryEnabled: Boolean = true,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
    destructivePrimary: Boolean = false,
) {
    Surface(
        modifier = modifier.fillMaxWidth().defaultMinSize(minHeight = OptimalComponentDefaults.bottomActionMinHeight),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = OptimalElevation.raised,
        shadowElevation = OptimalElevation.overlay,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        val contentModifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = OptimalSpacing.large, vertical = OptimalSpacing.medium)
        if (secondaryLabel != null && onSecondary != null) {
            OptimalResponsivePair(
                modifier = contentModifier,
                first = { itemModifier ->
                    OptimalSecondaryButton(
                        text = secondaryLabel,
                        onClick = onSecondary,
                        modifier = itemModifier,
                    )
                },
                second = { itemModifier ->
                    BottomPrimaryAction(
                        label = primaryLabel,
                        onClick = onPrimary,
                        enabled = primaryEnabled,
                        destructive = destructivePrimary,
                        modifier = primaryModifier.then(itemModifier),
                    )
                },
            )
        } else {
            Box(modifier = contentModifier) {
                BottomPrimaryAction(
                    label = primaryLabel,
                    onClick = onPrimary,
                    enabled = primaryEnabled,
                    destructive = destructivePrimary,
                    modifier = primaryModifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun BottomPrimaryAction(
    label: String,
    onClick: () -> Unit,
    enabled: Boolean,
    destructive: Boolean,
    modifier: Modifier,
) {
    if (destructive) {
        OptimalDestructiveButton(
            text = label,
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.fillMaxWidth(),
        )
    } else {
        OptimalPrimaryButton(
            text = label,
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.fillMaxWidth(),
        )
    }
}
