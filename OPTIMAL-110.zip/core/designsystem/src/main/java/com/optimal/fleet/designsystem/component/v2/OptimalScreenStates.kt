package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import com.optimal.fleet.designsystem.OptimalSemanticColors
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTypographyRoles

@Composable
fun OptimalLoadingState(
    modifier: Modifier = Modifier,
    message: String = "جارٍ التحميل",
) {
    StateContainerV2(modifier) {
        CircularProgressIndicator()
        Text(
            text = message,
            style = OptimalTypographyRoles.body,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun OptimalEmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    icon: ImageVector = Icons.Outlined.Inbox,
) {
    StateContainerV2(modifier) {
        StateIconV2(
            icon = icon,
            containerColor = OptimalSemanticColors.brandContainer,
            contentColor = MaterialTheme.colorScheme.primary,
        )
        StateTextV2(title = title, message = message)
        if (actionLabel != null && onAction != null) {
            OptimalPrimaryButton(text = actionLabel, onClick = onAction)
        }
    }
}

@Composable
fun OptimalErrorState(
    message: String,
    modifier: Modifier = Modifier,
    onRetry: (() -> Unit)? = null,
) {
    StateContainerV2(modifier) {
        StateIconV2(
            icon = Icons.Outlined.ErrorOutline,
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.error,
        )
        StateTextV2(title = "تعذر عرض المحتوى", message = message)
        onRetry?.let { OptimalPrimaryButton("إعادة المحاولة", it) }
    }
}

@Composable
private fun StateTextV2(
    title: String,
    message: String,
) {
    Text(
        text = title,
        style = OptimalTypographyRoles.sectionTitle,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
    )
    Text(
        text = message,
        style = OptimalTypographyRoles.body,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
    )
}

@Composable
private fun StateIconV2(
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
) {
    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        color = containerColor,
        contentColor = contentColor,
        modifier = Modifier.size(OptimalComponentDefaults.stateIconContainerSize),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(OptimalComponentDefaults.stateIconSize),
            )
        }
    }
}

@Composable
private fun StateContainerV2(
    modifier: Modifier,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(OptimalSpacing.xLarge),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium, Alignment.CenterVertically),
    ) {
        content()
    }
}
