package com.optimal.fleet.designsystem

import androidx.compose.ui.unit.dp

/** Base spacing scale and semantic layout aliases. */
object OptimalSpacing {
    val xxSmall = 2.dp
    val xSmall = 4.dp
    val small = 8.dp
    val medium = 12.dp
    val large = 16.dp
    val xLarge = 24.dp
    val xxLarge = 32.dp
    val xxxLarge = 40.dp

    // Semantic layout aliases. New screen patterns should prefer OptimalContentInsets.
    val screenHorizontal = 18.dp
    val screenVertical = 12.dp
    val section = 20.dp

}
