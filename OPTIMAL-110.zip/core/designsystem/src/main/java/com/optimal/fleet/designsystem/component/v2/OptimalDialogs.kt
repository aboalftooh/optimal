package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTouchTarget
import com.optimal.fleet.designsystem.OptimalTypographyRoles

@Composable
fun OptimalDialog(
    title: String,
    onDismissRequest: () -> Unit,
    confirmLabel: String,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier,
    dismissLabel: String = "إلغاء",
    enabled: Boolean = true,
    destructive: Boolean = false,
    icon: ImageVector? = null,
    confirmTestTag: String? = null,
    dismissTestTag: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        modifier = modifier,
        shape = MaterialTheme.shapes.extraLarge,
        containerColor = MaterialTheme.colorScheme.surface,
        icon = icon?.let {
            {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
            }
        },
        title = {
            Text(
                text = title,
                style = OptimalTypographyRoles.sectionTitle,
                color = MaterialTheme.colorScheme.onSurface,
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
                content = content,
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                enabled = enabled,
                modifier = (if (confirmTestTag == null) Modifier else Modifier.testTag(confirmTestTag))
                    .defaultMinSize(minHeight = OptimalTouchTarget.minimum),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                ),
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismissRequest,
                modifier = (if (dismissTestTag == null) Modifier else Modifier.testTag(dismissTestTag))
                    .defaultMinSize(minHeight = OptimalTouchTarget.minimum),
            ) {
                Text(dismissLabel)
            }
        },
    )
}

@Composable
fun OptimalConfirmationDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    dismissLabel: String = "إلغاء",
    enabled: Boolean = true,
    destructive: Boolean = false,
    icon: ImageVector? = null,
    confirmTestTag: String? = null,
) {
    OptimalDialog(
        title = title,
        onDismissRequest = onDismissRequest,
        confirmLabel = confirmLabel,
        onConfirm = onConfirm,
        modifier = modifier,
        dismissLabel = dismissLabel,
        enabled = enabled,
        destructive = destructive,
        icon = icon,
        confirmTestTag = confirmTestTag,
    ) {
        Text(
            text = message,
            style = OptimalTypographyRoles.body,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
