package com.optimal.fleet.designsystem

import androidx.compose.ui.unit.dp

/** Canonical shallow elevation hierarchy from the reference visual constitution. */
object OptimalElevation {
    val flat = 0.dp
    val raised = 2.dp
    val overlay = 5.dp
    val modal = 8.dp
}

object OptimalIconSize {
    val small = 18.dp
    val standard = 24.dp
    val large = 32.dp
    val hero = 40.dp
}

object OptimalTouchTarget {
    val minimum = 48.dp
    val comfortable = 56.dp
}

object OptimalContentInsets {
    val horizontal = 18.dp
    val vertical = 12.dp
    val sectionGap = 20.dp
    val bottomSafeContent = 24.dp
}

object OptimalContentWidth {
    val compactMax = 600.dp
    val readableMax = 840.dp
}

/** Responsive thresholds used when compact width or accessibility text scaling requires stacking. */
object OptimalResponsiveLayout {
    val compactStackMaxWidth = 300.dp
    const val accessibilityFontScale = 2.0f
}

/** Durations are milliseconds and describe intent, not feature-specific choreography. */
object OptimalMotionDuration {
    const val fast = 150
    const val standard = 250
    const val deliberate = 350
}
