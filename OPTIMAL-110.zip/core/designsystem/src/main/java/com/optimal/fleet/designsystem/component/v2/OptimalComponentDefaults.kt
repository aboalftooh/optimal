package com.optimal.fleet.designsystem.component.v2

import androidx.compose.ui.unit.dp
import com.optimal.fleet.designsystem.OptimalTouchTarget

/** Shared dimensions owned by Core Components v2. */
object OptimalComponentDefaults {
    val buttonMinHeight = OptimalTouchTarget.comfortable
    val iconButtonMinSize = OptimalTouchTarget.minimum
    val fieldMinHeight = OptimalTouchTarget.comfortable
    val listRowMinHeight = OptimalTouchTarget.comfortable
    val chipMinHeight = OptimalTouchTarget.minimum
    val passiveChipMinHeight = 32.dp
    val stateIconContainerSize = 72.dp
    val stateIconSize = 32.dp
    val bottomActionMinHeight = 72.dp
    val dividerThickness = 1.dp
}
