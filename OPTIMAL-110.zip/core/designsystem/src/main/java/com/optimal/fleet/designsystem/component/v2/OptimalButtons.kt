package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.size
import com.optimal.fleet.designsystem.OptimalIconSize
import com.optimal.fleet.designsystem.OptimalSemanticColors
import com.optimal.fleet.designsystem.OptimalSpacing

@Composable
fun OptimalPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable RowScope.() -> Unit)? = null,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.buttonMinHeight),
        shape = MaterialTheme.shapes.large,
    ) {
        ButtonContent(text, leadingIcon)
    }
}

@Composable
fun OptimalSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable RowScope.() -> Unit)? = null,
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            MaterialTheme.colorScheme.outline,
        ),
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.buttonMinHeight),
    ) {
        ButtonContent(text, leadingIcon)
    }
}

@Composable
fun OptimalTertiaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable RowScope.() -> Unit)? = null,
) {
    TextButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.iconButtonMinSize),
    ) {
        ButtonContent(text, leadingIcon)
    }
}

@Composable
fun OptimalDestructiveButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable RowScope.() -> Unit)? = null,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.buttonMinHeight),
        shape = MaterialTheme.shapes.large,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError,
        ),
    ) {
        ButtonContent(text, leadingIcon)
    }
}

/** Primary high-emphasis action used by reference-dashboard hero areas. */
@Composable
fun OptimalHeroButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable RowScope.() -> Unit)? = null,
) {
    val colors =
        if (enabled) {
            listOf(OptimalSemanticColors.brandGradientStart, OptimalSemanticColors.brandGradientEnd)
        } else {
            listOf(OptimalSemanticColors.surfaceMuted, OptimalSemanticColors.surfaceMuted)
        }
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier =
            modifier
                .defaultMinSize(minHeight = OptimalComponentDefaults.buttonMinHeight)
                .background(
                    brush = Brush.linearGradient(colors),
                    shape = MaterialTheme.shapes.large,
                ),
        shape = MaterialTheme.shapes.large,
        colors =
            ButtonDefaults.buttonColors(
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                disabledContainerColor = Color.Transparent,
                disabledContentColor = OptimalSemanticColors.contentMuted,
            ),
    ) {
        ButtonContent(text, leadingIcon)
    }
}

@Composable
fun OptimalIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = Color.Transparent,
    contentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    IconButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.defaultMinSize(
            minWidth = OptimalComponentDefaults.iconButtonMinSize,
            minHeight = OptimalComponentDefaults.iconButtonMinSize,
        ),
        colors = IconButtonDefaults.iconButtonColors(
            containerColor = containerColor,
            contentColor = contentColor,
        ),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            modifier = Modifier.size(OptimalIconSize.standard),
        )
    }
}

@Composable
private fun RowScope.ButtonContent(
    text: String,
    leadingIcon: (@Composable RowScope.() -> Unit)?,
) {
    if (leadingIcon != null) {
        leadingIcon()
        Spacer(Modifier.width(OptimalSpacing.small))
    }
    Text(text, style = MaterialTheme.typography.labelLarge)
}
