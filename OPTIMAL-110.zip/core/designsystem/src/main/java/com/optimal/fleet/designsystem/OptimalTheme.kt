package com.optimal.fleet.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun OptimalTheme(
    @Suppress("UNUSED_PARAMETER") darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    // The approved visual source currently defines one light identity.
    MaterialTheme(
        colorScheme = OptimalLightColorScheme,
        typography = OptimalTypography,
        shapes = OptimalShapes,
        content = content,
    )
}
