package com.optimal.fleet.designsystem

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val TajawalFontFamily =
    FontFamily(
        Font(R.font.tajawal_light, FontWeight.Light),
        Font(R.font.tajawal_regular, FontWeight.Normal),
        Font(R.font.tajawal_medium, FontWeight.Medium),
        Font(R.font.tajawal_bold, FontWeight.Bold),
        Font(R.font.tajawal_extra_bold, FontWeight.ExtraBold),
    )

val OptimalTypography =
    Typography(
        displaySmall =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 34.sp,
                lineHeight = 42.sp,
            ),
        headlineMedium =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 28.sp,
                lineHeight = 36.sp,
            ),
        headlineSmall =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 25.sp,
                lineHeight = 33.sp,
            ),
        titleLarge =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                lineHeight = 28.sp,
            ),
        titleMedium =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                lineHeight = 24.sp,
            ),
        titleSmall =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
                lineHeight = 21.sp,
            ),
        bodyLarge =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 16.sp,
                lineHeight = 25.sp,
            ),
        bodyMedium =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 14.sp,
                lineHeight = 22.sp,
            ),
        bodySmall =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 12.sp,
                lineHeight = 18.sp,
            ),
        labelLarge =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                lineHeight = 20.sp,
            ),
        labelMedium =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            ),
        labelSmall =
            TextStyle(
                fontFamily = TajawalFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                lineHeight = 16.sp,
            ),
    )

/** Canonical product typography roles locked by SESSION-97. */
object OptimalTypographyRoles {
    val appBarBrand = OptimalTypography.labelSmall
    val appBarTitle = OptimalTypography.headlineMedium
    val pageTitle = OptimalTypography.headlineSmall
    val heroTitle =
        TextStyle(
            fontFamily = TajawalFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            lineHeight = 30.sp,
        )
    val sectionTitle = OptimalTypography.titleLarge
    val body = OptimalTypography.bodyMedium
    val metadata = OptimalTypography.bodySmall
    val amount =
        TextStyle(
            fontFamily = TajawalFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 26.sp,
            lineHeight = 32.sp,
        )
    val action = OptimalTypography.labelLarge
    val label = OptimalTypography.labelMedium
}
