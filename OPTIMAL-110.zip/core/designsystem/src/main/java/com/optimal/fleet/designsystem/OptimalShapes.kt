package com.optimal.fleet.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

object OptimalRadius {
    val extraSmall = 8.dp
    val small = 12.dp
    val medium = 16.dp
    val large = 22.dp
    val extraLarge = 28.dp
}

val OptimalShapes =
    Shapes(
        extraSmall = RoundedCornerShape(OptimalRadius.extraSmall),
        small = RoundedCornerShape(OptimalRadius.small),
        medium = RoundedCornerShape(OptimalRadius.medium),
        large = RoundedCornerShape(OptimalRadius.large),
        extraLarge = RoundedCornerShape(OptimalRadius.extraLarge),
    )
