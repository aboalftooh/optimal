package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.SyncProblem
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import com.optimal.fleet.designsystem.OptimalContentInsets
import com.optimal.fleet.designsystem.OptimalElevation
import com.optimal.fleet.designsystem.OptimalIconSize
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTouchTarget
import com.optimal.fleet.designsystem.OptimalTypographyRoles

@Immutable
data class OptimalNavigationItem(
    val key: String,
    val label: String,
    val icon: ImageVector,
    val contentDescription: String,
)

enum class OptimalSyncVisualState {
    SavedLocally,
    WaitingForNetwork,
    Syncing,
    TemporaryFailure,
}

@Composable
fun OptimalAppTopBar(
    title: String,
    modifier: Modifier = Modifier,
    showBrand: Boolean = true,
    navigationIcon: ImageVector? = null,
    navigationContentDescription: String? = null,
    onNavigationClick: (() -> Unit)? = null,
    navigationModifier: Modifier = Modifier,
    actionIcon: ImageVector? = null,
    actionContentDescription: String? = null,
    onActionClick: (() -> Unit)? = null,
    actionModifier: Modifier = Modifier,
    status: (@Composable () -> Unit)? = null,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = OptimalElevation.flat,
    ) {
        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(
                        horizontal = OptimalContentInsets.horizontal,
                        vertical = OptimalContentInsets.vertical,
                    ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TopBarActionSlot(
                    icon = navigationIcon,
                    contentDescription = navigationContentDescription,
                    onClick = onNavigationClick,
                    modifier = navigationModifier,
                )

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(OptimalSpacing.xxSmall),
                ) {
                    if (showBrand) {
                        Text(
                            text = "OPTIMAL",
                            style = OptimalTypographyRoles.appBarBrand,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center,
                        )
                    }
                    Text(
                        text = title,
                        style = OptimalTypographyRoles.appBarTitle,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                    )
                }

                TopBarActionSlot(
                    icon = actionIcon,
                    contentDescription = actionContentDescription,
                    onClick = onActionClick,
                    modifier = actionModifier,
                )
            }
            status?.invoke()
        }
    }
}

@Composable
private fun TopBarActionSlot(
    icon: ImageVector?,
    contentDescription: String?,
    onClick: (() -> Unit)?,
    modifier: Modifier,
) {
    if (icon == null || contentDescription == null || onClick == null) {
        Spacer(Modifier.size(OptimalTouchTarget.minimum))
        return
    }

    OptimalIconButton(
        icon = icon,
        contentDescription = contentDescription,
        onClick = onClick,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.primary,
    )
}

@Composable
fun OptimalBottomNavigation(
    items: List<OptimalNavigationItem>,
    selectedKey: String?,
    onSelected: (OptimalNavigationItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        HorizontalDivider(
            thickness = OptimalComponentDefaults.dividerThickness,
            color = MaterialTheme.colorScheme.outlineVariant,
        )
        NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = OptimalElevation.flat,
        ) {
            items.forEach { item ->
                NavigationBarItem(
                    selected = item.key == selectedKey,
                    onClick = { onSelected(item) },
                    icon = {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.contentDescription,
                            modifier = Modifier.size(OptimalIconSize.standard),
                        )
                    },
                    label = {
                        Text(
                            text = item.label,
                            style = OptimalTypographyRoles.label,
                        )
                    },
                    alwaysShowLabel = true,
                    modifier = Modifier.testTag("nav-${item.key}"),
                    colors =
                        NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                )
            }
        }
    }
}

@Composable
fun OptimalSyncStatus(
    state: OptimalSyncVisualState,
    modifier: Modifier = Modifier,
) {
    val visual =
        when (state) {
            OptimalSyncVisualState.SavedLocally ->
                SyncVisual(
                    label = "تم الحفظ على الهاتف",
                    icon = Icons.Outlined.CloudDone,
                    tone = OptimalStatusTone.Success,
                )
            OptimalSyncVisualState.WaitingForNetwork ->
                SyncVisual(
                    label = "بانتظار الشبكة",
                    icon = Icons.Outlined.WifiOff,
                    tone = OptimalStatusTone.Warning,
                )
            OptimalSyncVisualState.Syncing ->
                SyncVisual(
                    label = "جاري المزامنة",
                    icon = Icons.Outlined.CloudSync,
                    tone = OptimalStatusTone.Info,
                )
            OptimalSyncVisualState.TemporaryFailure ->
                SyncVisual(
                    label = "تعذر مؤقتًا؛ سنعيد المحاولة",
                    icon = Icons.Outlined.SyncProblem,
                    tone = OptimalStatusTone.Danger,
                )
        }

    OptimalStatusBadge(
        text = visual.label,
        tone = visual.tone,
        modifier = modifier.semantics { stateDescription = visual.label },
        icon = visual.icon,
    )
}

private data class SyncVisual(
    val label: String,
    val icon: ImageVector,
    val tone: OptimalStatusTone,
)
