package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.optimal.fleet.designsystem.OptimalIconSize
import com.optimal.fleet.designsystem.OptimalSemanticColors
import com.optimal.fleet.designsystem.OptimalSpacing

@Composable
fun OptimalSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = "search-field-v2",
    onClear: () -> Unit = { onValueChange("") },
) {
    OptimalTextField(
        value = value,
        onValueChange = onValueChange,
        label = label,
        modifier = modifier,
        leadingIcon = {
            Icon(
                imageVector = Icons.Outlined.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
        trailingIcon = if (value.isNotBlank()) {
            {
                OptimalIconButton(
                    icon = Icons.Outlined.Clear,
                    contentDescription = "مسح البحث",
                    onClick = onClear,
                    modifier = Modifier.testTag("$testTag-clear"),
                )
            }
        } else {
            null
        },
        testTag = testTag,
    )
}

@Composable
fun OptimalChip(
    label: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
) {
    if (onClick != null) {
        AssistChip(
            onClick = onClick,
            label = { Text(label) },
            leadingIcon = icon?.let { image ->
                {
                    Icon(
                        imageVector = image,
                        contentDescription = null,
                        modifier = Modifier.size(OptimalIconSize.small),
                    )
                }
            },
            shape = MaterialTheme.shapes.large,
            border = AssistChipDefaults.assistChipBorder(
                enabled = true,
                borderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
            modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.chipMinHeight),
        )
    } else {
        Surface(
            modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.passiveChipMinHeight),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            border = BorderStroke(
                OptimalComponentDefaults.dividerThickness,
                MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = OptimalSpacing.medium, vertical = OptimalSpacing.small),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
            ) {
                Text(label, style = MaterialTheme.typography.labelMedium)
                icon?.let {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        modifier = Modifier.size(OptimalIconSize.small),
                    )
                }
            }
        }
    }
}

@Composable
fun OptimalFilterChip(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        shape = MaterialTheme.shapes.large,
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = OptimalSemanticColors.brandContainer,
            selectedLabelColor = MaterialTheme.colorScheme.primary,
            containerColor = MaterialTheme.colorScheme.surface,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = MaterialTheme.colorScheme.outlineVariant,
            selectedBorderColor = MaterialTheme.colorScheme.primary,
        ),
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.chipMinHeight),
    )
}
