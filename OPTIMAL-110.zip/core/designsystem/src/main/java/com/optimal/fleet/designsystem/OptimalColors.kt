package com.optimal.fleet.designsystem

import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * Canonical semantic light palette for the OPTIMAL v97-v110 migration program.
 *
 * Feature presentation must consume semantic/theme roles instead of declaring local colors.
 * Raw hexadecimal values are intentionally centralized in this file.
 */
object OptimalSemanticColors {
    val brandPrimary = Color(0xFF235AEA)
    val brandAccent = Color(0xFF356FF2)
    val brandStrong = Color(0xFF173EBA)
    val brandContainer = Color(0xFFECEEFF)
    val brandSubtle = Color(0xFFF6F8FF)
    val brandGradientStart = Color(0xFF2F6CF4)
    val brandGradientEnd = Color(0xFF1F49D9)

    val canvas = Color(0xFFFBFBFF)
    val surface = Color(0xFFFFFFFF)
    val surfaceMuted = Color(0xFFF6F7FB)
    val heroStart = Color(0xFFFAFCFF)
    val heroEnd = Color(0xFFF0F5FF)

    val contentPrimary = Color(0xFF101D4A)
    val contentSecondary = Color(0xFF737990)
    val contentMuted = Color(0xFF9AA0B2)

    val borderSubtle = Color(0xFFE5E8F1)
    val borderStrong = Color(0xFFD6DCEB)

    val success = Color(0xFF14965A)
    val successContainer = Color(0xFFEAF8F0)
    val warning = Color(0xFFA66A00)
    val warningContainer = Color(0xFFFFF4DE)
    val danger = Color(0xFFD94A66)
    val dangerContainer = Color(0xFFFFF0F3)
    val shadow = Color(0xFF1B2E6B)

    val info = brandPrimary
    val infoContainer = brandContainer
}

internal val OptimalLightColorScheme =
    lightColorScheme(
        primary = OptimalSemanticColors.brandPrimary,
        onPrimary = Color.White,
        primaryContainer = OptimalSemanticColors.brandContainer,
        onPrimaryContainer = OptimalSemanticColors.contentPrimary,
        secondary = OptimalSemanticColors.brandAccent,
        onSecondary = Color.White,
        secondaryContainer = OptimalSemanticColors.brandSubtle,
        onSecondaryContainer = OptimalSemanticColors.contentPrimary,
        tertiary = OptimalSemanticColors.brandStrong,
        onTertiary = Color.White,
        background = OptimalSemanticColors.canvas,
        onBackground = OptimalSemanticColors.contentPrimary,
        surface = OptimalSemanticColors.surface,
        onSurface = OptimalSemanticColors.contentPrimary,
        surfaceVariant = OptimalSemanticColors.surfaceMuted,
        onSurfaceVariant = OptimalSemanticColors.contentSecondary,
        outline = OptimalSemanticColors.borderStrong,
        outlineVariant = OptimalSemanticColors.borderSubtle,
        surfaceTint = OptimalSemanticColors.brandPrimary,
        error = OptimalSemanticColors.danger,
        onError = Color.White,
        errorContainer = OptimalSemanticColors.dangerContainer,
        onErrorContainer = OptimalSemanticColors.contentPrimary,
    )
