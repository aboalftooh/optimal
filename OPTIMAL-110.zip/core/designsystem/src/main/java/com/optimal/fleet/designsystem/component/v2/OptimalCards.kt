package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.optimal.fleet.designsystem.OptimalElevation
import com.optimal.fleet.designsystem.OptimalIconSize
import com.optimal.fleet.designsystem.OptimalSemanticColors
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTypographyRoles


@Composable
fun OptimalSurfaceCard(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(OptimalSpacing.large),
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = OptimalElevation.flat,
        shadowElevation = OptimalElevation.raised,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
            content = content,
        )
    }
}


@Composable
fun OptimalHeroSurface(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(OptimalSpacing.large),
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        color = Color.Transparent,
        tonalElevation = OptimalElevation.flat,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            OptimalSemanticColors.borderSubtle,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(
                            OptimalSemanticColors.heroStart,
                            OptimalSemanticColors.heroEnd,
                        ),
                    ),
                )
                .padding(contentPadding),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
            content = content,
        )
    }
}

@Composable
fun OptimalMetricCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
    icon: ImageVector? = null,
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = OptimalElevation.flat,
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(
            modifier = Modifier.padding(OptimalSpacing.large),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = label,
                    style = OptimalTypographyRoles.label,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                icon?.let {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        modifier = Modifier.size(OptimalIconSize.small),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            Text(
                text = value,
                style = OptimalTypographyRoles.amount,
                color = MaterialTheme.colorScheme.onSurface,
            )
            supportingText?.let {
                Text(
                    text = it,
                    style = OptimalTypographyRoles.metadata,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun OptimalActionCard(
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    description: String? = null,
    icon: ImageVector? = null,
    actionLabel: String? = null,
) {
    Card(
        onClick = onClick,
        modifier = modifier.defaultMinSize(minHeight = OptimalComponentDefaults.listRowMinHeight),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = OptimalSemanticColors.brandSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = OptimalElevation.flat),
        border = BorderStroke(
            OptimalComponentDefaults.dividerThickness,
            OptimalSemanticColors.borderSubtle,
        ),
    ) {
        val contentModifier = Modifier
            .fillMaxWidth()
            .padding(OptimalSpacing.large)
        if (actionLabel != null) {
            OptimalAdaptiveLayout(
                modifier = contentModifier,
                compactContent = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
                    ) {
                        ActionCardMain(
                            title = title,
                            description = description,
                            icon = icon,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text(
                            text = actionLabel,
                            style = OptimalTypographyRoles.label,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.align(Alignment.End),
                        )
                    }
                },
                regularContent = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
                    ) {
                        ActionCardMain(
                            title = title,
                            description = description,
                            icon = icon,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            text = actionLabel,
                            style = OptimalTypographyRoles.label,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                },
            )
        } else {
            ActionCardMain(
                title = title,
                description = description,
                icon = icon,
                modifier = contentModifier,
            )
        }
    }
}

@Composable
private fun ActionCardMain(
    title: String,
    description: String?,
    icon: ImageVector?,
    modifier: Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
    ) {
        icon?.let {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = OptimalSemanticColors.brandContainer,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    modifier = Modifier.padding(OptimalSpacing.medium).size(OptimalIconSize.standard),
                )
            }
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.xSmall),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            description?.let {
                Text(
                    text = it,
                    style = OptimalTypographyRoles.body,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun OptimalFormSection(
    title: String,
    modifier: Modifier = Modifier,
    description: String? = null,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(OptimalSpacing.xSmall)) {
            Text(
                text = title,
                style = OptimalTypographyRoles.sectionTitle,
                color = MaterialTheme.colorScheme.onSurface,
            )
            description?.let {
                Text(
                    text = it,
                    style = OptimalTypographyRoles.metadata,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        content()
    }
}
