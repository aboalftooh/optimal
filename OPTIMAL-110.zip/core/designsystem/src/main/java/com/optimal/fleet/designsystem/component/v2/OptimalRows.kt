package com.optimal.fleet.designsystem.component.v2

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import com.optimal.fleet.designsystem.OptimalResponsiveLayout
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTypographyRoles

@Composable
fun OptimalAdaptiveLayout(
    modifier: Modifier = Modifier,
    compactContent: @Composable () -> Unit,
    regularContent: @Composable () -> Unit,
) {
    BoxWithConstraints(modifier = modifier) {
        val useCompactLayout =
            maxWidth <= OptimalResponsiveLayout.compactStackMaxWidth ||
                LocalDensity.current.fontScale >= OptimalResponsiveLayout.accessibilityFontScale
        if (useCompactLayout) compactContent() else regularContent()
    }
}

@Composable
fun OptimalResponsivePair(
    modifier: Modifier = Modifier,
    first: @Composable (Modifier) -> Unit,
    second: @Composable (Modifier) -> Unit,
) {
    OptimalAdaptiveLayout(
        modifier = modifier.fillMaxWidth(),
        compactContent = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
            ) {
                first(Modifier.fillMaxWidth())
                second(Modifier.fillMaxWidth())
            }
        },
        regularContent = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
            ) {
                first(Modifier.weight(1f))
                second(Modifier.weight(1f))
            }
        },
    )
}

@Composable
fun OptimalSectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    actionModifier: Modifier = Modifier,
) {
    val hasAction = actionLabel != null && onAction != null
    if (!hasAction) {
        SectionHeaderText(
            title = title,
            supportingText = supportingText,
            modifier = modifier.fillMaxWidth(),
        )
        return
    }

    OptimalAdaptiveLayout(
        modifier = modifier.fillMaxWidth(),
        compactContent = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
            ) {
                SectionHeaderText(
                    title = title,
                    supportingText = supportingText,
                    modifier = Modifier.fillMaxWidth(),
                )
                OptimalTertiaryButton(
                    text = actionLabel!!,
                    onClick = onAction!!,
                    modifier = actionModifier.align(Alignment.End),
                )
            }
        },
        regularContent = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                SectionHeaderText(
                    title = title,
                    supportingText = supportingText,
                    modifier = Modifier.weight(1f),
                )
                OptimalTertiaryButton(
                    text = actionLabel!!,
                    onClick = onAction!!,
                    modifier = actionModifier,
                )
            }
        },
    )
}

@Composable
private fun SectionHeaderText(
    title: String,
    supportingText: String?,
    modifier: Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(OptimalSpacing.xSmall),
    ) {
        Text(
            text = title,
            style = OptimalTypographyRoles.sectionTitle,
            color = MaterialTheme.colorScheme.onSurface,
        )
        supportingText?.let {
            Text(
                text = it,
                style = OptimalTypographyRoles.metadata,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun OptimalListRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    metadata: String? = null,
    leadingContent: (@Composable () -> Unit)? = null,
    trailingContent: (@Composable RowScope.() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    showDivider: Boolean = true,
    onClickLabel: String? = null,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        val rowModifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = OptimalComponentDefaults.listRowMinHeight)
            .then(
                if (onClick == null) Modifier
                else Modifier.clickable(
                    onClickLabel = onClickLabel,
                    role = Role.Button,
                    onClick = onClick,
                )
            )
            .padding(vertical = OptimalSpacing.medium)

        OptimalAdaptiveLayout(
            modifier = rowModifier,
            compactContent = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(OptimalSpacing.small),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
                    ) {
                        leadingContent?.invoke()
                        ListRowText(
                            title = title,
                            subtitle = subtitle,
                            metadata = metadata,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    trailingContent?.let { content ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            content.invoke(this)
                        }
                    }
                }
            },
            regularContent = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
                ) {
                    leadingContent?.invoke()
                    ListRowText(
                        title = title,
                        subtitle = subtitle,
                        metadata = metadata,
                        modifier = Modifier.weight(1f),
                    )
                    trailingContent?.invoke(this)
                }
            },
        )
        if (showDivider) {
            HorizontalDivider(
                thickness = OptimalComponentDefaults.dividerThickness,
                color = MaterialTheme.colorScheme.outlineVariant,
            )
        }
    }
}

@Composable
private fun ListRowText(
    title: String,
    subtitle: String?,
    metadata: String?,
    modifier: Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(OptimalSpacing.xSmall),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        subtitle?.let {
            Text(
                text = it,
                style = OptimalTypographyRoles.body,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        metadata?.let {
            Text(
                text = it,
                style = OptimalTypographyRoles.metadata,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
