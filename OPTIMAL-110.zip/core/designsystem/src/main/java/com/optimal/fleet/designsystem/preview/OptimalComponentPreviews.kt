package com.optimal.fleet.designsystem.preview

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.optimal.fleet.designsystem.OptimalSpacing
import com.optimal.fleet.designsystem.OptimalTheme
import com.optimal.fleet.designsystem.component.v2.OptimalActionCard
import com.optimal.fleet.designsystem.component.v2.OptimalBottomActionBar
import com.optimal.fleet.designsystem.component.v2.OptimalDestructiveButton
import com.optimal.fleet.designsystem.component.v2.OptimalFormSection
import com.optimal.fleet.designsystem.component.v2.OptimalListRow
import com.optimal.fleet.designsystem.component.v2.OptimalMetricCard
import com.optimal.fleet.designsystem.component.v2.OptimalSurfaceCard
import com.optimal.fleet.designsystem.component.v2.OptimalChip
import com.optimal.fleet.designsystem.component.v2.OptimalConfirmationDialog
import com.optimal.fleet.designsystem.component.v2.OptimalDialog
import com.optimal.fleet.designsystem.component.v2.OptimalEmptyState
import com.optimal.fleet.designsystem.component.v2.OptimalErrorState
import com.optimal.fleet.designsystem.component.v2.OptimalFilterChip
import com.optimal.fleet.designsystem.component.v2.OptimalIconButton
import com.optimal.fleet.designsystem.component.v2.OptimalLoadingState
import com.optimal.fleet.designsystem.component.v2.OptimalMoneyField
import com.optimal.fleet.designsystem.component.v2.OptimalSearchField
import com.optimal.fleet.designsystem.component.v2.OptimalSelectionField
import com.optimal.fleet.designsystem.component.v2.OptimalStatusBadge
import com.optimal.fleet.designsystem.component.v2.OptimalStatusTone
import com.optimal.fleet.designsystem.component.v2.OptimalTextField
import com.optimal.fleet.designsystem.component.v2.OptimalPrimaryButton
import com.optimal.fleet.designsystem.component.v2.OptimalHeroButton
import com.optimal.fleet.designsystem.component.v2.OptimalInlineStatus
import com.optimal.fleet.designsystem.component.v2.OptimalSecondaryButton
import com.optimal.fleet.designsystem.component.v2.OptimalSectionHeader
import com.optimal.fleet.designsystem.component.v2.OptimalSegmentOption
import com.optimal.fleet.designsystem.component.v2.OptimalSegmentedControl
import com.optimal.fleet.designsystem.component.v2.OptimalTertiaryButton

@Preview(name = "Buttons v2", locale = "ar", showBackground = true)
@Composable
private fun ButtonsPreview() {
    OptimalTheme {
        Column(
            modifier = Modifier.padding(OptimalSpacing.large),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
        ) {
            OptimalPrimaryButton("حفظ", {})
            OptimalSecondaryButton("إجراء ثانوي", {})
            OptimalTertiaryButton("تخطي", {})
            OptimalDestructiveButton("حذف", {})
            OptimalHeroButton("إضافة عملية", {})
            Row(horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.small)) {
                OptimalIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "رجوع", {})
                OptimalIconButton(Icons.Outlined.MoreVert, "المزيد", {})
            }
        }
    }
}

@Preview(name = "Fields v2", locale = "ar", showBackground = true)
@Composable
private fun FieldsPreview() {
    OptimalTheme {
        Column(
            modifier = Modifier.padding(OptimalSpacing.large),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
        ) {
            OptimalSearchField("", {}, "ابحث")
            OptimalTextField("تويوتا هايلوكس", {}, "اسم السيارة")
            OptimalMoneyField("125000", {}, "التكلفة", "ج.س")
            OptimalSelectionField("2024", "السنة", {})
        }
    }
}

@Preview(name = "Status and filters v2", locale = "ar", showBackground = true)
@Composable
private fun StatusAndFiltersPreview() {
    OptimalTheme {
        Column(
            modifier = Modifier.padding(OptimalSpacing.large),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.medium),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.small)) {
                OptimalStatusBadge("مكتمل", OptimalStatusTone.Success, icon = Icons.Outlined.CheckCircle)
                OptimalStatusBadge("معلق", OptimalStatusTone.Warning)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(OptimalSpacing.small)) {
                OptimalChip("نشط")
                OptimalFilterChip(true, "الكل", {})
                OptimalFilterChip(false, "مفتوح", {})
            }
            OptimalSegmentedControl(
                options = listOf(OptimalSegmentOption("all", "الكل"), OptimalSegmentOption("open", "المفتوحة")),
                selected = "all",
                onSelected = {},
            )
        }
    }
}

@Preview(name = "Rows and sections v2", locale = "ar", showBackground = true)
@Composable
private fun RowsPreview() {
    OptimalTheme {
        Column(modifier = Modifier.padding(OptimalSpacing.large)) {
            OptimalSectionHeader("السيارات", actionLabel = "عرض الكل", onAction = {})
            OptimalListRow(
                title = "هايلوكس 2022",
                subtitle = "لوحة: 12345",
                metadata = "آخر صيانة قبل 12 يومًا",
                leadingContent = { androidx.compose.material3.Icon(Icons.Outlined.DirectionsCar, null) },
                onClick = {},
            )
            OptimalListRow(
                title = "لاندكروزر 2020",
                subtitle = "جاهزة للصيانة",
                showDivider = false,
            )
        }
    }
}

@Preview(name = "Cards and forms v2", locale = "ar", showBackground = true)
@Composable
private fun CardsAndFormsPreview() {
    OptimalTheme {
        Column(
            modifier = Modifier.padding(OptimalSpacing.large),
            verticalArrangement = Arrangement.spacedBy(OptimalSpacing.large),
        ) {
            OptimalMetricCard(
                label = "تكلفة هذا الشهر",
                value = "125,000 ج.س",
                supportingText = "+8% عن الشهر السابق",
                icon = Icons.Outlined.Build,
            )
            OptimalActionCard(
                title = "إضافة عملية صيانة",
                description = "سجل عملية جديدة للسيارة",
                icon = Icons.Outlined.Add,
                actionLabel = "ابدأ",
                onClick = {},
            )
            OptimalSurfaceCard {
                androidx.compose.material3.Text("سطح موحّد")
            }
            OptimalInlineStatus(
                title = "تم الحفظ",
                message = "سيتم رفع التغييرات عند توفر الشبكة.",
                tone = OptimalStatusTone.Success,
            )
            OptimalFormSection("بيانات السيارة", description = "أدخل المعلومات الأساسية") {
                OptimalTextField("", {}, "رقم اللوحة")
            }
        }
    }
}

@Preview(name = "Empty state v2", locale = "ar", showBackground = true)
@Composable
private fun EmptyStatePreview() {
    OptimalTheme {
        OptimalEmptyState(
            title = "لا توجد سيارات",
            message = "أضف أول سيارة لتظهر هنا.",
            actionLabel = "إضافة سيارة",
            onAction = {},
        )
    }
}

@Preview(name = "Loading state v2", locale = "ar", showBackground = true)
@Composable
private fun LoadingStatePreview() {
    OptimalTheme { OptimalLoadingState() }
}

@Preview(name = "Error state v2", locale = "ar", showBackground = true)
@Composable
private fun ErrorStatePreview() {
    OptimalTheme { OptimalErrorState("تعذر الاتصال بالخدمة.", onRetry = {}) }
}

@Preview(name = "Bottom action bar v2", locale = "ar", showBackground = true)
@Composable
private fun OptimalBottomActionBarPreview() {
    OptimalTheme {
        OptimalBottomActionBar(
            primaryLabel = "حفظ",
            onPrimary = {},
            secondaryLabel = "إلغاء",
            onSecondary = {},
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Preview(name = "Dialog v2", locale = "ar", showBackground = true)
@Composable
private fun DialogPreview() {
    OptimalTheme {
        OptimalConfirmationDialog(
            title = "حذف العنصر؟",
            message = "لا يمكن التراجع عن هذا الإجراء.",
            confirmLabel = "حذف",
            onConfirm = {},
            onDismissRequest = {},
            destructive = true,
            icon = Icons.Outlined.Delete,
        )
    }
}

@Preview(name = "Custom dialog v2", locale = "ar", showBackground = true)
@Composable
private fun CustomDialogPreview() {
    OptimalTheme {
        OptimalDialog(
            title = "تأكيد الإجراء",
            onDismissRequest = {},
            confirmLabel = "متابعة",
            onConfirm = {},
        ) {
            androidx.compose.material3.Text("راجع البيانات قبل المتابعة.")
        }
    }
}

@Preview(name = "App top bar v2", locale = "ar", showBackground = true)
@Composable
private fun AppTopBarPreview() {
    OptimalTheme {
        com.optimal.fleet.designsystem.component.v2.OptimalAppTopBar(
            title = "الرئيسية",
            navigationIcon = androidx.compose.material.icons.Icons.Outlined.AccountCircle,
            navigationContentDescription = "فتح الحساب",
            onNavigationClick = {},
            actionIcon = androidx.compose.material.icons.Icons.Outlined.Notifications,
            actionContentDescription = "فتح الإشعارات",
            onActionClick = {},
            status = {
                com.optimal.fleet.designsystem.component.v2.OptimalSyncStatus(
                    com.optimal.fleet.designsystem.component.v2.OptimalSyncVisualState.WaitingForNetwork,
                )
            },
        )
    }
}

@Preview(name = "Bottom navigation v2", locale = "ar", showBackground = true)
@Composable
private fun BottomNavigationPreview() {
    OptimalTheme {
        com.optimal.fleet.designsystem.component.v2.OptimalBottomNavigation(
            items =
                listOf(
                    com.optimal.fleet.designsystem.component.v2.OptimalNavigationItem(
                        key = "home",
                        label = "الرئيسية",
                        icon = androidx.compose.material.icons.Icons.Outlined.Home,
                        contentDescription = "فتح الرئيسية",
                    ),
                    com.optimal.fleet.designsystem.component.v2.OptimalNavigationItem(
                        key = "vehicles",
                        label = "السيارات",
                        icon = androidx.compose.material.icons.Icons.Outlined.DirectionsCar,
                        contentDescription = "فتح السيارات",
                    ),
                ),
            selectedKey = "home",
            onSelected = {},
        )
    }
}
