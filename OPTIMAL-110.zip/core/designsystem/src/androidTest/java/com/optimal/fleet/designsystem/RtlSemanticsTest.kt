package com.optimal.fleet.designsystem

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RtlSemanticsTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun rowPlacesFirstItemOnTheRightInRtl() {
        composeRule.setContent {
            OptimalTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Row(modifier = Modifier.width(240.dp)) {
                        Text("الأول", modifier = Modifier.testTag("first"))
                        Text("الثاني", modifier = Modifier.testTag("second"))
                    }
                }
            }
        }

        val firstX =
            composeRule
                .onNodeWithTag("first")
                .fetchSemanticsNode()
                .positionInRoot.x
        val secondX =
            composeRule
                .onNodeWithTag("second")
                .fetchSemanticsNode()
                .positionInRoot.x
        assertTrue("The first RTL item must be positioned to the right", firstX > secondX)
    }
}
