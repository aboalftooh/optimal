package com.optimal.fleet.designsystem

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertHeightIsAtLeast
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.optimal.fleet.designsystem.component.v2.OptimalPrimaryButton
import com.optimal.fleet.designsystem.component.v2.OptimalResponsivePair
import com.optimal.fleet.designsystem.component.v2.OptimalSecondaryButton
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ResponsiveRtlAccessibilityV109Test {
    @get:Rule
    val composeRule = createComposeRule()

    // SESSION-109 certification matrix. Large width is exercised where the test device permits it.
    private val requiredWidthsDp = listOf(320, 360, 412, 600, 840)
    private val requiredFontScales = listOf(1.0f, 1.3f, 2.0f)

    @Test
    fun requiredCertificationMatrixIsFrozenInTestSource() {
        assertTrue(requiredWidthsDp == listOf(320, 360, 412, 600, 840))
        assertTrue(requiredFontScales == listOf(1.0f, 1.3f, 2.0f))
    }

    @Test
    fun compact320ContentWidthStacksActionsAndKeeps48DpTargets() {
        composeRule.setContent {
            OptimalTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    // 320dp viewport minus the canonical 18dp start/end content insets.
                    Box(modifier = Modifier.width(284.dp)) {
                        TestPair()
                    }
                }
            }
        }

        val first = composeRule.onNodeWithTag("responsive-first").assertIsDisplayed()
        val second = composeRule.onNodeWithTag("responsive-second").assertIsDisplayed()
        first.assertHeightIsAtLeast(OptimalTouchTarget.minimum)
        second.assertHeightIsAtLeast(OptimalTouchTarget.minimum)
        assertTrue(
            "Compact actions must stack instead of clipping horizontally",
            first.fetchSemanticsNode().boundsInRoot.top < second.fetchSemanticsNode().boundsInRoot.top,
        )
    }

    @Test
    fun fontScale2StacksActionsInRtlEvenWhenWidthIsRegular() {
        composeRule.setContent {
            val baseDensity = LocalDensity.current
            OptimalTheme {
                CompositionLocalProvider(
                    LocalLayoutDirection provides LayoutDirection.Rtl,
                    LocalDensity provides Density(baseDensity.density, 2.0f),
                ) {
                    Box(modifier = Modifier.width(412.dp)) {
                        TestPair()
                    }
                }
            }
        }

        val first = composeRule.onNodeWithTag("responsive-first").assertIsDisplayed()
        val second = composeRule.onNodeWithTag("responsive-second").assertIsDisplayed()
        assertTrue(
            "fontScale 2.0 must use the accessible stacked layout",
            first.fetchSemanticsNode().boundsInRoot.top < second.fetchSemanticsNode().boundsInRoot.top,
        )
    }

    @Test
    fun regularPairPreservesLogicalRtlOrder() {
        composeRule.setContent {
            OptimalTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Box(modifier = Modifier.width(360.dp)) {
                        TestPair()
                    }
                }
            }
        }

        val first = composeRule.onNodeWithTag("responsive-first").fetchSemanticsNode().boundsInRoot
        val second = composeRule.onNodeWithTag("responsive-second").fetchSemanticsNode().boundsInRoot
        assertTrue("First logical action must stay on the right in RTL", first.left > second.left)
    }

    @androidx.compose.runtime.Composable
    private fun TestPair() {
        OptimalResponsivePair(
            first = { itemModifier ->
                OptimalPrimaryButton(
                    text = "الإجراء الأول",
                    onClick = {},
                    modifier = itemModifier.testTag("responsive-first"),
                )
            },
            second = { itemModifier ->
                OptimalSecondaryButton(
                    text = "الإجراء الثاني",
                    onClick = {},
                    modifier = itemModifier.testTag("responsive-second"),
                )
            },
        )
    }
}
