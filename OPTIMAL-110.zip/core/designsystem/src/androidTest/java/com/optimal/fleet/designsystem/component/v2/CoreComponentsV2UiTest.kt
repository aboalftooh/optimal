package com.optimal.fleet.designsystem.component.v2

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.optimal.fleet.designsystem.OptimalTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class CoreComponentsV2UiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun primaryButtonExposesActionAndHandlesClick() {
        var clicked = false
        composeRule.setContent {
            OptimalTheme {
                OptimalPrimaryButton(text = "حفظ", onClick = { clicked = true })
            }
        }

        composeRule.onNodeWithText("حفظ").performClick()
        assertTrue(clicked)
    }

    @Test
    fun searchFieldExposesClearActionWhenValueExists() {
        composeRule.setContent {
            OptimalTheme {
                OptimalSearchField(value = "تويوتا", onValueChange = {}, label = "ابحث")
            }
        }

        composeRule.onNodeWithContentDescription("مسح البحث").assertExists()
    }

    @Test
    fun semanticStatusBadgeCarriesVisibleText() {
        composeRule.setContent {
            OptimalTheme {
                OptimalStatusBadge(text = "مكتمل", tone = OptimalStatusTone.Success)
            }
        }

        composeRule.onNodeWithText("مكتمل").assertExists()
    }
}
