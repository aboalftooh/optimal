package com.optimal.fleet.designsystem

import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.optimal.fleet.designsystem.component.v2.OptimalPrimaryButton
import com.optimal.fleet.designsystem.component.v2.OptimalSyncStatus
import com.optimal.fleet.designsystem.component.v2.OptimalSyncVisualState
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DesignSystemComponentTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun primaryButtonIsVisibleAndInvokesAction() {
        var clicked = false
        composeRule.setContent {
            OptimalTheme {
                OptimalPrimaryButton(
                    text = "حفظ",
                    onClick = { clicked = true },
                    modifier = Modifier.testTag("primary-button"),
                )
            }
        }

        composeRule.onNodeWithTag("primary-button").assertIsDisplayed().performClick()
        composeRule.runOnIdle { assertTrue(clicked) }
    }

    @Test
    fun syncStatusExposesReadableText() {
        composeRule.setContent {
            OptimalTheme {
                Column {
                    OptimalSyncStatus(state = OptimalSyncVisualState.SavedLocally)
                    OptimalSyncStatus(state = OptimalSyncVisualState.WaitingForNetwork)
                }
            }
        }

        composeRule.onNodeWithText("تم الحفظ على الهاتف").assertIsDisplayed()
        composeRule.onNodeWithText("بانتظار الشبكة").assertIsDisplayed()
    }
}
