package com.optimal.fleet.designsystem.component.v2

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.optimal.fleet.designsystem.OptimalTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class AppShellV2UiTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun topBarExposesTitleAndBothAccessibleActions() {
        var accountClicked = false
        var notificationsClicked = false
        composeRule.setContent {
            OptimalTheme {
                OptimalAppTopBar(
                    title = "الرئيسية",
                    navigationIcon = Icons.Outlined.AccountCircle,
                    navigationContentDescription = "فتح الحساب",
                    onNavigationClick = { accountClicked = true },
                    actionIcon = Icons.Outlined.Notifications,
                    actionContentDescription = "فتح الإشعارات",
                    onActionClick = { notificationsClicked = true },
                )
            }
        }

        composeRule.onNodeWithText("الرئيسية").assertExists()
        composeRule.onNodeWithContentDescription("فتح الحساب").performClick()
        composeRule.onNodeWithContentDescription("فتح الإشعارات").performClick()
        composeRule.runOnIdle {
            assertTrue(accountClicked)
            assertTrue(notificationsClicked)
        }
    }

    @Test
    fun bottomNavigationReturnsSelectedItem() {
        var selected: String? = null
        composeRule.setContent {
            OptimalTheme {
                OptimalBottomNavigation(
                    items =
                        listOf(
                            OptimalNavigationItem("home", "الرئيسية", Icons.Outlined.Home, "فتح الرئيسية"),
                            OptimalNavigationItem("other", "أخرى", Icons.Outlined.AccountCircle, "فتح أخرى"),
                        ),
                    selectedKey = "home",
                    onSelected = { selected = it.key },
                )
            }
        }

        composeRule.onNodeWithTag("nav-other").performClick()
        composeRule.runOnIdle { assertEquals("other", selected) }
    }

    @Test
    fun syncStatusAlwaysIncludesReadableStateText() {
        composeRule.setContent {
            OptimalTheme {
                OptimalSyncStatus(
                    state = OptimalSyncVisualState.WaitingForNetwork,
                    modifier = Modifier.testTag("sync-status"),
                )
            }
        }

        composeRule.onNodeWithTag("sync-status").assertExists()
        composeRule.onNodeWithText("بانتظار الشبكة").assertExists()
    }
}
