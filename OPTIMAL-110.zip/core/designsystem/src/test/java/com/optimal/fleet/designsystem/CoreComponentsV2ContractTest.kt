package com.optimal.fleet.designsystem

import com.optimal.fleet.designsystem.component.v2.OptimalComponentDefaults
import com.optimal.fleet.designsystem.component.v2.OptimalStatusTone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreComponentsV2ContractTest {
    @Test
    fun interactiveComponentsRespectMinimumTouchTarget() {
        val minimum = OptimalTouchTarget.minimum
        assertTrue(OptimalComponentDefaults.buttonMinHeight >= minimum)
        assertTrue(OptimalComponentDefaults.iconButtonMinSize >= minimum)
        assertTrue(OptimalComponentDefaults.fieldMinHeight >= minimum)
        assertTrue(OptimalComponentDefaults.listRowMinHeight >= minimum)
        assertTrue(OptimalComponentDefaults.chipMinHeight >= minimum)
    }

    @Test
    fun statusTonesCoverRequiredSemanticStates() {
        assertEquals(
            setOf("Neutral", "Info", "Success", "Warning", "Danger"),
            OptimalStatusTone.entries.map { it.name }.toSet(),
        )
    }
}
