package com.optimal.fleet.designsystem

import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FoundationContractTest {
    @Test
    fun touchAndWidthTokensMatchVisualConstitution() {
        assertEquals(48.dp, OptimalTouchTarget.minimum)
        assertEquals(56.dp, OptimalTouchTarget.comfortable)
        assertEquals(600.dp, OptimalContentWidth.compactMax)
        assertEquals(840.dp, OptimalContentWidth.readableMax)
    }

    @Test
    fun spacingScaleAndInsetsMatchVisualConstitution() {
        val scale =
            listOf(
                OptimalSpacing.xxSmall,
                OptimalSpacing.xSmall,
                OptimalSpacing.small,
                OptimalSpacing.medium,
                OptimalSpacing.large,
                OptimalSpacing.xLarge,
                OptimalSpacing.xxLarge,
                OptimalSpacing.xxxLarge,
            )
        assertEquals(listOf(2.dp, 4.dp, 8.dp, 12.dp, 16.dp, 24.dp, 32.dp, 40.dp), scale)
        assertEquals(18.dp, OptimalContentInsets.horizontal)
        assertEquals(12.dp, OptimalContentInsets.vertical)
        assertEquals(20.dp, OptimalContentInsets.sectionGap)
        assertEquals(24.dp, OptimalContentInsets.bottomSafeContent)
    }

    @Test
    fun radiusElevationAndIconTokensMatchVisualConstitution() {
        assertEquals(listOf(8.dp, 12.dp, 16.dp, 22.dp, 28.dp), listOf(
            OptimalRadius.extraSmall,
            OptimalRadius.small,
            OptimalRadius.medium,
            OptimalRadius.large,
            OptimalRadius.extraLarge,
        ))
        assertEquals(listOf(0.dp, 2.dp, 5.dp, 8.dp), listOf(
            OptimalElevation.flat,
            OptimalElevation.raised,
            OptimalElevation.overlay,
            OptimalElevation.modal,
        ))
        assertEquals(listOf(18.dp, 24.dp, 32.dp, 40.dp), listOf(
            OptimalIconSize.small,
            OptimalIconSize.standard,
            OptimalIconSize.large,
            OptimalIconSize.hero,
        ))
    }

    @Test
    fun semanticColorsBackTheMaterialColorScheme() {
        assertEquals(OptimalSemanticColors.brandPrimary, OptimalLightColorScheme.primary)
        assertEquals(OptimalSemanticColors.brandContainer, OptimalLightColorScheme.primaryContainer)
        assertEquals(OptimalSemanticColors.contentPrimary, OptimalLightColorScheme.onSurface)
        assertEquals(OptimalSemanticColors.danger, OptimalLightColorScheme.error)
    }

    @Test
    fun typographyAndProductRolesAreExactAndTajawalBacked() {
        assertEquals(TajawalFontFamily, OptimalTypography.displaySmall.fontFamily)
        assertEquals(34.sp, OptimalTypography.displaySmall.fontSize)
        assertEquals(42.sp, OptimalTypography.displaySmall.lineHeight)
        assertEquals(28.sp, OptimalTypography.headlineMedium.fontSize)
        assertEquals(36.sp, OptimalTypography.headlineMedium.lineHeight)
        assertEquals(FontWeight.ExtraBold, OptimalTypography.headlineMedium.fontWeight)
        assertEquals(25.sp, OptimalTypography.headlineSmall.fontSize)
        assertEquals(33.sp, OptimalTypography.headlineSmall.lineHeight)
        assertEquals(20.sp, OptimalTypography.titleLarge.fontSize)
        assertEquals(28.sp, OptimalTypography.titleLarge.lineHeight)
        assertEquals(TajawalFontFamily, OptimalTypographyRoles.heroTitle.fontFamily)
        assertEquals(22.sp, OptimalTypographyRoles.heroTitle.fontSize)
        assertEquals(30.sp, OptimalTypographyRoles.heroTitle.lineHeight)
        assertEquals(TajawalFontFamily, OptimalTypographyRoles.amount.fontFamily)
        assertEquals(26.sp, OptimalTypographyRoles.amount.fontSize)
        assertEquals(32.sp, OptimalTypographyRoles.amount.lineHeight)
        assertEquals(OptimalTypography.labelLarge, OptimalTypographyRoles.action)
    }
}
