package com.optimal.fleet.core.database.sync

import androidx.room.Entity
import androidx.room.ForeignKey
import com.optimal.fleet.core.database.entity.CompanyEntity

@Entity(
    tableName = "sync_pull_cursors",
    primaryKeys = ["companyId", "scope"],
    foreignKeys = [
        ForeignKey(
            entity = CompanyEntity::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class SyncPullCursorEntity(
    val companyId: String,
    val scope: String,
    val lastAppliedRevision: Long,
    val updatedAtEpochMillis: Long,
)
