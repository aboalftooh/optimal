package com.optimal.fleet.core.database.maintenance

import androidx.room.withTransaction
import com.optimal.fleet.core.database.OptimalDatabase
import com.optimal.fleet.core.database.dao.MaintenanceAuditDao
import com.optimal.fleet.core.database.dao.MaintenanceFollowUpDao
import com.optimal.fleet.core.database.dao.MaintenanceReadDao
import com.optimal.fleet.core.database.dao.MaintenanceWriteDao
import com.optimal.fleet.core.database.entity.MaintenanceAuditEntity
import com.optimal.fleet.core.database.entity.MaintenanceOperationEntity
import com.optimal.fleet.core.database.model.FollowUpConversionDbResult
import com.optimal.fleet.core.database.sync.PendingSyncOperationEntity
import com.optimal.fleet.core.database.sync.SyncQueueDao
import javax.inject.Inject

class MaintenanceFollowUpTransactions
    @Inject
    constructor(
        private val database: OptimalDatabase,
        private val readDao: MaintenanceReadDao,
        private val writeDao: MaintenanceWriteDao,
        private val followUpDao: MaintenanceFollowUpDao,
        private val auditDao: MaintenanceAuditDao,
        private val syncQueueDao: SyncQueueDao,
    ) {
        suspend fun convertToOperation(
            companyId: String,
            followUpId: String,
            newOperation: MaintenanceOperationEntity,
            audit: MaintenanceAuditEntity,
            updatedAtEpochMillis: Long,
            syncState: String,
            syncOperations: List<PendingSyncOperationEntity> = emptyList(),
        ): FollowUpConversionDbResult =
            database.withTransaction {
                val followUp =
                    followUpDao.findById(companyId, followUpId)
                        ?: return@withTransaction FollowUpConversionDbResult.NOT_FOUND
                if (followUp.convertedOperationId != null) {
                    return@withTransaction FollowUpConversionDbResult.ALREADY_CONVERTED
                }
                if (readDao.countActiveVehicle(companyId, followUp.vehicleId) != 1) {
                    return@withTransaction FollowUpConversionDbResult.VEHICLE_NOT_FOUND
                }
                writeDao.insert(newOperation)
                val updated =
                    followUpDao.markConverted(
                        companyId = companyId,
                        followUpId = followUpId,
                        operationId = newOperation.id,
                        updatedAtEpochMillis = updatedAtEpochMillis,
                        syncState = syncState,
                    )
                check(updated == 1) { "Follow-up conversion lost its reservation" }
                auditDao.insert(audit)
                syncOperations.forEach { syncQueueDao.enqueueRequired(it) }
                FollowUpConversionDbResult.CREATED
            }
    }
