package com.optimal.fleet.core.database.model

data class InvoiceProjectionDetailsRow(
    val id: String,
    val vertoInvoiceId: String,
    val vertoOrganizationId: String,
    val vertoClientId: String?,
    val invoiceNumber: String,
    val invoiceType: String,
    val description: String?,
    val category: String?,
    val totalMinor: Long,
    val paidMinor: Long?,
    val remainingMinor: Long?,
    val partsCostMinor: Long?,
    val serviceCostMinor: Long?,
    val sourceStatus: String,
    val voided: Boolean,
    val invoiceDateEpochMillis: Long,
    val sourceUpdatedAtEpochMillis: Long,
    val cachedAtEpochMillis: Long,
    val requiresVehicleLink: Boolean,
)
