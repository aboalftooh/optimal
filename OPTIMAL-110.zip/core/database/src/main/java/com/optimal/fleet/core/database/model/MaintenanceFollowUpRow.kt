package com.optimal.fleet.core.database.model

data class MaintenanceFollowUpRow(
    val id: String,
    val vehicleId: String,
    val vehicleName: String,
    val plateNumber: String,
    val sourceOperationId: String,
    val sourceOperationType: String,
    val reason: String,
    val dueDateEpochMillis: Long?,
    val dueOdometerKm: Long?,
    val currentOdometerKm: Long?,
    val createdAtEpochMillis: Long,
)
