package com.optimal.fleet.core.database.sync

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert

@Dao
interface SyncPullStateDao {
    @Upsert
    suspend fun upsertCursor(cursor: SyncPullCursorEntity)

    @Query(
        """
        SELECT * FROM sync_pull_cursors
        WHERE companyId = :companyId AND scope = :scope
        LIMIT 1
        """,
    )
    suspend fun findCursor(
        companyId: String,
        scope: String,
    ): SyncPullCursorEntity?

    @Query(
        """
        SELECT COALESCE(
            (SELECT lastAppliedRevision FROM sync_pull_cursors
             WHERE companyId = :companyId AND scope = :scope
             LIMIT 1),
            0
        )
        """,
    )
    suspend fun lastAppliedRevisionOrZero(
        companyId: String,
        scope: String,
    ): Long

    @Upsert
    suspend fun upsertReplicaMetadata(metadata: SyncReplicaMetadataEntity)

    @Query(
        """
        SELECT * FROM sync_replica_metadata
        WHERE companyId = :companyId
          AND aggregateType = :aggregateType
          AND aggregateId = :aggregateId
        LIMIT 1
        """,
    )
    suspend fun findReplicaMetadata(
        companyId: String,
        aggregateType: String,
        aggregateId: String,
    ): SyncReplicaMetadataEntity?

    @Upsert
    suspend fun upsertDeferredChange(change: DeferredRemoteChangeEntity)

    @Query(
        """
        SELECT * FROM sync_deferred_remote_changes
        WHERE companyId = :companyId
        ORDER BY revision ASC
        """,
    )
    suspend fun findDeferredChanges(companyId: String): List<DeferredRemoteChangeEntity>

    @Query("DELETE FROM sync_deferred_remote_changes WHERE revision = :revision AND companyId = :companyId")
    suspend fun deleteDeferredChange(
        companyId: String,
        revision: Long,
    ): Int
}
