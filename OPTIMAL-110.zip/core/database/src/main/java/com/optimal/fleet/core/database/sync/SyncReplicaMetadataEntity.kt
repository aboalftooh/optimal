package com.optimal.fleet.core.database.sync

import androidx.room.Entity
import androidx.room.ForeignKey
import com.optimal.fleet.core.database.entity.CompanyEntity

@Entity(
    tableName = "sync_replica_metadata",
    primaryKeys = ["companyId", "aggregateType", "aggregateId"],
    foreignKeys = [
        ForeignKey(
            entity = CompanyEntity::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class SyncReplicaMetadataEntity(
    val companyId: String,
    val aggregateType: String,
    val aggregateId: String,
    val remoteId: String?,
    val remoteVersion: Long?,
    val lastAppliedServerRevision: Long,
    val lastAppliedIdempotencyKey: String?,
    val updatedAtEpochMillis: Long,
)
