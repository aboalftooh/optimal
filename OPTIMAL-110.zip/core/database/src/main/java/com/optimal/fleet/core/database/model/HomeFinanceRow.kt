package com.optimal.fleet.core.database.model

data class HomeFinanceRow(
    val isVertoLinked: Boolean,
    val owedMinor: Long,
    val paidMinor: Long,
    val unlinkedInvoiceCount: Int,
)
