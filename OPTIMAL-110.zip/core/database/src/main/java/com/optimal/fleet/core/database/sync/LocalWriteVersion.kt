package com.optimal.fleet.core.database.sync

/** Ensures two writes to the same aggregate never share one outbox version. */
object LocalWriteVersion {
    fun next(
        clockMillis: Long,
        previousVersion: Long?,
    ): Long =
        when {
            previousVersion == null -> clockMillis
            previousVersion == Long.MAX_VALUE -> error("Local write version exhausted")
            else -> maxOf(clockMillis, previousVersion + 1L)
        }
}
