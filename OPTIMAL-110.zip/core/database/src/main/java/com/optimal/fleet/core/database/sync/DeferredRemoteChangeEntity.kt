package com.optimal.fleet.core.database.sync

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.optimal.fleet.core.database.entity.CompanyEntity

@Entity(
    tableName = "sync_deferred_remote_changes",
    foreignKeys = [
        ForeignKey(
            entity = CompanyEntity::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["companyId", "revision"]),
        Index(value = ["companyId", "aggregateType", "aggregateId"]),
    ],
)
data class DeferredRemoteChangeEntity(
    @PrimaryKey val revision: Long,
    val companyId: String,
    val aggregateType: String,
    val aggregateId: String,
    val operationType: String,
    val payload: String,
    val remoteId: String?,
    val remoteVersion: Long?,
    val originLocalVersion: Long?,
    val idempotencyKey: String?,
    val deletedAtEpochMillis: Long?,
    val changedAtEpochMillis: Long,
)
