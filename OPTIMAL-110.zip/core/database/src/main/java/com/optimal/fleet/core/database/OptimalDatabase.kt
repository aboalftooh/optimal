
package com.optimal.fleet.core.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.optimal.fleet.core.database.dao.AuditEventDao
import com.optimal.fleet.core.database.dao.CompanyDao
import com.optimal.fleet.core.database.dao.FinanceDao
import com.optimal.fleet.core.database.dao.HomeDashboardDao
import com.optimal.fleet.core.database.dao.InvoiceLinkDao
import com.optimal.fleet.core.database.dao.InvoiceProjectionDao
import com.optimal.fleet.core.database.dao.LocalUserDao
import com.optimal.fleet.core.database.dao.MaintenanceAuditDao
import com.optimal.fleet.core.database.dao.MaintenanceFollowUpDao
import com.optimal.fleet.core.database.dao.MaintenanceReadDao
import com.optimal.fleet.core.database.dao.MaintenanceWriteDao
import com.optimal.fleet.core.database.dao.MemberDao
import com.optimal.fleet.core.database.dao.NotificationDao
import com.optimal.fleet.core.database.dao.SessionDao
import com.optimal.fleet.core.database.dao.VehicleDao
import com.optimal.fleet.core.database.dao.verto.VertoAttachmentDao
import com.optimal.fleet.core.database.dao.verto.VertoConversationDao
import com.optimal.fleet.core.database.dao.verto.VertoConversationUserStateDao
import com.optimal.fleet.core.database.dao.verto.VertoInvoiceItemDao
import com.optimal.fleet.core.database.dao.verto.VertoMaintenanceMediaDao
import com.optimal.fleet.core.database.dao.verto.VertoMaintenanceProjectionDao
import com.optimal.fleet.core.database.dao.verto.VertoMessageDao
import com.optimal.fleet.core.database.dao.verto.VertoRemoteCursorDao
import com.optimal.fleet.core.database.entity.ActiveSessionEntity
import com.optimal.fleet.core.database.entity.AdditionalCostEntity
import com.optimal.fleet.core.database.entity.AuditEventEntity
import com.optimal.fleet.core.database.entity.CompanyEntity
import com.optimal.fleet.core.database.entity.InvoiceLinkAuditEntity
import com.optimal.fleet.core.database.entity.InvoiceMaintenanceLinkEntity
import com.optimal.fleet.core.database.entity.InvoiceProjectionEntity
import com.optimal.fleet.core.database.entity.InvoiceSourceAuditEntity
import com.optimal.fleet.core.database.entity.LocalUserEntity
import com.optimal.fleet.core.database.entity.MaintenanceAuditEntity
import com.optimal.fleet.core.database.entity.MaintenanceFollowUpEntity
import com.optimal.fleet.core.database.entity.MaintenanceOperationEntity
import com.optimal.fleet.core.database.entity.MemberInviteEntity
import com.optimal.fleet.core.database.entity.NotificationEntity
import com.optimal.fleet.core.database.entity.VehicleAuditEntity
import com.optimal.fleet.core.database.entity.VehicleEntity
import com.optimal.fleet.core.database.entity.verto.VertoAttachmentEntity
import com.optimal.fleet.core.database.entity.verto.VertoConversationEntity
import com.optimal.fleet.core.database.entity.verto.VertoConversationUserStateEntity
import com.optimal.fleet.core.database.entity.verto.VertoInvoiceItemEntity
import com.optimal.fleet.core.database.entity.verto.VertoMaintenanceMediaEntity
import com.optimal.fleet.core.database.entity.verto.VertoMaintenanceProjectionEntity
import com.optimal.fleet.core.database.entity.verto.VertoMessageEntity
import com.optimal.fleet.core.database.entity.verto.VertoRemoteCursorEntity
import com.optimal.fleet.core.database.sync.DeferredRemoteChangeEntity
import com.optimal.fleet.core.database.sync.PendingSyncOperationEntity
import com.optimal.fleet.core.database.sync.SyncConflictAuditEntity
import com.optimal.fleet.core.database.sync.SyncPullCursorEntity
import com.optimal.fleet.core.database.sync.SyncPullStateDao
import com.optimal.fleet.core.database.sync.SyncReplicaMetadataEntity
import com.optimal.fleet.core.database.sync.SyncQueueDao

@Database(
    entities = [
        CompanyEntity::class,
        LocalUserEntity::class,
        ActiveSessionEntity::class,
        VehicleEntity::class,
        VehicleAuditEntity::class,
        MaintenanceOperationEntity::class,
        MaintenanceAuditEntity::class,
        MaintenanceFollowUpEntity::class,
        PendingSyncOperationEntity::class,
        SyncConflictAuditEntity::class,
        SyncPullCursorEntity::class,
        SyncReplicaMetadataEntity::class,
        DeferredRemoteChangeEntity::class,
        InvoiceProjectionEntity::class,
        InvoiceSourceAuditEntity::class,
        InvoiceMaintenanceLinkEntity::class,
        InvoiceLinkAuditEntity::class,
        AdditionalCostEntity::class,
        AuditEventEntity::class,
        MemberInviteEntity::class,
        NotificationEntity::class,
        VertoConversationEntity::class,
        VertoMessageEntity::class,
        VertoAttachmentEntity::class,
        VertoConversationUserStateEntity::class,
        VertoRemoteCursorEntity::class,
        VertoInvoiceItemEntity::class,
        VertoMaintenanceProjectionEntity::class,
        VertoMaintenanceMediaEntity::class,
    ],
    version = 4,
    exportSchema = true,
)
abstract class OptimalDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao

    abstract fun localUserDao(): LocalUserDao

    abstract fun sessionDao(): SessionDao

    abstract fun vehicleDao(): VehicleDao

    abstract fun maintenanceReadDao(): MaintenanceReadDao

    abstract fun maintenanceWriteDao(): MaintenanceWriteDao

    abstract fun maintenanceFollowUpDao(): MaintenanceFollowUpDao

    abstract fun maintenanceAuditDao(): MaintenanceAuditDao

    abstract fun syncQueueDao(): SyncQueueDao

    abstract fun syncPullStateDao(): SyncPullStateDao

    abstract fun invoiceProjectionDao(): InvoiceProjectionDao

    abstract fun invoiceLinkDao(): InvoiceLinkDao

    abstract fun financeDao(): FinanceDao

    abstract fun homeDashboardDao(): HomeDashboardDao

    abstract fun auditEventDao(): AuditEventDao

    abstract fun memberDao(): MemberDao

    abstract fun notificationDao(): NotificationDao

    abstract fun vertoConversationDao(): VertoConversationDao

    abstract fun vertoMessageDao(): VertoMessageDao

    abstract fun vertoAttachmentDao(): VertoAttachmentDao

    abstract fun vertoConversationUserStateDao(): VertoConversationUserStateDao

    abstract fun vertoRemoteCursorDao(): VertoRemoteCursorDao

    abstract fun vertoInvoiceItemDao(): VertoInvoiceItemDao

    abstract fun vertoMaintenanceProjectionDao(): VertoMaintenanceProjectionDao

    abstract fun vertoMaintenanceMediaDao(): VertoMaintenanceMediaDao
}
