package com.optimal.fleet.core.database.model

data class DueFollowUpNotificationRow(
    val followUpId: String,
    val vehicleName: String,
    val plateNumber: String,
    val reason: String,
    val dueDateEpochMillis: Long?,
    val dueOdometerKm: Long?,
    val currentOdometerKm: Long?,
)

data class InvoiceNotificationRow(
    val invoiceProjectionId: String,
    val vertoInvoiceId: String,
    val invoiceNumber: String,
    val totalMinor: Long,
    val cachedAtEpochMillis: Long,
)

data class SyncFailureNotificationRow(
    val operationId: String,
    val aggregateType: String,
    val aggregateId: String,
    val attemptCount: Int,
    val state: String,
    val lastErrorCode: String?,
    val updatedAtEpochMillis: Long,
)

data class VertoMessageNotificationRow(
    val messageRemoteId: String,
    val senderDisplayName: String,
    val kind: String,
    val bodyText: String?,
    val occurredAtEpochMillis: Long,
)
