package com.optimal.fleet.core.database.model

data class FinancialSummaryRow(
    val companyId: String,
    val currencyCode: String,
    val isVertoLinked: Boolean,
    val hasVertoInvoices: Boolean,
    val owedMinor: Long,
    val paidMinor: Long,
    val partsCostMinor: Long,
    val serviceCostMinor: Long,
    val additionalCostsMinor: Long,
)
