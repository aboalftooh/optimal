package com.optimal.fleet.core.database.model

data class MaintenanceAuditRow(
    val id: String,
    val actorUserId: String,
    val actorDisplayName: String,
    val action: String,
    val changedFields: String,
    val createdAtEpochMillis: Long,
)
