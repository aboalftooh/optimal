package com.optimal.fleet.core.database.maintenance

import androidx.room.withTransaction
import com.optimal.fleet.core.database.OptimalDatabase
import com.optimal.fleet.core.database.dao.MaintenanceAuditDao
import com.optimal.fleet.core.database.dao.MaintenanceFollowUpDao
import com.optimal.fleet.core.database.dao.MaintenanceReadDao
import com.optimal.fleet.core.database.dao.MaintenanceWriteDao
import com.optimal.fleet.core.database.entity.MaintenanceAuditEntity
import com.optimal.fleet.core.database.entity.MaintenanceFollowUpEntity
import com.optimal.fleet.core.database.entity.MaintenanceOperationEntity
import com.optimal.fleet.core.database.model.MaintenanceCompletionDbResult
import com.optimal.fleet.core.database.model.MaintenanceUpdateDbResult
import com.optimal.fleet.core.database.sync.PendingSyncOperationEntity
import com.optimal.fleet.core.database.sync.SyncQueueDao
import javax.inject.Inject

class MaintenanceOperationTransactions
    @Inject
    constructor(
        private val database: OptimalDatabase,
        private val readDao: MaintenanceReadDao,
        private val writeDao: MaintenanceWriteDao,
        private val followUpDao: MaintenanceFollowUpDao,
        private val auditDao: MaintenanceAuditDao,
        private val syncQueueDao: SyncQueueDao,
    ) {
        suspend fun insertWithAudit(
            operation: MaintenanceOperationEntity,
            audit: MaintenanceAuditEntity,
        ) = database.withTransaction {
            writeDao.insert(operation)
            auditDao.insert(audit)
        }

        suspend fun insertWithSync(
            operation: MaintenanceOperationEntity,
            syncOperation: PendingSyncOperationEntity,
        ) = database.withTransaction {
            writeDao.insert(operation)
            syncQueueDao.enqueueRequired(syncOperation)
        }

        suspend fun updateInProgressWithAudit(
            companyId: String,
            operationId: String,
            type: String,
            description: String,
            odometerKm: Long?,
            partsCostMinor: Long,
            serviceCostMinor: Long,
            updatedByUserId: String,
            updatedAtEpochMillis: Long,
            syncState: String,
            audit: MaintenanceAuditEntity,
            syncOperation: PendingSyncOperationEntity? = null,
        ): MaintenanceUpdateDbResult =
            database.withTransaction {
                val current =
                    readDao.findById(companyId, operationId)
                        ?: return@withTransaction MaintenanceUpdateDbResult.NOT_FOUND
                if (current.status != "IN_PROGRESS") {
                    return@withTransaction MaintenanceUpdateDbResult.NOT_EDITABLE
                }
                val updated =
                    writeDao.updateInProgress(
                        companyId = companyId,
                        operationId = operationId,
                        type = type,
                        description = description,
                        odometerKm = odometerKm,
                        partsCostMinor = partsCostMinor,
                        serviceCostMinor = serviceCostMinor,
                        updatedByUserId = updatedByUserId,
                        updatedAtEpochMillis = updatedAtEpochMillis,
                        syncState = syncState,
                    )
                if (updated != 1) {
                    return@withTransaction MaintenanceUpdateDbResult.NOT_EDITABLE
                }
                auditDao.insert(audit)
                syncOperation?.let { syncQueueDao.enqueueRequired(it) }
                MaintenanceUpdateDbResult.UPDATED
            }

        suspend fun completeWithFollowUpAndAudit(
            companyId: String,
            operationId: String,
            description: String,
            completedAtEpochMillis: Long,
            odometerKm: Long?,
            partsCostMinor: Long,
            serviceCostMinor: Long,
            updatedByUserId: String,
            updatedAtEpochMillis: Long,
            syncState: String,
            audit: MaintenanceAuditEntity,
            followUp: MaintenanceFollowUpEntity?,
            syncOperations: List<PendingSyncOperationEntity> = emptyList(),
        ): MaintenanceCompletionDbResult =
            database.withTransaction {
                val current =
                    readDao.findById(companyId, operationId)
                        ?: return@withTransaction MaintenanceCompletionDbResult.NOT_FOUND
                if (current.status == "COMPLETED") {
                    return@withTransaction MaintenanceCompletionDbResult.ALREADY_COMPLETED
                }
                val completed =
                    writeDao.markCompleted(
                        companyId = companyId,
                        operationId = operationId,
                        description = description,
                        completedAtEpochMillis = completedAtEpochMillis,
                        odometerKm = odometerKm,
                        partsCostMinor = partsCostMinor,
                        serviceCostMinor = serviceCostMinor,
                        updatedByUserId = updatedByUserId,
                        updatedAtEpochMillis = updatedAtEpochMillis,
                        syncState = syncState,
                    )
                if (completed != 1) {
                    return@withTransaction MaintenanceCompletionDbResult.ALREADY_COMPLETED
                }
                if (odometerKm != null) {
                    writeDao.updateVehicleOdometerIfNewer(
                        companyId = companyId,
                        vehicleId = current.vehicleId,
                        odometerKm = odometerKm,
                        updatedAtEpochMillis = updatedAtEpochMillis,
                        syncStatus = syncState,
                    )
                }
                followUp?.let { followUpDao.insert(it) }
                auditDao.insert(audit)
                syncOperations.forEach { syncQueueDao.enqueueRequired(it) }
                MaintenanceCompletionDbResult.COMPLETED
            }
    }
