package com.optimal.fleet.core.database.sync

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.optimal.fleet.core.database.entity.CompanyEntity

@Entity(
    tableName = "pending_sync_operations",
    foreignKeys = [
        ForeignKey(
            entity = CompanyEntity::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["idempotencyKey"], unique = true),
        Index(value = ["companyId", "state", "nextAttemptAtEpochMillis"]),
        Index(value = ["aggregateType", "aggregateId", "localVersion"]),
        Index(value = ["leaseUntilEpochMillis"]),
        Index(value = ["leaseToken"]),
    ],
)
data class PendingSyncOperationEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val aggregateType: String,
    val aggregateId: String,
    val operationType: String,
    val payload: String,
    val idempotencyKey: String,
    val localVersion: Long,
    val state: String,
    val attemptCount: Int,
    val nextAttemptAtEpochMillis: Long,
    val leaseUntilEpochMillis: Long?,
    val leaseToken: String? = null,
    val lastErrorCode: String?,
    val remoteId: String?,
    val remoteVersion: Long?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
