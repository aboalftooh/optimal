package com.optimal.fleet.core.database.model

data class MaintenanceOperationDetailsRow(
    val id: String,
    val vehicleId: String,
    val remoteId: String?,
    val vehicleName: String,
    val plateNumber: String,
    val type: String,
    val description: String,
    val status: String,
    val startedAtEpochMillis: Long,
    val completedAtEpochMillis: Long?,
    val odometerKm: Long?,
    val partsCostMinor: Long,
    val serviceCostMinor: Long,
    val source: String,
    val createdByUserId: String,
    val updatedByUserId: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
