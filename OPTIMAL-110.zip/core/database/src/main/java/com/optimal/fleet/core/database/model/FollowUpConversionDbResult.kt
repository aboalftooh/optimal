package com.optimal.fleet.core.database.model

enum class FollowUpConversionDbResult {
    CREATED,
    NOT_FOUND,
    ALREADY_CONVERTED,
    VEHICLE_NOT_FOUND,
}
