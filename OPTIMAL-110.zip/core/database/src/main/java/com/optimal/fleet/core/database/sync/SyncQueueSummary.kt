package com.optimal.fleet.core.database.sync

data class SyncQueueSummary(
    val pendingCount: Long,
    val runningCount: Long,
    val retryCount: Long,
    val permanentFailureCount: Long,
) {
    val hasWork: Boolean get() = pendingCount + runningCount + retryCount > 0L
}
