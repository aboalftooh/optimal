package com.optimal.fleet.core.database.model

enum class MaintenanceUpdateDbResult {
    UPDATED,
    NOT_FOUND,
    NOT_EDITABLE,
}
