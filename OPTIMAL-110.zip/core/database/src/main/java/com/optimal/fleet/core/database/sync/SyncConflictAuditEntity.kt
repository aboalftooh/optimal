package com.optimal.fleet.core.database.sync

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.optimal.fleet.core.database.entity.CompanyEntity

@Entity(
    tableName = "sync_conflict_audit",
    foreignKeys = [
        ForeignKey(
            entity = CompanyEntity::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["operationId"]),
        Index(value = ["aggregateType", "aggregateId"]),
        Index(value = ["createdAtEpochMillis"]),
    ],
)
data class SyncConflictAuditEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val operationId: String,
    val aggregateType: String,
    val aggregateId: String,
    val localVersion: Long,
    val remoteVersion: Long,
    val losingPayload: String,
    val winningPayload: String,
    val resolution: String,
    val createdAtEpochMillis: Long,
)
