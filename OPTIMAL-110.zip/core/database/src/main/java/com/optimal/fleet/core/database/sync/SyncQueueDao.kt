package com.optimal.fleet.core.database.sync

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncQueueDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun enqueue(operation: PendingSyncOperationEntity): Long

    /** Atomic domain writes use ABORT so an outbox failure rolls back the whole write. */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun enqueueRequired(operation: PendingSyncOperationEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertConflictAudit(audit: SyncConflictAuditEntity): Long

    @Query(
        """
        SELECT * FROM pending_sync_operations
        WHERE companyId = :companyId
          AND state IN ('PENDING', 'RETRY')
          AND nextAttemptAtEpochMillis <= :nowEpochMillis
        ORDER BY createdAtEpochMillis ASC, id ASC
        LIMIT :limit
        """,
    )
    suspend fun findDueForCompany(
        companyId: String,
        nowEpochMillis: Long,
        limit: Int,
    ): List<PendingSyncOperationEntity>

    @Query(
        """
        SELECT * FROM pending_sync_operations
        WHERE companyId = :companyId
          AND state = 'RUNNING'
          AND leaseUntilEpochMillis IS NOT NULL
          AND leaseUntilEpochMillis <= :nowEpochMillis
        ORDER BY leaseUntilEpochMillis ASC, id ASC
        LIMIT :limit
        """,
    )
    suspend fun findExpiredLeasesForCompany(
        companyId: String,
        nowEpochMillis: Long,
        limit: Int,
    ): List<PendingSyncOperationEntity>

    /** System-only scheduler query. Returned rows keep their company identity. */
    @Query(
        """
        SELECT * FROM pending_sync_operations
        WHERE state IN ('PENDING', 'RETRY')
          AND nextAttemptAtEpochMillis <= :nowEpochMillis
        ORDER BY createdAtEpochMillis ASC, id ASC
        LIMIT :limit
        """,
    )
    suspend fun findDueForSystem(
        nowEpochMillis: Long,
        limit: Int,
    ): List<PendingSyncOperationEntity>

    @Query(
        """
        SELECT * FROM pending_sync_operations
        WHERE state = 'RUNNING'
          AND leaseUntilEpochMillis IS NOT NULL
          AND leaseUntilEpochMillis <= :nowEpochMillis
        ORDER BY leaseUntilEpochMillis ASC, id ASC
        LIMIT :limit
        """,
    )
    suspend fun findExpiredLeasesForSystem(
        nowEpochMillis: Long,
        limit: Int,
    ): List<PendingSyncOperationEntity>

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'RUNNING',
            leaseUntilEpochMillis = :leaseUntilEpochMillis,
            leaseToken = :leaseToken,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state IN ('PENDING', 'RETRY')
        """,
    )
    suspend fun claim(
        companyId: String,
        operationId: String,
        leaseUntilEpochMillis: Long,
        leaseToken: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        SELECT * FROM pending_sync_operations
        WHERE id = :operationId AND companyId = :companyId
        LIMIT 1
        """,
    )
    suspend fun findById(
        companyId: String,
        operationId: String,
    ): PendingSyncOperationEntity?

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'RETRY',
            nextAttemptAtEpochMillis = :nowEpochMillis,
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            lastErrorCode = NULL,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state IN ('RETRY', 'PERMANENT_FAILURE')
        """,
    )
    suspend fun retryNow(
        companyId: String,
        operationId: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        SELECT COUNT(*) FROM pending_sync_operations
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
          AND leaseUntilEpochMillis > :nowEpochMillis
        """,
    )
    suspend fun countActiveLease(
        companyId: String,
        operationId: String,
        leaseToken: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'SUCCEEDED',
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            lastErrorCode = NULL,
            remoteId = :remoteId,
            remoteVersion = :remoteVersion,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
          AND leaseUntilEpochMillis > :nowEpochMillis
        """,
    )
    suspend fun markSucceeded(
        companyId: String,
        operationId: String,
        leaseToken: String,
        remoteId: String?,
        remoteVersion: Long?,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'RETRY',
            attemptCount = attemptCount + 1,
            nextAttemptAtEpochMillis = :nextAttemptAtEpochMillis,
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            lastErrorCode = :errorCode,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
          AND leaseUntilEpochMillis > :nowEpochMillis
        """,
    )
    suspend fun markRetry(
        companyId: String,
        operationId: String,
        leaseToken: String,
        nextAttemptAtEpochMillis: Long,
        errorCode: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'PERMANENT_FAILURE',
            attemptCount = attemptCount + 1,
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            lastErrorCode = :errorCode,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
          AND leaseUntilEpochMillis > :nowEpochMillis
        """,
    )
    suspend fun markPermanentFailure(
        companyId: String,
        operationId: String,
        leaseToken: String,
        errorCode: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'RETRY',
            attemptCount = attemptCount + 1,
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            nextAttemptAtEpochMillis = :nextAttemptAtEpochMillis,
            lastErrorCode = :errorCode,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
          AND leaseUntilEpochMillis <= :nowEpochMillis
        """,
    )
    suspend fun recoverExpiredLeaseAsRetry(
        companyId: String,
        operationId: String,
        leaseToken: String,
        nextAttemptAtEpochMillis: Long,
        errorCode: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'PERMANENT_FAILURE',
            attemptCount = attemptCount + 1,
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            lastErrorCode = :errorCode,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
          AND leaseUntilEpochMillis <= :nowEpochMillis
        """,
    )
    suspend fun recoverExpiredLeaseAsPermanentFailure(
        companyId: String,
        operationId: String,
        leaseToken: String,
        errorCode: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE pending_sync_operations
        SET state = 'RETRY',
            nextAttemptAtEpochMillis = :nextAttemptAtEpochMillis,
            leaseUntilEpochMillis = NULL,
            leaseToken = NULL,
            lastErrorCode = :errorCode,
            updatedAtEpochMillis = :nowEpochMillis
        WHERE id = :operationId
          AND companyId = :companyId
          AND state = 'RUNNING'
          AND leaseToken = :leaseToken
        """,
    )
    suspend fun releaseLeaseForSessionChange(
        companyId: String,
        operationId: String,
        leaseToken: String,
        nextAttemptAtEpochMillis: Long,
        errorCode: String,
        nowEpochMillis: Long,
    ): Int

    @Query(
        """
        SELECT COUNT(*) FROM pending_sync_operations
        WHERE companyId = :companyId
          AND aggregateType = :aggregateType
          AND aggregateId = :aggregateId
          AND state IN ('PENDING', 'RUNNING', 'RETRY')
        """,
    )
    suspend fun countDirtyAggregate(
        companyId: String,
        aggregateType: String,
        aggregateId: String,
    ): Int

    @Query(
        """
        SELECT
            COUNT(CASE WHEN state = 'PENDING' THEN 1 END) AS pendingCount,
            COUNT(CASE WHEN state = 'RUNNING' THEN 1 END) AS runningCount,
            COUNT(CASE WHEN state = 'RETRY' THEN 1 END) AS retryCount,
            COUNT(CASE WHEN state = 'PERMANENT_FAILURE' THEN 1 END) AS permanentFailureCount
        FROM pending_sync_operations
        WHERE companyId = :companyId
        """,
    )
    fun observeSummary(companyId: String): Flow<SyncQueueSummary>

    @Query(
        """
        SELECT COUNT(*) FROM pending_sync_operations
        WHERE companyId = :companyId AND state = :state
        """,
    )
    suspend fun countByState(
        companyId: String,
        state: String,
    ): Int

    @Transaction
    suspend fun claimDueBatchForCompany(
        companyId: String,
        nowEpochMillis: Long,
        leaseDurationMillis: Long,
        limit: Int,
        leaseToken: String,
    ): List<PendingSyncOperationEntity> {
        val due = findDueForCompany(companyId, nowEpochMillis, limit)
        val claimed = mutableListOf<PendingSyncOperationEntity>()
        for (candidate in due) {
            val rows =
                claim(
                    companyId = companyId,
                    operationId = candidate.id,
                    leaseUntilEpochMillis = nowEpochMillis + leaseDurationMillis,
                    leaseToken = leaseToken,
                    nowEpochMillis = nowEpochMillis,
                )
            if (rows == 1) {
                findById(companyId, candidate.id)?.let(claimed::add)
            }
        }
        return claimed
    }

    @Transaction
    suspend fun claimDueBatchForSystem(
        nowEpochMillis: Long,
        leaseDurationMillis: Long,
        limit: Int,
        leaseToken: String,
    ): List<PendingSyncOperationEntity> {
        val due = findDueForSystem(nowEpochMillis, limit)
        val claimed = mutableListOf<PendingSyncOperationEntity>()
        for (candidate in due) {
            val rows =
                claim(
                    companyId = candidate.companyId,
                    operationId = candidate.id,
                    leaseUntilEpochMillis = nowEpochMillis + leaseDurationMillis,
                    leaseToken = leaseToken,
                    nowEpochMillis = nowEpochMillis,
                )
            if (rows == 1) {
                findById(candidate.companyId, candidate.id)?.let(claimed::add)
            }
        }
        return claimed
    }

    @Transaction
    suspend fun insertConflictAuditIfLeaseOwned(
        audit: SyncConflictAuditEntity,
        leaseToken: String,
        nowEpochMillis: Long,
    ): Boolean {
        if (countActiveLease(audit.companyId, audit.operationId, leaseToken, nowEpochMillis) != 1) {
            return false
        }
        insertConflictAudit(audit)
        return true
    }
}
