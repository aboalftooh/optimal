package com.optimal.fleet.core.database.model

data class MaintenanceVehicleOptionRow(
    val id: String,
    val name: String,
    val plateNumber: String,
    val odometerKm: Long?,
)
