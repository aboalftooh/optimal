package com.optimal.fleet.core.database.model

data class ActiveSessionRow(
    val userId: String,
    val companyId: String,
    val userDisplayName: String,
    val companyName: String,
)
