package com.optimal.fleet.core.database.sync

/** Builds every local sync outbox row with one stable identity contract. */
object SyncOutboxEntryFactory {
    fun create(
        companyId: String,
        aggregateType: String,
        aggregateId: String,
        operationType: String,
        payload: String,
        localVersion: Long,
        remoteId: String?,
    ): PendingSyncOperationEntity {
        val key =
            idempotencyKey(
                aggregateType = aggregateType,
                aggregateId = aggregateId,
                operationType = operationType,
                localVersion = localVersion,
            )
        return PendingSyncOperationEntity(
            id = key,
            companyId = companyId,
            aggregateType = aggregateType,
            aggregateId = aggregateId,
            operationType = operationType,
            payload = payload,
            idempotencyKey = key,
            localVersion = localVersion,
            state = SyncQueueState.PENDING,
            attemptCount = 0,
            nextAttemptAtEpochMillis = localVersion,
            leaseUntilEpochMillis = null,
            lastErrorCode = null,
            remoteId = remoteId,
            remoteVersion = null,
            createdAtEpochMillis = localVersion,
            updatedAtEpochMillis = localVersion,
        )
    }

    fun idempotencyKey(
        aggregateType: String,
        aggregateId: String,
        operationType: String,
        localVersion: Long,
    ): String = "$aggregateType:$aggregateId:$operationType:$localVersion"
}
