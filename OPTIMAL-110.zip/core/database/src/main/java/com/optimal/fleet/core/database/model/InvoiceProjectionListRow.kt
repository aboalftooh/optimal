package com.optimal.fleet.core.database.model

data class InvoiceProjectionListRow(
    val id: String,
    val vertoInvoiceId: String,
    val invoiceNumber: String,
    val invoiceType: String,
    val description: String?,
    val category: String?,
    val totalMinor: Long,
    val paidMinor: Long?,
    val remainingMinor: Long?,
    val sourceStatus: String,
    val voided: Boolean,
    val invoiceDateEpochMillis: Long,
    val sourceUpdatedAtEpochMillis: Long,
    val requiresVehicleLink: Boolean,
)
