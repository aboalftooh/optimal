package com.optimal.fleet.core.database.model

enum class MaintenanceCompletionDbResult {
    COMPLETED,
    NOT_FOUND,
    ALREADY_COMPLETED,
}
