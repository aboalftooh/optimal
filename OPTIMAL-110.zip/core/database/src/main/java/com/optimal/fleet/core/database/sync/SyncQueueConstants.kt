package com.optimal.fleet.core.database.sync

object SyncQueueState {
    const val PENDING = "PENDING"
    const val RUNNING = "RUNNING"
    const val RETRY = "RETRY"
    const val SUCCEEDED = "SUCCEEDED"
    const val PERMANENT_FAILURE = "PERMANENT_FAILURE"
}

object SyncAggregateType {
    const val VEHICLE = "VEHICLE"
    const val MAINTENANCE = "MAINTENANCE"
    const val FOLLOW_UP = "FOLLOW_UP"
    const val VERTO_MESSAGE = "VERTO_MESSAGE"
    const val VERTO_CONVERSATION_STATE = "VERTO_CONVERSATION_STATE"
}

object SyncOperationType {
    const val UPSERT = "UPSERT"
    const val ARCHIVE = "ARCHIVE"
    const val COMPLETE = "COMPLETE"
    const val CONVERT = "CONVERT"
    const val SEND_TEXT = "SEND_TEXT"
    const val SEND_ATTACHMENT = "SEND_ATTACHMENT"
    const val SET_ARCHIVED = "SET_ARCHIVED"
}
