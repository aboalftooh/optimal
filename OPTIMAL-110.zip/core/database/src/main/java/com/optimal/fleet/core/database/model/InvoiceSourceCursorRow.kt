package com.optimal.fleet.core.database.model

data class InvoiceSourceCursorRow(
    val sourceUpdatedAtEpochMillis: Long,
    val vertoInvoiceId: String,
)
