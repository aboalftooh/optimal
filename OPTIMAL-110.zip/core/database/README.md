# :core:database

يمتلك إعداد Room والـEntities والـDAOs والمهاجرات فقط.

## الحالة الحالية

- Room schema version: `2`.
- المخطط التاريخي `1.json` محفوظ بوصفه مدخل Migration.
- المخطط الحالي `2.json`: 23 جدولًا، 292 عمودًا، 126 فهرسًا، و43 مفتاحًا خارجيًا.
- Migration المدعومة: `1 → 2` عبر `OptimalDatabaseMigrations.MIGRATION_1_2`.
- لا يوجد `fallbackToDestructiveMigration`.

## ملكية البيانات

- الشركات والمستخدمون والجلسة المحلية.
- السيارات والصيانة والتكاليف والتدقيق والإشعارات والمزامنة.
- إسقاطات فواتير Verto الحالية.
- محادثة Verto ورسائلها ومرفقاتها وحالة المستخدم والـCursor المحلي.

لا تُمرر DAOs إلى Presentation أو Domain؛ تستهلكها Data Adapters المالكة فقط.
