plugins {
    id("optimal.kotlin.library")
}

group = "com.optimal.fleet.core.testing"

dependencies {
    api(project(":core:model"))
    api(project(":core:session"))
    api(libs.junit4)
    api(libs.kotlinx.coroutines.test)
    api(libs.turbine)
}
