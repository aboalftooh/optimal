package com.optimal.fleet.core.testing

import com.optimal.fleet.core.testing.fake.MutableSessionReader
import com.optimal.fleet.core.testing.fake.RecordingTransactionRunner
import com.optimal.fleet.core.testing.fixture.CoreFixtures
import com.optimal.fleet.core.testing.time.MutableTestClock
import java.time.Duration
import java.time.Instant
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test

class TestToolsTest {
    @Test
    fun mutableClockAdvancesDeterministically() {
        val clock = MutableTestClock(Instant.ofEpochMilli(1_000))

        clock.advanceBy(Duration.ofSeconds(2))

        assertEquals(3_000L, clock.millis())
    }

    @Test(expected = IllegalArgumentException::class)
    fun mutableClockRejectsBackwardTravel() {
        MutableTestClock().advanceBy(Duration.ofMillis(-1))
    }

    @Test
    fun mutableSessionReaderPublishesExplicitLifecycle() = runTest {
        val reader = MutableSessionReader()
        assertNull(reader.currentSession())

        val session = CoreFixtures.activeSession()
        reader.set(session)
        assertEquals(session, reader.currentSession())

        reader.clear()
        assertNull(reader.currentSession())
    }

    @Test
    fun recordingTransactionRunsBlockExactlyOnce() = runTest {
        val runner = RecordingTransactionRunner()
        val expected = Any()

        val actual = runner.run { expected }

        assertSame(expected, actual)
        assertEquals(1, runner.runs)
    }
}
