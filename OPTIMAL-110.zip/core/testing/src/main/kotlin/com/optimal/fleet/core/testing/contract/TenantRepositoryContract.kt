package com.optimal.fleet.core.testing.contract

import com.optimal.fleet.core.testing.fixture.CoreFixtures
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/** Reusable contract for repositories whose primary key is scoped by company. */
abstract class TenantRepositoryContract<T : Any> {
    protected open val companyA: String = CoreFixtures.COMPANY_A_ID
    protected open val companyB: String = CoreFixtures.COMPANY_B_ID

    protected abstract suspend fun create(companyId: String): T
    protected abstract suspend fun find(companyId: String, id: String): T?
    protected abstract fun idOf(value: T): String

    @Test
    fun createdRecordCanBeReadInsideOwningCompany() = runTest {
        val created = create(companyA)

        assertEquals(created, find(companyA, idOf(created)))
    }

    @Test
    fun recordCannotBeReadThroughAnotherCompany() = runTest {
        val created = create(companyA)

        assertNull(find(companyB, idOf(created)))
        assertNotNull(find(companyA, idOf(created)))
    }
}
