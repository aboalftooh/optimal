package com.optimal.fleet.core.testing.database

/** Stable tenant identities and values shared by Room instrumentation tests. */
data class TenantFixture(
    val companyId: String,
    val userId: String,
    val vehicleId: String,
    val operationId: String,
    val invoiceId: String,
    val normalizedPhone: String,
    val plate: String,
    val vin: String,
)

object DatabaseFixture {
    const val NOW = 1_000L
    const val LATER = 2_000L
    const val MUCH_LATER = 100_000L

    val COMPANY_A = TenantFixture(
        companyId = "company-a",
        userId = "user-a",
        vehicleId = "vehicle-a",
        operationId = "operation-a",
        invoiceId = "invoice-a",
        normalizedPhone = "249100000001",
        plate = "A-100",
        vin = "VIN-A-100",
    )

    val COMPANY_B = TenantFixture(
        companyId = "company-b",
        userId = "user-b",
        vehicleId = "vehicle-b",
        operationId = "operation-b",
        invoiceId = "invoice-b",
        normalizedPhone = "249100000002",
        plate = "B-200",
        vin = "VIN-B-200",
    )
}
