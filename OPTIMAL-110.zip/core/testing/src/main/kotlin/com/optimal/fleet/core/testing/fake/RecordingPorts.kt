package com.optimal.fleet.core.testing.fake

import com.optimal.fleet.core.model.audit.AuditEventDraft
import com.optimal.fleet.core.model.audit.AuditPort
import com.optimal.fleet.core.model.transaction.AtomicWriteTransactionRunner

class RecordingAuditPort : AuditPort {
    private val recorded = mutableListOf<AuditEventDraft>()
    val events: List<AuditEventDraft> get() = recorded.toList()

    override suspend fun append(event: AuditEventDraft) {
        recorded += event
    }

    fun clear() = recorded.clear()
}

class RecordingTransactionRunner(private val failure: Throwable? = null) : AtomicWriteTransactionRunner {
    var runs: Int = 0
        private set

    override suspend fun <T> run(block: suspend () -> T): T {
        runs += 1
        failure?.let { throw it }
        return block()
    }
}
