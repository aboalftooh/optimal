package com.optimal.fleet.core.testing.fixture

/** Deterministic values for production ports that generate opaque identifiers. */
class SequenceValues(private val prefix: String = "test") {
    private var next: Long = 0

    fun next(): String {
        next += 1
        return "$prefix-$next"
    }
}
