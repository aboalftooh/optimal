package com.optimal.fleet.core.testing.time

import java.time.Clock
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

/** Mutable, thread-safe clock for expiry, retry and process-recreation tests. */
class MutableTestClock(initialInstant: Instant = Instant.EPOCH, private val testZone: ZoneId = ZoneOffset.UTC) : Clock() {
    @Volatile
    private var currentInstant: Instant = initialInstant

    override fun getZone(): ZoneId = testZone

    override fun withZone(zone: ZoneId): Clock = MutableTestClock(currentInstant, zone)

    override fun instant(): Instant = currentInstant

    fun set(instant: Instant) {
        currentInstant = instant
    }

    fun advanceBy(duration: Duration) {
        require(!duration.isNegative) { "Test clock cannot move backwards" }
        currentInstant = currentInstant.plus(duration)
    }

    companion object {
        fun atEpochMillis(epochMillis: Long): MutableTestClock = MutableTestClock(Instant.ofEpochMilli(epochMillis))
    }
}

fun fixedTestClock(epochMillis: Long): Clock = Clock.fixed(Instant.ofEpochMilli(epochMillis), ZoneOffset.UTC)
