package com.optimal.fleet.core.testing.fake

import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.core.session.SessionReader
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class MutableSessionReader(initial: ActiveSession? = null) : SessionReader {
    private val mutableSession = MutableStateFlow(initial)
    val session = mutableSession.asStateFlow()

    override fun observeActiveSession(): Flow<ActiveSession?> = session

    override suspend fun currentSession(): ActiveSession? = session.value

    fun set(value: ActiveSession?) {
        mutableSession.value = value
    }

    fun clear() = set(null)
}
