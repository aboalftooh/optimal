package com.optimal.fleet.core.testing.fixture

import com.optimal.fleet.core.model.audit.AuditAction
import com.optimal.fleet.core.model.audit.AuditActorSource
import com.optimal.fleet.core.model.audit.AuditEntityType
import com.optimal.fleet.core.model.audit.AuditEventDraft
import com.optimal.fleet.core.session.ActiveSession

object CoreFixtures {
    const val COMPANY_A_ID = "company-a"
    const val COMPANY_B_ID = "company-b"
    const val USER_A_ID = "user-a"
    const val USER_B_ID = "user-b"
    const val VEHICLE_A_ID = "vehicle-a"
    const val OPERATION_A_ID = "operation-a"
    const val NOW_EPOCH_MILLIS = 1_000L

    fun activeSession(
        userId: String = USER_A_ID,
        companyId: String = COMPANY_A_ID,
        userDisplayName: String = "مستخدم اختبار",
        companyName: String = "شركة اختبار",
    ): ActiveSession = ActiveSession(
        userId = userId,
        companyId = companyId,
        userDisplayName = userDisplayName,
        companyName = companyName,
    )

    fun auditDraft(
        companyId: String = COMPANY_A_ID,
        actorUserId: String = USER_A_ID,
        entityId: String = VEHICLE_A_ID,
        summary: String = "حدث اختبار",
    ): AuditEventDraft = AuditEventDraft(
        companyId = companyId,
        actorUserId = actorUserId,
        actorSource = AuditActorSource.USER,
        action = AuditAction.VEHICLE_UPDATED,
        entityType = AuditEntityType.VEHICLE,
        entityId = entityId,
        vehicleId = entityId,
        summary = summary,
        occurredAtEpochMillis = NOW_EPOCH_MILLIS,
    )
}
