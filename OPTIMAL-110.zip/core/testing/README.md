# :core:testing

مكتبة JVM مشتركة لأدوات الاختبار الحتمية.

توفر:

- `MainDispatcherRule` لاختبارات ViewModel.
- `MutableTestClock` و`fixedTestClock` لاختبارات الوقت والانتهاء وإعادة المحاولة.
- `CoreFixtures` و`DatabaseFixture` لهويات شركتين وقيم ثابتة.
- `MutableSessionReader` و`RecordingAuditPort` و`RecordingTransactionRunner` كـFakes مشتركة.
- `TenantRepositoryContract` لعقد عزل المستودعات حسب الشركة.

لا تعتمد على `core:database` لتجنب دورة اعتماد؛ Builders الخاصة بكيانات Room تبقى داخل اختبارات قاعدة البيانات.
