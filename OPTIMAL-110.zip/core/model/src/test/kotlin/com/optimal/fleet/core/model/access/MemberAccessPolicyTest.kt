package com.optimal.fleet.core.model.access

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MemberAccessPolicyTest {
    @Test
    fun ownerAndManagerDefaultToViewAndSend() {
        listOf(MemberRole.OWNER, MemberRole.MANAGER).forEach { role ->
            assertTrue(can(role, MemberCapability.VIEW_VERTO_CHAT))
            assertTrue(can(role, MemberCapability.SEND_VERTO_CHAT))
        }
    }

    @Test
    fun nonManagerRolesDefaultToNoVertoChatAccess() {
        listOf(
            MemberRole.ENGINEER,
            MemberRole.ACCOUNTANT,
            MemberRole.DRIVER,
            MemberRole.MEMBER,
        ).forEach { role ->
            assertFalse(can(role, MemberCapability.VIEW_VERTO_CHAT))
            assertFalse(can(role, MemberCapability.SEND_VERTO_CHAT))
        }
    }

    @Test
    fun explicitTrueOverridesGrantDelegatedAccess() {
        val overrides = mapOf(
            MemberCapability.VIEW_VERTO_CHAT to true,
            MemberCapability.SEND_VERTO_CHAT to true,
        )
        assertTrue(can(MemberRole.MEMBER, MemberCapability.VIEW_VERTO_CHAT, overrides))
        assertTrue(can(MemberRole.MEMBER, MemberCapability.SEND_VERTO_CHAT, overrides))
    }

    @Test
    fun explicitFalseOverridesRevokeOwnerDefaults() {
        val overrides = mapOf(MemberCapability.VIEW_VERTO_CHAT to false)
        assertFalse(can(MemberRole.OWNER, MemberCapability.VIEW_VERTO_CHAT, overrides))
        assertFalse(can(MemberRole.OWNER, MemberCapability.SEND_VERTO_CHAT, overrides))
    }

    @Test
    fun sendCannotBeGrantedWithoutView() {
        val overrides = mapOf(MemberCapability.SEND_VERTO_CHAT to true)
        assertFalse(can(MemberRole.MEMBER, MemberCapability.SEND_VERTO_CHAT, overrides))
    }

    @Test
    fun inactiveMembersFailClosed() {
        assertFalse(
            MemberAccessPolicy.can(
                role = MemberRole.OWNER,
                permissionOverrides = emptyMap(),
                isActive = false,
                capability = MemberCapability.VIEW_VERTO_CHAT,
            ),
        )
    }

    private fun can(
        role: MemberRole,
        capability: MemberCapability,
        overrides: Map<MemberCapability, Boolean> = emptyMap(),
    ): Boolean = MemberAccessPolicy.can(
        role = role,
        permissionOverrides = overrides,
        isActive = true,
        capability = capability,
    )
}
