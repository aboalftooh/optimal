package com.optimal.fleet.core.model.audit

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuditRedactionTest {
    @Test
    fun sensitiveFieldsAreDroppedBeforePersistence() {
        val sanitized = AuditRedactionPolicy.sanitize(
            AuditEventDraft(
                companyId = "company",
                actorUserId = "user",
                actorSource = AuditActorSource.USER,
                action = AuditAction.MEMBER_UPDATED,
                entityType = AuditEntityType.MEMBER,
                entityId = "user",
                summary = "changed member",
                changes = listOf(
                    AuditFieldChange("displayName", "A", "B"),
                    AuditFieldChange("passwordHash", "old", "new"),
                    AuditFieldChange("accessToken", "old", "new"),
                    AuditFieldChange("attachmentUri", null, "content://private"),
                ),
            ),
        )

        assertEquals(listOf("displayName"), sanitized.changes.map { it.fieldName })
    }

    @Test
    fun unchangedValuesAndControlCharactersAreRemoved() {
        val sanitized = AuditRedactionPolicy.sanitize(
            AuditEventDraft(
                companyId = "company",
                actorUserId = null,
                actorSource = AuditActorSource.SYSTEM,
                action = AuditAction.SYNC_BATCH_COMPLETED,
                entityType = AuditEntityType.SYNC,
                entityId = "batch",
                summary = "batch\ncompleted\t",
                changes = listOf(
                    AuditFieldChange("claimed", "2", "2"),
                    AuditFieldChange("succeeded", null, "2\n"),
                ),
            ),
        )

        assertFalse(sanitized.summary.contains('\n'))
        assertEquals(1, sanitized.changes.size)
        assertEquals("2", sanitized.changes.single().afterValue)
    }

    @Test
    fun storedTextIsBounded() {
        val sanitized = AuditRedactionPolicy.sanitize(
            AuditEventDraft(
                companyId = "company",
                actorUserId = null,
                actorSource = AuditActorSource.VERTO,
                action = AuditAction.INVOICE_IMPORTED,
                entityType = AuditEntityType.INVOICE,
                entityId = "invoice",
                summary = "x".repeat(500),
                changes = (1..50).map { AuditFieldChange("field$it", null, "y".repeat(500)) },
            ),
        )

        assertTrue(sanitized.summary.length <= 240)
        assertEquals(24, sanitized.changes.size)
        assertTrue(sanitized.changes.all { (it.afterValue?.length ?: 0) <= 160 })
    }
}
