package com.optimal.fleet.core.model.audit

object AuditRedactionPolicy {
    private val forbiddenFieldFragments = setOf(
        "password",
        "passcode",
        "token",
        "secret",
        "authorization",
        "cookie",
        "otp",
        "pin",
        "attachmenturi",
        "payload",
    )

    private const val MAX_SUMMARY_LENGTH = 240
    private const val MAX_VALUE_LENGTH = 160
    private const val MAX_CHANGES = 24

    fun sanitize(event: AuditEventDraft): AuditEventDraft = event.copy(
        summary = event.summary.clean(MAX_SUMMARY_LENGTH),
        changes = event.changes
            .asSequence()
            .filterNot { change ->
                val normalized = change.fieldName.lowercase().filter(Char::isLetterOrDigit)
                forbiddenFieldFragments.any(normalized::contains)
            }
            .filter { it.beforeValue != it.afterValue }
            .take(MAX_CHANGES)
            .map { change ->
                change.copy(
                    fieldName = change.fieldName.clean(64),
                    beforeValue = change.beforeValue?.clean(MAX_VALUE_LENGTH),
                    afterValue = change.afterValue?.clean(MAX_VALUE_LENGTH),
                )
            }
            .toList(),
        sourceReference = event.sourceReference?.clean(120),
    )

    private fun String.clean(maxLength: Int): String = replace(Regex("[\\u0000-\\u001F\\u007F]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(maxLength)
}
