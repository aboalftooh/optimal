package com.optimal.fleet.core.model.access

enum class MemberRole(val wireValue: String) {
    OWNER("OWNER"),
    MANAGER("MANAGER"),
    ENGINEER("ENGINEER"),
    ACCOUNTANT("ACCOUNTANT"),
    DRIVER("DRIVER"),
    MEMBER("MEMBER"),
    UNKNOWN("UNKNOWN");

    companion object {
        fun fromWire(value: String): MemberRole =
            values().firstOrNull { it.wireValue == value.trim().uppercase() } ?: UNKNOWN
    }
}

enum class MemberCapability(val wireValue: String) {
    VIEW_MEMBER_DIRECTORY("VIEW_MEMBER_DIRECTORY"),
    CREATE_MEMBER_INVITE("CREATE_MEMBER_INVITE"),
    RESEND_MEMBER_INVITE("RESEND_MEMBER_INVITE"),
    REVOKE_MEMBER_INVITE("REVOKE_MEMBER_INVITE"),
    CHANGE_MEMBER_STATUS("CHANGE_MEMBER_STATUS"),
    VIEW_VERTO_CHAT("VIEW_VERTO_CHAT"),
    SEND_VERTO_CHAT("SEND_VERTO_CHAT");

    companion object {
        fun fromWire(value: String): MemberCapability? =
            values().firstOrNull { it.wireValue == value.trim().uppercase() }
    }
}

/**
 * المصدر المشترك الوحيد لسياسة قدرات الأعضاء داخل Android.
 *
 * قدرات إدارة الأعضاء تحافظ على سلوك المنتج السابق لكل عضو نشط. محادثة Verto
 * متاحة افتراضيًا للمالك والمدير فقط، ويمكن تفويض بقية الأدوار صراحة. الإرسال
 * لا يصبح فعالًا أبدًا ما لم تكن الرؤية فعالة أيضًا.
 */
object MemberAccessPolicy {
    private val memberManagementCapabilities = setOf(
        MemberCapability.VIEW_MEMBER_DIRECTORY,
        MemberCapability.CREATE_MEMBER_INVITE,
        MemberCapability.RESEND_MEMBER_INVITE,
        MemberCapability.REVOKE_MEMBER_INVITE,
        MemberCapability.CHANGE_MEMBER_STATUS,
    )

    private val defaultsByRole: Map<MemberRole, Set<MemberCapability>> = mapOf(
        MemberRole.OWNER to MemberCapability.values().toSet(),
        MemberRole.MANAGER to MemberCapability.values().toSet(),
        MemberRole.ENGINEER to memberManagementCapabilities,
        MemberRole.ACCOUNTANT to memberManagementCapabilities,
        MemberRole.DRIVER to memberManagementCapabilities,
        MemberRole.MEMBER to memberManagementCapabilities,
        MemberRole.UNKNOWN to emptySet(),
    )

    fun capabilities(
        role: MemberRole,
        permissionOverrides: Map<MemberCapability, Boolean>,
        isActive: Boolean,
    ): Set<MemberCapability> {
        if (!isActive || role == MemberRole.UNKNOWN) return emptySet()
        val defaults = defaultsByRole.getValue(role)
        val effective = MemberCapability.values().filterTo(linkedSetOf()) { capability ->
            permissionOverrides[capability] ?: (capability in defaults)
        }
        if (MemberCapability.VIEW_VERTO_CHAT !in effective) {
            effective.remove(MemberCapability.SEND_VERTO_CHAT)
        }
        return effective
    }

    fun can(
        role: MemberRole,
        permissionOverrides: Map<MemberCapability, Boolean>,
        isActive: Boolean,
        capability: MemberCapability,
    ): Boolean = capability in capabilities(role, permissionOverrides, isActive)
}
