package com.optimal.fleet.core.model.paging

/** Pure paging contract shared by domain boundaries without Android dependencies. */
data class PageRequest(val offset: Int, val limit: Int) {
    init {
        require(offset >= 0) { "offset must be non-negative" }
        require(limit in 1..MAX_PAGE_SIZE) { "limit must be between 1 and $MAX_PAGE_SIZE" }
    }

    companion object {
        const val MAX_PAGE_SIZE: Int = 100
    }
}

data class PageSlice<out T>(val items: List<T>, val hasMore: Boolean) {
    fun <R> map(transform: (T) -> R): PageSlice<R> = PageSlice(
        items = items.map(transform),
        hasMore = hasMore,
    )

    companion object {
        fun <T> empty(): PageSlice<T> = PageSlice(emptyList(), hasMore = false)
    }
}

fun <T> List<T>.toPageSlice(requestedLimit: Int): PageSlice<T> {
    require(requestedLimit in 1..PageRequest.MAX_PAGE_SIZE)
    val hasMore = size > requestedLimit
    return PageSlice(
        items = if (hasMore) take(requestedLimit) else this,
        hasMore = hasMore,
    )
}
