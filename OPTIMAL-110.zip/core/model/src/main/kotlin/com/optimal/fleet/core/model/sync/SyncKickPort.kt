package com.optimal.fleet.core.model.sync

/** Requests durable background synchronization after a local synchronized write commits. */
fun interface SyncKickPort {
    fun request(companyId: String)
}
