package com.optimal.fleet.core.model.audit

enum class AuditActorSource {
    USER,
    VERTO,
    SYSTEM,
}

enum class AuditEntityType {
    COMPANY,
    MEMBER,
    VEHICLE,
    MAINTENANCE_OPERATION,
    INVOICE,
    ADDITIONAL_COST,
    SYNC,
}

enum class AuditAction {
    COMPANY_CREATED,
    COMPANY_UPDATED,
    MEMBER_ADDED,
    MEMBER_UPDATED,
    MEMBER_INVITED,
    MEMBER_INVITE_RESENT,
    MEMBER_INVITE_REVOKED,
    MEMBER_JOINED,
    MEMBER_DISABLED,
    MEMBER_ENABLED,
    MEMBER_VERTO_PERMISSIONS_UPDATED,
    VERTO_CHAT_ACCESS_DENIED,
    VEHICLE_CREATED,
    VEHICLE_UPDATED,
    VEHICLE_ARCHIVED,
    MAINTENANCE_CREATED,
    MAINTENANCE_UPDATED,
    MAINTENANCE_COMPLETED,
    MAINTENANCE_IMPORTED,
    FOLLOW_UP_CONVERTED,
    INVOICE_IMPORTED,
    INVOICE_UPDATED,
    INVOICE_VOIDED,
    INVOICE_LINKED,
    ADDITIONAL_COST_CREATED,
    SYNC_BATCH_COMPLETED,
    SYNC_CONFLICT_RESOLVED,
}

data class AuditFieldChange(val fieldName: String, val beforeValue: String?, val afterValue: String?)

data class AuditEventDraft(
    val companyId: String,
    val actorUserId: String?,
    val actorSource: AuditActorSource,
    val action: AuditAction,
    val entityType: AuditEntityType,
    val entityId: String,
    val vehicleId: String? = null,
    val operationId: String? = null,
    val summary: String,
    val changes: List<AuditFieldChange> = emptyList(),
    val sourceReference: String? = null,
    val occurredAtEpochMillis: Long? = null,
)

data class AuditEvent(
    val id: String,
    val companyId: String,
    val actorUserId: String?,
    val actorDisplayName: String,
    val actorSource: AuditActorSource,
    val action: AuditAction,
    val entityType: AuditEntityType,
    val entityId: String,
    val vehicleId: String?,
    val operationId: String?,
    val summary: String,
    val changes: List<AuditFieldChange>,
    val sourceReference: String?,
    val occurredAtEpochMillis: Long,
)
