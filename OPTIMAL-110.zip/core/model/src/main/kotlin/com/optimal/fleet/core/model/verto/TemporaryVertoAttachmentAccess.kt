package com.optimal.fleet.core.model.verto

data class TemporaryVertoAttachment(
    val signedUrl: String,
    val expiresAtEpochMillis: Long,
    val mimeType: String,
    val sizeBytes: Long,
)

sealed interface TemporaryVertoAttachmentResult {
    data class Available(val attachment: TemporaryVertoAttachment) : TemporaryVertoAttachmentResult
    data object NotLinked : TemporaryVertoAttachmentResult
    data object PermissionDenied : TemporaryVertoAttachmentResult
    data class RetryableFailure(val code: String) : TemporaryVertoAttachmentResult
    data class Rejected(val code: String) : TemporaryVertoAttachmentResult
}

interface TemporaryVertoAttachmentAccess {
    suspend fun resolve(attachmentId: String): TemporaryVertoAttachmentResult
}

object UnavailableTemporaryVertoAttachmentAccess : TemporaryVertoAttachmentAccess {
    override suspend fun resolve(attachmentId: String): TemporaryVertoAttachmentResult =
        TemporaryVertoAttachmentResult.RetryableFailure("ATTACHMENT_ACCESS_UNAVAILABLE")
}
