package com.optimal.fleet.core.model.transaction

/**
 * Runs a complete local write boundary as one atomic unit.
 *
 * Production binds this contract to Room. The direct implementation exists only as a
 * lightweight default for pure unit tests whose fakes already provide atomic behavior.
 */
interface AtomicWriteTransactionRunner {
    suspend fun <T> run(block: suspend () -> T): T
}

object DirectAtomicWriteTransactionRunner : AtomicWriteTransactionRunner {
    override suspend fun <T> run(block: suspend () -> T): T = block()
}
