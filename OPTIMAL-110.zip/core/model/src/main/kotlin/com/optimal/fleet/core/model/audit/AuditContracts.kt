package com.optimal.fleet.core.model.audit

import com.optimal.fleet.core.model.paging.PageRequest
import com.optimal.fleet.core.model.paging.PageSlice
import com.optimal.fleet.core.model.paging.toPageSlice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf

interface AuditPort {
    suspend fun append(event: AuditEventDraft)
}

interface ActivityQuery {
    fun observeCompanyActivity(companyId: String, limit: Int = 100): Flow<List<AuditEvent>>

    fun observeEntityActivity(companyId: String, entityType: AuditEntityType, entityId: String, limit: Int = 50): Flow<List<AuditEvent>>

    suspend fun loadCompanyActivityPage(companyId: String, request: PageRequest): PageSlice<AuditEvent> =
        observeCompanyActivity(companyId, request.offset + request.limit + 1)
            .first()
            .drop(request.offset)
            .take(request.limit + 1)
            .toPageSlice(request.limit)

    suspend fun loadEntityActivityPage(
        companyId: String,
        entityType: AuditEntityType,
        entityId: String,
        request: PageRequest,
    ): PageSlice<AuditEvent> = observeEntityActivity(
        companyId = companyId,
        entityType = entityType,
        entityId = entityId,
        limit = request.offset + request.limit + 1,
    ).first()
        .drop(request.offset)
        .take(request.limit + 1)
        .toPageSlice(request.limit)

    fun observeVehicleActivity(companyId: String, vehicleId: String, limit: Int = 20): Flow<List<AuditEvent>>

    fun observeOperationActivity(companyId: String, operationId: String, limit: Int = 20): Flow<List<AuditEvent>>
}

object NoOpAuditPort : AuditPort {
    override suspend fun append(event: AuditEventDraft) = Unit
}

object EmptyActivityQuery : ActivityQuery {
    override fun observeCompanyActivity(companyId: String, limit: Int): Flow<List<AuditEvent>> = flowOf(emptyList())

    override fun observeEntityActivity(
        companyId: String,
        entityType: AuditEntityType,
        entityId: String,
        limit: Int,
    ): Flow<List<AuditEvent>> = flowOf(emptyList())

    override suspend fun loadCompanyActivityPage(companyId: String, request: PageRequest): PageSlice<AuditEvent> = PageSlice.empty()

    override suspend fun loadEntityActivityPage(
        companyId: String,
        entityType: AuditEntityType,
        entityId: String,
        request: PageRequest,
    ): PageSlice<AuditEvent> = PageSlice.empty()

    override fun observeVehicleActivity(companyId: String, vehicleId: String, limit: Int): Flow<List<AuditEvent>> = flowOf(emptyList())

    override fun observeOperationActivity(companyId: String, operationId: String, limit: Int): Flow<List<AuditEvent>> = flowOf(emptyList())
}
