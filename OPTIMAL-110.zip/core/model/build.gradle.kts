plugins {
    id("optimal.kotlin.library")
}

group = "com.optimal.fleet.core.model"

dependencies {
    api(libs.kotlinx.coroutines.core)
    testImplementation(libs.junit4)
}
