package com.optimal.fleet.core.session

import org.junit.Assert.assertEquals
import org.junit.Test

class ActiveSessionTest {
    @Test
    fun keepsCompanyIdentitySeparateFromUserIdentity() {
        val session = ActiveSession(
            userId = "user-1",
            companyId = "company-1",
            userDisplayName = "أحمد",
            companyName = "شركة الندى",
        )

        assertEquals("user-1", session.userId)
        assertEquals("company-1", session.companyId)
    }
}
