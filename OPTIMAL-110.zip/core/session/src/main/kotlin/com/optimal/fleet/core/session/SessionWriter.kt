package com.optimal.fleet.core.session

interface SessionWriter {
    suspend fun saveActiveSession(session: ActiveSession)

    suspend fun clearActiveSession()
}
