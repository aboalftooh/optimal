package com.optimal.fleet.core.session

interface MemberSessionInvalidator {
    suspend fun invalidateMemberSession(companyId: String, userId: String)
}
