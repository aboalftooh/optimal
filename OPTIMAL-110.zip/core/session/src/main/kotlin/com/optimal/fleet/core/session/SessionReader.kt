package com.optimal.fleet.core.session

import kotlinx.coroutines.flow.Flow

interface SessionReader {
    fun observeActiveSession(): Flow<ActiveSession?>

    suspend fun currentSession(): ActiveSession?
}
