package com.optimal.fleet.core.session

data class SessionIdentity(
    val userId: String,
    val companyId: String,
) {
    init {
        require(userId.isNotBlank()) { "Session userId must not be blank" }
        require(companyId.isNotBlank()) { "Session companyId must not be blank" }
    }

    fun matches(session: ActiveSession?): Boolean =
        session != null && session.userId == userId && session.companyId == companyId
}

fun ActiveSession.identity(): SessionIdentity = SessionIdentity(
    userId = userId,
    companyId = companyId,
)
