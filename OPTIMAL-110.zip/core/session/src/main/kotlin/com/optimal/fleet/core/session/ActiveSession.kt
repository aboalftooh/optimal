package com.optimal.fleet.core.session

data class ActiveSession(val userId: String, val companyId: String, val userDisplayName: String, val companyName: String)
