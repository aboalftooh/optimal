# :core:network

تهيئة Retrofit/OkHttp/Serialization فقط. لا يوجد API عقده غير محسومة قبل v03.
