package com.optimal.fleet.core.network.supabase

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SupabaseAuthSession(
    @SerialName("access_token") val accessToken: String,
    @SerialName("refresh_token") val refreshToken: String,
    @SerialName("expires_in") val expiresInSeconds: Long,
    @SerialName("expires_at") val expiresAtEpochSeconds: Long? = null,
    @SerialName("token_type") val tokenType: String = "bearer",
    val user: SupabaseAuthUser? = null,
) {
    fun resolvedExpiryEpochSeconds(nowEpochSeconds: Long): Long = expiresAtEpochSeconds ?: (nowEpochSeconds + expiresInSeconds)
}

@Serializable
data class SupabaseAuthUser(val id: String, val phone: String? = null)
