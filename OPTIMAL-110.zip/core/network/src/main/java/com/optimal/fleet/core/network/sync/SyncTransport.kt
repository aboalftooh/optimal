package com.optimal.fleet.core.network.sync

data class SyncEnvelope(
    val companyId: String,
    val aggregateType: String,
    val aggregateId: String,
    val operationType: String,
    val payload: String,
    val idempotencyKey: String,
    val localVersion: Long,
    val remoteId: String?,
    val remoteVersion: Long?,
)

sealed interface SyncPushResult {
    data class Success(val remoteId: String?, val remoteVersion: Long?) : SyncPushResult

    data class RetryableFailure(val code: String, val correlationId: String? = null) : SyncPushResult

    data class PermanentFailure(val code: String, val correlationId: String? = null) : SyncPushResult

    data class Conflict(
        val remoteVersion: Long,
        val remotePayload: String,
        val remoteUpdatedAtEpochMillis: Long? = null,
        val remoteIdempotencyKey: String? = null,
        val remoteId: String? = null,
        val correlationId: String? = null,
    ) : SyncPushResult
}

interface SyncTransport {
    suspend fun push(envelope: SyncEnvelope): SyncPushResult

    suspend fun resolveConflict(envelope: SyncEnvelope, winningPayload: String, winningVersion: Long): SyncPushResult
}
