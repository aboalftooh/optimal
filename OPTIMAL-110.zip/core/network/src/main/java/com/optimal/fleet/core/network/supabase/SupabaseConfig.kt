package com.optimal.fleet.core.network.supabase

interface SupabaseConfig {
    val baseUrl: String
    val anonKey: String

    val isConfigured: Boolean
        get() = baseUrl.startsWith("https://") && anonKey.isSafeClientKey()

    private fun String.isSafeClientKey(): Boolean {
        val value = trim()
        return value.isNotBlank() &&
            !value.startsWith("sbp_", ignoreCase = true) &&
            !value.startsWith("sb_secret_", ignoreCase = true)
    }
}

class SupabaseNotConfiguredException :
    IllegalStateException(
        "Supabase is not configured. Set SUPABASE_URL and SUPABASE_ANON_KEY.",
    )
