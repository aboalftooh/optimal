package com.optimal.fleet.core.network.verto

import com.optimal.fleet.core.model.verto.TemporaryVertoAttachment
import com.optimal.fleet.core.model.verto.TemporaryVertoAttachmentAccess
import com.optimal.fleet.core.model.verto.TemporaryVertoAttachmentResult
import com.optimal.fleet.core.network.supabase.AuthSessionStore
import com.optimal.fleet.core.network.supabase.SupabaseConfig
import com.optimal.fleet.core.network.supabase.SupabaseRetrofit
import java.net.URI
import java.time.Instant
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.POST

@Singleton
class SupabaseTemporaryVertoAttachmentAccess @Inject constructor(
    @SupabaseRetrofit retrofit: Retrofit,
    private val config: SupabaseConfig,
    private val authSessionStore: AuthSessionStore,
) : TemporaryVertoAttachmentAccess {
    private val api = retrofit.create(TemporaryVertoAttachmentApi::class.java)

    override suspend fun resolve(attachmentId: String): TemporaryVertoAttachmentResult {
        val normalizedId = runCatching { UUID.fromString(attachmentId.trim()).toString() }.getOrNull()
            ?: return TemporaryVertoAttachmentResult.Rejected("INVALID_ATTACHMENT_ID")
        if (!config.isConfigured) {
            return TemporaryVertoAttachmentResult.RetryableFailure("SUPABASE_NOT_CONFIGURED")
        }
        if (authSessionStore.current() == null) return TemporaryVertoAttachmentResult.PermissionDenied

        return try {
            val response = api.resolve(TemporaryAttachmentAccessRequest(normalizedId))
            if (!response.isSuccessful) return mapFailure(response)
            val body = response.body()
                ?: return TemporaryVertoAttachmentResult.RetryableFailure("EMPTY_ATTACHMENT_ACCESS_RESPONSE")
            val uri = runCatching { URI(body.signedUrl.trim()) }.getOrNull()
            val expiresAt = runCatching { Instant.parse(body.expiresAt).toEpochMilli() }.getOrNull()
            val isValid = uri != null && uri.isAbsolute && uri.host != null &&
                uri.scheme?.lowercase() in setOf("https", "http") &&
                expiresAt != null && body.mimeType.startsWith("image/") && body.sizeBytes > 0L
            if (!isValid) {
                TemporaryVertoAttachmentResult.Rejected("INVALID_SIGNED_URL_RESPONSE")
            } else {
                TemporaryVertoAttachmentResult.Available(
                    TemporaryVertoAttachment(
                        signedUrl = uri.toString(),
                        expiresAtEpochMillis = requireNotNull(expiresAt),
                        mimeType = body.mimeType,
                        sizeBytes = body.sizeBytes,
                    ),
                )
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: Exception) {
            TemporaryVertoAttachmentResult.RetryableFailure("VERTO_ATTACHMENT_NETWORK_UNAVAILABLE")
        }
    }

    private fun mapFailure(response: Response<*>): TemporaryVertoAttachmentResult {
        val body = runCatching { response.errorBody()?.string().orEmpty().lowercase() }.getOrDefault("")
        return when {
            response.code() == 404 || "verto_link_missing" in body || "verto_link_inactive" in body ->
                TemporaryVertoAttachmentResult.NotLinked
            response.code() == 401 || response.code() == 403 || "permission" in body || "capability" in body ->
                TemporaryVertoAttachmentResult.PermissionDenied
            response.code() in setOf(408, 425, 429) || response.code() >= 500 || "backend_not_ready" in body ->
                TemporaryVertoAttachmentResult.RetryableFailure("VERTO_ATTACHMENT_HTTP_${response.code()}")
            "attachment_not_ready" in body || "not_ready" in body ->
                TemporaryVertoAttachmentResult.RetryableFailure("ATTACHMENT_NOT_READY")
            "attachment_not_found" in body ->
                TemporaryVertoAttachmentResult.Rejected("ATTACHMENT_NOT_FOUND")
            else -> TemporaryVertoAttachmentResult.Rejected("VERTO_ATTACHMENT_REJECTED_${response.code()}")
        }
    }
}

private interface TemporaryVertoAttachmentApi {
    @POST("functions/v1/verto-attachment-access")
    suspend fun resolve(
        @Body request: TemporaryAttachmentAccessRequest,
    ): Response<TemporaryAttachmentAccessDto>
}

@Serializable
private data class TemporaryAttachmentAccessRequest(
    @SerialName("attachment_id") val attachmentId: String,
)

@Serializable
private data class TemporaryAttachmentAccessDto(
    @SerialName("signed_url") val signedUrl: String,
    @SerialName("expires_at") val expiresAt: String,
    @SerialName("mime_type") val mimeType: String,
    @SerialName("size_bytes") val sizeBytes: Long,
)
