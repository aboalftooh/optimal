package com.optimal.fleet.core.network.supabase

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.optimal.fleet.core.common.error.DomainErrorException
import com.optimal.fleet.core.common.error.DomainErrorMapper
import com.optimal.fleet.core.common.error.ErrorContext
import com.optimal.fleet.core.common.error.InfrastructureBoundary
import com.optimal.fleet.core.common.error.NoOpSafeErrorReporter
import com.optimal.fleet.core.common.error.SafeErrorReporter
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.serialization.json.Json

class AndroidKeystoreAuthSessionStore(
    context: Context,
    private val json: Json,
    private val errorReporter: SafeErrorReporter = NoOpSafeErrorReporter,
) : AuthSessionStore {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    private val lock = Any()

    @Volatile
    private var cached: SupabaseAuthSession? = readEncrypted()

    override fun current(): SupabaseAuthSession? = cached

    override fun save(session: SupabaseAuthSession) = synchronized(lock) {
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val plaintext = json.encodeToString(SupabaseAuthSession.serializer(), session)
                .toByteArray(StandardCharsets.UTF_8)
            val ciphertext = cipher.doFinal(plaintext)
            val committed = preferences.edit()
                .putString(KEY_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .putString(KEY_CIPHERTEXT, Base64.encodeToString(ciphertext, Base64.NO_WRAP))
                .commit()
            check(committed) { "Unable to persist encrypted auth session" }
            cached = session
        } catch (error: Exception) {
            throw reportAndWrap(error, "auth_session.save")
        }
    }

    override fun clear() = synchronized(lock) {
        try {
            val committed = preferences.edit().clear().commit()
            check(committed) { "Unable to clear encrypted auth session" }
            cached = null
        } catch (error: Exception) {
            throw reportAndWrap(error, "auth_session.clear")
        }
    }

    private fun readEncrypted(): SupabaseAuthSession? {
        return try {
            val iv = preferences.getString(KEY_IV, null) ?: return null
            val ciphertext = preferences.getString(KEY_CIPHERTEXT, null) ?: return null
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                getOrCreateKey(),
                GCMParameterSpec(TAG_LENGTH_BITS, Base64.decode(iv, Base64.NO_WRAP)),
            )
            val plaintext = cipher.doFinal(Base64.decode(ciphertext, Base64.NO_WRAP))
            json.decodeFromString(
                SupabaseAuthSession.serializer(),
                String(plaintext, StandardCharsets.UTF_8),
            )
        } catch (error: Exception) {
            val failure = DomainErrorMapper.fromThrowable(
                throwable = error,
                context = ErrorContext(
                    operation = "auth_session.read",
                    boundary = InfrastructureBoundary.STORAGE,
                ),
            )
            errorReporter.report(failure)
            preferences.edit().clear().commit()
            null
        }
    }

    private fun reportAndWrap(error: Exception, operation: String): DomainErrorException {
        val failure = DomainErrorMapper.fromThrowable(
            throwable = error,
            context = ErrorContext(operation, InfrastructureBoundary.STORAGE),
        )
        errorReporter.report(failure)
        return DomainErrorException(failure.error, error)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val PREFERENCES_NAME = "optimal_auth_session"
        const val KEY_IV = "iv"
        const val KEY_CIPHERTEXT = "ciphertext"
        const val KEY_ALIAS = "optimal_auth_session_v1"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val TAG_LENGTH_BITS = 128
    }
}
