package com.optimal.fleet.core.network.supabase

interface AuthSessionStore {
    fun current(): SupabaseAuthSession?

    fun save(session: SupabaseAuthSession)

    fun clear()
}
