package com.optimal.fleet.core.network.sync

/**
 * Authoritative server delta row exposed to the synchronization integration layer.
 * [companyId] is the local Room company identity requested by the caller.
 */
data class SyncRemoteChange(
    val revision: Long,
    val companyId: String,
    val aggregateType: String,
    val aggregateId: String,
    val operationType: String,
    val payload: String,
    val remoteId: String?,
    val remoteVersion: Long?,
    val originLocalVersion: Long?,
    val idempotencyKey: String?,
    val deletedAtEpochMillis: Long?,
    val changedAtEpochMillis: Long,
)

data class SyncPullPage(
    val changes: List<SyncRemoteChange>,
    val hasMore: Boolean,
)

sealed interface SyncPullResult {
    data class Success(val page: SyncPullPage) : SyncPullResult

    data class RetryableFailure(val code: String, val correlationId: String? = null) : SyncPullResult

    data class PermanentFailure(val code: String, val correlationId: String? = null) : SyncPullResult
}

/**
 * Pull transport only. Push/conflict responsibilities stay on [SyncTransport].
 */
interface SyncPullTransport {
    suspend fun pull(
        companyId: String,
        afterRevision: Long,
    ): SyncPullResult

    companion object {
        const val PAGE_LIMIT = 100
    }
}
