package com.optimal.fleet.core.network.supabase

import javax.inject.Qualifier
import okhttp3.Interceptor
import okhttp3.Response

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class SupabaseRetrofit

class SupabaseAuthInterceptor(private val config: SupabaseConfig, private val sessionStore: AuthSessionStore) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        if (!config.isConfigured) throw SupabaseNotConfiguredException()
        val original = chain.request()
        val authorization = original.header("Authorization")
            ?: sessionStore.current()?.accessToken?.let { "Bearer $it" }
            ?: "Bearer ${config.anonKey}"
        val request = original.newBuilder()
            .header("apikey", config.anonKey)
            .header("Authorization", authorization)
            .header("Accept", "application/json")
            .build()
        return chain.proceed(request)
    }
}
