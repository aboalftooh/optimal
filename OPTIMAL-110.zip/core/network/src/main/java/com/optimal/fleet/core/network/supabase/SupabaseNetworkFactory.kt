package com.optimal.fleet.core.network.supabase

import android.content.Context
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.optimal.fleet.core.common.error.SafeErrorReporter
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit

object SupabaseNetworkFactory {
    fun createJson(): Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        encodeDefaults = true
    }

    fun createSessionStore(context: Context, json: Json, errorReporter: SafeErrorReporter): AuthSessionStore =
        AndroidKeystoreAuthSessionStore(
            context = context.applicationContext,
            json = json,
            errorReporter = errorReporter,
        )

    fun createRetrofit(config: SupabaseConfig, sessionStore: AuthSessionStore, json: Json): Retrofit {
        val client = OkHttpClient.Builder()
            .addInterceptor(SupabaseAuthInterceptor(config, sessionStore))
            .build()
        val baseUrl = if (config.isConfigured) {
            config.baseUrl.trimEnd('/') + "/"
        } else {
            INVALID_BASE_URL
        }
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory(JSON_MEDIA_TYPE.toMediaType()))
            .build()
    }

    private const val INVALID_BASE_URL = "https://supabase.invalid/"
    private const val JSON_MEDIA_TYPE = "application/json"
}
