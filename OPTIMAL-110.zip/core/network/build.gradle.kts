plugins {
    id("optimal.android.library")
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.optimal.fleet.core.network"
}

dependencies {
    implementation(project(":core:common"))
    implementation(project(":core:model"))
    api(libs.retrofit.core)
    implementation(libs.retrofit.kotlinx.serialization)
    implementation(libs.okhttp.core)
    implementation(libs.okhttp.logging)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.hilt.android)
    testImplementation(project(":core:testing"))
    testImplementation(libs.junit4)
}
