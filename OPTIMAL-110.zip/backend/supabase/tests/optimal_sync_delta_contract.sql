-- Catalog-level contract checks for v91 after applying the migration.
-- Intended for a Supabase/PostgreSQL verification environment.

begin;

do $$
begin
    if to_regclass('public.optimal_sync_change_log') is null then
        raise exception 'missing optimal_sync_change_log';
    end if;

    if not exists (
        select 1 from pg_class
        where oid = 'public.optimal_sync_change_log'::regclass
          and relrowsecurity
    ) then
        raise exception 'RLS must be enabled on optimal_sync_change_log';
    end if;

    if not exists (
        select 1 from pg_indexes
        where schemaname = 'public'
          and tablename = 'optimal_sync_change_log'
          and indexname = 'optimal_sync_change_log_company_revision_idx'
    ) then
        raise exception 'missing company/revision index';
    end if;

    if not exists (
        select 1 from pg_indexes
        where schemaname = 'public'
          and tablename = 'optimal_sync_change_log'
          and indexname = 'optimal_sync_change_log_company_idempotency_idx'
          and indexdef ilike '%unique%'
    ) then
        raise exception 'missing unique company/idempotency index';
    end if;

    if has_table_privilege('authenticated', 'public.optimal_sync_change_log', 'INSERT')
       or has_table_privilege('authenticated', 'public.optimal_sync_change_log', 'UPDATE')
       or has_table_privilege('authenticated', 'public.optimal_sync_change_log', 'DELETE') then
        raise exception 'authenticated role must not mutate sync change log directly';
    end if;

    if not has_table_privilege('authenticated', 'public.optimal_sync_change_log', 'SELECT') then
        raise exception 'authenticated role needs SELECT for tenant-scoped Realtime hints';
    end if;

    if to_regprocedure('public.optimal_pull_sync_changes(uuid,bigint,integer)') is null then
        raise exception 'missing optimal_pull_sync_changes';
    end if;

    if to_regprocedure('public.optimal_apply_sync_operation_v2(uuid,text,text,text,jsonb,text,bigint)') is null then
        raise exception 'missing optimal_apply_sync_operation_v2';
    end if;

    if to_regprocedure('public.optimal_resolve_sync_conflict_v2(uuid,text,text,text,jsonb,bigint,text)') is null then
        raise exception 'missing optimal_resolve_sync_conflict_v2';
    end if;

    if not has_function_privilege(
        'authenticated',
        'public.optimal_pull_sync_changes(uuid,bigint,integer)',
        'EXECUTE'
    ) then
        raise exception 'authenticated role needs pull RPC execute';
    end if;
end;
$$;

rollback;
