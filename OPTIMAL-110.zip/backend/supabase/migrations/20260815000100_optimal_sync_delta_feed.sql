-- OPTIMAL v91: durable generic delta feed for VEHICLE / MAINTENANCE / FOLLOW_UP.
-- Realtime observes INSERTs only as hints; authoritative data is pulled through
-- public.optimal_pull_sync_changes().

create sequence if not exists public.optimal_sync_change_revision_seq as bigint;

revoke all on sequence public.optimal_sync_change_revision_seq from public, anon, authenticated;

create table if not exists public.optimal_sync_change_log (
    revision bigint primary key,
    company_id uuid not null,
    aggregate_type text not null,
    aggregate_id text not null,
    operation_type text not null,
    payload jsonb not null,
    remote_id text null,
    remote_version bigint null,
    origin_local_version bigint null,
    idempotency_key text null,
    deleted_at timestamptz null,
    changed_at timestamptz not null default now(),
    constraint optimal_sync_change_log_revision_positive check (revision > 0),
    constraint optimal_sync_change_log_aggregate_type_v1 check (
        aggregate_type in ('VEHICLE', 'MAINTENANCE', 'FOLLOW_UP')
    )
);

create index if not exists optimal_sync_change_log_company_revision_idx
    on public.optimal_sync_change_log (company_id, revision);

create unique index if not exists optimal_sync_change_log_company_idempotency_idx
    on public.optimal_sync_change_log (company_id, idempotency_key)
    where idempotency_key is not null;

alter table public.optimal_sync_change_log enable row level security;

revoke all on table public.optimal_sync_change_log from public, anon, authenticated;
grant select on table public.optimal_sync_change_log to authenticated;

-- Tenant-scoped SELECT is required for the later Realtime hint layer. Android
-- receives no INSERT / UPDATE / DELETE grant on this table.
drop policy if exists optimal_sync_change_log_member_select on public.optimal_sync_change_log;
create policy optimal_sync_change_log_member_select
    on public.optimal_sync_change_log
    for select
    to authenticated
    using (public.optimal_is_active_company_member(company_id));

-- Every INSERT receives its revision only after obtaining the same per-company
-- transaction lock used by V2 wrappers. This prevents a later revision for that
-- company from committing while an earlier assigned revision is still invisible.
create or replace function public.optimal_assign_sync_change_revision()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
    perform pg_advisory_xact_lock(hashtextextended(new.company_id::text, 704915091));
    new.revision := nextval('public.optimal_sync_change_revision_seq'::regclass);
    return new;
end;
$$;

revoke all on function public.optimal_assign_sync_change_revision() from public, anon, authenticated;

do $$
begin
    if not exists (
        select 1
        from pg_trigger
        where tgrelid = 'public.optimal_sync_change_log'::regclass
          and tgname = 'optimal_sync_change_log_assign_revision'
          and not tgisinternal
    ) then
        execute $trigger$
            create trigger optimal_sync_change_log_assign_revision
            before insert on public.optimal_sync_change_log
            for each row
            execute function public.optimal_assign_sync_change_revision()
        $trigger$;
    end if;
end;
$$;

-- The feed is append-only even for ordinary privileged writers. Migration owners
-- can still alter/drop schema explicitly when a future protocol version requires it.
create or replace function public.optimal_reject_sync_change_log_mutation()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
    raise exception using
        errcode = '55000',
        message = 'optimal_sync_change_log_is_append_only';
end;
$$;

revoke all on function public.optimal_reject_sync_change_log_mutation() from public, anon, authenticated;

do $$
begin
    if not exists (
        select 1
        from pg_trigger
        where tgrelid = 'public.optimal_sync_change_log'::regclass
          and tgname = 'optimal_sync_change_log_no_update_delete'
          and not tgisinternal
    ) then
        execute $trigger$
            create trigger optimal_sync_change_log_no_update_delete
            before update or delete on public.optimal_sync_change_log
            for each row
            execute function public.optimal_reject_sync_change_log_mutation()
        $trigger$;
    end if;
end;
$$;

-- Revisions for one company are assigned only while its transaction-scoped lock
-- is held by the V2 wrappers. Cursors are per company, so this preserves safe
-- per-tenant commit order without globally serializing unrelated companies.

create or replace function public.optimal_apply_sync_operation_v2(
    p_company_id uuid,
    p_aggregate_type text,
    p_aggregate_id text,
    p_operation_type text,
    p_payload jsonb,
    p_idempotency_key text,
    p_local_version bigint
)
returns table (
    status text,
    remote_id text,
    remote_version bigint,
    remote_payload jsonb,
    remote_updated_at_epoch_millis bigint,
    remote_idempotency_key text,
    error_code text
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
    v_result jsonb;
begin
    if auth.uid() is null then
        raise exception using errcode = '42501', message = 'auth_session_required';
    end if;
    if not public.optimal_is_active_company_member(p_company_id) then
        raise exception using errcode = '42501', message = 'active_membership_required';
    end if;

    perform pg_advisory_xact_lock(hashtextextended(p_company_id::text, 704915091));

    select to_jsonb(v1)
      into strict v_result
      from public.optimal_apply_sync_operation(
          p_company_id => p_company_id,
          p_aggregate_type => p_aggregate_type,
          p_aggregate_id => p_aggregate_id,
          p_operation_type => p_operation_type,
          p_payload => p_payload,
          p_idempotency_key => p_idempotency_key,
          p_local_version => p_local_version
      ) as v1;

    if upper(coalesce(v_result ->> 'status', '')) = 'SUCCESS' then
        insert into public.optimal_sync_change_log (
            company_id,
            aggregate_type,
            aggregate_id,
            operation_type,
            payload,
            remote_id,
            remote_version,
            origin_local_version,
            idempotency_key,
            deleted_at
        ) values (
            p_company_id,
            p_aggregate_type,
            p_aggregate_id,
            p_operation_type,
            p_payload,
            nullif(v_result ->> 'remote_id', ''),
            nullif(v_result ->> 'remote_version', '')::bigint,
            p_local_version,
            p_idempotency_key,
            null
        )
        on conflict (company_id, idempotency_key)
            where idempotency_key is not null
        do nothing;
    end if;

    return query
    select
        v_result ->> 'status',
        nullif(v_result ->> 'remote_id', ''),
        nullif(v_result ->> 'remote_version', '')::bigint,
        v_result -> 'remote_payload',
        nullif(v_result ->> 'remote_updated_at_epoch_millis', '')::bigint,
        nullif(v_result ->> 'remote_idempotency_key', ''),
        nullif(v_result ->> 'error_code', '');
end;
$$;

revoke all on function public.optimal_apply_sync_operation_v2(uuid, text, text, text, jsonb, text, bigint)
    from public, anon;
grant execute on function public.optimal_apply_sync_operation_v2(uuid, text, text, text, jsonb, text, bigint)
    to authenticated;

create or replace function public.optimal_resolve_sync_conflict_v2(
    p_company_id uuid,
    p_aggregate_type text,
    p_aggregate_id text,
    p_operation_type text,
    p_winning_payload jsonb,
    p_winning_version bigint,
    p_idempotency_key text
)
returns table (
    status text,
    remote_id text,
    remote_version bigint,
    remote_payload jsonb,
    remote_updated_at_epoch_millis bigint,
    remote_idempotency_key text,
    error_code text
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
    v_result jsonb;
begin
    if auth.uid() is null then
        raise exception using errcode = '42501', message = 'auth_session_required';
    end if;
    if not public.optimal_is_active_company_member(p_company_id) then
        raise exception using errcode = '42501', message = 'active_membership_required';
    end if;

    perform pg_advisory_xact_lock(hashtextextended(p_company_id::text, 704915091));

    select to_jsonb(v1)
      into strict v_result
      from public.optimal_resolve_sync_conflict(
          p_company_id => p_company_id,
          p_aggregate_type => p_aggregate_type,
          p_aggregate_id => p_aggregate_id,
          p_operation_type => p_operation_type,
          p_winning_payload => p_winning_payload,
          p_winning_version => p_winning_version,
          p_idempotency_key => p_idempotency_key
      ) as v1;

    if upper(coalesce(v_result ->> 'status', '')) = 'SUCCESS' then
        insert into public.optimal_sync_change_log (
            company_id,
            aggregate_type,
            aggregate_id,
            operation_type,
            payload,
            remote_id,
            remote_version,
            origin_local_version,
            idempotency_key,
            deleted_at
        ) values (
            p_company_id,
            p_aggregate_type,
            p_aggregate_id,
            p_operation_type,
            p_winning_payload,
            nullif(v_result ->> 'remote_id', ''),
            nullif(v_result ->> 'remote_version', '')::bigint,
            p_winning_version,
            p_idempotency_key,
            null
        )
        on conflict (company_id, idempotency_key)
            where idempotency_key is not null
        do nothing;
    end if;

    return query
    select
        v_result ->> 'status',
        nullif(v_result ->> 'remote_id', ''),
        nullif(v_result ->> 'remote_version', '')::bigint,
        v_result -> 'remote_payload',
        nullif(v_result ->> 'remote_updated_at_epoch_millis', '')::bigint,
        nullif(v_result ->> 'remote_idempotency_key', ''),
        nullif(v_result ->> 'error_code', '');
end;
$$;

revoke all on function public.optimal_resolve_sync_conflict_v2(uuid, text, text, text, jsonb, bigint, text)
    from public, anon;
grant execute on function public.optimal_resolve_sync_conflict_v2(uuid, text, text, text, jsonb, bigint, text)
    to authenticated;

create or replace function public.optimal_pull_sync_changes(
    p_company_id uuid,
    p_after_revision bigint,
    p_limit integer
)
returns jsonb
language plpgsql
security definer
stable
set search_path = public, pg_temp
as $$
declare
    v_result jsonb;
begin
    if auth.uid() is null then
        raise exception using errcode = '42501', message = 'auth_session_required';
    end if;
    if not public.optimal_is_active_company_member(p_company_id) then
        raise exception using errcode = '42501', message = 'active_membership_required';
    end if;
    if p_after_revision is null or p_after_revision < 0 then
        raise exception using errcode = '22023', message = 'invalid_after_revision';
    end if;
    if p_limit is null or p_limit < 1 or p_limit > 200 then
        raise exception using errcode = '22023', message = 'invalid_pull_limit';
    end if;

    with candidates as materialized (
        select
            c.revision,
            c.company_id,
            c.aggregate_type,
            c.aggregate_id,
            c.operation_type,
            c.payload,
            c.remote_id,
            c.remote_version,
            c.origin_local_version,
            c.idempotency_key,
            c.deleted_at,
            c.changed_at
        from public.optimal_sync_change_log c
        where c.company_id = p_company_id
          and c.revision > p_after_revision
          and c.aggregate_type in ('VEHICLE', 'MAINTENANCE', 'FOLLOW_UP')
        order by c.revision asc
        limit p_limit + 1
    ), page_rows as (
        select
            c.revision,
            c.company_id::text as company_id,
            c.aggregate_type,
            c.aggregate_id,
            c.operation_type,
            c.payload,
            c.remote_id,
            c.remote_version,
            c.origin_local_version,
            c.idempotency_key,
            case
                when c.deleted_at is null then null
                else floor(extract(epoch from c.deleted_at) * 1000)::bigint
            end as deleted_at_epoch_millis,
            floor(extract(epoch from c.changed_at) * 1000)::bigint as changed_at_epoch_millis
        from candidates c
        order by c.revision asc
        limit p_limit
    )
    select jsonb_build_object(
        'changes', coalesce(
            (select jsonb_agg(to_jsonb(p) order by p.revision) from page_rows p),
            '[]'::jsonb
        ),
        'has_more', (select count(*) > p_limit from candidates)
    )
    into v_result;

    return v_result;
end;
$$;

revoke all on function public.optimal_pull_sync_changes(uuid, bigint, integer)
    from public, anon;
grant execute on function public.optimal_pull_sync_changes(uuid, bigint, integer)
    to authenticated;

-- Prepare the table for Session 94 Realtime INSERT hints when the standard
-- Supabase publication exists. The Pull RPC remains the correctness path.
do $$
begin
    if exists (
        select 1 from pg_publication where pubname = 'supabase_realtime'
    ) and not exists (
        select 1
        from pg_publication_tables
        where pubname = 'supabase_realtime'
          and schemaname = 'public'
          and tablename = 'optimal_sync_change_log'
    ) then
        execute 'alter publication supabase_realtime add table public.optimal_sync_change_log';
    end if;
end;
$$;
