#!/usr/bin/env python3
from collections import Counter
from pathlib import Path
import hashlib
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications"


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def tree_hash(rel: str) -> str:
    h = hashlib.sha256()
    for path in sorted((ROOT / rel).rglob("*")):
        if not path.is_file():
            continue
        h.update(path.relative_to(ROOT).as_posix().encode())
        h.update(b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


checks: list[tuple[str, bool, str]] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    checks.append((label, bool(condition), detail))


screen = read(f"{BASE}/presentation/NotificationsScreen.kt")
components = read(f"{BASE}/presentation/NotificationsComponents.kt")
route = read(f"{BASE}/presentation/NotificationsRoute.kt")
test = read("feature/notifications/src/androidTest/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreenV106Test.kt")

# Presentation-only design-system migration.
for name, source in [("screen", screen), ("components", components), ("route", route)]:
    check(f"{name} has no legacy DS import", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", source) is None)
    check(f"{name} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", source) is None)
    check(f"{name} has no raw hex color", "Color(0x" not in source)
    check(f"{name} has no raw font size", re.search(r"fontSize\s*=\s*\d+(?:\.\d+)?\.sp\b", source) is None)
    check(f"{name} has no raw rounded shape", "RoundedCornerShape(" not in source)
    check(f"{name} has no direct Material text field", re.search(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(", source) is None)
    check(f"{name} has no direct Material button", re.search(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(", source) is None)
    check(f"{name} has no direct AlertDialog", re.search(r"(?<![A-Za-z0-9_])AlertDialog\s*\(", source) is None)

# SCR-026 and STA-069..073 canonical states.
for token in ["OptimalLoadingState", "OptimalErrorState", "NotificationsEmpty", "OptimalInlineStatus", "OptimalSecondaryButton"]:
    check(f"screen uses {token}", token in screen)
for tag in ["destination-notifications", "notifications-loading", "notifications-error", "notifications-empty", "notifications-list", "notifications-load-more", "notifications-append-error"]:
    check(f"screen exposes {tag}", f'"{tag}"' in screen)
for event in ["Refresh", "LoadMore", "OpenNotification"]:
    check(f"screen preserves event {event}", f"NotificationsUiEvent.{event}" in screen)
check("loading state has canonical copy", 'message = "جارٍ تحميل الإشعارات"' in screen)
check("full error retries through Refresh", "NotificationsUiEvent.Refresh" in screen and "onRetry" in screen)
check("append error uses danger semantic", "OptimalStatusTone.Danger" in screen)
check("pagination loading label preserved", 'if (state.isLoadingMore) "جارٍ التحميل" else "تحميل المزيد"' in screen)
check("pagination disablement preserved", "enabled = state.hasMore && !state.isLoadingMore" in screen)
check("notification target event uses stable id", "OpenNotification(item.id)" in screen)

# Header, message and row grammar.
for token in ["OptimalSectionHeader", "OptimalListRow", "OptimalStatusBadge", "OptimalInlineStatus", "OptimalTertiaryButton", "OptimalSecondaryButton"]:
    check(f"components use {token}", token in components)
for tag in ["notification-unread-count", "refresh-notifications", "mark-all-notifications-read", "notifications-message", "notification-${item.id}", "notification-action-${item.id}"]:
    check(f"components expose {tag}", f'"{tag}"' in components)
check("header preserves unread count", "state.unreadCount" in components)
check("refresh remains disabled while refreshing", "enabled = !state.isRefreshing" in components)
check("mark all remains disabled when no unread", "enabled = state.unreadCount > 0" in components)
check("header refresh event preserved", "NotificationsUiEvent.Refresh" in components)
check("header mark-all event preserved", "NotificationsUiEvent.MarkAllRead" in components)
check("center message uses canonical semantic feedback", "fun NotificationsMessage" in components and "OptimalInlineStatus(" in components)
check("read status text is explicit", '"مقروء"' in components)
check("unread status text is explicit", '"جديد"' in components)
check("read/unread tone is semantic", "OptimalStatusTone.Neutral" in components and "OptimalStatusTone.Info" in components)
check("read/unread icon state differs", "Icons.Outlined.DoneAll" in components and "Icons.Outlined.Notifications" in components)
check("row exposes accessibility state description", "stateDescription = statusText" in components)
check("row preserves action label", "text = item.actionLabel" in components and "onClickLabel = item.actionLabel" in components)

# Focused UI coverage source.
for test_name in [
    "loadingEmptyAndMessageStatesRemainVisible",
    "emptyStateUsesCanonicalEmptyPresentation",
    "appendErrorKeepsLoadMoreEvent",
    "readAndUnreadRowsExposeTextStatusAndKeepOpenEvent",
]:
    check(f"v106 UI test {test_name}", test_name in test)

# Functional freeze against supplied OPTIMAL-v105.
expected_hashes = {
    f"{BASE}/presentation/NotificationsContract.kt": "7e2babf6796e43995cd085f0d81bb0113c3ea5990d7cfee9b867615c63afd3a7",
    f"{BASE}/presentation/NotificationsViewModel.kt": "560e7686686e90bbe69028cfa70649f9202731ddd4d28b2bf8d146beacf05510",
    f"{BASE}/navigation/NotificationsNavigation.kt": "3c2c6801cd0f864712fce9c4872843ce94df820e5d57e36473ffd82e3e077d08",
    "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt": "fb2e94c9b53dd8094967a886004d1a86304b02d35a80900f9e8029e7df8003ad",
}
for rel, expected in expected_hashes.items():
    actual = sha256(rel)
    check(f"v105 functional boundary unchanged: {Path(rel).name}", actual == expected, actual)
check("notifications domain tree unchanged", tree_hash(f"{BASE}/domain") == "11825cf2379fb63573f0cc1c882bd756f6bc384901b177ef418b20f168b2d526")
check("notifications data tree unchanged", tree_hash(f"{BASE}/data") == "de4b816d6bca128df4e2b9c2f78d61849f75e8193a1068e26d7c2b26670e231b")

# Ledger and allowlist acceptance.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_106 = {"SCR-026", *(f"STA-{i:03d}" for i in range(69, 74))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("SESSION-106 has exactly 6 inventory IDs", len(expected_106) == 6)
check("all SESSION-106 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_106), str(sorted(i for i in expected_106 if statuses.get(i) != "MIGRATED")))
counts = Counter(status for _, status in rows)
check("ledger migrated total is 110", counts["MIGRATED"] == 110, str(counts))
check("ledger unmigrated total is 13", counts["UNMIGRATED"] == 13, str(counts))
check("ledger has no blocked rows", counts["BLOCKED"] == 0, str(counts))
allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("Notifications UI removed from allowlist", not any(path.startswith(f"{BASE}/presentation/") for path in allow))
check("remaining allowlist is 8 Verto UI files", len(allow) == 8 and all(path.startswith("feature/verto/") for path in allow), str(allow))

# Every Notifications Compose UI file is now guarded.
ui_files: list[Path] = []
for path in sorted((ROOT / f"{BASE}/presentation").rglob("*.kt")):
    source = path.read_text(encoding="utf-8")
    if "@Composable" not in source:
        continue
    ui_files.append(path)
    rel = path.relative_to(ROOT).as_posix()
    check(f"{rel} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", source) is None)
    check(f"{rel} has no raw hex color", "Color(0x" not in source)
    check(f"{rel} has no local font family", "FontFamily(" not in source and "fontFamily =" not in source)
    check(f"{rel} has no raw font size", re.search(r"fontSize\s*=\s*\d+(?:\.\d+)?\.sp\b", source) is None)
    check(f"{rel} has no raw rounded shape", "RoundedCornerShape(" not in source)
check("Notifications has 3 Compose UI files", len(ui_files) == 3, str(len(ui_files)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-106 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
