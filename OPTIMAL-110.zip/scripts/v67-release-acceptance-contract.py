#!/usr/bin/env python3
"""Static release-acceptance contract for OPTIMAL v67."""
from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKS: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    CHECKS.append((name, bool(condition), detail))


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


required = [
    "docs/sessions/v67.md",
    "docs/release-notes-v67.md",
    "docs/final-migration-list-v67.md",
    "docs/manual-test-scenarios-v67.md",
    "config/v67-production-baseline.sha256",
    "docs/source-archive-v67-input.sha256",
]
for item in required:
    check(f"required file {item}", (ROOT / item).is_file())

app_build = read("app/build.gradle.kts")
for token, label in [
    ('applicationId = "com.optimal.fleet"', "application id stable"),
    ("versionCode = 32", "version code unchanged"),
    ('versionName = "0.37.0-v37"', "version name unchanged"),
    ("isDebuggable = false", "release non-debuggable"),
    ("isMinifyEnabled = true", "R8 enabled"),
    ("isShrinkResources = true", "resource shrinking enabled"),
    ("proguard-android-optimize.txt", "optimized ProGuard baseline"),
]:
    check(label, token in app_build)

migration_dir = ROOT / "supabase/migrations"
migrations = sorted(path.name for path in migration_dir.glob("*.sql"))
check("14 Supabase migrations", len(migrations) == 14, str(len(migrations)))
pattern = re.compile(r"^(\d{14})_[a-z0-9_]+\.sql$")
parsed = [pattern.match(name) for name in migrations]
check("migration filenames valid", all(parsed))
timestamps = [match.group(1) for match in parsed if match]
check("migration timestamps unique and ordered", timestamps == sorted(set(timestamps)))

migration_doc = read("docs/final-migration-list-v67.md")
for name in migrations:
    check(f"migration documented {name}", f"`{name}`" in migration_doc)

post_deploy = sorted(path.name for path in (ROOT / "supabase/post_deploy").glob("*.sql"))
expected_post = [
    "v40_promote_verto_registration_ready.sql",
    "v44_promote_verto_finance_v23_ready.sql",
    "v45_promote_verto_maintenance_ready.sql",
    "v46_promote_verto_backend_v23.sql",
]
check("post-deploy promotion set stable", post_deploy == expected_post, ",".join(post_deploy))
for name in expected_post:
    check(f"post-deploy documented {name}", f"`{name}`" in migration_doc)

schemas = sorted(path.name for path in (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase").glob("*.json"))
check("Room schemas 1-3 retained", schemas == ["1.json", "2.json", "3.json"], ",".join(schemas))
database_source = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
check("Room version remains 3", re.search(r"version\s*=\s*3\b", database_source) is not None)
check("no destructive Room fallback", "fallbackToDestructiveMigration" not in "\n".join(
    path.read_text(encoding="utf-8", errors="ignore")
    for path in (ROOT / "core/database/src/main").rglob("*.kt")
))

baseline = ROOT / "config/v67-production-baseline.sha256"
baseline_ok = True
baseline_detail = ""
if baseline.is_file():
    for line_number, raw in enumerate(baseline.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            expected, relative = raw.split(maxsplit=1)
        except ValueError:
            baseline_ok = False
            baseline_detail = f"malformed line {line_number}"
            break
        path = ROOT / relative.strip()
        if not path.is_file():
            baseline_ok = False
            baseline_detail = f"missing {relative.strip()}"
            break
        actual = sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            baseline_ok = False
            baseline_detail = f"changed {relative.strip()}"
            break
check("production sources unchanged from v66 input", baseline_ok, baseline_detail)

session = read("docs/sessions/v67.md")
for phrase in [
    "لا وظائف جديدة",
    "لا ادعاء نجاح Gradle",
    "Backend/E2E الحي",
    "assembleRelease",
    "فحص حزمة المشروع النهائية",
]:
    check(f"session rule retained: {phrase}", phrase in session)

failed = [(name, detail) for name, ok, detail in CHECKS if not ok]
for name, ok, detail in CHECKS:
    suffix = f" — {detail}" if detail and not ok else ""
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f"\nv67 release acceptance contract: {len(CHECKS) - len(failed)}/{len(CHECKS)}")
if failed:
    print("FAILED: " + ", ".join(name for name, _ in failed), file=sys.stderr)
    sys.exit(1)
