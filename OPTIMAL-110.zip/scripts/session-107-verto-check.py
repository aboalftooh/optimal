#!/usr/bin/env python3
from collections import Counter
from pathlib import Path
import hashlib
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = "feature/verto/src/main/java/com/optimal/fleet/feature/verto"
PRESENTATION = f"{BASE}/presentation"


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def tree_hash(rel: str) -> str:
    h = hashlib.sha256()
    for path in sorted((ROOT / rel).rglob("*")):
        if not path.is_file():
            continue
        h.update(path.relative_to(ROOT).as_posix().encode())
        h.update(b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


checks: list[tuple[str, bool, str]] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    checks.append((label, bool(condition), detail))


screen = read(f"{PRESENTATION}/VertoChatScreen.kt")
chrome = read(f"{PRESENTATION}/VertoChatChrome.kt")
messages = read(f"{PRESENTATION}/VertoChatMessages.kt")
composer = read(f"{PRESENTATION}/VertoChatComposer.kt")
attachments = read(f"{PRESENTATION}/VertoChatAttachments.kt")
formatting = read(f"{PRESENTATION}/VertoChatFormatting.kt")
fields = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt")

# Every Verto Compose presentation file must satisfy the migration guard rules after SESSION-107.
ui_files: list[Path] = []
for path in sorted((ROOT / PRESENTATION).glob("*.kt")):
    source = path.read_text(encoding="utf-8")
    if "@Composable" not in source:
        continue
    ui_files.append(path)
    rel = path.relative_to(ROOT).as_posix()
    for label, pattern in [
        ("raw dp", r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b"),
        ("raw hex color", r"\bColor\s*\(\s*0x[0-9A-Fa-f]+"),
        ("raw font size", r"\bfontSize\s*=\s*[^,\n]+\.sp\b"),
        ("raw rounded shape", r"\bRoundedCornerShape\s*\("),
        ("direct Material button", r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\("),
        ("direct Material field", r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\("),
        ("direct AlertDialog", r"(?<![A-Za-z0-9_])AlertDialog\s*\("),
    ]:
        check(f"{rel} has no {label}", re.search(pattern, source) is None)
    check(f"{rel} has no local font family", "FontFamily(" not in source and "fontFamily =" not in source)

# SCR-027 and gate/full-screen states STA-074..078.
check("screen uses canonical loading state", "OptimalLoadingState(" in screen)
for tag in ["VERTO_LOADING_TAG", "VERTO_ACCESS_DENIED_TAG", "VERTO_UNLINKED_TAG", "VERTO_EMPTY_TAG"]:
    check(f"screen exposes {tag}", tag in screen)
check("screen preserves access-before-link gate order", screen.index("state.accessDenied") < screen.index("!state.linkState.linked"))
check("screen preserves empty conversation copy", 'title = "لا توجد رسائل"' in screen)
check("cached error uses canonical inline status", "OptimalInlineStatus(" in chrome and "VERTO_ERROR_TAG" in chrome)
check("cached error preserves retry callback", 'actionLabel = "إعادة المحاولة"' in chrome and "onAction = onRetry" in chrome)

# Header/archive state STA-083.
check("header uses canonical status badge", "OptimalStatusBadge(" in chrome)
check("archive toggle callback preserved", "onClick = onToggleArchived" in chrome)
check("archive progress is visible", "ARCHIVE_PROGRESS_TAG" in chrome and "archiveOperationInProgress" in chrome)
check("archive stable control tag preserved", 'testTag("verto-archive-toggle")' in chrome)

# Message flow + pagination STA-079.
check("chat-native side alignment preserved", "if (outgoing) Arrangement.Start else Arrangement.End" in messages)
check("chat bubble bounded width preserved", "fillMaxWidth(MESSAGE_BUBBLE_MAX_WIDTH_FRACTION)" in messages)
check("chat bubble uses theme shape", "shape = MaterialTheme.shapes.large" in messages)
check("feature-local RoundedCornerShape removed", "RoundedCornerShape(" not in messages)
check("load older action preserved", 'text = "تحميل رسائل أقدم"' in messages and "onClick = onLoadOlder" in messages)
check("load older progress preserved", "state.loadingOlder" in messages and "CircularProgressIndicator" in messages)
check("retry failed message preserved", "onRetryMessage(message.localId)" in messages)

# Composer + overlay + audio/busy states STA-080..082 and OVL-002.
for token in ["OptimalTextField(", "OptimalDropdownMenu(", "OptimalDropdownMenuItem(", "OptimalInlineStatus(", "OptimalIconButton("]:
    check(f"composer uses {token.rstrip('(')}", token in composer)
check("composer direct Material field removed", "OutlinedTextField(" not in composer)
check("composer IME send preserved", "ImeAction.Send" in composer and "if (state.sendEnabled) onSend()" in composer)
check("composer send callback preserved", "onClick = onSend" in composer)
check("composer text callback preserved", "onValueChange = onTextChanged" in composer)
for label in ["التقاط صورة", "اختيار صورة", "اختيار فيديو", "اختيار مستند"]:
    check(f"attachment menu preserves {label}", label in composer)
for tag in ["AUDIO_RECORDING_TAG", "AUDIO_STOP_TAG", "AUDIO_DRAFT_TAG", "AUDIO_PREVIEW_TAG", "AUDIO_DISCARD_TAG", "AUDIO_SEND_TAG", "AUDIO_BUSY_TAG", "ATTACHMENT_MENU_TAG", "SEND_TAG", "COMPOSER_ERROR_TAG"]:
    check(f"composer exposes {tag}", tag in composer or tag in formatting)
check("shared menu item supports semantic leading icon", "leadingIcon: (@Composable () -> Unit)? = null" in fields and "leadingIcon = leadingIcon" in fields)

# Attachment display/progress STA-084.
check("attachments use canonical status badge", "OptimalStatusBadge(" in attachments)
check("attachment transfer tag is stable per attachment", 'testTag("verto-attachment-transfer-${attachment.clientAttachmentId}")' in attachments)
for label in ["بانتظار الرفع", "جارٍ الرفع", "جارٍ التحقق", "جاهز", "تعذر الرفع مؤقتًا", "تعذر الرفع"]:
    check(f"attachment transfer label preserved: {label}", label in attachments)
check("attachment open callback preserved", "onOpenRemoteAttachment" in attachments)

# Functional freeze against supplied OPTIMAL-v106.
expected_hashes = {
    f"{PRESENTATION}/VertoChatContract.kt": "65e99bad21d55f9cfb080212abe8d053b5e56d0d79ecd8009316d879259df6d0",
    f"{PRESENTATION}/VertoChatViewModel.kt": "d160312ae48c1ced85dc0e102f3f9bc87c2f5d9a6c5a468359fa0c768f1469cb",
    f"{PRESENTATION}/VertoAttachmentPickerCoordinator.kt": "74aa740467eeb0d9a0b670bbabe70ff286aaef05c4216656845c8489794464c0",
    f"{PRESENTATION}/VertoAudioPlayback.kt": "a07ef2c8ebf97dfe6755bdc243ac5b0ae49bd0ce67ceb1499d9996fa90319383",
    f"{PRESENTATION}/VertoConversationEntryRoute.kt": "21c428519492d38413fb5a6b38cbaa1b5cc4ba16c20f3282300df9499db3301c",
    f"{PRESENTATION}/VertoAttachmentOpenContract.kt": "acd9b82ff9166111dd60b3362c6106a5d53dfe1792c91122e820cc22da93e642",
    f"{PRESENTATION}/VertoHomeEntry.kt": "3584b1dcb9ace74216a4254d853f61fc86e8c47e91292db78e6ee6253f540d32",
    "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt": "fb2e94c9b53dd8094967a886004d1a86304b02d35a80900f9e8029e7df8003ad",
}
for rel, expected in expected_hashes.items():
    actual = sha256(rel)
    check(f"v106 functional boundary unchanged: {Path(rel).name}", actual == expected, actual)
check("Verto domain tree unchanged", tree_hash(f"{BASE}/domain") == "4525f4fc8f5dd55a4abf5e2146443de629d052f67c1721405adb133594598540")
check("Verto data tree unchanged", tree_hash(f"{BASE}/data") == "ba98e90d619d4e2d757c477bb0fd97b1250eeedbe97e127d26407459a9839bd0")

# Ledger / allowlist acceptance.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_107 = {"SCR-027", "OVL-002", *(f"STA-{i:03d}" for i in range(74, 85))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("SESSION-107 has exactly 13 inventory IDs", len(expected_107) == 13)
check("all SESSION-107 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_107), str(sorted(i for i in expected_107 if statuses.get(i) != "MIGRATED")))
counts = Counter(status for _, status in rows)
check("ledger migrated total is 123", counts["MIGRATED"] == 123, str(counts))
check("ledger unmigrated total is 0", counts["UNMIGRATED"] == 0, str(counts))
check("ledger has no blocked rows", counts["BLOCKED"] == 0, str(counts))
allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("migration allowlist has no feature paths", allow == [], str(allow))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-107 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
