#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/stubs/javax/inject"
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
KT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  "$TMP_DIR/stubs/javax/inject/Inject.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionIdentity.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/access/VertoChatAuthorization.kt" \
  "$ROOT_DIR"/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/*.kt \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt" \
  "$ROOT_DIR/scripts/v51-verto-entry-harness.kt" \
  -include-runtime -d "$TMP_DIR/v51-verto-entry.jar"
java -cp "$TMP_DIR/v51-verto-entry.jar:$COROUTINES_JAR" \
  com.optimal.fleet.feature.verto.domain.usecase.V51_verto_entry_harnessKt
