#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, bool(ok), detail))

build = read("app/build.gradle.kts")
check("versionCode 30", bool(re.search(r"\bversionCode\s*=\s*30\b", build)))
check("versionName v35", 'versionName = "0.35.0-v35"' in build)

old_design_system = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalComponents.kt"
check("design-system monolith removed", not old_design_system.exists())

design_files = [
    "OptimalHeader.kt",
    "OptimalButtons.kt",
    "OptimalCards.kt",
    "OptimalFields.kt",
    "OptimalDialogs.kt",
    "OptimalNavigation.kt",
    "OptimalSegments.kt",
    "OptimalEmptyCards.kt",
]
ds_dir = "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component"
for file_name in design_files:
    path = f"{ds_dir}/{file_name}"
    exists = (ROOT / path).is_file()
    check(f"design-system split {file_name}", exists)
    if exists:
        lines = len(read(path).splitlines())
        check(f"design-system focused size {file_name}", lines <= 130, str(lines))

all_ds = "\n".join(read(f"{ds_dir}/{name}") for name in design_files)
for symbol in [
    "AppHeader", "StatusBadge", "PrimaryButton", "SecondaryButton", "AppCard",
    "AppTextField", "SearchField", "EmptyStateCard", "AppDialog", "BottomNavItem",
    "BottomNavBar", "SegmentOption", "Segment", "ConfirmationDialog",
]:
    check(f"design-system API retained {symbol}", symbol in all_ds)
check("design-system imports no feature", "com.optimal.fleet.feature." not in all_ds)

ui_splits = {
    "auth": [
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthScreenContent.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthAccountContent.kt",
    ],
    "home": [
        "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt",
        "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt",
    ],
    "finance-dashboard": [
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardRoute.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreen.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/AddCostDialog.kt",
    ],
    "finance-invoices": [
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListComponents.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt",
    ],
    "vehicles": [
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesScreen.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesComponents.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorRoute.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorScreen.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorComponents.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorDialogs.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailComponents.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailDialogs.kt",
    ],
    "settings": [
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsContract.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsRoute.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsScreen.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsComponents.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersRoute.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreen.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersDialogs.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityScreen.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityComponents.kt",
    ],
    "notifications": [
        "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt",
        "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreen.kt",
        "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsComponents.kt",
    ],
}
for group, paths in ui_splits.items():
    for path in paths:
        check(f"{group} split {Path(path).name}", (ROOT / path).is_file())

route_limits = {
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt": 130,
    "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt": 130,
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardRoute.kt": 70,
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt": 80,
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt": 80,
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt": 80,
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorRoute.kt": 90,
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt": 80,
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsRoute.kt": 30,
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersRoute.kt": 55,
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt": 80,
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt": 45,
}
for path, limit in route_limits.items():
    lines = len(read(path).splitlines())
    check(f"thin route {Path(path).stem}", lines <= limit, f"{lines}>{limit}")

for path in route_limits:
    text = read(path)
    check(f"route has no repository {Path(path).stem}", not re.search(r"(Repository|Dao|Entity|\.data\.)", text))

contracts = [
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeContract.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardContract.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListContract.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesContract.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorContract.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsContract.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsContract.kt",
]
for path in contracts:
    text = read(path)
    check(f"immutable state {Path(path).stem}", "@Immutable" in text and "UiState" in text)
    check(f"event contract {Path(path).stem}", "UiEvent" in text)

screen_state = read(f"{ds_dir}/OptimalScreenStates.kt")
check("shared loading state retained", "fun OptimalLoadingState" in screen_state)
check("shared empty state retained", "fun OptimalEmptyState" in screen_state)
check("shared error state retained", "fun OptimalErrorState" in screen_state)
check("shared confirmation state added", "fun ConfirmationDialog" in read(f"{ds_dir}/OptimalDialogs.kt"))
check(
    "vehicle archive uses shared confirmation",
    "ConfirmationDialog(" in read("feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailDialogs.kt"),
)

stable_lists = {
    "vehicles": ("feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesScreen.kt", "key = VehicleListItemUi::id"),
    "members": ("feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreen.kt", "key = MemberUi::id"),
    "notifications": ("feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreen.kt", "key = NotificationItemUi::id"),
    "finance invoices": ("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt", "key = InvoiceListItemUi::id"),
}
for name, (path, token) in stable_lists.items():
    check(f"stable key {name}", token in read(path))

check(
    "home cards remain bounded",
    read("feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt").count("items.take(3).forEach") == 2,
)

ui_tests = [
    "feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AuthScreenTest.kt",
    "feature/home/src/androidTest/java/com/optimal/fleet/feature/home/HomeUiTest.kt",
    "feature/vehicles/src/androidTest/java/com/optimal/fleet/feature/vehicles/presentation/VehicleScreensTest.kt",
    "feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/SettingsScreenTest.kt",
    "feature/notifications/src/androidTest/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreenTest.kt",
    "feature/finance/src/androidTest/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreenTest.kt",
]
for path in ui_tests:
    check(f"critical UI test {Path(path).name}", (ROOT / path).is_file())

for module in ["settings", "notifications", "finance"]:
    gradle = read(f"feature/{module}/build.gradle.kts")
    check(f"{module} compose UI test dependency", "androidx.compose.ui.test.junit4" in gradle)
    check(f"{module} compose test manifest", "androidx.compose.ui.test.manifest" in gradle)

preserved_tags = [
    "join-code", "destination-home", "destination-finance", "invoice-search", "vehicle-detail",
    "destination-settings", "members-list", "activity-list", "destination-notifications",
]
ui_text = "\n".join(
    p.read_text(encoding="utf-8")
    for base in [ROOT / "feature/auth/src/main", ROOT / "feature/home/src/main", ROOT / "feature/finance/src/main",
                 ROOT / "feature/vehicles/src/main", ROOT / "feature/settings/src/main", ROOT / "feature/notifications/src/main"]
    for p in base.rglob("*.kt")
)
for tag in preserved_tags:
    check(f"critical test tag retained {tag}", f'"{tag}"' in ui_text)

for path in [
    "README.md", "AGENTS.md", "docs/sessions/v35.md", "docs/verifications/verification-v35.md",
    "verification-v35.md", "PATCH_MANIFEST-v35.md", "CHANGED_FILES-v35.txt", "DELETED_FILES-v35.txt",
]:
    check(f"delivery {path}", (ROOT / path).is_file())
for script in ["run-v35-ui-syntax-check.sh", "verify-v35-static.sh", "verify-v35-regressions.sh"]:
    check(f"gate {script}", (ROOT / "scripts" / script).is_file())

failed = [(name, detail) for name, ok, detail in checks if not ok]
for name, ok, detail in checks:
    suffix = f" ({detail})" if detail and not ok else ""
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)}")
if failed:
    print("FAILED: " + ", ".join(name for name, _ in failed), file=sys.stderr)
    sys.exit(1)
