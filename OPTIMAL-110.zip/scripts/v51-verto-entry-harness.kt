package com.optimal.fleet.feature.verto.domain.usecase

import com.optimal.fleet.feature.verto.domain.access.GrantedVertoChatAccess
import com.optimal.fleet.feature.verto.domain.access.VertoChatAccessGrant
import com.optimal.fleet.feature.verto.domain.access.VertoChatAuthorization
import com.optimal.fleet.feature.verto.domain.access.VertoChatAuthorizationResult
import com.optimal.fleet.feature.verto.domain.access.VertoChatDenialReason
import com.optimal.fleet.feature.verto.domain.access.VertoChatOperation
import com.optimal.fleet.feature.verto.domain.model.VertoLinkState
import com.optimal.fleet.feature.verto.domain.model.VertoMessageCursor
import com.optimal.fleet.feature.verto.domain.model.VertoMessagePage
import com.optimal.fleet.feature.verto.domain.model.VertoOutgoingMessageIdentity
import com.optimal.fleet.feature.verto.domain.repository.VertoConversationRepository
import com.optimal.fleet.feature.verto.domain.repository.VertoReadResult
import com.optimal.fleet.feature.verto.domain.repository.VertoRefreshResult
import com.optimal.fleet.feature.verto.domain.repository.VertoTextEnqueueResult
import com.optimal.fleet.feature.verto.domain.repository.VertoTextRetryResult
import com.optimal.fleet.feature.verto.domain.repository.VertoTextSyncResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking

private class FixedAuthorization(
    private val result: VertoChatAuthorizationResult,
) : VertoChatAuthorization {
    override suspend fun authorize(operation: VertoChatOperation): VertoChatAuthorizationResult = result
}

private class FixedRepository(
    private val state: VertoLinkState,
) : VertoConversationRepository {
    override fun observeLinkState(grant: VertoChatAccessGrant): Flow<VertoLinkState> = flowOf(state)
    override fun observeMessages(grant: VertoChatAccessGrant, limit: Int): Flow<VertoMessagePage> = flowOf(VertoMessagePage(emptyList(), 0, 0))
    override fun observeRealtimeHints(grant: VertoChatAccessGrant): Flow<Unit> = flowOf()
    override suspend fun refresh(grant: VertoChatAccessGrant): VertoRefreshResult = VertoRefreshResult.Refreshed
    override suspend fun markRead(grant: VertoChatAccessGrant, through: VertoMessageCursor): VertoReadResult = VertoReadResult.Synced
    override suspend fun enqueueTextMessage(
        grant: VertoChatAccessGrant,
        identity: VertoOutgoingMessageIdentity,
        bodyText: String,
    ): VertoTextEnqueueResult = VertoTextEnqueueResult.Queued(identity.localId)

    override suspend fun syncPendingTextMessage(
        grant: VertoChatAccessGrant,
        companyId: String,
        localMessageId: String,
    ): VertoTextSyncResult = VertoTextSyncResult.NotFound

    override suspend fun retryTextMessage(
        grant: VertoChatAccessGrant,
        localMessageId: String,
    ): VertoTextRetryResult = VertoTextRetryResult.NotFound

    override suspend fun markOutgoingMessageFailure(
        companyId: String,
        localMessageId: String,
        retryable: Boolean,
        failureCode: String,
    ) = Unit
}

private suspend fun badge(
    authorizationResult: VertoChatAuthorizationResult,
    state: VertoLinkState,
): VertoObservationResult<Long> = ObserveVertoUnreadBadge(
    ObserveVertoLinkState(FixedAuthorization(authorizationResult), FixedRepository(state)),
)()

fun main() = runBlocking {
    val grant = GrantedVertoChatAccess(
        userId = "user-a",
        companyId = "company-a",
        operation = VertoChatOperation.OBSERVE_LINK_STATE,
    )
    val linked = badge(
        VertoChatAuthorizationResult.Granted(grant),
        VertoLinkState(
            linked = true,
            linkId = "link-a",
            conversationId = "conversation-a",
            unreadCount = 8,
            canView = true,
            canSend = true,
        ),
    )
    check(linked is VertoObservationResult.Allowed && linked.stream.first() == 8L)
    println("PASS: linked unread badge is read locally")

    val unlinked = badge(
        VertoChatAuthorizationResult.Granted(grant),
        VertoLinkState.unlinked(),
    )
    check(unlinked is VertoObservationResult.Allowed && unlinked.stream.first() == 0L)
    println("PASS: unlinked badge is zero")

    val denied = badge(
        VertoChatAuthorizationResult.Denied(
            VertoChatOperation.OBSERVE_LINK_STATE,
            VertoChatDenialReason.CAPABILITY_NOT_GRANTED,
        ),
        VertoLinkState.unlinked(),
    )
    check(denied is VertoObservationResult.Denied)
    println("PASS: missing view permission fails closed")

    println("V51 Verto entry domain harness: 3/3 PASS")
}
