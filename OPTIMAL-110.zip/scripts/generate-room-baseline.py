#!/usr/bin/env python3
"""Generate or verify the current source-derived Room schema.

Historical schema JSON files remain immutable migration inputs. The script reads
the current @Database and @Entity Kotlin sources and writes/checks only the
current version, allowing offline structural verification without Room KSP.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DATABASE_SOURCE = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt"
SCHEMA_DIR = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
SOURCE_ROOT = ROOT / "core/database/src/main/java"

TYPE_AFFINITY = {
    "String": "TEXT",
    "Long": "INTEGER",
    "Int": "INTEGER",
    "Boolean": "INTEGER",
    "Double": "REAL",
    "Float": "REAL",
    "ByteArray": "BLOB",
}


def database_version() -> int:
    source = DATABASE_SOURCE.read_text(encoding="utf-8")
    match = re.search(r"\bversion\s*=\s*(\d+)", source)
    if match is None:
        raise ValueError("@Database version is missing")
    return int(match.group(1))


def balanced(text: str, start: int, opening: str = "(", closing: str = ")") -> tuple[str, int]:
    if text[start] != opening:
        raise ValueError(f"Expected {opening!r} at {start}")
    depth = 0
    quoted = False
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
            continue
        if char == '"':
            quoted = True
        elif char == opening:
            depth += 1
        elif char == closing:
            depth -= 1
            if depth == 0:
                return text[start : index + 1], index + 1
    raise ValueError(f"Unbalanced {opening}{closing}")


def top_level_parts(text: str) -> list[str]:
    parts: list[str] = []
    start = 0
    depth = 0
    quoted = False
    escaped = False
    for index, char in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
            continue
        if char == '"':
            quoted = True
        elif char in "([":
            depth += 1
        elif char in ")]":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append(text[start:index].strip())
            start = index + 1
    parts.append(text[start:].strip())
    return [part for part in parts if part]


def named_array(arguments: str, name: str) -> str:
    match = re.search(rf"\b{name}\s*=\s*\[", arguments)
    if match is None:
        return ""
    value, _ = balanced(arguments, match.end() - 1, "[", "]")
    return value[1:-1]


def call_blocks(text: str, name: str) -> list[str]:
    blocks: list[str] = []
    position = 0
    while True:
        match = re.search(rf"\b{name}\s*\(", text[position:])
        if match is None:
            return blocks
        start = position + match.start()
        opening = text.find("(", start)
        value, end = balanced(text, opening)
        blocks.append(text[start:end])
        position = end


def quoted_values(text: str) -> list[str]:
    return re.findall(r'"([^"]+)"', text)


def entity_sources() -> dict[str, Path]:
    result: dict[str, Path] = {}
    for path in SOURCE_ROOT.rglob("*Entity.kt"):
        source = path.read_text(encoding="utf-8")
        match = re.search(r"\bdata class\s+(\w+Entity)\s*\(", source)
        if match:
            result[match.group(1)] = path
    return result


def database_entity_order() -> list[str]:
    source = DATABASE_SOURCE.read_text(encoding="utf-8")
    match = re.search(r"\bentities\s*=\s*\[", source)
    if match is None:
        raise ValueError("@Database entities list is missing")
    array, _ = balanced(source, match.end() - 1, "[", "]")
    return re.findall(r"(\w+Entity)::class", array)


def parse_entity(class_name: str, path: Path) -> dict:
    source = path.read_text(encoding="utf-8")
    entity_match = re.search(r"@Entity\s*\(", source)
    if entity_match is None:
        raise ValueError(f"{path}: @Entity is missing")
    arguments, _ = balanced(source, source.find("(", entity_match.start()))
    arguments = arguments[1:-1]
    table_match = re.search(r'\btableName\s*=\s*"([^"]+)"', arguments)
    if table_match is None:
        raise ValueError(f"{path}: explicit tableName is required")
    table = table_match.group(1)

    class_match = re.search(rf"\bdata class\s+{re.escape(class_name)}\s*\(", source)
    if class_match is None:
        raise ValueError(f"{path}: data class {class_name} is missing")
    constructor, _ = balanced(source, source.find("(", class_match.start()))

    fields = []
    for parameter in top_level_parts(constructor[1:-1]):
        field_match = re.search(r"\bval\s+(\w+)\s*:\s*([\w?.<>]+)", parameter, re.S)
        if field_match is None:
            raise ValueError(f"{path}: unsupported entity parameter: {parameter!r}")
        field_name, kotlin_type = field_match.groups()
        default_match = re.search(
            r'@ColumnInfo\s*\(\s*defaultValue\s*=\s*"([^"]*)"',
            parameter,
            re.S,
        )
        fields.append(
            {
                "fieldPath": field_name,
                "columnName": field_name,
                "kotlinType": kotlin_type,
                "primaryKey": "@PrimaryKey" in parameter,
                "defaultValue": default_match.group(1) if default_match else None,
            },
        )

    foreign_keys = []
    for block in call_blocks(named_array(arguments, "foreignKeys"), "ForeignKey"):
        parent = re.search(r"\bentity\s*=\s*(\w+Entity)::class", block)
        parent_columns = re.search(r"\bparentColumns\s*=\s*\[([^\]]*)\]", block, re.S)
        child_columns = re.search(r"\bchildColumns\s*=\s*\[([^\]]*)\]", block, re.S)
        if not parent or not parent_columns or not child_columns:
            raise ValueError(f"{path}: unsupported ForeignKey declaration")
        delete = re.search(r"\bonDelete\s*=\s*ForeignKey\.(\w+)", block)
        update = re.search(r"\bonUpdate\s*=\s*ForeignKey\.(\w+)", block)
        foreign_keys.append(
            {
                "entity": parent.group(1),
                "parentColumns": quoted_values(parent_columns.group(1)),
                "childColumns": quoted_values(child_columns.group(1)),
                "onDelete": delete.group(1) if delete else "NO_ACTION",
                "onUpdate": update.group(1) if update else "NO_ACTION",
            },
        )

    indices = []
    for block in call_blocks(named_array(arguments, "indices"), "Index"):
        values = re.search(r"\bvalue\s*=\s*\[([^\]]*)\]", block, re.S)
        if values is None:
            raise ValueError(f"{path}: unsupported Index declaration")
        explicit_name = re.search(r'\bname\s*=\s*"([^"]+)"', block)
        indices.append(
            {
                "columns": quoted_values(values.group(1)),
                "unique": bool(re.search(r"\bunique\s*=\s*true", block)),
                "name": explicit_name.group(1) if explicit_name else None,
            },
        )

    return {
        "className": class_name,
        "path": str(path.relative_to(ROOT)),
        "tableName": table,
        "fields": fields,
        "foreignKeys": foreign_keys,
        "indices": indices,
    }


def action(value: str) -> str:
    return value.replace("_", " ")


def room_entity(entity: dict, entities: dict[str, dict]) -> dict:
    fields = []
    columns = []
    primary_key = []
    for field in entity["fields"]:
        kotlin_type = field["kotlinType"]
        base_type = kotlin_type.rstrip("?")
        affinity = TYPE_AFFINITY.get(base_type)
        if affinity is None:
            raise ValueError(f"{entity['className']}.{field['fieldPath']}: unsupported type {kotlin_type}")
        not_null = not kotlin_type.endswith("?")
        schema_field = {
            "fieldPath": field["fieldPath"],
            "columnName": field["columnName"],
            "affinity": affinity,
            "notNull": not_null,
        }
        if field["defaultValue"] is not None:
            schema_field["defaultValue"] = field["defaultValue"]
        fields.append(schema_field)

        column = f"`{field['columnName']}` {affinity}"
        if not_null:
            column += " NOT NULL"
        if field["defaultValue"] is not None:
            column += f" DEFAULT {field['defaultValue']}"
        columns.append(column)
        if field["primaryKey"]:
            primary_key.append(field["columnName"])

    if len(primary_key) != 1:
        raise ValueError(f"{entity['className']}: exactly one @PrimaryKey is required")

    clauses = columns + [
        "PRIMARY KEY(" + ", ".join(f"`{column}`" for column in primary_key) + ")",
    ]
    foreign_keys = []
    for foreign_key in entity["foreignKeys"]:
        parent_table = entities[foreign_key["entity"]]["tableName"]
        on_delete = action(foreign_key["onDelete"])
        on_update = action(foreign_key["onUpdate"])
        child_sql = ", ".join(f"`{column}`" for column in foreign_key["childColumns"])
        parent_sql = ", ".join(f"`{column}`" for column in foreign_key["parentColumns"])
        clauses.append(
            f"FOREIGN KEY({child_sql}) REFERENCES `{parent_table}`({parent_sql}) "
            f"ON UPDATE {on_update} ON DELETE {on_delete} ",
        )
        foreign_keys.append(
            {
                "table": parent_table,
                "onDelete": on_delete,
                "onUpdate": on_update,
                "columns": foreign_key["childColumns"],
                "referencedColumns": foreign_key["parentColumns"],
            },
        )

    indices = []
    for index in entity["indices"]:
        name = index["name"] or (
            f"index_{entity['tableName']}_{'_'.join(index['columns'])}"
        )
        prefix = "CREATE UNIQUE INDEX" if index["unique"] else "CREATE INDEX"
        column_sql = ", ".join(f"`{column}`" for column in index["columns"])
        indices.append(
            {
                "name": name,
                "unique": index["unique"],
                "columnNames": index["columns"],
                "orders": [],
                "createSql": (
                    f"{prefix} IF NOT EXISTS `{name}` ON `${{TABLE_NAME}}` ({column_sql})"
                ),
            },
        )

    return {
        "tableName": entity["tableName"],
        "createSql": "CREATE TABLE IF NOT EXISTS `${TABLE_NAME}` (" + ", ".join(clauses) + ")",
        "fields": fields,
        "primaryKey": {"autoGenerate": False, "columnNames": primary_key},
        "indices": indices,
        "foreignKeys": foreign_keys,
    }


def build_schema() -> dict:
    sources = entity_sources()
    order = database_entity_order()
    missing = [class_name for class_name in order if class_name not in sources]
    if missing:
        raise ValueError(f"Missing entity sources: {', '.join(missing)}")
    parsed = {class_name: parse_entity(class_name, sources[class_name]) for class_name in order}
    entities = [room_entity(parsed[class_name], parsed) for class_name in order]
    version = database_version()
    structural = {"version": version, "entities": entities, "views": []}
    identity_hash = hashlib.md5(
        json.dumps(structural, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    ).hexdigest()
    return {
        "formatVersion": 1,
        "database": {
            "version": version,
            "identityHash": identity_hash,
            "entities": entities,
            "views": [],
            "setupQueries": [
                "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)",
                (
                    "INSERT OR REPLACE INTO room_master_table (id,identity_hash) "
                    f"VALUES(42, '{identity_hash}')"
                ),
            ],
        },
    }


def structural(schema: dict) -> dict:
    database = schema["database"]
    return {
        "formatVersion": schema["formatVersion"],
        "version": database["version"],
        "entities": database["entities"],
        "views": database["views"],
    }


def validate_sqlite(schema: dict) -> None:
    database = schema["database"]
    version = database["version"]
    with tempfile.TemporaryDirectory(prefix=f"optimal-room-v{version}-") as directory:
        connection = sqlite3.connect(str(Path(directory) / "optimal.db"))
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            for entity in database["entities"]:
                table = entity["tableName"]
                connection.execute(entity["createSql"].replace("${TABLE_NAME}", table))
                for index in entity["indices"]:
                    connection.execute(index["createSql"].replace("${TABLE_NAME}", table))
            connection.execute(f"PRAGMA user_version = {version}")
            quick = connection.execute("PRAGMA quick_check(1)").fetchone()[0]
            foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
            if quick != "ok" or foreign_key_errors:
                raise ValueError(f"SQLite validation failed: quick={quick}, fk={foreign_key_errors}")
            actual_version = connection.execute("PRAGMA user_version").fetchone()[0]
            if actual_version != version:
                raise ValueError(f"Expected user_version {version}, got {actual_version}")
        finally:
            connection.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true", help="write the current committed schema JSON")
    parser.add_argument("--check", action="store_true", help="verify committed schema against sources")
    arguments = parser.parse_args()
    if arguments.write == arguments.check:
        parser.error("choose exactly one of --write or --check")

    generated = build_schema()
    validate_sqlite(generated)
    version = generated["database"]["version"]
    schema_path = SCHEMA_DIR / f"{version}.json"

    if arguments.write:
        SCHEMA_DIR.mkdir(parents=True, exist_ok=True)
        schema_path.write_text(
            json.dumps(generated, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(
            f"WROTE: {schema_path.relative_to(ROOT)} "
            f"({len(generated['database']['entities'])} tables)",
        )
        return 0

    expected_files = {f"{number}.json" for number in range(1, version + 1)}
    actual_files = {path.name for path in SCHEMA_DIR.glob("*.json")}
    if actual_files != expected_files:
        print(f"FAIL: schema history must be contiguous: expected={sorted(expected_files)}, actual={sorted(actual_files)}")
        return 1
    if not schema_path.is_file():
        print(f"FAIL: missing {schema_path.relative_to(ROOT)}")
        return 1
    committed = json.loads(schema_path.read_text(encoding="utf-8"))
    if structural(committed) != structural(generated):
        print("FAIL: committed Room schema does not match @Database/@Entity sources")
        return 1
    identity = committed.get("database", {}).get("identityHash", "")
    if not re.fullmatch(r"[0-9a-f]{32}", identity):
        print("FAIL: committed schema identityHash is not a 32-character hex value")
        return 1
    validate_sqlite(committed)
    print(
        f"PASS: Room v{version} schema matches source "
        f"({len(committed['database']['entities'])} tables)",
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
