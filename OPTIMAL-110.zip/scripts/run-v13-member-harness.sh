#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$(mktemp -d)"
trap 'rm -rf "$OUT_DIR"' EXIT
kotlinc \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/InviteCodePolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberSafetyPolicies.kt" \
  "$ROOT_DIR/scripts/v13-member-harness.kt" \
  -include-runtime \
  -d "$OUT_DIR/v13-member-harness.jar"
java -jar "$OUT_DIR/v13-member-harness.jar"
