#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
COROUTINES="/root/.sdkman/candidates/kotlin/current/lib/kotlinx-coroutines-core-jvm.jar"
KOTLINC="/root/.sdkman/candidates/kotlin/current/bin/kotlinc"
KOTLIN="/root/.sdkman/candidates/kotlin/current/bin/kotlin"

mkdir -p "$TMP/javax/inject"
cat > "$TMP/javax/inject/Inject.kt" <<'KOT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
KOT

"$KOTLINC" \
  "$TMP/javax/inject/Inject.kt" \
  "$ROOT/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/linking/LinkVertoInvoice.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/ports/FinanceProjectionPort.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationType.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/importing/MaintenanceImportPort.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/ImportedMaintenancePlanner.kt" \
  "$ROOT/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/matching/VehicleMatcherPort.kt" \
  "$ROOT/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/matching/VehicleMatchPolicy.kt" \
  "$ROOT/app/src/main/java/com/optimal/fleet/coordinator/verto/VertoLinkAuditPort.kt" \
  "$ROOT/app/src/main/java/com/optimal/fleet/coordinator/verto/VertoLinkTransactionRunner.kt" \
  "$ROOT/app/src/main/java/com/optimal/fleet/coordinator/verto/VertoInvoiceMaintenanceCoordinator.kt" \
  "$ROOT/scripts/v10-linking-harness.kt" \
  -cp "$COROUTINES" \
  -d "$TMP/v10-harness.jar"

"$KOTLIN" -cp "$TMP/v10-harness.jar:$COROUTINES" com.optimal.fleet.v10harness.V10_linking_harnessKt
