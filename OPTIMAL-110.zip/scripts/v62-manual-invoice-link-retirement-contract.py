#!/usr/bin/env python3
"""Static acceptance gate for OPTIMAL v62 manual invoice-link retirement."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []


def check(label: str, condition: bool) -> None:
    checks.append((label, condition))
    if not condition:
        raise AssertionError(label)


def read(relative: str) -> str:
    path = ROOT / relative
    check(f"file:{relative}", path.is_file())
    return path.read_text(encoding="utf-8")


link_contract = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/linking/LinkVertoInvoice.kt")
coordinator = read("app/src/main/java/com/optimal/fleet/coordinator/verto/VertoInvoiceMaintenanceCoordinator.kt")
auto_import = read("app/src/main/java/com/optimal/fleet/coordinator/verto/VertoMaintenanceAutoImportCoordinator.kt")
details_contract = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt")
details_vm = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt")
details_screen = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt")
details_components = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt")
list_screen = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt")
list_components = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListComponents.kt")
dashboard_components = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt")
home_components = read("feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt")
notification_source = read("feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data/RoomNotificationCandidateSource.kt")
notification_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt")
notification_rows = read("core/database/src/main/java/com/optimal/fleet/core/database/model/NotificationCandidateRows.kt")
v23_mapper = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceV23Mapper.kt")
repository = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt")
link_test = read("app/src/test/java/com/optimal/fleet/coordinator/verto/LinkInvoiceToVehicleTest.kt")
idempotency_test = read("app/src/test/java/com/optimal/fleet/coordinator/verto/ImportIdempotencyTest.kt")
notification_test = read("app/src/test/java/com/optimal/fleet/notifications/NotificationArchitectureTest.kt")
architecture_test = read("app/src/test/java/com/optimal/fleet/CrossFeatureArchitectureTest.kt")
product_spec = read("docs/PRODUCT_SPEC.md")
root_build = read("build.gradle.kts")
ci_fast = read("scripts/ci-fast.sh")
ci_full = read("scripts/ci-full.sh")
verify_project = read("scripts/verify-project.sh")
verify_v62 = read("scripts/verify-v62-static.sh")
app_build = read("app/build.gradle.kts")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")

# v23 contract remains authoritative and rejects manual-link requests at ingestion.
check("v23:mapper-contract", "contractVersion == 23" in v23_mapper)
check("v23:mapper-no-manual-link", "!dto.requiresVehicleLink" in v23_mapper)
check("v23:repository-no-manual-link", "!snapshot.requiresVehicleLink" in repository)

# Compatibility adapter can read existing links, but cannot create maintenance or links.
check("link-contract:disabled-result", "ManualLinkingDisabled" in link_contract)
check("coordinator:read-existing-link", "financeProjectionPort.observeLink" in coordinator)
check("coordinator:lookup-existing-link", "financeProjectionPort.findLink" in coordinator)
check("coordinator:existing-result", "LinkVertoInvoiceResult.AlreadyLinked" in coordinator)
check("coordinator:disabled-result", "LinkVertoInvoiceResult.ManualLinkingDisabled" in coordinator)
check("coordinator:no-vehicle-options", "flowOf(emptyList())" in coordinator)
for forbidden in (
    "MaintenanceImportPort",
    "VehicleMatcherPort",
    "VertoLinkAuditPort",
    "VertoLinkTransactionRunner",
    "SaveInvoiceLinkCommand",
    "financeProjectionPort.saveLink",
    "maintenanceImportPort.importInvoice",
    "selectManual",
    "updateOdometerIfNewer",
):
    check(f"coordinator:no-write:{forbidden}", forbidden not in coordinator)

# Trusted automatic import remains the only creator for official v23 maintenance links.
for token in (
    "VertoMaintenanceProjectionRepository",
    "VehicleMatchHints(trustedRemoteId = candidate.optimalVehicleRemoteId)",
    "maintenanceImportPort.importInvoice",
    "financeProjectionPort.saveLink",
    "VertoLinkAuditPort",
):
    check(f"auto-import:retained:{token}", token in auto_import)

# Invoice details remain financially visible and legacy links remain readable.
check("details:no-events", "InvoiceDetailsUiEvent" not in details_contract)
check("details:no-vehicle-options", "InvoiceVehicleOptionUi" not in details_contract)
check("details:no-link-command", "LinkVertoInvoiceCommand" not in details_vm)
check("details:observe-existing-link", "observeLink(invoiceId)" in details_vm)
check("details:money-visible", "InvoiceMoneyCard(invoice)" in details_screen)
check("details:existing-link-visible", "LinkedInvoiceCard" in details_screen)
check("details:legacy-notice", "LegacyInvoiceLinkNotice" in details_screen)
check("details:legacy-read-only-tag", "legacy-invoice-link-read-only" in details_components)
for forbidden in (
    "LinkInvoiceCard",
    "link-invoice",
    "invoice-link-card",
    "VehicleSelected",
    "ServiceModeSelected",
    "ربط الفاتورة",
    "اختر السيارة",
):
    check(f"details:no-manual-action:{forbidden}", forbidden not in details_screen + details_components + details_vm)

# No list/dashboard/home affordance encourages manual linking.
check("list:no-needs-link-filter", "InvoiceListFilter.NEEDS_LINK" not in list_screen)
check("list:no-link-off", "LinkOff" not in list_components)
check("list:no-link-copy", "تحتاج ربطًا" not in list_components)
check("dashboard:no-link-off", "LinkOff" not in dashboard_components)
check("dashboard:no-link-copy", "تحتاج ربطًا" not in dashboard_components)
check("home:no-link-copy", "تحتاج ربطًا" not in home_components)

# New invoice notifications are standard review events only.
check("notification:standard-key", "NotificationEventPolicy.invoiceNewKey" in notification_source)
check("notification:standard-type", "NotificationType.INVOICE_NEW" in notification_source)
check("notification:no-link-key", "invoiceRequiresLinkKey" not in notification_source)
check("notification:no-link-type", "INVOICE_REQUIRES_LINK" not in notification_source)
check("notification:no-link-copy", "اربط الفاتورة" not in notification_source)
check("notification:recent-only", "cachedAtEpochMillis >= :newInvoiceCutoffEpochMillis" in notification_dao)
check("notification:no-persistent-link-query", "requiresVehicleLink = 1" not in notification_dao)
check("notification:row-no-link-flag", "requiresVehicleLink" not in notification_rows)

# Regression evidence covers disabled writes, existing links and notifications.
check("test:manual-disabled", "manualLinkIsDisabledAndCreatesNoMaintenanceOrLink" in link_test)
check("test:no-save", "assertEquals(0, finance.saves)" in link_test)
check("test:legacy-readable", "existingLegacyLinkRemainsReadableAndCannotBeRecreated" in idempotency_test)
check("test:already-linked", "LinkVertoInvoiceResult.AlreadyLinked" in idempotency_test)
check("test:notification-no-link", "assertFalse(source.contains(\"INVOICE_REQUIRES_LINK\"))" in notification_test)
check("test:legacy-reader-has-no-write-ports", "assertFalse(legacyReader.contains(\"MaintenanceImportPort\"))" in architecture_test)
check("test:auto-import-retains-write-ports", "assertTrue(automaticImporter.contains(\"MaintenanceImportPort\"))" in architecture_test)
check("spec:v62-precedence", "قرار Verto v23 النافذ منذ v62" in product_spec)
check("spec:financial-invoice-remains-visible", "الفاتورة المالية تبقى ظاهرة حتى دون صيانة" in product_spec)

# Delivery and quality gates.
for relative in (
    "scripts/v62-manual-invoice-link-retirement-harness.py",
    "scripts/run-v62-source-syntax-check.sh",
    "scripts/verify-v62-static.sh",
    "docs/sessions/v62.md",
    "docs/verifications/verification-v62.md",
):
    check(f"evidence:{relative}", (ROOT / relative).is_file())
check("gradle:v62-gate", "manualInvoiceLinkRetirementContractCheck" in root_build)
check("ci-fast:v62", "v62-manual-invoice-link-retirement-contract.py" in ci_fast)
check("ci-full:v62", "verify-v62-static.sh" in ci_full or "verify-v63-static.sh" in ci_full)
check("verify-project:v62", "verify-v62-static.sh" in verify_project or "verify-v63-static.sh" in verify_project)
check("verify-v62:v61-regression", "verify-v61-static.sh" in verify_v62)
check("android:version-stable", "versionCode = 32" in app_build and 'versionName = "0.37.0-v37"' in app_build)
check("room:version-stable", "version = 3" in database)
check("backend:no-v62-migration", not any((ROOT / "supabase/migrations").glob("*v62*")))

print(f"v62 manual invoice-link retirement contract: {len(checks)}/{len(checks)} PASS")
