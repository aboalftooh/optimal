#!/usr/bin/env python3
"""Static acceptance gate for OPTIMAL v60 Verto v23 source ingestion."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    checks.append((label, condition, detail))
    if not condition:
        raise AssertionError(f"{label}: {detail}")


def read(relative: str) -> str:
    path = ROOT / relative
    check(f"file:{relative}", path.is_file())
    return path.read_text(encoding="utf-8")


FINANCE = "feature/finance/src/main/java/com/optimal/fleet/feature/finance"
MAINTENANCE = "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance"

invoice_dto = read(f"{FINANCE}/data/verto/VertoInvoiceV23Dto.kt")
invoice_api = read(f"{FINANCE}/data/verto/OptimalVertoV23Api.kt")
invoice_transport = read(f"{FINANCE}/data/verto/SupabaseVertoInvoiceV23Transport.kt")
invoice_transport_contract = read(f"{FINANCE}/data/verto/VertoInvoiceV23Transport.kt")
invoice_mapper = read(f"{FINANCE}/data/verto/VertoInvoiceV23Mapper.kt")
invoice_source = read(f"{FINANCE}/data/verto/LinkedCompanyVertoInvoiceSource.kt")
invoice_repository = read(f"{FINANCE}/data/RoomInvoiceProjectionRepository.kt")
invoice_model = read(f"{FINANCE}/domain/invoice/model/VertoInvoiceSnapshot.kt")
invoice_repo_contract = read(f"{FINANCE}/domain/invoice/repository/InvoiceProjectionRepository.kt")
invoice_source_contract = read(f"{FINANCE}/domain/invoice/repository/VertoInvoiceSource.kt")
invoice_sync = read(f"{FINANCE}/domain/invoice/usecase/SyncVertoInvoices.kt")
finance_di = read(f"{FINANCE}/di/FinanceDataModule.kt")

maintenance_dto = read(f"{MAINTENANCE}/data/remote/VertoMaintenanceRemoteModels.kt")
maintenance_api = read(f"{MAINTENANCE}/data/remote/OptimalVertoMaintenanceApi.kt")
maintenance_remote = read(f"{MAINTENANCE}/data/remote/VertoMaintenanceRemoteDataSource.kt")
maintenance_mapper = read(f"{MAINTENANCE}/data/remote/VertoMaintenanceRemoteMapper.kt")
maintenance_source = read(f"{MAINTENANCE}/data/LinkedCompanyVertoMaintenanceSource.kt")
maintenance_repository = read(f"{MAINTENANCE}/data/RoomVertoMaintenanceProjectionRepository.kt")
maintenance_models = read(f"{MAINTENANCE}/domain/source/VertoMaintenanceSourceModels.kt")
maintenance_source_contract = read(f"{MAINTENANCE}/domain/source/VertoMaintenanceSource.kt")
maintenance_repo_contract = read(f"{MAINTENANCE}/domain/source/VertoMaintenanceProjectionRepository.kt")
maintenance_sync = read(f"{MAINTENANCE}/domain/usecase/SyncVertoMaintenanceProjections.kt")
maintenance_di = read(f"{MAINTENANCE}/di/MaintenanceSourceFeedModule.kt")
maintenance_build = read("feature/maintenance/build.gradle.kts")
projection_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceProjectionDao.kt")
constants = read("core/database/src/main/java/com/optimal/fleet/core/database/DatabaseConstants.kt")
root_build = read("build.gradle.kts")
ci_fast = read("scripts/ci-fast.sh")
ci_full = read("scripts/ci-full.sh")
verify_project = read("scripts/verify-project.sh")
verify_v60 = read("scripts/verify-v60-static.sh")

# Wire contract: endpoint and cursor-only request, no caller-provided tenant identity.
check("invoice:endpoint-v23", 'optimal_verto_invoice_feed_v23' in invoice_api)
check("maintenance:endpoint-v23", 'optimal_verto_maintenance_feed_v23' in maintenance_api)
for token in ("p_after_updated_at", "p_after_invoice_id", "p_limit"):
    check(f"invoice:request:{token}", token in invoice_dto)
for token in ("p_after_updated_at", "p_after_maintenance_id", "p_limit"):
    check(f"maintenance:request:{token}", token in maintenance_dto)
for source, label in ((invoice_dto, "invoice"), (maintenance_dto, "maintenance")):
    check(f"{label}:request-no-company-id", "p_company_id" not in source and "p_organization_id" not in source)
    check(f"{label}:serialization", "@Serializable" in source and "@SerialName" in source)

for token in (
    "organization_id", "client_id", "invoice_number", "currency_code", "total_amount",
    "paid_amount", "remaining_amount", "parts_cost_amount", "service_cost_amount",
    "source_updated_at", "contract_version", "requires_vehicle_link", "items",
    "unit_price", "line_total", "position",
):
    check(f"invoice:dto-field:{token}", token in invoice_dto)
for token in (
    "invoice_id", "optimal_vehicle_remote_id", "vehicle_name_snapshot", "plate_number_snapshot",
    "driver_name_snapshot", "odometer_km", "source_status", "completed_at", "source_updated_at",
    "media", "attachment_id", "mime_type", "size_bytes", "position",
):
    check(f"maintenance:dto-field:{token}", token in maintenance_dto)
check("maintenance:dto-no-public-url", all(token not in maintenance_dto for token in ("publicUrl", "storagePath", "signedUrl", "thumbnailPath")))

# Boundary/auth behavior.
for source, label in ((invoice_transport, "invoice"), (maintenance_remote, "maintenance")):
    check(f"{label}:configured-gate", "config.isConfigured" in source)
    check(f"{label}:auth-gate", "authSessionStore.current() == null" in source)
    check(f"{label}:permission-denied", "PermissionDenied" in source)
    check(f"{label}:missing-rpc-is-not-link-loss", "response.code() == 404 || isNotLinked" not in source)
    check(f"{label}:cancellation-rethrown", "throw cancellation" in source)
    check(f"{label}:limit-clamped", "coerceIn(1, MAX_PAGE_SIZE)" in source)
check("invoice:transport-domain-error", "DomainErrorMapper" in invoice_transport and "SafeErrorReporter" in invoice_transport)
check("invoice:transport-contract", "interface VertoInvoiceV23Transport" in invoice_transport_contract)

# Mapper validation and exact source semantics.
for token in ("RoundingMode.HALF_UP", 'currency == "SDG"', "contractVersion == 23", "!dto.requiresVehicleLink", "UUID.fromString", "itemUpdatedAt == sourceUpdatedAt"):
    check(f"invoice:mapper:{token}", token in invoice_mapper)
check("invoice:mapper-full-items", "items = items" in invoice_mapper and "VertoInvoiceItemSnapshot" in invoice_mapper)
check("invoice:mapper-stable-cursor", "VertoInvoiceCursor(sourceUpdatedAt, id)" in invoice_mapper)
for token in ("UUID.fromString", 'kind.trim().uppercase() == "IMAGE"', 'startsWith("image/")', "odometerKm >= 0L", "VertoMaintenanceCursor(sourceUpdatedAt, maintenanceId)"):
    check(f"maintenance:mapper:{token}", token in maintenance_mapper)
check("maintenance:trusted-vehicle-required", "optimalVehicleRemoteId.requiredUuid" in maintenance_mapper)
check("maintenance:private-metadata-only", all(token not in maintenance_mapper for token in ("storagePath", "publicUrl", "signedUrl")))

# Source pages must preserve and verify server order rather than silently repairing it.
for source, label in ((invoice_source, "invoice"), (maintenance_source, "maintenance")):
    check(f"{label}:strict-order", "zipWithNext().all" in source and "left.cursor < right.cursor" in source)
    check(f"{label}:no-order-repair", ".sortedBy { it.cursor }" not in source)
    check(f"{label}:cursor-advance", "it.cursor > cursor" in source)
    check(f"{label}:response-size-bound", "exceeded the requested limit" in source)
    check(f"{label}:link-state-updated", "updateVertoLinkStatus" in source)
check("invoice:source-v23-transport", "VertoInvoiceV23Transport" in invoice_source)
check("maintenance:source-module-owner", "package com.optimal.fleet.feature.maintenance" in maintenance_source)

# Atomic Room page persistence: projection + full children + cursor in one transaction.
invoice_commit_start = invoice_repository.index("override suspend fun commitVertoPage")
invoice_commit_end = invoice_repository.index("private suspend fun upsertSnapshotsInCurrentTransaction", invoice_commit_start)
invoice_commit = invoice_repository[invoice_commit_start:invoice_commit_end]
maintenance_commit_start = maintenance_repository.index("override suspend fun commitPage")
maintenance_commit_end = maintenance_repository.index("private fun validatePage", maintenance_commit_start)
maintenance_commit = maintenance_repository[maintenance_commit_start:maintenance_commit_end]

for repository, commit_block, label, child_call, page_commit_call, feed_key in (
    (
        invoice_repository,
        invoice_commit,
        "invoice",
        "itemDao.replaceSnapshot",
        "val summary = upsertSnapshotsInCurrentTransaction",
        "VERTO_INVOICES_V23_CURSOR",
    ),
    (
        maintenance_repository,
        maintenance_commit,
        "maintenance",
        "mediaDao.replaceSnapshot",
        "mediaDao.replaceSnapshot",
        "VERTO_MAINTENANCE_V23_CURSOR",
    ),
):
    check(f"{label}:transaction-runner", "transactionRunner.run" in commit_block)
    check(f"{label}:full-snapshot", child_call in repository)
    check(f"{label}:durable-cursor", "cursorDao.upsert" in commit_block and feed_key in commit_block)
    check(f"{label}:cursor-written-last", commit_block.find(page_commit_call) < commit_block.rfind("cursorDao.upsert"))
    check(
        f"{label}:monotonic-in-transaction",
        commit_block.find("transactionRunner.run")
        < commit_block.find("must advance monotonically")
        < commit_block.rfind("cursorDao.upsert"),
    )
    check(f"{label}:strict-page-validation", "zipWithNext().all" in repository)
    check(f"{label}:page-cursor-match", "page cursor does not match the committed page" in repository)
check("invoice:room-v23-only", "Only Verto invoice contract v23" in invoice_repository)
check("invoice:room-sdg-only", "only supports SDG" in invoice_repository)
check("invoice:room-no-manual-link", "cannot request manual vehicle linking" in invoice_repository)
check("invoice:v22-equal-version-upgrade", "existing.contractVersion < snapshot.contractVersion" in invoice_repository)
check("invoice:stable-item-id", '"verto-item:$vertoInvoiceId:${item.sourceItemId}"' in invoice_repository)
check("maintenance:stable-projection-id", '"verto-maintenance:$sourceMaintenanceId"' in maintenance_repository)
check("maintenance:stable-media-id", '"verto-maintenance-media:$sourceMaintenanceId:${item.sourceMediaId}"' in maintenance_repository)
check("maintenance:tenant-scoped-update", "updateScoped" in projection_dao and "WHERE id = :id AND companyId = :companyId" in projection_dao)

# Cursor/domain pagination and DI.
check("cursor:invoice-independent", 'VERTO_INVOICES_V23_CURSOR = "VERTO_INVOICES_V23"' in constants)
check("cursor:maintenance-independent", 'VERTO_MAINTENANCE_V23_CURSOR = "VERTO_MAINTENANCE_V23"' in constants)
check("invoice:model-items", "data class VertoInvoiceItemSnapshot" in invoice_model and "items: List<VertoInvoiceItemSnapshot>" in invoice_model)
check("invoice:repo-page-contract", "commitVertoPage" in invoice_repo_contract and "currentVertoFeedCursor" in invoice_repo_contract)
check("invoice:source-page-contract", "fetchPage" in invoice_source_contract and "nextCursor" in invoice_source_contract)
check("invoice:sync-paged", "MAX_PAGES_PER_SYNC" in invoice_sync and "commitVertoPage" in invoice_sync)
check("maintenance:source-models-pure", not any(token in maintenance_models for token in ("android.", "androidx.", "retrofit2", "kotlinx.serialization")))
check("maintenance:source-contract", "interface VertoMaintenanceSource" in maintenance_source_contract)
check("maintenance:repo-contract", "interface VertoMaintenanceProjectionRepository" in maintenance_repo_contract)
check("maintenance:sync-paged", "MAX_PAGES_PER_SYNC" in maintenance_sync and "commitPage" in maintenance_sync)
check("finance:di-v23", "bindVertoInvoiceV23Transport" in finance_di and "bindVertoInvoiceSource" in finance_di)
check("maintenance:di-source", "bindVertoMaintenanceSource" in maintenance_di and "bindVertoMaintenanceProjectionRepository" in maintenance_di)
check("maintenance:network-dependency", 'implementation(project(":core:network"))' in maintenance_build)
check("maintenance:serialization-plugin", "kotlin.serialization" in maintenance_build and "kotlinx.serialization.json" in maintenance_build)

# Ownership and deferred runtime import.
verto_maintenance_files = [p for p in (ROOT / "feature/verto/src/main").rglob("*VertoMaintenance*.kt")]
check("ownership:no-maintenance-ingestion-in-feature-verto", not verto_maintenance_files, str(verto_maintenance_files))
app_text = "\n".join(p.read_text(encoding="utf-8") for p in (ROOT / "app/src/main").rglob("*.kt"))
check("v60:maintenance-ingestion-remains-domain-owned", "SyncVertoMaintenanceProjections" in maintenance_sync)
check("v60:no-supabase-migration", not any((ROOT / "supabase/migrations").glob("*v60*")))
check("android:version-stable", "versionCode = 32" in read("app/build.gradle.kts"))

# Tests, executable evidence, and Gradle gate.
for relative in (
    "feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceV23MapperTest.kt",
    "feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/VertoInvoicePageCommitTest.kt",
    "feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/data/remote/VertoMaintenanceRemoteMapperTest.kt",
    "scripts/v60-verto-source-ingestion-harness.py",
    "scripts/run-v60-verto-source-ingestion-harness.sh",
    "scripts/run-v60-source-syntax-check.sh",
    "scripts/verify-v60-static.sh",
):
    check(f"evidence:{relative}", (ROOT / relative).is_file())
check("gradle:v60-gate-registered", "vertoSourceIngestionContractCheck" in root_build and "scripts/v60-verto-source-ingestion-contract.py" in root_build)
check("gradle:static-quality-depends-v60", "vertoSourceIngestionContractCheck," in root_build)
check("ci-fast:v60-contract", "v60-verto-source-ingestion-contract.py" in ci_fast)
check("ci-fast:v60-harness", "v60-verto-source-ingestion-harness.py" in ci_fast)
check("ci-full:v60-route", any(name in ci_full for name in ("verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-project:v60-route", any(name in verify_project for name in ("verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-v60:room-v3-regression", "v59-room-v3-contract.py" in verify_v60)
check("verify-v60:architecture", "static-architecture-check.py" in verify_v60 and "v47-verto-feature-architecture.py" in verify_v60)
check("verify-v60:security", "security-release-check.py" in verify_v60)
check("verify-v60:focused-syntax", "run-v60-source-syntax-check.sh" in verify_v60 and "run-v59-room-syntax-check.sh" in verify_v60)

print(f"v60 Verto source ingestion contract: {len(checks)}/{len(checks)} PASS")
