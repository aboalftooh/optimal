#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v44 detailed Verto invoice feed."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
V22 = ROOT / "supabase/migrations/20260728002200_optimal_verto_direct_link.sql"
V43 = ROOT / "supabase/migrations/20260731004300_optimal_verto_private_attachments.sql"
V44 = ROOT / "supabase/migrations/20260731004400_optimal_verto_invoice_feed_v23.sql"
PREFLIGHT = ROOT / "supabase/tests/v44_verto_invoice_preflight.sql"
SCENARIOS = ROOT / "supabase/tests/v44_verto_invoice_scenarios.sql"
PROMOTION = ROOT / "supabase/post_deploy/v44_promote_verto_finance_v23_ready.sql"
SESSION = ROOT / "docs/sessions/v44.md"
DEPLOYMENT = ROOT / "docs/integrations/verto-invoice-feed-deployment-v44.md"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
MATRIX = ROOT / "docs/integrations/verto-contract-matrix-v23.md"
ROOT_GRADLE = ROOT / "build.gradle.kts"
CI_FAST = ROOT / "scripts/ci-fast.sh"
CI_FULL = ROOT / "scripts/ci-full.sh"
VERIFY_PROJECT = ROOT / "scripts/verify-project.sh"

checks: list[tuple[str, bool]] = []

def check(name: str, condition: bool) -> None:
    checks.append((name, condition))

def has(text: str, *values: str) -> bool:
    return all(value in text for value in values)

def block(sql: str, name: str, next_name: str | None = None) -> str:
    marker = f"create or replace function public.{name}("
    start = sql.find(marker)
    if start < 0:
        return ""
    if next_name:
        end = sql.find(f"create or replace function public.{next_name}(", start + len(marker))
        if end >= 0:
            return sql[start:end]
    return sql[start:]

required = [V22, V43, V44, PREFLIGHT, SCENARIOS, PROMOTION, SESSION, DEPLOYMENT,
            CONTRACT, MATRIX, ROOT_GRADLE, CI_FAST, CI_FULL, VERIFY_PROJECT]
for path in required:
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())
if not all(path.is_file() for path in required):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

v22 = V22.read_text(encoding="utf-8")
v43 = V43.read_text(encoding="utf-8")
v44 = V44.read_text(encoding="utf-8")
preflight = PREFLIGHT.read_text(encoding="utf-8")
scenarios = SCENARIOS.read_text(encoding="utf-8")
promotion = PROMOTION.read_text(encoding="utf-8")
session = SESSION.read_text(encoding="utf-8")
deployment = DEPLOYMENT.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
matrix = MATRIX.read_text(encoding="utf-8")
root_gradle = ROOT_GRADLE.read_text(encoding="utf-8")
ci_fast = CI_FAST.read_text(encoding="utf-8")
ci_full = CI_FULL.read_text(encoding="utf-8")
verify_project = VERIFY_PROJECT.read_text(encoding="utf-8")

context = block(v44, "optimal_verto_current_financial_context", "optimal_touch_invoice_source_updated_at")
touch = block(v44, "optimal_touch_invoice_source_updated_at", "optimal_verto_invoice_feed")
v22feed = block(v44, "optimal_verto_invoice_feed", "optimal_verto_invoice_feed_v23")
v23feed = block(v44, "optimal_verto_invoice_feed_v23")

migrations = sorted(p.name for p in (ROOT / "supabase/migrations").glob("*.sql"))
check("order:v44-after-v43", migrations.index(V44.name) > migrations.index(V43.name))
check("scope:no-kotlin-production", not any(p.suffix in {".kt", ".java"} and "v44" in p.name.lower() for p in ROOT.rglob("*")))
check("scope:no-financial-bridge-table", "create table" not in v44.lower())
check("scope:no-financial-copy-names", not any(x in v44.lower() for x in ("finance_bridge", "invoice_items_bridge", "invoice_v23_snapshots")))
check("scope:contract-version-not-promoted", "set contract_version = 23" not in v44.lower())
check("scope:finance-readiness-false", has(v44, "set verto_finance_v23_ready = false", "where singleton = true"))
check("scope:v22-source-preserved", "create or replace function public.optimal_verto_invoice_feed(" in v44)

for source in ("public.invoices", "public.invoice_items", "public.payments"):
    check(f"source:{source.split('.')[-1]}", source in v23feed)
check("source:no-payments-updated-at", "p.updated_at" not in v44 and "payments.updated_at" in v44)
check("source:no-items-updated-at", "ii.updated_at" not in v44)
for col in ("item_name", "item_type", "quantity", "sell_price", "total_price"):
    check(f"source:item-column:{col}", f"ii.{col}" in v23feed)
for col in ("invoice_id", "client_id", "organization_id", "amount"):
    check(f"source:payment-column:{col}", f"p.{col}" in v23feed)

check("context:no-arguments", "optimal_verto_current_financial_context()" in context)
check("context:security-definer", has(context, "security definer", "set search_path = pg_catalog, public, auth"))
check("context:auth-required", has(context, "auth.uid() is null", "auth_session_required"))
check("context:active-member", has(context, "m.auth_user_id = auth.uid()", "m.is_active = true"))
check("context:active-link", has(context, "l.is_active = true", "l.optimal_company_id = m.company_id"))
check("context:link-org-match", has(context, "c.id = l.verto_client_id", "c.organization_id = l.verto_organization_id"))
check("context:no-chat-capability", "VIEW_VERTO_CHAT" not in context and "SEND_VERTO_CHAT" not in context)
check("context:not-client-executable", "from public, anon, authenticated" in context and "to service_role" in context)

check("v23:no-company-payload", "p_company_id" not in v23feed)
check("v23:uses-server-context", "optimal_verto_current_financial_context()" in v23feed)
check("touch:security-definer", "security definer" in touch)
check("touch:old-id", "old.invoice_id" in touch)
check("touch:new-id", "new.invoice_id" in touch)
check("touch:moved-child-both-parents", has(touch, "tg_op in ('UPDATE', 'DELETE')", "tg_op in ('INSERT', 'UPDATE')", "is distinct from old.invoice_id"))
check("touch:clock-time", "clock_timestamp()" in touch)
check("touch:item-trigger", has(v44, "optimal_invoice_items_touch_invoice", "on public.invoice_items"))
check("touch:payment-trigger", has(v44, "optimal_payments_touch_invoice", "on public.payments"))
check("touch:delete-reversal", "tg_op = 'DELETE'" in touch)

check("v22:same-signature", has(v22feed, "p_company_id uuid", "p_updated_after_ms bigint", "p_after_invoice_id text"))
for field in ("id text", "organization_id text", "client_id text", "invoice_number bigint",
              "total_amount numeric", "paid_amount numeric", "remaining_amount numeric",
              "parts_cost_amount numeric", "service_cost_amount numeric", "requires_vehicle_link boolean"):
    check(f"v22:return:{field}", field in v22feed)
check("v22:membership", "optimal_is_active_company_member(p_company_id)" in v22feed)
check("v22:linked-client-org", has(v22feed, "l.verto_client_id = inv.client_id", "l.verto_organization_id = inv.organization_id"))
check("v22:parent-source-version", "coalesce(inv.updated_at, inv.created_at" in v22feed)
check("v22:no-invalid-payment-timestamp", "payment_updated_at" not in v22feed and "p.updated_at" not in v22feed)
check("v22:requires-link-true", re.search(r"f\.source_updated_at,\s*true", v22feed, re.S) is not None)
check("v22:limit-500", "limit 500" in v22feed)
check("v22:authenticated-grant", has(v44, "grant execute on function public.optimal_verto_invoice_feed(uuid, bigint, text)", "to authenticated"))

check("v23:signature", has(v23feed, "p_after_updated_at timestamptz", "p_after_invoice_id uuid", "p_limit integer"))
for field in ("id uuid", "organization_id uuid", "client_id uuid", "invoice_number text", "currency_code text",
              "total_amount text", "paid_amount text", "remaining_amount text", "parts_cost_amount text",
              "service_cost_amount text", "source_updated_at timestamptz", "contract_version integer",
              "requires_vehicle_link boolean", "items jsonb"):
    check(f"v23:return:{field}", field in v23feed)
check("v23:cursor-pair", "(p_after_updated_at is null) <> (p_after_invoice_id is null)" in v23feed)
check("v23:cursor-error", "invoice_cursor_pair_required" in v23feed)
check("v23:composite-cursor", "(f.source_updated_at, f.id) > (p_after_updated_at, p_after_invoice_id)" in v23feed)
check("v23:ordered", v23feed.count("order by p.source_updated_at asc, p.id asc") >= 1)
check("v23:no-offset", " offset " not in v23feed.lower())
check("v23:default-limit-500", "coalesce(p_limit, 500)" in v23feed)
check("v23:bounded-limit", "least(greatest" in v23feed and "500" in v23feed)
check("v23:currency-sdg", "'SDG'::text" in v23feed)
check("v23:contract-23", re.search(r"p\.source_updated_at,\s*23,\s*false", v23feed, re.S) is not None)
check("v23:decimal-text", v23feed.count("pg_catalog.to_char") >= 7 and "ranked.quantity_value::text" in v23feed)
check("v23:authenticated-grant", has(v44, "grant execute on function public.optimal_verto_invoice_feed_v23(timestamptz, uuid, integer)", "to authenticated"))

check("tenant:invoice-client", "c.verto_client_id = inv.client_id" in v23feed)
check("tenant:invoice-org", "c.verto_organization_id = inv.organization_id" in v23feed)
check("tenant:payment-client", "c.verto_client_id = p.client_id" in v23feed)
check("tenant:payment-org", "c.verto_organization_id = p.organization_id" in v23feed)
check("tenant:item-org", "ii.organization_id = p.organization_id" in v23feed)
check("totals:payments-sum", "sum(p.amount)" in v23feed)
check("totals:remaining", "greatest(coalesce(inv.total_amount, 0) - coalesce(pt.paid, 0), 0)" in v23feed)
check("totals:parts", "ii.item_type = 'GOODS'" in v23feed)
check("totals:service", "ii.item_type = 'SERVICE'" in v23feed)
check("totals:voided", "coalesce(inv.voided, false)" in v23feed)

check("items:json-array", has(v23feed, "jsonb_agg", "jsonb_build_object", "'[]'::jsonb"))
for field in ("'id'", "'name'", "'kind'", "'quantity'", "'unit_price'", "'line_total'", "'position'", "'source_updated_at'"):
    check(f"items:field:{field}", field in v23feed)
check("items:full-current-snapshot", has(v23feed, "from public.invoice_items ii", "where ii.invoice_id = p.id"))
check("items:stable-position", "row_number() over (order by ii.id) - 1" in v23feed)
check("items:source-version-parent", "'source_updated_at', p.source_updated_at" in v23feed)
check("items:name-source-derived", has(v23feed, "ii.item_name", "ii.description", "'Item'"))
check("items:unit-price", has(v23feed, "ii.sell_price", "ii.total_price / ii.quantity"))
check("items:line-total", "coalesce(ii.total_price, 0)" in v23feed)

for token in ("v44_missing_invoice_feed_v23", "v44_v23_wire_signature_mismatch", "v44_missing_item_touch_trigger",
              "v44_missing_payment_touch_trigger", "v44_financial_bridge_copy_detected", "v44_readiness_promoted_before_live_scenarios"):
    check(f"preflight:{token}", token in preflight)
for token in ("v44_multi_item_snapshot_missing", "v44_multi_payment_total_missing", "v44_payment_reversal_not_visible",
              "v44_item_only_update_not_visible", "v44_void_not_visible", "v44_v22_compatibility_broken",
              "v44_page_limit_returned_empty", "v44_composite_cursor_lost_equal_time_invoice",
              "v44_cross_tenant_invoice_leaked", "rollback;"):
    check(f"scenario:{token}", token in scenarios)

check("promotion:not-migration", PROMOTION.parent.name == "post_deploy")
check("promotion:gated", has(promotion, "v44_touch_triggers_missing", "v44_readiness_prerequisites_not_met"))
check("promotion:sets-only-ready", "set verto_finance_v23_ready = true" in promotion and "set contract_version" not in promotion.lower())
check("docs:session-scope", has(session, "v44", "الفواتير", "Cursor"))
check("docs:session-no-copy", "لا" in session and "نسخة مالية" in session)
check("docs:deployment-order", has(deployment, "preflight", "scenarios", "post_deploy"))
check("docs:deployment-rollback", "Rollback" in deployment or "تراجع" in deployment)
check("docs:contract-v23", "optimal_verto_invoice_feed_v23" in contract and "items" in contract)
check("docs:matrix-items", "VertoInvoiceItemDto" in matrix and "Full snapshot" in matrix)
check("gradle:gate", has(root_gradle, "vertoInvoiceFeedContractCheck", "scripts/v44-invoice-feed-contract.py"))
check("ci-fast:gate", "scripts/v44-invoice-feed-contract.py" in ci_fast)
check("ci-full:v44-wrapper", any(name in ci_full for name in ("verify-v44-static.sh", "verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh", "verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-project:v44-wrapper", any(name in verify_project for name in ("verify-v44-static.sh", "verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh", "verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))

for label, text in (("v44", v44), ("preflight", preflight), ("scenarios", scenarios), ("promotion", promotion)):
    check(f"syntax:{label}-dollar-quotes", text.count("$$") % 2 == 0)
    check(f"syntax:{label}-no-merge-markers", not any(x in text for x in ("<<<<<<<", "=======", ">>>>>>>")))

failed = []
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
    if not ok:
        failed.append(name)
print(f"RESULT {len(checks)-len(failed)}/{len(checks)}")
if failed:
    print("FAILED:", ", ".join(failed))
    sys.exit(1)
