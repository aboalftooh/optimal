package v20harness

import com.optimal.fleet.feature.finance.data.verto.VertoInvoiceDto
import com.optimal.fleet.feature.finance.data.verto.VertoInvoiceMapper
import kotlinx.serialization.json.JsonPrimitive

private var checks = 0
private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks++
    println("PASS: $name")
}

fun main() {
    val snapshot = VertoInvoiceMapper.map(
        VertoInvoiceDto(
            id = "invoice-v20",
            organizationId = "org-1",
            clientId = "client-1",
            invoiceNumber = 200,
            type = "SERVICE",
            description = "صيانة دورية",
            totalAmount = JsonPrimitive("1000.00"),
            paidAmount = JsonPrimitive("400.50"),
            remainingAmount = JsonPrimitive("599.50"),
            partsCostAmount = JsonPrimitive("650.25"),
            serviceCostAmount = JsonPrimitive("349.75"),
            status = "PARTIALLY_PAID",
            category = "FULL_SERVICE",
            voided = false,
            createdAt = "2026-07-28T08:00:00Z",
            updatedAt = "2026-07-28T09:00:00Z",
            requiresVehicleLink = false,
        ),
    )
    verify("total mapped to minor", snapshot.totalMinor == 100_000L)
    verify("paid mapped to minor", snapshot.paidMinor == 40_050L)
    verify("remaining mapped to minor", snapshot.remainingMinor == 59_950L)
    verify("parts mapped to minor", snapshot.partsCostMinor == 65_025L)
    verify("service mapped to minor", snapshot.serviceCostMinor == 34_975L)
    verify("source vehicle-link flag preserved", !snapshot.requiresVehicleLink)
    verify("source invoice identity preserved", snapshot.vertoInvoiceId == "invoice-v20")
    verify("source client identity preserved", snapshot.vertoClientId == "client-1")
    verify("source status preserved", snapshot.sourceStatus == "PARTIALLY_PAID")

    val rounded = VertoInvoiceMapper.map(
        VertoInvoiceDto(
            id = "rounding",
            organizationId = "org-1",
            invoiceNumber = 201,
            type = "PARTS",
            totalAmount = JsonPrimitive("1.005"),
            status = "OPEN",
            voided = false,
            createdAt = "2026-07-28T08:00:00Z",
            updatedAt = "2026-07-28T08:00:00Z",
        ),
    )
    verify("money rounding is deterministic", rounded.totalMinor == 101L)
    verify("optional financial fields stay null", rounded.paidMinor == null && rounded.remainingMinor == null)
    verify("default vehicle-link requirement stays true", rounded.requiresVehicleLink)

    println("V20 domain harness: $checks/$checks")
}
