package v28harness

import com.optimal.fleet.core.database.sync.LocalWriteVersion
import com.optimal.fleet.core.database.sync.SyncOutboxEntryFactory
import com.optimal.fleet.core.model.transaction.DirectAtomicWriteTransactionRunner
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var passed = 0
private var failed = 0

private fun check(name: String, condition: Boolean) {
    if (condition) {
        passed += 1
        println("PASS: $name")
    } else {
        failed += 1
        println("FAIL: $name")
    }
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var result: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(resumeResult: Result<T>) {
            result = resumeResult
        }
    })
    return result!!.getOrThrow()
}

fun main() {
    val first = SyncOutboxEntryFactory.create(
        companyId = "company",
        aggregateType = "VEHICLE",
        aggregateId = "vehicle",
        operationType = "UPSERT",
        payload = "{}",
        localVersion = 42L,
        remoteId = null,
    )
    val retry = SyncOutboxEntryFactory.create(
        companyId = "company",
        aggregateType = "VEHICLE",
        aggregateId = "vehicle",
        operationType = "UPSERT",
        payload = "{}",
        localVersion = 42L,
        remoteId = null,
    )
    val next = SyncOutboxEntryFactory.create(
        companyId = "company",
        aggregateType = "VEHICLE",
        aggregateId = "vehicle",
        operationType = "UPSERT",
        payload = "{}",
        localVersion = 43L,
        remoteId = null,
    )

    check("stable id", first.id == retry.id)
    check("stable idempotency key", first.idempotencyKey == retry.idempotencyKey)
    check("expected key format", first.id == "VEHICLE:vehicle:UPSERT:42")
    check("new version gets new identity", first.id != next.id)
    check("new write starts pending", first.state == "PENDING")
    check("captured version timestamps entry", first.createdAtEpochMillis == 42L && first.updatedAtEpochMillis == 42L)
    check("clock starts version", LocalWriteVersion.next(100L, null) == 100L)
    check("version advances if clock stalls", LocalWriteVersion.next(99L, 100L) == 101L)
    check("clock wins if newer", LocalWriteVersion.next(150L, 100L) == 150L)
    check("direct test runner returns block result", runSuspend { DirectAtomicWriteTransactionRunner.run { 7 } } == 7)

    println("V28 atomic Kotlin harness: $passed/${passed + failed}")
    if (failed != 0) error("v28 atomic harness failed")
}
