#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
python3 scripts/v58-verto-daily-cycle-contract.py
./scripts/run-v58-verto-daily-cycle-harness.sh
bash scripts/verify-v57-static.sh
bash scripts/run-v53-verto-sync-syntax-check.sh
bash scripts/run-v54-verto-text-syntax-check.sh
bash scripts/run-v55-verto-attachment-syntax-check.sh
bash scripts/run-v36-test-syntax-check.sh
