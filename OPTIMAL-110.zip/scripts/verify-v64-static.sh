#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v64-unified-sync-contract.py
python3 scripts/v64-unified-sync-harness.py
python3 scripts/v64-kotlin-source-check.py
bash scripts/run-v64-source-syntax-check.sh
bash scripts/run-v64-unified-semantic-compile.sh
python3 scripts/v63-invoice-vehicle-history-contract.py
python3 scripts/v63-invoice-vehicle-history-harness.py
python3 scripts/v62-manual-invoice-link-retirement-contract.py
python3 scripts/v62-manual-invoice-link-retirement-harness.py
python3 scripts/v61-verto-maintenance-import-contract.py
python3 scripts/v61-verto-maintenance-import-harness.py
python3 scripts/v60-verto-source-ingestion-contract.py
python3 scripts/v60-verto-source-ingestion-harness.py
python3 scripts/v59-room-v3-contract.py
python3 scripts/v58-verto-daily-cycle-contract.py
bash scripts/run-v58-verto-daily-cycle-harness.sh
python3 scripts/v57-verto-attachment-transfer-contract.py
python3 scripts/v57-verto-attachment-transfer-harness.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/static-architecture-check.py
python3 scripts/security-release-check.py
python3 -m py_compile scripts/v64-unified-sync-contract.py scripts/v64-unified-sync-harness.py scripts/v64-kotlin-source-check.py
bash -n scripts/verify-v64-static.sh scripts/run-v64-source-syntax-check.sh scripts/run-v64-unified-semantic-compile.sh
