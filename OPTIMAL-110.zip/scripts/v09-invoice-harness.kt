package v09harness

import com.optimal.fleet.feature.finance.data.verto.VertoInvoiceDto
import com.optimal.fleet.feature.finance.data.verto.VertoInvoiceMapper
import com.optimal.fleet.feature.finance.domain.invoice.model.InvoiceMergeDecision
import com.optimal.fleet.feature.finance.domain.invoice.model.InvoiceSourceVersionPolicy
import com.optimal.fleet.feature.finance.domain.invoice.model.VertoInvoiceSnapshot
import kotlinx.serialization.json.JsonPrimitive

private var checks = 0
private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks++
    println("PASS: $name")
}

private class Ledger {
    private val rows = linkedMapOf<String, VertoInvoiceSnapshot>()
    var auditCount = 0
        private set

    fun upsert(snapshot: VertoInvoiceSnapshot): InvoiceMergeDecision {
        val old = rows[snapshot.vertoInvoiceId]
        val decision = InvoiceSourceVersionPolicy.decide(
            old?.sourceUpdatedAtEpochMillis,
            snapshot.sourceUpdatedAtEpochMillis,
        )
        when (decision) {
            InvoiceMergeDecision.INSERT,
            InvoiceMergeDecision.UPDATE,
            -> {
                rows[snapshot.vertoInvoiceId] = snapshot
                auditCount++
            }
            InvoiceMergeDecision.IGNORE_STALE_OR_EQUAL -> Unit
        }
        return decision
    }

    fun get(id: String): VertoInvoiceSnapshot? = rows[id]
    fun size(): Int = rows.size
}

fun main() {
    val mapped = VertoInvoiceMapper.map(
        VertoInvoiceDto(
            id = "invoice-1",
            organizationId = "org-1",
            clientId = "client-company",
            invoiceNumber = 77,
            type = "SALE",
            description = "قطع غيار",
            totalAmount = JsonPrimitive("1250.50"),
            status = "OPEN",
            category = "PARTS",
            voided = false,
            createdAt = "2026-07-01T10:00:00Z",
            updatedAt = "2026-07-01T11:00:00Z",
        ),
    )
    verify("money mapped to minor units", mapped.totalMinor == 125_050L)
    verify("source id preserved", mapped.vertoInvoiceId == "invoice-1")
    verify("client id preserved", mapped.vertoClientId == "client-company")
    verify("unknown paid is null", mapped.paidMinor == null)
    verify("unknown remaining is null", mapped.remainingMinor == null)
    verify("unknown parts split is null", mapped.partsCostMinor == null)
    verify("unknown service split is null", mapped.serviceCostMinor == null)
    verify("missing vehicle data requires linking", mapped.requiresVehicleLink)

    val ledger = Ledger()
    verify("first projection inserts", ledger.upsert(mapped) == InvoiceMergeDecision.INSERT)
    verify("duplicate source version ignored", ledger.upsert(mapped) == InvoiceMergeDecision.IGNORE_STALE_OR_EQUAL)
    verify("dedup keeps one projection", ledger.size() == 1)

    val newer = mapped.copy(totalMinor = 150_000L, sourceUpdatedAtEpochMillis = mapped.sourceUpdatedAtEpochMillis + 1)
    verify("newer source updates", ledger.upsert(newer) == InvoiceMergeDecision.UPDATE)
    verify("same projection updated in place", ledger.size() == 1 && ledger.get("invoice-1")?.totalMinor == 150_000L)

    val stale = mapped.copy(totalMinor = 1L, sourceUpdatedAtEpochMillis = mapped.sourceUpdatedAtEpochMillis - 1)
    verify("stale source cannot overwrite", ledger.upsert(stale) == InvoiceMergeDecision.IGNORE_STALE_OR_EQUAL)
    verify("newer cached value retained", ledger.get("invoice-1")?.totalMinor == 150_000L)

    val voided = newer.copy(voided = true, sourceUpdatedAtEpochMillis = newer.sourceUpdatedAtEpochMillis + 1)
    verify("source void updates same projection", ledger.upsert(voided) == InvoiceMergeDecision.UPDATE)
    verify("source void retained", ledger.get("invoice-1")?.voided == true)
    verify("audit only records insert and source changes", ledger.auditCount == 3)

    println("V09 invoice harness: $checks/$checks")
}
