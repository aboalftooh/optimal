#!/usr/bin/env python3
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))

colors = (ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalColors.kt").read_text(encoding="utf-8")
for hex_value in [
    "235AEA","356FF2","173EBA","ECEEFF","F6F8FF","2F6CF4","1F49D9",
    "FBFBFF","FFFFFF","F6F7FB","FAFCFF","F0F5FF","101D4A","737990","9AA0B2",
    "E5E8F1","D6DCEB","14965A","EAF8F0","A66A00","FFF4DE","D94A66","FFF0F3","1B2E6B",
]:
    check(f"color #{hex_value}", f"0xFF{hex_value}" in colors)

foundations = (ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalFoundations.kt").read_text(encoding="utf-8")
for token in ["flat = 0.dp","raised = 2.dp","overlay = 5.dp","modal = 8.dp","minimum = 48.dp","comfortable = 56.dp","compactMax = 600.dp","readableMax = 840.dp"]:
    check(f"foundation {token}", token in foundations)
spacing=(ROOT/"core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalSpacing.kt").read_text(encoding="utf-8")
for token in ["2.dp","4.dp","8.dp","12.dp","16.dp","24.dp","32.dp","40.dp","18.dp","20.dp"]:
    check(f"spacing contains {token}", token in spacing)
shapes=(ROOT/"core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalShapes.kt").read_text(encoding="utf-8")
for token in ["8.dp","12.dp","16.dp","22.dp","28.dp"]:
    check(f"radius contains {token}", token in shapes)

typography=(ROOT/"core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTypography.kt").read_text(encoding="utf-8")
for token in ["fontSize = 34.sp","lineHeight = 42.sp","fontSize = 28.sp","lineHeight = 36.sp","fontSize = 25.sp","lineHeight = 33.sp","fontSize = 20.sp","lineHeight = 28.sp","fontSize = 22.sp","lineHeight = 30.sp","fontSize = 26.sp","lineHeight = 32.sp","val appBarBrand","val appBarTitle","val action"]:
    check(f"typography contains {token}", token in typography)
check("headlineMedium ExtraBold", bool(re.search(r"headlineMedium\s*=.*?fontWeight = FontWeight\.ExtraBold", typography, flags=re.S)))

font_files=sorted(p.name for p in (ROOT/"core/designsystem/src/main/res/font").glob("*"))
expected_fonts=sorted(["tajawal_bold.ttf","tajawal_extra_bold.ttf","tajawal_light.ttf","tajawal_medium.ttf","tajawal_regular.ttf"])
check("Tajawal is the only product font asset family", font_files==expected_fonts, str(font_files))
production_font_refs=[]
for base in [ROOT/"app/src/main", ROOT/"feature"]:
    if not base.exists(): continue
    for p in base.rglob("*.kt"):
        t=p.read_text(encoding="utf-8",errors="ignore")
        if "FontFamily" in t or "fontFamily =" in t:
            production_font_refs.append(p.relative_to(ROOT).as_posix())
check("feature/app code defines no competing font family", not production_font_refs, str(production_font_refs))

ledger=(ROOT/"docs/design-system/FULL_UI_MIGRATION_LEDGER.md").read_text(encoding="utf-8")
ids=re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|", ledger, flags=re.M)
check("ledger has 123 rows", len(ids)==123, str(len(ids)))
check("ledger IDs unique", len(set(ids))==123, str(len(set(ids))))
for prefix,expected in [("SCR",27),("DLG",5),("OVL",2),("CMP",1),("STA",88)]:
    count=sum(1 for i in ids if i.startswith(prefix+"-"))
    check(f"ledger {prefix} count {expected}", count==expected, str(count))
status_rows=re.findall(r"^\| (?:SCR|DLG|OVL|CMP|STA)-\d{3} \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$",ledger,flags=re.M)
check("all 123 migration rows have a valid status",len(status_rows)==123,str(len(status_rows)))
check("all 123 rows are UNMIGRATED",status_rows.count("UNMIGRATED")==123,str(status_rows.count("UNMIGRATED")))

constitution=(ROOT/"docs/design-system/REFERENCE_VISUAL_CONSTITUTION.md").read_text(encoding="utf-8")
for marker in ["# 4. Locked visual constitution","# 5. Canonical visual patterns","# 6. Shared component contract","BrandPrimary          #235AEA","OptimalHeroButton","OptimalConfirmationDialog"]:
    check(f"constitution contains {marker}", marker in constitution)

plan=ROOT/"docs/design-system/OPTIMAL_FULL_DESIGN_SYSTEM_MIGRATION_MASTER_PLAN_v96.md"
check("master plan embedded in project",plan.is_file())

proc=subprocess.run([sys.executable,str(ROOT/"scripts/design-system-compliance-guard.py"),"--baseline"],cwd=ROOT,text=True,capture_output=True)
print(proc.stdout,end="")
if proc.stderr: print(proc.stderr,end="",file=sys.stderr)
check("compliance guard baseline",proc.returncode==0)

failed=[x for x in checks if not x[1]]
for name,ok,detail in checks:
    print(("PASS" if ok else "FAIL")+": "+name+(f" [{detail}]" if detail else ""))
print(f"\nSESSION-97 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
