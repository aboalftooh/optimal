#!/usr/bin/env python3
"""Release security gate for OPTIMAL v37.

Uses the Python standard library only so it can fail CI before Gradle or an
Android SDK is available. It verifies release hardening and scans production
sources/configuration for committed credentials and unsafe logging.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKS: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    CHECKS.append((name, bool(condition), detail))


def production_files() -> list[Path]:
    files: list[Path] = []
    for base in [ROOT / "app", ROOT / "core", ROOT / "feature"]:
        for path in base.rglob("*"):
            if not path.is_file() or "/src/main/" not in path.as_posix():
                continue
            if path.suffix.lower() in {".kt", ".java", ".xml", ".json", ".properties"}:
                files.append(path)
    return sorted(files)


app_build = read("app/build.gradle.kts")
check("release is non-debuggable by default", 'release {' in app_build and 'isDebuggable = false' in app_build)
check("R8 minification enabled", 'isMinifyEnabled = true' in app_build)
check("resource shrinking enabled", 'isShrinkResources = true' in app_build)
check("optimized default ProGuard file", 'proguard-android-optimize.txt' in app_build)
check("release secrets come from providers", 'providers.environmentVariable("SUPABASE_ANON_KEY")' in app_build)
check("no hard-coded Supabase key in build script", not re.search(r'SUPABASE_ANON_KEY"\s*,\s*"eyJ', app_build))

manifest = read("app/src/main/AndroidManifest.xml")
for token, label in [
    ('android:allowBackup="false"', "backup disabled"),
    ('android:usesCleartextTraffic="false"', "cleartext disabled"),
    ('android:networkSecurityConfig="@xml/network_security_config"', "network security config attached"),
    ('android:dataExtractionRules="@xml/data_extraction_rules"', "data extraction rules attached"),
    ('android:fullBackupContent="@xml/backup_rules"', "legacy backup rules attached"),
]:
    check(label, token in manifest)

exported_true = re.findall(r'<(?:activity|service|receiver|provider)\b[^>]*android:exported="true"[^>]*>', manifest, re.S)
check("only launcher component is exported", len(exported_true) == 1 and '.MainActivity' in exported_true[0], str(len(exported_true)))
check("no exported provider/service/receiver", not re.search(r'<(?:service|receiver|provider)\b[^>]*android:exported="true"', manifest, re.S))

network = read("app/src/main/res/xml/network_security_config.xml")
check("network base config rejects cleartext", 'cleartextTrafficPermitted="false"' in network)
check("network trusts system CA only", '<certificates src="system"' in network and 'src="user"' not in network)

backup = read("app/src/main/res/xml/backup_rules.xml")
extraction = read("app/src/main/res/xml/data_extraction_rules.xml")
for domain in ["root", "file", "database", "sharedpref", "external"]:
    check(f"legacy backup excludes {domain}", f'<exclude domain="{domain}" path="."' in backup)
    check(f"data extraction excludes {domain}", extraction.count(f'<exclude domain="{domain}" path="."') >= 2)

proguard = read("app/proguard-rules.pro")
check("Retrofit service interfaces protected", 'interface com.optimal.fleet.**.*Api' in proguard)
check("runtime parameter annotations preserved", "RuntimeVisibleParameterAnnotations" in proguard)
check("debug/info logs removed in release", "-assumenosideeffects class android.util.Log" in proguard)
check("no broad dontwarn", not re.search(r'^-dontwarn\s+\*\*', proguard, re.M))
check("no broad application keep", not re.search(r'^-keep[^\n]*class\s+com\.optimal\.fleet\.\*\*', proguard, re.M))
check("source and line metadata removed", "!SourceFile,!LineNumberTable" in proguard)

analytics = read("app/src/main/java/com/optimal/fleet/analytics/PrivacySafeAnalyticsTracker.kt")
error_reporter = read("app/src/main/java/com/optimal/fleet/infrastructure/error/AndroidSafeErrorReporter.kt")
check("analytics logging is debug-only", "BuildConfig.DEBUG" in analytics)
check("error reporter uses redactor", "SensitiveDataRedactor.redact" in error_reporter)
check("error reporter never logs throwable message", ".message" not in error_reporter and "stackTrace" not in error_reporter)

source_files = production_files()
unsafe_logging: list[str] = []
log_call_files: set[str] = set()
for path in source_files:
    if path.suffix not in {".kt", ".java"}:
        continue
    text = path.read_text(encoding="utf-8")
    relative = str(path.relative_to(ROOT))
    if re.search(r'\b(?:println|print)\s*\(|\.printStackTrace\s*\(', text):
        unsafe_logging.append(relative)
    if re.search(r'HttpLoggingInterceptor\.Level\.(?:BODY|HEADERS)', text):
        unsafe_logging.append(relative)
    if re.search(r'\bLog\.[vdiew]\s*\(', text):
        log_call_files.add(relative)
allowed_log_files = {
    "app/src/main/java/com/optimal/fleet/analytics/PrivacySafeAnalyticsTracker.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/error/AndroidSafeErrorReporter.kt",
}
check("no unsafe console/body logging", not unsafe_logging, ", ".join(sorted(set(unsafe_logging))))
check("production Log calls are allow-listed", log_call_files <= allowed_log_files, ", ".join(sorted(log_call_files - allowed_log_files)))

# Scan production and release configuration, not historical documentation/test fixtures.
scan_files = list(source_files)
for path in [
    ROOT / "app/build.gradle.kts",
    ROOT / "build.gradle.kts",
    ROOT / "settings.gradle.kts",
    ROOT / "gradle.properties",
    ROOT / "gradle/libs.versions.toml",
    ROOT / "supabase.properties.example",
]:
    if path.is_file():
        scan_files.append(path)
for path in (ROOT / ".github/workflows").glob("*.yml"):
    scan_files.append(path)
for path in (ROOT / "supabase/migrations").glob("*.sql"):
    scan_files.append(path)

credential_patterns = {
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "AWS access key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "Google API key": re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"),
    "GitHub token": re.compile(r"\bgh[psoru]_[0-9A-Za-z]{30,}\b"),
    "Slack token": re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{20,}\b"),
    "JWT credential": re.compile(r"\beyJ[0-9A-Za-z_-]{20,}\.[0-9A-Za-z_-]{10,}\.[0-9A-Za-z_-]{10,}\b"),
}
secret_hits: list[str] = []
for path in sorted(set(scan_files)):
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    for label, pattern in credential_patterns.items():
        if pattern.search(text):
            secret_hits.append(f"{path.relative_to(ROOT)}:{label}")
    # Values in the example must remain explicit placeholders.
    if path.name.endswith(".properties") or path.name.endswith(".example"):
        for match in re.finditer(r"(?m)^\s*(?:SUPABASE_ANON_KEY|SUPABASE_SERVICE_ROLE_KEY|API_KEY|TOKEN)\s*=\s*(.+)$", text):
            value = match.group(1).strip().strip('"\'')
            if value and not any(marker in value.upper() for marker in ["YOUR_", "PLACEHOLDER", "EXAMPLE"]):
                secret_hits.append(f"{path.relative_to(ROOT)}:assigned credential")
check("no committed credential material", not secret_hits, ", ".join(secret_hits))

# v65: server-side service-role material must never exist in Android or repositories.
service_role_hits: list[str] = []
service_role_patterns = (
    re.compile(r"SUPABASE_SERVICE_ROLE_KEY", re.IGNORECASE),
    re.compile(r"\bservice[_-]?role\b", re.IGNORECASE),
    re.compile(r"\bserviceRole(?:Key|Client)?\b"),
)
for path in source_files:
    text = path.read_text(encoding="utf-8", errors="ignore")
    if any(pattern.search(text) for pattern in service_role_patterns):
        service_role_hits.append(str(path.relative_to(ROOT)))
check(
    "service role material absent from Android",
    not service_role_hits,
    ", ".join(sorted(service_role_hits)),
)

for forbidden in ["local.properties", "secrets.properties", "supabase.properties"]:
    check(f"{forbidden} not committed", not (ROOT / forbidden).exists())

gitignore = read(".gitignore")
for token in ["local.properties", "*.jks", "*.keystore", "secrets.properties"]:
    check(f"gitignore protects {token}", token in gitignore)

failed = [(name, detail) for name, ok, detail in CHECKS if not ok]
for name, ok, detail in CHECKS:
    suffix = f" — {detail}" if detail and not ok else ""
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f"\nSecurity release checks: {len(CHECKS) - len(failed)}/{len(CHECKS)}")
if failed:
    print("FAILED: " + ", ".join(name for name, _ in failed), file=sys.stderr)
    sys.exit(1)
