#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
./scripts/run-v19-domain-harness.sh
./scripts/run-v33-paging-harness.sh
python3 scripts/v33-paging-contract.py
python3 scripts/v33-room-query-contract.py
./scripts/run-v32-member-policy-harness.sh
python3 scripts/v32-member-security-contract.py
./scripts/run-v31-auth-harness.sh
./scripts/run-v30-error-harness.sh
python3 scripts/v29-sync-contract.py
python3 scripts/v28-atomic-contract.py
