#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v51-verto-home-entry-contract.py
./scripts/run-v51-verto-entry-harness.sh
./scripts/run-v36-test-syntax-check.sh
./scripts/run-v35-ui-syntax-check.sh
exec ./scripts/verify-v50-static.sh
