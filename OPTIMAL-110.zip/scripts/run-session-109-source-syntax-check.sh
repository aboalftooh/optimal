#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalFoundations.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalBottomActions.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalCards.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalDialogs.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalRows.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalStatus.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountRoute.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt"
  "$ROOT_DIR/feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceCompletionContent.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContent.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceEditContent.kt"
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsComponents.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorScreen.kt"
  "$ROOT_DIR/core/designsystem/src/androidTest/java/com/optimal/fleet/designsystem/ResponsiveRtlAccessibilityV109Test.kt"
)
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 120s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: SESSION-109 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: SESSION-109 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted all changed SESSION-109 Kotlin sources; unresolved Android/Compose symbols were intentionally ignored without the Gradle classpath."
