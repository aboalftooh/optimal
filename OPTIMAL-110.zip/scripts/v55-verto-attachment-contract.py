#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v55 local Verto attachments."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "selection": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingAttachment.kt",
    "import_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/attachment/VertoAttachmentImporter.kt",
    "usecase": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAttachmentUseCases.kt",
    "identity_factory": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/UuidVertoAttachmentIdentityFactory.kt",
    "importer": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/AndroidVertoAttachmentImporter.kt",
    "module": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/di/VertoAttachmentModule.kt",
    "repo_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "picker": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentPickerCoordinator.kt",
    "open": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentOpenContract.kt",
    "contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "entry": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "manifest": ROOT / "feature/verto/src/main/AndroidManifest.xml",
    "paths": ROOT / "feature/verto/src/main/res/xml/verto_file_paths.xml",
    "model": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessage.kt",
    "usecase_test": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAttachmentUseCaseTest.kt",
    "validator_test": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoMediaValidatorTest.kt",
    "process_test": ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV2ProcessRecreationTest.kt",
}
CHAT_PRESENTATION_DIR = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation"
CHAT_PRESENTATION_FILES = (
    "VertoChatScreen.kt",
    "VertoChatChrome.kt",
    "VertoChatMessages.kt",
    "VertoChatAttachments.kt",
    "VertoChatComposer.kt",
    "VertoChatFormatting.kt",
)

def chat_presentation_text() -> str:
    return "\n".join(
        (CHAT_PRESENTATION_DIR / name).read_text(encoding="utf-8")
        for name in CHAT_PRESENTATION_FILES
    )

checks: list[tuple[str, bool]] = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    if not condition:
        raise AssertionError(name)

def text(key: str) -> str:
    if key == "screen":
        return chat_presentation_text()
    return FILES[key].read_text(encoding="utf-8")

for name, path in FILES.items():
    check(f"exists:{name}", path.is_file())

selection = text("selection")
for token in [
    "VertoAttachmentSelection", "sourceUri", "expectedKind", "deleteSourceAfterImport",
    "VertoPreparedAttachment", "mimeType", "sizeBytes", "durationMillis", "originalName",
    "localPrivatePath", "VertoOutgoingAttachmentIdentity", "VertoAttachmentIdentityFactory",
]:
    check(f"selection:{token}", token in selection)
check("audio deferred to v56", "expectedKind != VertoAttachmentKind.AUDIO" in selection)
check("private path traversal rejected", "none { it == \"..\" }" in selection)

contract = text("import_contract")
for token in [
    "VertoAttachmentImporter", "VertoAttachmentImportResult", "VertoAttachmentImportFailure",
    "PERMISSION_DENIED", "SOURCE_MISSING", "EMPTY_FILE", "UNSUPPORTED_TYPE", "INVALID_CONTENT",
    "COPY_FAILED", "VertoMediaValidator", "application/pdf", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]:
    check(f"import contract:{token}", token in contract)
check("image MIME family", 'mimeType.startsWith("image/")' in contract)
check("video MIME family", 'mimeType.startsWith("video/")' in contract)
check("no invented size limit", "MAX_SIZE" not in contract and "sizeBytes >" not in contract)

picker = text("picker")
for token in [
    "ActivityResultContracts.PickVisualMedia", "PickVisualMedia.ImageOnly", "PickVisualMedia.VideoOnly",
    "ActivityResultContracts.OpenDocument", "DOCUMENT_MIME_TYPES", "ActivityResultContracts.TakePicture",
    "ActivityResultContracts.RequestPermission", "Manifest.permission.CAMERA", "rememberSaveable",
    "deleteSourceAfterImport = true", "FileProvider.getUriForFile", "verto-camera",
]:
    check(f"picker:{token}", token in picker)
check("cancelled picker creates no selection", "uri?.let" in picker)
check("camera target cleared", "cameraTarget = null" in picker)

importer = text("importer")
for token in [
    "Dispatchers.IO", "context.filesDir", 'ATTACHMENT_DIRECTORY = "verto/attachments"',
    "openInputStream", "FileOutputStream", "output.fd.sync()", "PART_SUFFIX", "moveAtomically",
    "BitmapFactory", "MediaMetadataRetriever", "METADATA_KEY_DURATION", "ZipFile",
    'archive.getEntry("word/document.xml")', "PDF_SIGNATURE", "DOC_SIGNATURE", "RTF_SIGNATURE",
    "queryDisplayName", "OpenableColumns.DISPLAY_NAME", "sanitizeOriginalName", "UUID.randomUUID()",
    "contentResolver.delete", "canonicalFile", "discard(localPrivatePath",
]:
    check(f"importer:{token}", token in importer)
check("private relative path persisted", 'localPrivatePath = "$ATTACHMENT_DIRECTORY/$generatedName"' in importer)
check("actual copied size stored", "sizeBytes = actualSize" in importer)
check("zero file rejected", "validator.validate(selection.expectedKind, mimeType, actualSize)" in importer)
check("temporary file removed", "temporaryFile?.delete()" in importer)
check("failed final file removed", "if (!completed) finalFile?.delete()" in importer)
check("no source URI persisted", "sourceUri =" not in importer)

usecase = text("usecase")
for token in [
    "class SendVertoAttachmentUseCase", "authorizeSend()", "importer.import(selection)",
    "identityFactory.create()", "repository.enqueueAttachmentMessage", "SavedLocally", "NotLinked",
    "PermissionDenied", "Rejected", "Unavailable", "discardQuietly(prepared.localPrivatePath)",
]:
    check(f"usecase:{token}", token in usecase)
check("authorization before URI import", usecase.index("authorizeSend()") < usecase.index("importer.import(selection)"))

factory = text("identity_factory")
check("message identity reused", "messageIdentityFactory.create()" in factory)
check("attachment identities stable", factory.count("UUID.randomUUID().toString()") == 3)
module = text("module")
check("importer bound", "bindVertoAttachmentImporter" in module)
check("identity bound", "bindVertoAttachmentIdentityFactory" in module)

repo_contract = text("repo_contract")
check("attachment repository operation", "enqueueAttachmentMessage" in repo_contract)
check("fail-closed default", "Attachment persistence is unavailable" in repo_contract)
repo = text("repository")
for token in [
    "override suspend fun enqueueAttachmentMessage", "conversationDao.findByCompany", "findActiveUser",
    "VertoMessageKind.IMAGE", "VertoMessageKind.VIDEO", "VertoMessageKind.DOCUMENT",
    "VertoDeliveryState.PENDING.name", "VertoAttachmentTransferState.LOCAL_READY.name",
    "VertoMessageEntity", "VertoAttachmentEntity", "AtomicWriteTransactionRunner", "transactionRunner.run",
    "messageDao.upsert(message)", "attachmentDao.upsert(attachmentRow)", "localPrivatePath = attachment.localPrivatePath",
]:
    check(f"repository:{token}", token in repo)
start = repo.index("override suspend fun enqueueAttachmentMessage")
transaction = min(
    repo.index(token, start)
    for token in ("database.withTransaction", "transactionRunner.run")
    if token in repo[start:]
)
message_insert = repo.index("messageDao.upsert(message)", transaction)
attachment_insert = repo.index("attachmentDao.upsert(attachmentRow)", transaction)
check("message and attachment atomic", transaction < message_insert < attachment_insert)
check("v55 does not enqueue upload worker", "SyncOperationType.UPLOAD" not in repo[start:repo.index("override suspend fun syncPendingTextMessage", start)])

model = text("model")
for token in ["localPrivatePath", "VertoAttachmentTransferState", "LOCAL_READY", "UPLOADED"]:
    check(f"domain model:{token}", token in model)

manifest = text("manifest")
for token in ["android.permission.CAMERA", "androidx.core.content.FileProvider", "verto.fileprovider", "verto_file_paths"]:
    check(f"manifest:{token}", token in manifest)
paths = text("paths")
check("only attachment files exposed", 'path="verto/attachments/"' in paths)
check("only camera cache exposed", 'path="verto-camera/"' in paths)
check("provider not broad", 'path="."' not in paths)

open_contract = text("open")
for token in ["canonicalFile", "startsWith", "FileProvider.getUriForFile", "FLAG_GRANT_READ_URI_PERMISSION", "ACTION_VIEW"]:
    check(f"open:{token}", token in open_contract)

ui_contract = text("contract")
for token in ["importingAttachment", "attachmentEnabled", "AttachmentSelected", "AttachmentPickerFailed"]:
    check(f"ui contract:{token}", token in ui_contract)
viewmodel = text("viewmodel")
for token in ["SendVertoAttachmentUseCase", "importAttachment", "attachmentFailureMessage", "importingAttachment = true", "importingAttachment = false"]:
    check(f"viewmodel:{token}", token in viewmodel)
screen = text("screen")
for token in ["VertoAttachmentMenu", "التقاط صورة", "اختيار صورة", "اختيار فيديو", "اختيار مستند", "VertoAttachmentOpenContract.open"]:
    check(f"screen:{token}", token in screen)
check("screen:local transfer label", "محفوظ محليًا" in screen or "بانتظار الرفع" in screen)
entry = text("entry")
for token in ["rememberVertoAttachmentPickerActions", "AttachmentSelected", "AttachmentPickerFailed", "onTakePhoto", "onPickDocument"]:
    check(f"entry:{token}", token in entry)
check("presentation has no DAO/network", all(x not in screen + viewmodel + entry + picker for x in ["core.database", "Retrofit", "Supabase", ".data.AndroidVertoAttachmentImporter"]))

unit = text("usecase_test")
for token in [
    "deniedPermissionDoesNotReadTheSelectedUri", "importedPrivateFileAndMetadataAreSavedAsOneLocalMessage",
    "databaseFailureDeletesTheAlreadyCopiedPrivateFile", "expiredUriStopsBeforeRoomWrite",
]:
    check(f"usecase test:{token}", token in unit)
validator_test = text("validator_test")
for token in ["supportedTypesMatchTheirDeclaredAttachmentKind", "mismatchedOrAudioTypeIsRejected", "emptyFileIsRejectedBeforeContentInspection", "genericMimeCanBeInferredFromSupportedFileNameOnly"]:
    check(f"validator test:{token}", token in validator_test)
process_test = text("process_test")
check("process death private path", '"verto/attachments/invoice.pdf"' in process_test)
check("process death pending state", '"LOCAL_READY"' in process_test)

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains immutable", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("no v55 Supabase migration", not any((ROOT / "supabase/migrations").glob("*v55*")))
all_text = "\n".join(path.read_text(encoding="utf-8") for path in FILES.values())
check("no merge markers", not any(marker in all_text for marker in ("<<<<<<<", "=======", ">>>>>>>")))

print(f"v55 Verto local attachment contract: {len(checks)}/{len(checks)} PASS")
