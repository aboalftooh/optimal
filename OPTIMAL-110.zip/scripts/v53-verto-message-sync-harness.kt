import com.optimal.fleet.feature.verto.domain.model.VertoMessageCursor

private data class FeedMessage(
    val id: String,
    val createdAt: Long,
    val incoming: Boolean = true,
) {
    val cursor = VertoMessageCursor(createdAt, id)
}

private class LocalFeed {
    private val rows = linkedMapOf<String, FeedMessage>()
    var cursor: VertoMessageCursor? = null
        private set

    fun persistPage(page: List<FeedMessage>) {
        val ordered = page.sortedBy(FeedMessage::cursor)
        ordered.forEach { rows[it.id] = it }
        val pageCursor = ordered.maxOfOrNull(FeedMessage::cursor)
        cursor = listOfNotNull(cursor, pageCursor).maxOrNull()
    }

    fun unreadAfter(read: VertoMessageCursor?): Int = rows.values.count {
        it.incoming && (read == null || it.cursor > read)
    }

    fun ids(): List<String> = rows.values.sortedBy(FeedMessage::cursor).map(FeedMessage::id)
}

fun main() {
    val feed = LocalFeed()
    val equalLow = FeedMessage("00000000-0000-0000-0000-000000000001", 1_000)
    val equalHigh = FeedMessage("00000000-0000-0000-0000-000000000002", 1_000)
    val newer = FeedMessage("00000000-0000-0000-0000-000000000003", 2_000)

    feed.persistPage(listOf(newer, equalHigh, equalLow))
    check(feed.ids() == listOf(equalLow.id, equalHigh.id, newer.id))
    check(feed.cursor == newer.cursor)
    println("PASS: out-of-order page is stored in composite cursor order")

    feed.persistPage(listOf(equalHigh, newer))
    check(feed.ids().size == 3)
    println("PASS: duplicate Realtime-triggered pull remains idempotent by remote id")

    val missedRealtime = FeedMessage("00000000-0000-0000-0000-000000000004", 3_000)
    feed.persistPage(listOf(missedRealtime))
    check(feed.cursor == missedRealtime.cursor)
    println("PASS: periodic pull recovers a message without a Realtime event")

    check(feed.unreadAfter(equalLow.cursor) == 3)
    check(feed.unreadAfter(newer.cursor) == 1)
    println("PASS: partial read checkpoint keeps only later incoming messages unread")

    val outgoing = FeedMessage("00000000-0000-0000-0000-000000000005", 4_000, incoming = false)
    feed.persistPage(listOf(outgoing))
    check(feed.unreadAfter(newer.cursor) == 1)
    println("PASS: outgoing messages do not increase unread count")

    println("V53 Verto sync harness: 5/5 PASS")
}
