#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Current architecture and v19 contract.
python3 scripts/static-architecture-check.py
python3 scripts/static-v19-check.py
./scripts/run-v19-domain-harness.sh

# Still-applicable schema and domain regressions. Checks replaced by the
# server-backed v19 auth/member architecture are intentionally not executed.
python3 scripts/static-v04-check.py
python3 scripts/sqlite-v04-migration-check.py
python3 scripts/static-v05-check.py
python3 scripts/sqlite-v05-migration-check.py
python3 scripts/static-v06-check.py
python3 scripts/static-branding-check.py
python3 scripts/sqlite-v06-migration-check.py
python3 scripts/static-v07-check.py
python3 scripts/sqlite-v07-migration-check.py
./scripts/run-v07-domain-harness.sh
python3 scripts/static-v08-check.py
python3 scripts/sqlite-v08-migration-check.py
./scripts/run-v08-sync-harness.sh
python3 scripts/static-v09-check.py
python3 scripts/sqlite-v09-migration-check.py
./scripts/run-v09-invoice-harness.sh
python3 scripts/static-v10-check.py
python3 scripts/sqlite-v10-migration-check.py
./scripts/run-v10-linking-harness.sh
python3 scripts/static-v11-check.py
python3 scripts/sqlite-v11-migration-check.py
./scripts/run-v11-finance-harness.sh
python3 scripts/sqlite-v12-migration-check.py
./scripts/run-v12-audit-harness.sh
python3 scripts/sqlite-v13-migration-check.py
./scripts/run-v13-member-harness.sh
python3 scripts/static-v14-check.py
python3 scripts/sqlite-v14-migration-check.py
./scripts/run-v14-notification-harness.sh
python3 scripts/static-v15-check.py
./scripts/run-v15-domain-harness.sh
python3 scripts/static-v16-check.py
python3 scripts/sqlite-v16-all-published-migrations.py
python3 scripts/static-v17-check.py
