#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs"/{androidx/lifecycle,androidx/compose/runtime,dagger/hilt/android/lifecycle,javax/inject,kotlinx/coroutines/flow,com/optimal/fleet/feature/finance/navigation,com/optimal/fleet/feature/finance/domain/invoice/usecase}
cat > "$TMP_DIR/stubs/androidx/lifecycle/Lifecycle.kt" <<'KT'
package androidx.lifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
open class ViewModel
class SavedStateHandle(private val values: Map<String, Any?> = emptyMap()) {
    @Suppress("UNCHECKED_CAST") operator fun <T> get(key: String): T? = values[key] as? T
}
val ViewModel.viewModelScope: CoroutineScope get() = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
KT
cat > "$TMP_DIR/stubs/androidx/compose/runtime/Immutable.kt" <<'KT'
package androidx.compose.runtime
@Target(AnnotationTarget.CLASS) annotation class Immutable
KT
cat > "$TMP_DIR/stubs/dagger/hilt/android/lifecycle/HiltViewModel.kt" <<'KT'
package dagger.hilt.android.lifecycle
@Target(AnnotationTarget.CLASS) annotation class HiltViewModel
KT
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
KT
cat > "$TMP_DIR/stubs/kotlinx/coroutines/flow/Collect.kt" <<'KT'
package kotlinx.coroutines.flow
import kotlinx.coroutines.InternalCoroutinesApi
inline fun <T> MutableStateFlow<T>.update(function: (T) -> T) { value = function(value) }
@OptIn(InternalCoroutinesApi::class)
suspend fun <T> Flow<T>.collect(action: suspend (T) -> Unit) {
    collect(object : FlowCollector<T> { override suspend fun emit(value: T) = action(value) })
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/finance/navigation/Nav.kt" <<'KT'
package com.optimal.fleet.feature.finance.navigation
const val INVOICE_ID_ARG = "invoiceId"
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/finance/domain/invoice/usecase/Observe.kt" <<'KT'
package com.optimal.fleet.feature.finance.domain.invoice.usecase
import com.optimal.fleet.feature.finance.domain.invoice.model.InvoiceProjectionDetails
import kotlinx.coroutines.flow.Flow
fun interface ObserveInvoiceProjectionDetails {
    operator fun invoke(invoiceId: String): Flow<InvoiceProjectionDetails?>
}
KT
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  $(find "$TMP_DIR/stubs" -type f -name '*.kt' | sort) \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/verto/TemporaryVertoAttachmentAccess.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjection.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjectionDetails.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/linking/LinkVertoInvoice.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/money/Money.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/MoneyTextFormatter.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt" \
  -d "$TMP_DIR/v63-finance-presentation.jar"
echo "PASS: invoice details contract and ViewModel compile against v63 contracts"
echo "V63 finance presentation compilation: 1/1"
