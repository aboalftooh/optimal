#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
python3 scripts/v59-room-v3-contract.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/v58-verto-daily-cycle-contract.py
./scripts/run-v58-verto-daily-cycle-harness.sh
bash scripts/verify-v57-static.sh
bash scripts/run-v59-room-syntax-check.sh
