import com.optimal.fleet.core.common.error.CorrelationId
import com.optimal.fleet.core.common.error.DomainError
import com.optimal.fleet.core.common.error.DomainErrorMapper
import com.optimal.fleet.core.common.error.ErrorContext
import com.optimal.fleet.core.common.error.InfrastructureBoundary
import com.optimal.fleet.core.common.error.SensitiveDataRedactor
import com.optimal.fleet.core.common.error.UiErrorKind
import com.optimal.fleet.core.common.error.toUiError
import java.io.IOException
import java.net.SocketTimeoutException

private class AuthenticationException : RuntimeException()
private class SQLiteConstraintException : RuntimeException()
private class JsonDecodingException : RuntimeException()
private class RoomDatabaseException : RuntimeException()

private var passed = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { "FAIL: $name" }
    println("PASS: $name")
    passed += 1
}

private fun context(
    boundary: InfrastructureBoundary = InfrastructureBoundary.NETWORK,
): ErrorContext = ErrorContext(
    operation = "v30-harness",
    boundary = boundary,
    correlationId = CorrelationId.deterministic("v30-error-harness"),
)

fun main() {
    verify("HTTP 400 maps to Validation", DomainErrorMapper.fromHttp(400, null, context()).error is DomainError.Validation)
    verify("HTTP 401 maps to Authentication", DomainErrorMapper.fromHttp(401, null, context()).error is DomainError.Authentication)
    verify("HTTP 403 maps to Permission", DomainErrorMapper.fromHttp(403, null, context()).error is DomainError.Permission)
    verify("HTTP 408 maps to Timeout", DomainErrorMapper.fromHttp(408, null, context()).error is DomainError.Timeout)
    verify("HTTP 409 maps to Conflict", DomainErrorMapper.fromHttp(409, null, context()).error is DomainError.Conflict)
    verify("HTTP duplicate signal maps to Conflict", DomainErrorMapper.fromHttp(412, "duplicate", context()).error is DomainError.Conflict)
    verify("HTTP 429 maps to retryable Network", DomainErrorMapper.fromHttp(429, null, context()).error.let { it is DomainError.Network && it.retryable })
    verify("HTTP 503 maps to retryable Network", DomainErrorMapper.fromHttp(503, null, context()).error.let { it is DomainError.Network && it.retryable })
    verify("unknown HTTP maps to Unexpected", DomainErrorMapper.fromHttp(418, null, context()).error is DomainError.Unexpected)

    verify("socket timeout maps to Timeout", DomainErrorMapper.fromThrowable(SocketTimeoutException(), context()).error is DomainError.Timeout)
    verify("authentication exception maps to Authentication", DomainErrorMapper.fromThrowable(AuthenticationException(), context()).error is DomainError.Authentication)
    verify("security exception maps to Permission", DomainErrorMapper.fromThrowable(SecurityException(), context()).error is DomainError.Permission)
    verify("SQLite constraint maps to Conflict", DomainErrorMapper.fromThrowable(SQLiteConstraintException(), context(InfrastructureBoundary.STORAGE)).error is DomainError.Conflict)
    verify("remote serialization maps to Unexpected", DomainErrorMapper.fromThrowable(JsonDecodingException(), context(InfrastructureBoundary.SERIALIZATION)).error is DomainError.Unexpected)
    verify("stored serialization maps to Storage", DomainErrorMapper.fromThrowable(JsonDecodingException(), context(InfrastructureBoundary.STORAGE)).error is DomainError.Storage)
    verify("Room exception maps to Storage", DomainErrorMapper.fromThrowable(RoomDatabaseException(), context(InfrastructureBoundary.STORAGE)).error is DomainError.Storage)
    verify("network IO maps to Network", DomainErrorMapper.fromThrowable(IOException(), context()).error is DomainError.Network)
    verify("storage IO maps to Storage", DomainErrorMapper.fromThrowable(IOException(), context(InfrastructureBoundary.STORAGE)).error is DomainError.Storage)
    verify("bad serialized payload maps to Validation", DomainErrorMapper.fromThrowable(IllegalArgumentException(), context(InfrastructureBoundary.SERIALIZATION)).error is DomainError.Validation)
    verify("unknown throwable maps to Unexpected", DomainErrorMapper.fromThrowable(IllegalStateException(), context()).error is DomainError.Unexpected)

    val id = CorrelationId.deterministic("stable")
    verify("correlation IDs are deterministic", id == CorrelationId.deterministic("stable"))
    verify("reference code is short and safe", id.referenceCode.length == 8 && id.referenceCode.all(Char::isLetterOrDigit))

    val errors = listOf<DomainError>(
        DomainError.Validation("op", id),
        DomainError.Authentication("op", id),
        DomainError.Permission("op", id),
        DomainError.Network("op", id),
        DomainError.Timeout("op", id),
        DomainError.Conflict("op", id),
        DomainError.Storage("op", id),
        DomainError.Unexpected("op", id),
    )
    verify(
        "UI distinguishes every domain category",
        errors.map { it.toUiError().kind }.toSet() == UiErrorKind.entries.toSet(),
    )
    verify("UI messages contain no technical secret", errors.none { it.toUiError().message.contains("token", ignoreCase = true) })

    val unsafe = "Authorization=Bearer abc.def access_token=secret password=hunter2 otp=123456 phone=0912345678 email=a@b.com"
    val safe = SensitiveDataRedactor.redact(unsafe)
    verify("Bearer credential is redacted", "abc.def" !in safe)
    verify("access token is redacted", "access_token=secret" !in safe)
    verify("password is redacted", "hunter2" !in safe)
    verify("OTP is redacted", "123456" !in safe)
    verify("phone is redacted", "0912345678" !in safe)
    verify("email is redacted", "a@b.com" !in safe)
    verify("safe logs are length bounded", SensitiveDataRedactor.redact("x".repeat(2_000)).length == 800)

    println("\nV30 error harness: $passed/31")
    check(passed == 31)
}
