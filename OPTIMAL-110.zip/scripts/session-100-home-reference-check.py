#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

cards = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalCards.kt")
route = read("feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt")
components = read("feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt")
verto = read("feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoHomeEntry.kt")

check("generic hero surface exists", "fun OptimalHeroSurface(" in cards)
check("hero surface uses locked hero colors", "OptimalSemanticColors.heroStart" in cards and "OptimalSemanticColors.heroEnd" in cards)
check("hero surface uses canonical large shape", "shape = MaterialTheme.shapes.large" in cards)
check("hero surface uses canonical border", "OptimalSemanticColors.borderSubtle" in cards)

check("HomeRoute still exists", "fun HomeRoute(" in route)
check("HomeConnected still exists", "fun HomeConnected(" in route)
check("home loading uses canonical state", "state.isLoading -> OptimalLoadingState" in route)
check("home error uses canonical state", "state.errorMessage != null -> OptimalErrorState" in route)
check("home retry callback preserved", "HomeUiEvent.Retry" in route)
check("home dominant action uses hero button", "OptimalHeroButton(" in route and 'text = "إضافة عملية"' in route)
check("home dominant action retains test tag", 'testTag("home-add-operation")' in route)
check("home dominant action callback preserved", "HomeUiEvent.AddOperation" in route)
check("Verto injected content preserved", 'item(key = "verto-entry") { content() }' in route)

check("welcome uses hero surface", "OptimalHeroSurface(" in components)
check("welcome uses hero typography role", "OptimalTypographyRoles.heroTitle" in components)
check("welcome preserves user greeting", '"مرحبًا، $userName"' in components)
check("welcome preserves company fallback", 'companyName.ifBlank { "OPTIMAL" }' in components)
check("sections use canonical section header", components.count("OptimalSectionHeader(") >= 3)
check("operation rows use canonical list rows", components.count("OptimalListRow(") >= 2)
check("finance uses canonical metric cards", components.count("OptimalMetricCard(") >= 2)
check("empty/current/follow-up states use outlined surface", "private fun HomeInlineStatus(" in components and "OptimalSurfaceCard(" in components)
check("follow-up empty copy preserved", '"لا توجد متابعة مستحقة قريبًا."' in components)
check("current empty copy preserved", '"لا توجد عمليات جاري معالجتها."' in route)
check("completed empty copy preserved", '"ستظهر هنا آخر العمليات المكتملة."' in route)
check("completed state preserves success semantic icon path", "success = true" in route and "success = success" in components)

check("Verto visibility gate preserved", "if (!state.isVisibleOnHome) return" in verto)
check("Verto linked state preserved", "val linked = state.linkState.linked" in verto)
check("Verto archived text preserved", '"مؤرشفة لهذا المستخدم"' in verto)
check("Verto linked text preserved", '"مرتبط بـ $it"' in verto and '?: "مرتبط"' in verto)
check("Verto unlinked text preserved", '"غير مرتبط"' in verto)
check("Verto uses outlined canonical surface", "OptimalSurfaceCard(" in verto)
check("Verto uses canonical list row", "OptimalListRow(" in verto)
check("Verto keeps soft semantic icon well", "OptimalSemanticColors.brandContainer" in verto)
check("Verto unread status uses canonical badge", "OptimalStatusBadge(" in verto and "OptimalStatusTone.Info" in verto)
check("Verto open callback preserved", "onClick = onOpenConversation" in verto)
check("Verto click semantics preserved", 'onClickLabel = "فتح التواصل مع Verto"' in verto)
check("Verto unread cap preserved", 'if (this > 99L) "99+" else toString()' in verto)

for event in [
    "OpenCreateOperation", "OpenMaintenance", "OpenFollowUps", "OpenFinance", "OpenOperation", "OpenFollowUp",
]:
    check(f"home effect mapping preserved: {event}", f"HomeUiEffect.{event}" in route)

ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_100 = {"SCR-008", "CMP-001", *(f"STA-{i:03d}" for i in range(8, 13))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("all SESSION-100 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_100), str(sorted(i for i in expected_100 if statuses.get(i) != "MIGRATED")))
check("ledger migrated total is 25", sum(status == "MIGRATED" for _, status in rows) == 25)
check("ledger unmigrated total is 98", sum(status == "UNMIGRATED" for _, status in rows) == 98)
check("ledger has no blocked rows", all(status != "BLOCKED" for _, status in rows))

allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("Home UI removed from allowlist", not any(path.startswith("feature/home/") for path in allow))
check("Verto home entry removed from allowlist", not any(path.endswith("/VertoHomeEntry.kt") for path in allow))
check("remaining allowlist is 54 UI files", len(allow) == 54, str(len(allow)))

for rel, text in [
    ("HomeRoute.kt", route),
    ("HomeComponents.kt", components),
    ("VertoHomeEntry.kt", verto),
]:
    check(f"{rel} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", text) is None)
    check(f"{rel} has no raw hex color", "Color(0x" not in text)
    check(f"{rel} has no local font family", "FontFamily(" not in text and "fontFamily =" not in text)

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-100 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
