#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from collections import Counter
import hashlib
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

def sha256(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

def tree_hash(rel: str) -> str:
    base = ROOT / rel
    h = hashlib.sha256()
    for path in sorted(base.rglob("*")):
        if path.is_file():
            h.update(path.relative_to(ROOT).as_posix().encode())
            h.update(b"\0")
            h.update(path.read_bytes())
            h.update(b"\0")
    return h.hexdigest()

base = "feature/settings/src/main/java/com/optimal/fleet/feature/settings"
settings = read(f"{base}/presentation/SettingsScreen.kt")
settings_components = read(f"{base}/presentation/SettingsComponents.kt")
join = read(f"{base}/presentation/join/JoinCompanyRoute.kt")
members_route = read(f"{base}/presentation/members/MembersRoute.kt")
members = read(f"{base}/presentation/members/MembersScreen.kt")
members_components = read(f"{base}/presentation/members/MembersComponents.kt")
members_dialogs = read(f"{base}/presentation/members/MembersDialogs.kt")
activity_route = read(f"{base}/presentation/activity/ActivityRoute.kt")
activity = read(f"{base}/presentation/activity/ActivityScreen.kt")
activity_components = read(f"{base}/presentation/activity/ActivityComponents.kt")
settings_nav = read(f"{base}/navigation/SettingsNavigation.kt")
app_nav = read("app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt")

# SCR-022 Settings pattern.
check("settings screen exists", "fun SettingsScreen(" in settings)
check("settings company summary uses canonical hero", "OptimalHeroSurface(" in settings_components)
check("settings company summary tag preserved", 'testTag("settings-company-summary")' in settings_components)
check("settings uses section headers", settings.count("OptimalSectionHeader(") >= 2)
check("settings rows use canonical list row", "OptimalListRow(" in settings_components)
check("settings icon wells use semantic brand container", "OptimalSemanticColors.brandContainer" in settings_components)
for tag in ["destination-settings", "more-members", "more-activity", "more-account", "more-notifications", "more-help"]:
    check(f"settings tag preserved {tag}", f'"{tag}"' in settings)
for event in ["OpenMembers", "OpenActivity", "OpenAccount", "OpenNotifications"]:
    check(f"settings event preserved {event}", f"SettingsUiEvent.{event}" in settings)
check("Help remains inert", 'testTag = "more-help"' in settings and "onClick = {}," in settings)
check("no help navigation event invented", "OpenHelp" not in settings and "HELP_ROUTE" not in settings_nav)

# SCR-024 + STA-057..058 Join Company form; intentionally remains unlinked.
check("join route exists", "fun JoinCompanyRoute(" in join)
check("join canonical form section", "OptimalFormSection(" in join)
check("join canonical field", "OptimalTextField(" in join)
check("join submit canonical", "OptimalPrimaryButton(" in join)
check("join validation remains field-adjacent", 'Text("راجع كود الدعوة."' in join and "isError = hasValidationError" in join)
check("join loading text preserved", 'if (state.isLoading) "جارٍ التحقق من الكود"' in join)
check("join loading disables action", "enabled = !state.isLoading" in join)
check("join error uses canonical semantic feedback", "OptimalInlineStatus(" in join and "OptimalStatusTone.Danger" in join)
check("join error reference preserved", 'append("\\nرمز المتابعة: $it")' in join)
check("join submit event preserved", "JoinCompanyUiEvent.Submit" in join)
check("join code event preserved", "JoinCompanyUiEvent.CodeChanged(it)" in join)
check("join route constant preserved", 'MEMBER_JOIN_ROUTE = "settings/join-company"' in settings_nav)
check("join destination remains registered only as before", settings_nav.count("composable(route = MEMBER_JOIN_ROUTE)") == 1)
check("join route is not added to app nav", "MEMBER_JOIN_ROUTE" not in app_nav and 'navigate("settings/join-company")' not in app_nav)

# SCR-023, DLG-004/005, STA-059..063 Members.
check("members loading canonical", "OptimalLoadingState(" in members_route and 'testTag("members-loading")' in members_route)
check("members screen exists", "fun MembersScreen(" in members)
check("members primary invite action canonical", "OptimalPrimaryButton(" in members and "MembersUiEvent.OpenInviteDialog" in members)
check("members invite action permission-gated", "state.canCreateInvites && !state.isSaving" in members)
check("members generated code state present", "GeneratedInviteCodeCard(" in members)
check("generated code success semantic", "OptimalStatusTone.Success" in members_components and 'text = "تم إنشاء الكود"' in members_components)
check("generated code uses canonical surface", "OptimalSurfaceCard(" in members_components)
check("generated code value tag preserved", 'testTag("generated-invite-code-value")' in members_components)
check("members message canonical semantic", "OptimalInlineStatus(" in members_components)
check("members message danger semantic", "OptimalStatusTone.Danger" in members_components)
check("members message info semantic", "OptimalStatusTone.Info" in members_components)
check("members message dismiss preserved", "MembersUiEvent.DismissMessage" in members)
check("members empty canonical", "OptimalEmptyState(" in members and 'testTag("members-empty")' in members)
check("members rows canonical", "OptimalListRow(" in members_components)
check("pending invite warning semantic", "OptimalStatusTone.Warning" in members_components)
check("revoke remains destructive", "OptimalDestructiveButton(" in members_components and 'text = "إلغاء الدعوة"' in members_components)
check("member active state semantic", "OptimalStatusTone.Success" in members_components and "OptimalStatusTone.Neutral" in members_components)
check("member status action permission-gated", "state.canChangeMemberStatus && !state.isSaving" in members)
check("Verto permission action permission-gated", "state.canManageVertoPermissions && !state.isSaving" in members)
check("invite dialog canonical", "fun MembersInviteDialog(" in members_dialogs and "OptimalDialog(" in members_dialogs)
check("invite dialog canonical form", "OptimalFormSection(" in members_dialogs and members_dialogs.count("OptimalTextField(") >= 2)
check("invite dialog permission section preserved", "state.canManageInviteVertoPermissions" in members_dialogs)
check("invite send dependency preserved", "state.canGrantVertoSend" in members_dialogs)
check("permissions dialog canonical", "fun MemberVertoPermissionsDialog(" in members_dialogs and members_dialogs.count("OptimalDialog(") >= 2)
check("permissions dialog editor guard preserved", "val member = state.permissionEditorMember ?: return" in members_dialogs)
check("permissions dialog management guard preserved", "!state.isSaving && state.canManageVertoPermissions" in members_dialogs)
for event in ["CreateInvite", "ResendInvite", "RevokeInvite", "ChangeMemberStatus", "OpenMemberPermissions", "SaveMemberPermissions"]:
    corpus = members + members_components + members_dialogs
    check(f"members event preserved {event}", f"MembersUiEvent.{event}" in corpus)

# SCR-025 + STA-064..068 Activity timeline/list.
check("activity loading canonical", "OptimalLoadingState(" in activity_route and 'testTag("activity-loading")' in activity_route)
check("activity error canonical", "OptimalErrorState(" in activity_route and "ActivityUiEvent.Retry" in activity_route)
check("activity empty canonical", "OptimalEmptyState(" in activity_route and 'testTag("activity-empty")' in activity_route)
check("activity screen exists", "fun ActivityScreen(" in activity)
check("activity section header canonical", "OptimalSectionHeader(" in activity)
check("activity timeline row canonical", "OptimalListRow(" in activity_components)
check("activity source badge semantic", "OptimalStatusBadge(" in activity_components and "OptimalStatusTone.Info" in activity_components)
check("activity timeline preserves changed fields", "event.changedFieldsLabel" in activity_components)
check("activity timeline preserves actor", "event.actorLabel" in activity_components)
check("activity timeline preserves timestamp", "event.timestampLabel" in activity_components)
check("activity load more action canonical", "OptimalSecondaryButton(" in activity and "ActivityUiEvent.LoadMore" in activity)
check("activity loading-more label preserved", 'if (state.isLoadingMore) "جارٍ التحميل" else "تحميل المزيد"' in activity)
check("activity append error semantic", "OptimalInlineStatus(" in activity and "OptimalStatusTone.Danger" in activity)
check("activity append error tag preserved", 'testTag("activity-append-error")' in activity)

# Functional freeze against supplied OPTIMAL-v104.
expected_hashes = {
    f"{base}/presentation/SettingsContract.kt": "50cf4c778109cd388d2115d0ccb557a5542c550d0a425cafa241a2b3b320e1f9",
    f"{base}/presentation/members/MembersContract.kt": "683dbf6f76031e07e3797a31c3f986c83047cc23df1d07a515a0324ed8a5b34f",
    f"{base}/presentation/members/MembersViewModel.kt": "f1422597725aedcdab569438448cb37908a850f959c6f58737f3b5671b89fe98",
    f"{base}/presentation/activity/ActivityContract.kt": "36bcbd177a43be936f716f03019a55cc4071418f3cac39fdfad24b22948e85cd",
    f"{base}/presentation/activity/ActivityViewModel.kt": "6be605a28a5c7089205596801053b22492b2d75b074070afac34571629c21e23",
    f"{base}/presentation/join/JoinCompanyContract.kt": "615e08139a2096981f437241a7b20a69d6910757e75f7cec23665c675d6889f3",
    f"{base}/presentation/join/JoinCompanyViewModel.kt": "6ff8ddf7eb20494ca9988a77bbbfb54c8f00fbadee590932b9817da4ed8fc049",
    f"{base}/navigation/SettingsNavigation.kt": "8861804dfeae111e35eafde1f5ed32df6f4cddb9b1557c009950986f4a479df8",
    "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt": "fb2e94c9b53dd8094967a886004d1a86304b02d35a80900f9e8029e7df8003ad",
}
for rel, expected in expected_hashes.items():
    actual = sha256(rel)
    check(f"v104 functional boundary unchanged: {Path(rel).name}", actual == expected, actual)
check("settings domain tree unchanged", tree_hash(f"{base}/domain") == "bcf34c3f18d22ed6a1d7209347397f9e427c51a528d19a670c73dcc2141ec647")
check("settings data tree unchanged", tree_hash(f"{base}/data") == "ca09349c43da216f8580d30e7da538cc65e94d3ecfaa26f49669e5a7da198e79")

# Ledger/allowlist acceptance: 4 screens + 2 dialogs + 12 states.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_105 = {"SCR-022", "SCR-023", "SCR-024", "SCR-025", "DLG-004", "DLG-005", *(f"STA-{i:03d}" for i in range(57, 69))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("SESSION-105 has exactly 18 inventory IDs", len(expected_105) == 18)
check("all SESSION-105 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_105), str(sorted(i for i in expected_105 if statuses.get(i) != "MIGRATED")))
counts = Counter(status for _, status in rows)
check("ledger migrated total is 104", counts["MIGRATED"] == 104, str(counts))
check("ledger unmigrated total is 19", counts["UNMIGRATED"] == 19, str(counts))
check("ledger has no blocked rows", counts["BLOCKED"] == 0, str(counts))
allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("Settings UI removed from allowlist", not any(path.startswith(f"{base}/presentation/") for path in allow))
check("remaining allowlist is 11 UI files", len(allow) == 11, str(len(allow)))

# Every Settings Compose UI file must now be free of local visual-language violations.
ui_files: list[Path] = []
for path in sorted((ROOT / f"{base}/presentation").rglob("*.kt")):
    text = path.read_text(encoding="utf-8")
    if "@Composable" not in text:
        continue
    ui_files.append(path)
    rel = path.relative_to(ROOT).as_posix()
    check(f"{rel} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", text) is None)
    check(f"{rel} has no raw hex color", "Color(0x" not in text)
    check(f"{rel} has no local font family", "FontFamily(" not in text and "fontFamily =" not in text)
    check(f"{rel} has no raw font size", re.search(r"fontSize\s*=\s*\d+(?:\.\d+)?\.sp\b", text) is None)
    check(f"{rel} has no raw rounded shape", "RoundedCornerShape(" not in text)
    check(f"{rel} has no direct Material field", re.search(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(", text) is None)
    check(f"{rel} has no direct Material button", re.search(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(", text) is None)
    check(f"{rel} has no direct AlertDialog", re.search(r"(?<![A-Za-z0-9_])AlertDialog\s*\(", text) is None)
check("Settings has 11 Compose UI files", len(ui_files) == 11, str(len(ui_files)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-105 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
