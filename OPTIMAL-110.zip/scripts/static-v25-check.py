#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "docs/sessions/v25.md",
    "docs/database-schema-v25.md",
    "docs/verification-scripts-v25.md",
    "docs/source-archive-v25.sha256",
    "scripts/generate-room-baseline.py",
    "scripts/static-v25-check.py",
    "scripts/verify-v25-static.sh",
    "scripts/verify-v25-regressions.sh",
    "PATCH_MANIFEST-v25.md",
    "CHANGED_FILES-v25.txt",
    "DELETED_FILES-v25.txt",
    "verification-v25.md",
    "docs/verifications/verification-v25.md",
    "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/1.json",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 20", bool(re.search(r"\bversionCode\s*=\s*20\b", build)))
check("versionName is v25", 'versionName = "0.25.0-v25"' in build)

database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
database_module = read("core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt")
database_callback = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabaseCallback.kt")
production_sources = "\n".join(
    path.read_text(encoding="utf-8")
    for root_name in ["app/src/main", "core", "feature"]
    for path in (ROOT / root_name).rglob("*.kt")
    if "/src/test/" not in path.as_posix() and "/src/androidTest/" not in path.as_posix()
)
check("OptimalDatabase is reset to version 1", "version = 1" in database and "version = 13" not in database)
check("all 18 entities remain registered", len(re.findall(r"\w+Entity::class", database)) == 18)
check("migration source is deleted", not (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt").exists())
check("migration package is absent", not (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/migration").exists())
check("DatabaseModule installs no migrations", "addMigrations" not in database_module and "DatabaseMigrations" not in database_module)
check("destructive fallback is absent", "fallbackToDestructiveMigration" not in production_sources)
check("database module installs shared creation callback", ".addCallback(OptimalDatabaseCallback)" in database_module)
check("audit append-only callback remains installed", "AuditEventSchema.installAppendOnlyGuards(db)" in database_callback)

schema_dir = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
schema_files = sorted(path.name for path in schema_dir.glob("*.json"))
check("schemas directory contains only 1.json", schema_files == ["1.json"], ", ".join(schema_files))
try:
    schema = json.loads((schema_dir / "1.json").read_text(encoding="utf-8"))
except Exception as error:
    schema = {}
    check("1.json is valid JSON", False, str(error))
else:
    check("1.json is valid JSON", True)
db = schema.get("database", {})
entities = db.get("entities", [])
tables = {entity.get("tableName") for entity in entities}
expected_tables = {
    "companies",
    "local_users",
    "active_session",
    "vehicles",
    "vehicle_audit_events",
    "maintenance_operations",
    "maintenance_audit_events",
    "maintenance_follow_ups",
    "pending_sync_operations",
    "sync_conflict_audit",
    "verto_invoice_projections",
    "invoice_source_audit",
    "verto_invoice_maintenance_links",
    "verto_invoice_link_audit",
    "additional_costs",
    "audit_events",
    "member_invites",
    "notifications",
}
check("schema version is 1", db.get("version") == 1, str(db.get("version")))
check("schema contains all 18 final tables", tables == expected_tables, str(sorted(tables)))
check("schema contains 219 columns", sum(len(entity.get("fields", [])) for entity in entities) == 219)
check("schema contains 91 declared indices", sum(len(entity.get("indices", [])) for entity in entities) == 91)
check("schema contains 35 foreign keys", sum(len(entity.get("foreignKeys", [])) for entity in entities) == 35)
check("schema identity hash is present", bool(re.fullmatch(r"[0-9a-f]{32}", db.get("identityHash", ""))))

company = next((entity for entity in entities if entity.get("tableName") == "companies"), {})
local_user = next((entity for entity in entities if entity.get("tableName") == "local_users"), {})
company_fields = {field.get("columnName"): field for field in company.get("fields", [])}
user_fields = {field.get("columnName"): field for field in local_user.get("fields", [])}
check("currency default is preserved", company_fields.get("currencyCode", {}).get("defaultValue") == "'SDG'")
check("Verto-link default is preserved", company_fields.get("isVertoLinked", {}).get("defaultValue") == "0")
check("last-active default is preserved", user_fields.get("lastActiveAtEpochMillis", {}).get("defaultValue") == "0")

generator = subprocess.run(
    [sys.executable, str(ROOT / "scripts/generate-room-baseline.py"), "--check"],
    cwd=ROOT,
    capture_output=True,
    text=True,
)
check("source-derived Room schema check passes", generator.returncode == 0, (generator.stdout + generator.stderr).strip())

test_source = "\n".join(
    path.read_text(encoding="utf-8")
    for base in ["app/src/test", "core/database/src/androidTest", "core/database/src/test"]
    for path in (ROOT / base).rglob("*.kt")
    if (ROOT / base).exists()
)
check("tests no longer depend on published migrations", not re.search(r"MigrationTestHelper|import .*DatabaseMigrations|migration/DatabaseMigrations\.kt|\.addMigrations\(|MIGRATION_\d+_\d+", test_source))
check("fresh database test exists", (ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/FreshDatabaseSchemaTest.kt").is_file())
check("invoice baseline test exists", (ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/InvoiceDaoBaselineTest.kt").is_file())
check("old migration tests are deleted", all(not (ROOT / path).exists() for path in [
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/AllPublishedMigrationsTest.kt",
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/InvoiceDaoMigrationTest.kt",
]))

for document in [
    "README.md",
    "AGENTS.md",
    "docs/release-notes.md",
    "docs/database-schema-v25.md",
]:
    text = read(document)
    check(f"{document} states current version or reset rule", (
        "0.25.0-v25" in text or "v25" in text
    ) and ("مسح" in text or "إلغاء تثبيت" in text))

schema_doc = read("docs/database-schema-v25.md")
check("schema document lists every table", all(f"`{table}`" in schema_doc for table in expected_tables))
check("schema document records keys and indices", "المفاتيح الخارجية" in schema_doc and "الفهارس" in schema_doc)

verify_project = read("scripts/verify-project.sh")
verify_static = read("scripts/verify-v25-static.sh")
verify_regressions = read("scripts/verify-v25-regressions.sh")
check("verify-project invokes v25 static gate", "verify-v25-static.sh" in verify_project)
check("verify-project invokes v25 regression gate", "verify-v25-regressions.sh" in verify_project)
check("verify-project retains required Gradle commands", all(command in verify_project for command in [
    "./gradlew clean",
    "./gradlew testDebugUnitTest",
    "./gradlew lintDebug",
    "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))
check("v25 static gate includes schema and architecture checks", "generate-room-baseline.py --check" in verify_static and "static-architecture-check.py" in verify_static)
check("v25 regression harnesses run sequentially", "for script" in verify_regressions and not re.search(r"&\s*(?:p\d+|$)", verify_regressions, re.M))

for script in [
    "scripts/verify-project.sh",
    "scripts/generate-room-baseline.py",
    "scripts/static-v25-check.py",
    "scripts/verify-v25-static.sh",
    "scripts/verify-v25-regressions.sh",
]:
    path = ROOT / script
    check(f"active script is executable: {script}", path.is_file() and bool(path.stat().st_mode & 0o111))

for script in [
    "scripts/generate-room-baseline.py",
    "scripts/static-v25-check.py",
    "scripts/static-architecture-check.py",
]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid = True
        detail = ""
    except py_compile.PyCompileError as error:
        valid = False
        detail = str(error)
    check(f"Python syntax valid: {script}", valid, detail)

for script in [
    "scripts/verify-project.sh",
    "scripts/verify-v25-static.sh",
    "scripts/verify-v25-regressions.sh",
]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result.returncode == 0, result.stderr.strip())

source_hash = read("docs/source-archive-v25.sha256").strip()
check(
    "v24 source archive SHA-256 is recorded",
    bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-full-v24\.zip", source_hash)),
    source_hash,
)

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV25 Room baseline checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
