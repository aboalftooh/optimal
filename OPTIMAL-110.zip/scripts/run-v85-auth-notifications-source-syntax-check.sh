#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthAccountContent.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRoute.kt"
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreen.kt"
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsComponents.kt"
  "$ROOT_DIR/feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AuthRouteV85Test.kt"
  "$ROOT_DIR/feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRouteV85Test.kt"
  "$ROOT_DIR/feature/notifications/src/androidTest/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreenV85Test.kt"
)
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 90s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: v85 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v85 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} changed v85 Kotlin/test files; unresolved Android/Compose symbols were intentionally ignored without Gradle classpath."
