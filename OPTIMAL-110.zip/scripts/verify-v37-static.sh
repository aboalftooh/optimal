#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/static-architecture-check.py
python3 scripts/security-release-check.py
python3 scripts/static-v37-check.py
python3 scripts/v21-backend-contract-harness.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
./scripts/run-v36-testing-harness.sh
./scripts/run-v36-auth-process-death-harness.sh
./scripts/run-v36-vehicle-contract-harness.sh
./scripts/run-v36-test-syntax-check.sh
python3 scripts/v35-ui-parity-contract.py
