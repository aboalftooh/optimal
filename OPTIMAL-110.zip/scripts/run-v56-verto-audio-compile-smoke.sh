#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
cat > "$TMP_DIR/android_content.kt" <<'KT'
package android.content
import java.io.File
open class Context { open val filesDir: File = File(".") }
KT
cat > "$TMP_DIR/android_os.kt" <<'KT'
package android.os
object Build { object VERSION { const val SDK_INT = 35 }; object VERSION_CODES { const val S = 31 } }
KT
cat > "$TMP_DIR/android_media.kt" <<'KT'
package android.media
import android.content.Context
class MediaRecorder {
    constructor()
    constructor(context: Context)
    fun setAudioSource(value: Int) = Unit
    fun setOutputFormat(value: Int) = Unit
    fun setAudioEncoder(value: Int) = Unit
    fun setAudioChannels(value: Int) = Unit
    fun setAudioSamplingRate(value: Int) = Unit
    fun setAudioEncodingBitRate(value: Int) = Unit
    fun setOutputFile(value: String) = Unit
    fun prepare() = Unit
    fun start() = Unit
    fun stop() = Unit
    fun reset() = Unit
    fun release() = Unit
    object AudioSource { const val MIC = 1 }
    object OutputFormat { const val MPEG_4 = 2 }
    object AudioEncoder { const val AAC = 3 }
}
class MediaMetadataRetriever {
    fun setDataSource(path: String) = Unit
    fun extractMetadata(key: Int): String? = "1000"
    fun release() = Unit
    companion object { const val METADATA_KEY_DURATION = 9 }
}
KT
cat > "$TMP_DIR/hilt.kt" <<'KT'
package dagger.hilt.android.qualifiers
@Target(AnnotationTarget.VALUE_PARAMETER, AnnotationTarget.FIELD) annotation class ApplicationContext
KT
cat > "$TMP_DIR/inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FUNCTION, AnnotationTarget.FIELD) annotation class Inject
@Target(AnnotationTarget.CLASS) annotation class Singleton
KT
kotlinc -nowarn \
  "$TMP_DIR"/*.kt \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessage.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingMessageIdentity.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingAttachment.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/attachment/VertoAttachmentImporter.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/audio/VertoAudioRecorder.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/AndroidVertoAudioRecorder.kt" \
  -d "$TMP_DIR/audio.jar" >/dev/null
echo "PASS: AndroidVertoAudioRecorder compiled against strict Android media/storage API stubs."
