#!/usr/bin/env python3
"""Executable architecture boundaries for OPTIMAL.

This check intentionally uses only the Python standard library so it can run
before Gradle is available. It protects module direction and the two critical
source boundaries required by the v24 baseline:

* domain code must remain independent from Android and infrastructure details;
* presentation/UI code must not reach DAOs, entities, network clients or data adapters.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = [
    ":app",
    ":core:model",
    ":core:common",
    ":core:session",
    ":core:database",
    ":core:network",
    ":core:designsystem",
    ":core:testing",
    ":feature:auth",
    ":feature:home",
    ":feature:vehicles",
    ":feature:maintenance",
    ":feature:finance",
    ":feature:notifications",
    ":feature:settings",
    ":feature:verto",
]
FEATURES = [module for module in EXPECTED if module.startswith(":feature:")]
CORES = [module for module in EXPECTED if module.startswith(":core:")]

checks: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


def module_path(module: str) -> Path:
    return ROOT / module.strip(":").replace(":", "/")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def production_kotlin() -> list[Path]:
    return sorted(
        path
        for path in ROOT.rglob("*.kt")
        if "/src/main/" in path.as_posix()
        and not any(part in {"build", ".gradle"} for part in path.parts)
    )


settings_path = ROOT / "settings.gradle.kts"
settings = read(settings_path) if settings_path.is_file() else ""
check("01 settings.gradle.kts exists", settings_path.is_file())
check("02 all expected modules are declared", all(f'include("{m}")' in settings for m in EXPECTED))

build_files = {module: module_path(module) / "build.gradle.kts" for module in EXPECTED}
missing_builds = [module for module, path in build_files.items() if not path.is_file()]
check("03 every declared module has a build file", not missing_builds, ", ".join(missing_builds))

app_build_path = ROOT / "app/build.gradle.kts"
app_build = read(app_build_path) if app_build_path.is_file() else ""
check("04 applicationId is com.optimal.fleet", 'applicationId = "com.optimal.fleet"' in app_build)
application_plugin = ROOT / "build-logic/src/main/kotlin/AndroidApplicationConventionPlugin.kt"
check(
    "05 minSdk 26 is centralized",
    application_plugin.is_file() and "minSdk = 26" in read(application_plugin),
)

# Parse project dependencies once and validate their direction.
graph: dict[str, set[str]] = {module: set() for module in EXPECTED}
for module, path in build_files.items():
    if not path.is_file():
        continue
    for dependency in re.findall(r'project\("(:[^\"]+)"\)', read(path)):
        graph[module].add(dependency)

feature_to_feature = [
    f"{module}->{dependency}"
    for module in FEATURES
    for dependency in sorted(graph[module])
    if dependency.startswith(":feature:")
]
check("06 no feature-to-feature Gradle dependency", not feature_to_feature, ", ".join(feature_to_feature))

core_to_outer = [
    f"{module}->{dependency}"
    for module in CORES
    for dependency in sorted(graph[module])
    if dependency == ":app" or dependency.startswith(":feature:")
]
check("07 core modules do not depend on app/features", not core_to_outer, ", ".join(core_to_outer))

unknown_deps = [
    f"{module}->{dependency}"
    for module, dependencies in graph.items()
    for dependency in sorted(dependencies)
    if dependency not in graph
]
check("08 project dependencies target declared modules", not unknown_deps, ", ".join(unknown_deps))


def has_cycle() -> bool:
    visiting: set[str] = set()
    complete: set[str] = set()

    def visit(node: str) -> bool:
        if node in visiting:
            return True
        if node in complete:
            return False
        visiting.add(node)
        for dependency in graph.get(node, ()):
            if dependency in graph and visit(dependency):
                return True
        visiting.remove(node)
        complete.add(node)
        return False

    return any(visit(node) for node in graph)


check("09 project dependency graph is acyclic", not has_cycle())

# Source-level cross-feature imports are forbidden even when Gradle would fail later.
feature_imports: list[str] = []
for module in FEATURES:
    own_package = f"com.optimal.fleet.feature.{module.split(':')[-1]}."
    for path in module_path(module).rglob("*.kt"):
        if "/src/main/" not in path.as_posix():
            continue
        for imported in re.findall(r"^import\s+(com\.optimal\.fleet\.feature\.[^\s]+)", read(path), re.M):
            if not imported.startswith(own_package):
                feature_imports.append(f"{path.relative_to(ROOT)} -> {imported}")
check("10 no source import crosses feature boundaries", not feature_imports, "; ".join(feature_imports))

common_sources = [path for path in (ROOT / "core/common").rglob("*.kt") if "/src/main/" in path.as_posix()]
common_namespaces = {
    "analytics": "com.optimal.fleet.core.common.analytics",
    "error": "com.optimal.fleet.core.common.error",
}
common_consumers: dict[str, set[str]] = {name: set() for name in common_namespaces}
for module in EXPECTED:
    if module == ":core:common":
        continue
    for source in module_path(module).rglob("*.kt"):
        if "/src/main/" not in source.as_posix():
            continue
        content = read(source)
        for name, namespace in common_namespaces.items():
            if namespace in content:
                common_consumers[name].add(module)
allowed_common_sources = all(
    any(f"/{name}/" in path.as_posix() for name in common_namespaces)
    for path in common_sources
)
used_namespaces = {
    name
    for name in common_namespaces
    if any(f"/{name}/" in path.as_posix() for path in common_sources)
}
common_is_justified = (
    not common_sources
    or (
        allowed_common_sources
        and all(len(common_consumers[name]) >= 2 for name in used_namespaces)
    )
)
check(
    "11 core:common contains genuinely shared abstractions",
    common_is_justified,
    f"files={len(common_sources)}, consumers={dict((name, sorted(values)) for name, values in common_consumers.items())}",
)
check("12 no central AppModule", not any(ROOT.rglob("AppModule.kt")))

sources = production_kotlin()
imports_by_file: dict[Path, list[str]] = {
    path: re.findall(r"^import\s+([^\s]+)", read(path), re.M) for path in sources
}

domain_android: list[str] = []
domain_infrastructure: list[str] = []
presentation_storage: list[str] = []
presentation_network_or_data: list[str] = []
for path, imports in imports_by_file.items():
    path_string = path.as_posix()
    relative = str(path.relative_to(ROOT))
    if "/domain/" in path_string:
        for imported in imports:
            if imported.startswith(("android.", "androidx.")):
                domain_android.append(f"{relative} -> {imported}")
            if imported.startswith(
                (
                    "retrofit2.",
                    "okhttp3.",
                    "kotlinx.serialization.",
                    "com.optimal.fleet.core.database.",
                    "com.optimal.fleet.core.network.",
                    "io.github.jan.supabase.",
                )
            ):
                domain_infrastructure.append(f"{relative} -> {imported}")
    if "/presentation/" in path_string or "/ui/" in path_string:
        for imported in imports:
            if imported.startswith(("androidx.room.", "com.optimal.fleet.core.database.")):
                presentation_storage.append(f"{relative} -> {imported}")
            if (
                imported.startswith(
                    (
                        "retrofit2.",
                        "okhttp3.",
                        "com.optimal.fleet.core.network.",
                        "androidx.work.",
                        "io.github.jan.supabase.",
                    )
                )
                or ".data." in imported
            ):
                presentation_network_or_data.append(f"{relative} -> {imported}")

check("13 domain is independent from Android", not domain_android, "; ".join(domain_android))
check(
    "14 domain is independent from Room/network/serialization/Supabase",
    not domain_infrastructure,
    "; ".join(domain_infrastructure),
)
check("15 presentation/UI does not import Room/database", not presentation_storage, "; ".join(presentation_storage))
check(
    "16 presentation/UI does not import network/data adapters/WorkManager",
    not presentation_network_or_data,
    "; ".join(presentation_network_or_data),
)

production_text = "\n".join(read(path) for path in sources)
check("17 production code has no GlobalScope", "GlobalScope" not in production_text)
check("18 production code has no runBlocking", not re.search(r"\brunBlocking\b", production_text))
check("19 destructive Room fallback is absent", "fallbackToDestructiveMigration" not in production_text)

check("20 app is the feature composition root", all(f'project("{module}")' in app_build for module in FEATURES))
required_app_shell = [
    ROOT / "app/src/main/java/com/optimal/fleet/OptimalApplication.kt",
    ROOT / "app/src/main/java/com/optimal/fleet/MainActivity.kt",
    ROOT / "app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt",
    ROOT / "app/src/main/java/com/optimal/fleet/ui/OptimalAppScaffold.kt",
]
check("21 application shell files exist", all(path.is_file() for path in required_app_shell))
check("22 version catalog exists", (ROOT / "gradle/libs.versions.toml").is_file())
wrapper_files = [
    "gradlew",
    "gradlew.bat",
    "gradle/wrapper/gradle-wrapper.jar",
    "gradle/wrapper/gradle-wrapper.properties",
]
check("23 Gradle wrapper files exist", all((ROOT / path).is_file() for path in wrapper_files))

secret_or_build: list[str] = []
for path in ROOT.rglob("*"):
    relative = path.relative_to(ROOT)
    if path.name in {"local.properties", "secrets.properties", "supabase.properties"}:
        secret_or_build.append(str(relative))
    elif any(part in {"build", ".gradle"} for part in relative.parts) and "build-logic" not in relative.parts:
        secret_or_build.append(str(relative))
check("24 archive contains no secrets or generated build output", not secret_or_build, ", ".join(secret_or_build))

for name, passed, detail in checks:
    status = "PASS" if passed else "FAIL"
    print(f"{status}: {name}" + (f" — {detail}" if detail and not passed else ""))

passed = sum(1 for _, ok, _ in checks if ok)
print(f"\nArchitecture checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
