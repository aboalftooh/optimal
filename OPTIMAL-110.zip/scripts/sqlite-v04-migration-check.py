#!/usr/bin/env python3
import sqlite3

conn = sqlite3.connect(':memory:')
conn.execute('PRAGMA foreign_keys = ON')
conn.executescript('''
CREATE TABLE companies (
 id TEXT NOT NULL PRIMARY KEY,
 remoteId TEXT,
 name TEXT NOT NULL,
 createdAtEpochMillis INTEGER NOT NULL,
 updatedAtEpochMillis INTEGER NOT NULL,
 syncStatus TEXT NOT NULL
);
CREATE UNIQUE INDEX index_companies_remoteId ON companies(remoteId);
CREATE TABLE local_users (
 id TEXT NOT NULL,
 companyId TEXT NOT NULL,
 remoteId TEXT,
 displayName TEXT NOT NULL,
 phone TEXT,
 isActive INTEGER NOT NULL,
 createdAtEpochMillis INTEGER NOT NULL,
 updatedAtEpochMillis INTEGER NOT NULL,
 syncStatus TEXT NOT NULL,
 PRIMARY KEY(id),
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX index_local_users_id_companyId ON local_users(id, companyId);
''')
conn.executescript('''
CREATE TABLE IF NOT EXISTS vehicles (
 id TEXT NOT NULL,
 companyId TEXT NOT NULL,
 remoteId TEXT,
 name TEXT NOT NULL,
 plateNumber TEXT NOT NULL,
 normalizedPlateNumber TEXT NOT NULL,
 brand TEXT,
 model TEXT,
 manufactureYear INTEGER,
 odometerKm INTEGER,
 department TEXT,
 driverName TEXT,
 archivedAtEpochMillis INTEGER,
 createdAtEpochMillis INTEGER NOT NULL,
 updatedAtEpochMillis INTEGER NOT NULL,
 syncStatus TEXT NOT NULL,
 PRIMARY KEY(id),
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT
);
CREATE INDEX index_vehicles_companyId ON vehicles(companyId);
CREATE UNIQUE INDEX index_vehicles_id_companyId ON vehicles(id, companyId);
CREATE UNIQUE INDEX index_vehicles_companyId_normalizedPlateNumber ON vehicles(companyId, normalizedPlateNumber);
CREATE UNIQUE INDEX index_vehicles_remoteId ON vehicles(remoteId);
CREATE INDEX index_vehicles_companyId_archivedAtEpochMillis ON vehicles(companyId, archivedAtEpochMillis);
CREATE TABLE IF NOT EXISTS vehicle_audit_events (
 id TEXT NOT NULL,
 companyId TEXT NOT NULL,
 vehicleId TEXT NOT NULL,
 actorUserId TEXT NOT NULL,
 action TEXT NOT NULL,
 previousOdometerKm INTEGER,
 newOdometerKm INTEGER,
 reason TEXT,
 createdAtEpochMillis INTEGER NOT NULL,
 syncStatus TEXT NOT NULL,
 PRIMARY KEY(id),
 FOREIGN KEY(vehicleId, companyId) REFERENCES vehicles(id, companyId) ON DELETE RESTRICT,
 FOREIGN KEY(actorUserId, companyId) REFERENCES local_users(id, companyId) ON DELETE RESTRICT
);
CREATE INDEX index_vehicle_audit_events_companyId ON vehicle_audit_events(companyId);
CREATE INDEX index_vehicle_audit_events_vehicleId_companyId ON vehicle_audit_events(vehicleId, companyId);
CREATE INDEX index_vehicle_audit_events_actorUserId_companyId ON vehicle_audit_events(actorUserId, companyId);
CREATE INDEX index_vehicle_audit_events_createdAtEpochMillis ON vehicle_audit_events(createdAtEpochMillis);
''')

checks = 0
def ok(name, condition):
    global checks
    if not condition:
        raise AssertionError(name)
    checks += 1
    print(f'PASS: {name}')

for c, u in [('c1','u1'),('c2','u2')]:
    conn.execute('INSERT INTO companies VALUES (?,NULL,?,1,1,?)', (c,c,'PENDING'))
    conn.execute('INSERT INTO local_users VALUES (?,?,NULL,?,NULL,1,1,1,?)', (u,c,u,'PENDING'))
conn.execute("INSERT INTO vehicles VALUES ('v1','c1',NULL,'A','12-34','1234',NULL,NULL,NULL,100,NULL,NULL,NULL,1,1,'PENDING')")
conn.execute("INSERT INTO vehicles VALUES ('v2','c2',NULL,'B','12-34','1234',NULL,NULL,NULL,200,NULL,NULL,NULL,1,1,'PENDING')")
ok('same normalized plate allowed across companies', conn.execute('SELECT COUNT(*) FROM vehicles').fetchone()[0] == 2)

try:
    conn.execute("INSERT INTO vehicles VALUES ('v3','c1',NULL,'C','12 34','1234',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'PENDING')")
    duplicate_blocked = False
except sqlite3.IntegrityError:
    duplicate_blocked = True
ok('duplicate normalized plate blocked within company', duplicate_blocked)

try:
    conn.execute("INSERT INTO vehicles VALUES ('v4','missing',NULL,'D','99','99',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'PENDING')")
    orphan_blocked = False
except sqlite3.IntegrityError:
    orphan_blocked = True
ok('orphan vehicle blocked', orphan_blocked)

conn.execute("INSERT INTO vehicle_audit_events VALUES ('a1','c1','v1','u1','VEHICLE_CREATED',NULL,100,NULL,1,'PENDING')")
ok('valid scoped audit accepted', conn.execute('SELECT COUNT(*) FROM vehicle_audit_events').fetchone()[0] == 1)

try:
    conn.execute("INSERT INTO vehicle_audit_events VALUES ('a2','c2','v1','u2','VEHICLE_UPDATED',100,90,'x',2,'PENDING')")
    cross_scope_blocked = False
except sqlite3.IntegrityError:
    cross_scope_blocked = True
ok('cross-company audit blocked', cross_scope_blocked)

try:
    conn.execute("DELETE FROM vehicles WHERE id='v1'")
    delete_blocked = False
except sqlite3.IntegrityError:
    delete_blocked = True
ok('vehicle deletion blocked when audit exists', delete_blocked)

conn.execute("UPDATE vehicles SET archivedAtEpochMillis=10 WHERE id='v1' AND companyId='c1'")
ok('archive preserves vehicle row', conn.execute("SELECT COUNT(*) FROM vehicles WHERE id='v1' AND archivedAtEpochMillis=10").fetchone()[0] == 1)
print(f'SQLite v04 migration checks: {checks}/{checks}')
