#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

base = "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation"
list_route = read(f"{base}/list/MaintenanceListRoute.kt")
list_components = read(f"{base}/list/MaintenanceListComponents.kt")
history_route = read(f"{base}/history/MaintenanceHistoryRoute.kt")
history_components = read(f"{base}/history/MaintenanceHistoryComponents.kt")
followup = read(f"{base}/followup/MaintenanceFollowUpRoute.kt")
status_component = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalStatus.kt")

# Generic DS support added without changing existing call sites.
check("inline status retains canonical API", "fun OptimalInlineStatus(" in status_component)
check("inline status supports optional action label", "actionLabel: String? = null" in status_component)
check("inline status supports optional action callback", "onAction: (() -> Unit)? = null" in status_component)
check("inline status action remains tertiary", "OptimalTertiaryButton(" in status_component)

# SCR-012 + STA-022..026: Maintenance list discovery.
check("maintenance list route exists", "fun MaintenanceListRoute(" in list_route)
check("maintenance destination tag preserved", 'testTag("destination-maintenance")' in list_route)
check("maintenance local-first notice semantic", "OptimalInlineStatus(" in list_route and "OptimalStatusTone.Info" in list_route)
check("maintenance local-first copy preserved", '"سجل الصيانة متاح دون اتصال"' in list_route)
check("maintenance local-first tag preserved", 'testTag("maintenance-local-first")' in list_route)
check("maintenance opens history callback", "MaintenanceListUiEvent.OpenHistory" in list_route)
check("maintenance opens follow-up callback", "MaintenanceListUiEvent.OpenFollowUps" in list_route)
check("maintenance status uses segmented control", "OptimalSegmentedControl(" in list_route)
check("maintenance in-progress segment preserved", "OperationStatus.IN_PROGRESS" in list_route and '"جاري المعالجة"' in list_route)
check("maintenance completed segment preserved", "OperationStatus.COMPLETED" in list_route and '"مكتمل"' in list_route)
check("maintenance search canonical", "OptimalSearchField(" in list_route)
check("maintenance search callback preserved", "MaintenanceListUiEvent.SearchChanged(it)" in list_route)
check("maintenance clear callback preserved", "MaintenanceListUiEvent.ClearSearch" in list_route)
check("maintenance source filter callbacks preserved", "MaintenanceListUiEvent.SourceChanged" in list_route)
check("maintenance type filter callbacks preserved", "MaintenanceListUiEvent.TypeChanged" in list_route)
check("maintenance period filter callbacks preserved", "MaintenanceListUiEvent.PeriodChanged" in list_route)
check("maintenance filters canonical", list_route.count("OptimalFilterChip(") >= 1)
check("maintenance loading canonical", "state.isLoading -> OptimalLoadingState(" in list_route)
check("maintenance loading tag preserved", 'testTag("maintenance-loading")' in list_route)
check("maintenance full error canonical", "state.errorMessage != null -> OptimalErrorState(" in list_route)
check("maintenance full error retry preserved", "MaintenanceListUiEvent.Retry" in list_route)
check("maintenance empty canonical", "state.operations.isEmpty() -> OptimalEmptyState(" in list_route)
check("maintenance empty/no-results copy preserved", '"لا توجد عمليات"' in list_route and '"لا توجد نتائج"' in list_route)
check("maintenance list rows canonical", "OptimalListRow(" in list_components)
check("maintenance row vehicle hierarchy", "title = operation.vehicleName" in list_components)
check("maintenance row description hierarchy", "subtitle = operation.description" in list_components)
check("maintenance row metadata contains plate", "operation.plateNumber" in list_components)
check("maintenance row metadata contains type", "operation.typeLabel" in list_components)
check("maintenance row metadata contains source", "operation.sourceLabel" in list_components)
check("maintenance row metadata contains date", "operation.dateLabel" in list_components)
check("maintenance row status canonical", "OptimalStatusBadge(" in list_components)
check("maintenance row status tones semantic", "OptimalStatusTone.Info" in list_components and "OptimalStatusTone.Success" in list_components)
check("maintenance row selection callback preserved", "MaintenanceListUiEvent.OperationSelected(operation.id)" in list_route)
check("maintenance append error semantic", 'item(key = "maintenance-append-error")' in list_route and "OptimalStatusTone.Danger" in list_route)
check("maintenance append retry preserved", "onAction = { onEvent(MaintenanceListUiEvent.LoadMore) }" in list_route)
check("maintenance append retry tag preserved", 'testTag("maintenance-load-more-retry")' in list_route)
check("maintenance paging action canonical", "OptimalSecondaryButton(" in list_route)
check("maintenance paging load-more callback preserved", "MaintenanceListUiEvent.LoadMore" in list_route)
check("maintenance add action canonical", "OptimalPrimaryButton(" in list_route)
check("maintenance add callback preserved", "MaintenanceListUiEvent.AddOperation" in list_route)
check("maintenance add tag preserved", 'testTag("add-maintenance-operation")' in list_route)
for effect in ["OpenCreateOperation", "OpenHistory", "OpenFollowUps", "OpenOperation"]:
    check(f"maintenance effect mapping preserved: {effect}", f"MaintenanceListUiEffect.{effect}" in list_route)

# SCR-014 + STA-027..031: history, including vehicle scope behavior.
check("history route exists", "fun MaintenanceHistoryRoute(" in history_route)
check("history destination tag preserved", 'testTag("maintenance-history")' in history_route)
check("history search canonical", "OptimalSearchField(" in history_route)
check("history search callback preserved", "MaintenanceHistoryUiEvent.SearchChanged(it)" in history_route)
check("history clear-search behavior preserved", 'MaintenanceHistoryUiEvent.SearchChanged("")' in history_route)
check("history vehicle-scoped label preserved", "state.isVehicleScoped" in history_route and '"ابحث في سجل صيانة السيارة"' in history_route)
check("history global label preserved", '"ابحث في سجل الصيانة"' in history_route)
check("history loading canonical", "state.isLoading -> OptimalLoadingState(" in history_route)
check("history loading tag preserved", 'testTag("maintenance-history-loading")' in history_route)
check("history error canonical", "state.errorMessage != null -> OptimalErrorState(" in history_route)
check("history retry callback preserved", "MaintenanceHistoryUiEvent.Retry" in history_route)
check("history empty canonical", "state.items.isEmpty() -> OptimalEmptyState(" in history_route)
check("history empty/no-results copy preserved", '"لا يوجد سجل صيانة"' in history_route and '"لا توجد نتائج"' in history_route)
check("history row canonical", "OptimalListRow(" in history_components)
check("history row vehicle hierarchy", "title = item.vehicleName" in history_components)
check("history row description hierarchy", "subtitle = item.description" in history_components)
check("history metadata contains plate", "item.plateNumber" in history_components)
check("history metadata contains type", "item.typeLabel" in history_components)
check("history metadata contains source", "item.sourceLabel" in history_components)
check("history metadata contains completion date", "item.completionDateLabel" in history_components)
check("history completed status canonical", "OptimalStatusBadge(" in history_components and "OptimalStatusTone.Success" in history_components)
check("history selection callback preserved", "MaintenanceHistoryUiEvent.ItemSelected(item.id)" in history_route)
check("history append error semantic", 'item(key = "history-append-error")' in history_route and "OptimalStatusTone.Danger" in history_route)
check("history append retry preserved", "onAction = { onEvent(MaintenanceHistoryUiEvent.LoadMore) }" in history_route)
check("history append retry tag preserved", 'testTag("history-load-more-retry")' in history_route)
check("history paging action canonical", "OptimalSecondaryButton(" in history_route)
check("history load-more callback preserved", "MaintenanceHistoryUiEvent.LoadMore" in history_route)
check("history effect mapping preserved", "MaintenanceHistoryUiEffect.OpenOperation" in history_route)

# SCR-015 + STA-032..035: follow-up discovery, focus behavior and conversion.
check("follow-up route exists", "fun MaintenanceFollowUpRoute(" in followup)
check("follow-up destination tag preserved", 'testTag("maintenance-followups")' in followup)
check("follow-up filter group preserved", 'testTag("followup-filters")' in followup)
check("follow-up all filter canonical", 'label = "الكل"' in followup and "OptimalFilterChip(" in followup)
for status, label in [("OVERDUE", "متأخرة"), ("DUE", "مستحقة"), ("UPCOMING", "قادمة")]:
    check(f"follow-up {status.lower()} filter preserved", f"FollowUpStatus.{status}" in followup and f'label = "{label}"' in followup)
check("follow-up status callbacks preserved", "MaintenanceFollowUpUiEvent.StatusChanged" in followup)
check("follow-up loading canonical", "state.isLoading -> OptimalLoadingState(" in followup)
check("follow-up loading tag present", 'testTag("maintenance-followups-loading")' in followup)
check("follow-up error canonical", "state.errorMessage != null -> OptimalErrorState(" in followup)
check("follow-up error tag present", 'testTag("maintenance-followups-error")' in followup)
check("follow-up empty canonical", "state.items.isEmpty() -> OptimalEmptyState(" in followup)
check("follow-up empty tag preserved", 'testTag("maintenance-followups-empty")' in followup)
check("follow-up empty copy preserved", '"لا توجد متابعة قادمة"' in followup)
check("follow-up creation failure semantic", "state.message?.let" in followup and "OptimalInlineStatus(" in followup and "OptimalStatusTone.Danger" in followup)
check("follow-up failure dismiss callback preserved", "MaintenanceFollowUpUiEvent.DismissMessage" in followup)
check("follow-up row canonical", "OptimalListRow(" in followup)
check("follow-up row vehicle hierarchy", "title = item.vehicleName" in followup)
check("follow-up row reason hierarchy", "subtitle = item.reason" in followup)
check("follow-up status badge canonical", "OptimalStatusBadge(" in followup)
check("follow-up status semantic mapping", all(x in followup for x in ["OptimalStatusTone.Info", "OptimalStatusTone.Warning", "OptimalStatusTone.Danger"]))
check("follow-up conversion action canonical", "OptimalPrimaryButton(" in followup)
check("follow-up conversion callback preserved", "MaintenanceFollowUpUiEvent.CreateOperation(item.id)" in followup)
check("follow-up conversion tag preserved", 'testTag("convert-followup-${item.id}")' in followup)
check("focus id parameter preserved", "focusFollowUpId: String? = null" in followup)
check("focus id lookup preserved", "state.items.indexOfFirst { it.id == focusFollowUpId }" in followup)
check("focus id scrolling preserved", "listState.animateScrollToItem(index)" in followup)
check("follow-up effect mapping preserved", "MaintenanceFollowUpUiEffect.OpenOperation" in followup)

# Non-visual contracts and ViewModels must be byte-identical to supplied v101.
expected_hashes = {
    f"{base}/list/MaintenanceListContract.kt": "b20cdceec0307ac4d11656fe7eabb8b328213ab761d1c57931dd036e4a5cba8d",
    f"{base}/list/MaintenanceListViewModel.kt": "a66ce3ed1dc7aae31e237351d773c80404c7e7123570fae85b1c6e65b386ad13",
    f"{base}/history/MaintenanceHistoryContract.kt": "e69ac9f673407ee47138a0913ef8268db75af40b68229b630a62b7a595d50425",
    f"{base}/history/MaintenanceHistoryViewModel.kt": "8a6d88b07e51534f7dd1e30a8ee2ef4455fca5a6e4d4e1685ce5e5a3aed97162",
    f"{base}/followup/MaintenanceFollowUpContract.kt": "15c454596866335ff6daad81798221360d8d2c7ac3c5bcdcf21e048a86d304ee",
    f"{base}/followup/MaintenanceFollowUpViewModel.kt": "33295b4621c105d1efcbbfdfdecad3512566dbdea53dd20e2c4c1979516add4d",
}
for rel, expected in expected_hashes.items():
    actual = sha256(rel)
    check(f"v101 behavior file unchanged: {Path(rel).name}", actual == expected, actual)

# Explicit scoping contract remains in the untouched history VM.
history_vm = read(f"{base}/history/MaintenanceHistoryViewModel.kt")
check("history vehicle arg preserved", "MAINTENANCE_HISTORY_VEHICLE_ARG" in history_vm)
check("history vehicle scoping preserved in loader", "loadHistoryPage(vehicleId, currentQuery" in history_vm)
check("history scoped state preserved", "isVehicleScoped = vehicleId != null" in history_vm)

# Ledger / allowlist acceptance.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_102 = {"SCR-012", "SCR-014", "SCR-015", *(f"STA-{i:03d}" for i in range(22, 36))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("all SESSION-102 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_102), str(sorted(i for i in expected_102 if statuses.get(i) != "MIGRATED")))
check("ledger migrated total is 56", sum(status == "MIGRATED" for _, status in rows) == 56)
check("ledger unmigrated total is 67", sum(status == "UNMIGRATED" for _, status in rows) == 67)
check("ledger has no blocked rows", all(status != "BLOCKED" for _, status in rows))

allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
discovery_prefixes = (f"{base}/list/", f"{base}/history/", f"{base}/followup/")
check("Maintenance discovery UI removed from allowlist", not any(path.startswith(discovery_prefixes) for path in allow))
check("remaining allowlist is 38 UI files", len(allow) == 38, str(len(allow)))

# No visual constitution drift in all five discovery Compose files.
ui_files: list[Path] = []
for subdir in ["list", "history", "followup"]:
    for path in sorted((ROOT / base / subdir).glob("*.kt")):
        text = path.read_text(encoding="utf-8")
        if "@Composable" not in text:
            continue
        ui_files.append(path)
        rel = path.relative_to(ROOT).as_posix()
        check(f"{rel} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", text) is None)
        check(f"{rel} has no raw hex color", "Color(0x" not in text)
        check(f"{rel} has no local font family", "FontFamily(" not in text and "fontFamily =" not in text)
        check(f"{rel} has no direct Material field", re.search(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(", text) is None)
        check(f"{rel} has no direct Material button", re.search(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(", text) is None)
check("Maintenance discovery has 5 Compose UI files", len(ui_files) == 5, str(len(ui_files)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-102 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
