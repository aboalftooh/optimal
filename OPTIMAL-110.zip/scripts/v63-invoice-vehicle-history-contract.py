#!/usr/bin/env python3
"""Static acceptance gate for OPTIMAL v63 invoice and vehicle maintenance history."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(label, condition):
    checks.append((label, condition))
    if not condition:
        raise AssertionError(label)

def read(path):
    target = ROOT / path
    check(f"file:{path}", target.is_file())
    return target.read_text(encoding="utf-8")

invoice_model = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjectionDetails.kt")
invoice_repo = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt")
invoice_vm = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt")
invoice_screen = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt")
invoice_components = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt")
temp_contract = read("core/model/src/main/kotlin/com/optimal/fleet/core/model/verto/TemporaryVertoAttachmentAccess.kt")
temp_remote = read("core/network/src/main/java/com/optimal/fleet/core/network/verto/SupabaseTemporaryVertoAttachmentAccess.kt")
maintenance_source = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/source/VertoMaintenanceSourceModels.kt")
maintenance_repo = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceQueryRepository.kt")
maintenance_content = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContent.kt")
history_vm = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryViewModel.kt")
history_route = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt")
maintenance_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt")
vehicle_screen = read("feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt")
app_nav = read("app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt")
app_build = read("app/build.gradle.kts")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")

for token in ("InvoiceLineItem", "OfficialMaintenanceRecord", "OfficialMaintenanceImage"):
    check(f"invoice:model:{token}", token in invoice_model)
check("invoice:items-observed", "itemDao.observeForInvoice" in invoice_repo)
check("invoice:official-observed", "observeBySourceInvoiceId" in invoice_repo and "observeForMaintenance" in invoice_repo)
check("invoice:items-visible", "InvoiceItemsCard(invoice.items)" in invoice_screen)
check("invoice:official-visible", "OfficialMaintenanceCard" in invoice_screen)
check("invoice:financial-source-copy", "مرجع المبالغ الوحيد هو فاتورة Verto" in invoice_screen)

for forbidden in ("totalMinor", "paidMinor", "remainingMinor", "partsCostMinor", "serviceCostMinor"):
    official_block = invoice_model.split("data class OfficialMaintenanceRecord", 1)[1]
    check(f"invoice:official-no-money:{forbidden}", forbidden not in official_block)
    source_block = maintenance_source.split("data class VertoOfficialMaintenanceRecord", 1)[1]
    check(f"maintenance:official-no-money:{forbidden}", forbidden not in source_block)

check("attachment:sealed-result", "sealed interface TemporaryVertoAttachmentResult" in temp_contract)
check("attachment:temporary-url-only", "signedUrl" in temp_contract and "expiresAtEpochMillis" in temp_contract)
check("attachment:endpoint", 'functions/v1/verto-attachment-access' in temp_remote)
check("attachment:image-only", 'startsWith("image/")' in temp_remote)
check("attachment:url-validation", "uri.isAbsolute" in temp_remote and 'setOf("https", "http")' in temp_remote)
check("attachment:no-url-in-room", not any("signedUrl" in p.read_text(encoding="utf-8") for p in (ROOT / "core/database/src/main").rglob("*.kt")))
check("invoice:image-action", "OpenOfficialImage" in invoice_vm and "OpenTemporaryImage" in invoice_vm)
check("invoice:image-button", "official-image-" in invoice_components)

check("history:vehicle-arg", "MAINTENANCE_HISTORY_VEHICLE_ARG" in history_route)
check("history:encoded-route", "Uri.encode" in history_route)
check("history:dao-filter", "(:vehicleId IS NULL OR operation.vehicleId = :vehicleId)" in maintenance_dao)
check("history:vm-filter", "loadHistoryPage(vehicleId" in history_vm)
check("vehicle:entry", "سجل صيانة السيارة" in vehicle_screen)
check("vehicle:navigation", "maintenanceHistoryRoute(vehicleId)" in app_nav)
check("history:no-verto-money", "if (source == OperationSource.VERTO) null" in history_vm)
check("details:no-verto-money", "if (details.showsFinancialValues)" in maintenance_content)
check("details:official-source", "officialRecord" in maintenance_repo and "observeBySourceInvoiceId" in maintenance_repo)

check("android:version-stable", "versionCode = 32" in app_build and 'versionName = "0.37.0-v37"' in app_build)
check("room:version-stable", "version = 3" in database)
check("backend:no-v63-migration", not any((ROOT / "supabase/migrations").glob("*v63*")))
for path in (
    "scripts/v63-invoice-vehicle-history-harness.py",
    "scripts/run-v63-source-syntax-check.sh",
    "scripts/verify-v63-static.sh",
    "docs/sessions/v63.md",
    "docs/verifications/verification-v63.md",
):
    check(f"delivery:{path}", (ROOT / path).is_file())

print(f"v63 invoice/vehicle history contract: {len(checks)}/{len(checks)} PASS")
