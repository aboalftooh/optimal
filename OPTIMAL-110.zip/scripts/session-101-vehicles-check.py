#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


base = "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation"
vehicles = read(f"{base}/VehiclesScreen.kt")
vehicle_components = read(f"{base}/VehiclesComponents.kt")
vehicles_route = read(f"{base}/VehiclesRoute.kt")
detail = read(f"{base}/VehicleDetailScreen.kt")
detail_components = read(f"{base}/VehicleDetailComponents.kt")
detail_dialogs = read(f"{base}/VehicleDetailDialogs.kt")
detail_route = read(f"{base}/VehicleDetailRoute.kt")
editor = read(f"{base}/VehicleEditorScreen.kt")
editor_components = read(f"{base}/VehicleEditorComponents.kt")
editor_dialogs = read(f"{base}/VehicleEditorDialogs.kt")
editor_route = read(f"{base}/VehicleEditorRoute.kt")

# SCR-009 + STA-013..016: searchable list and states.
check("VehiclesScreen exists", "internal fun VehiclesScreen(" in vehicles)
check("vehicles destination tag preserved", 'testTag("destination-vehicles")' in vehicles)
check("vehicles uses canonical search", "OptimalSearchField(" in vehicles)
check("vehicles search callback preserved", "VehiclesUiEvent.SearchChanged(it)" in vehicles)
check("vehicles clear-search callback preserved", "VehiclesUiEvent.ClearSearch" in vehicles)
check("vehicles uses canonical archived filter", "OptimalFilterChip(" in vehicles)
check("vehicles archived callback preserved", "VehiclesUiEvent.IncludeArchivedChanged(!state.includeArchived)" in vehicles)
check("vehicles loading uses canonical state", "state.isLoading -> OptimalLoadingState(" in vehicles)
check("vehicles error uses canonical state", "state.errorMessage != null -> OptimalErrorState(" in vehicles)
check("vehicles retry callback preserved", "VehiclesUiEvent.Retry" in vehicles)
check("vehicles empty uses canonical state", "state.vehicles.isEmpty() -> OptimalEmptyState(" in vehicles)
check("vehicles empty/no-results copy preserved", '"لا توجد سيارات"' in vehicles and '"لا توجد نتائج"' in vehicles)
check("vehicle rows use canonical list row", "OptimalListRow(" in vehicle_components)
check("vehicle selection callback preserved", "VehiclesUiEvent.VehicleSelected(vehicle.id)" in vehicles)
check("vehicles paging state preserved", "state.hasMore || state.isLoadingMore" in vehicles)
check("vehicles load-more callback preserved", "VehiclesUiEvent.LoadMore" in vehicles)
check("vehicles paging action canonical", "OptimalSecondaryButton(" in vehicles)
check("vehicles add action canonical", "OptimalPrimaryButton(" in vehicles)
check("vehicles add callback preserved", "VehiclesUiEvent.AddVehicle" in vehicles)
check("vehicles add tag preserved", 'testTag("add-vehicle")' in vehicles)

# SCR-010 + STA-017..019: details pattern.
check("VehicleDetailScreen exists", "internal fun VehicleDetailScreen(" in detail)
check("detail identity uses canonical hero", "OptimalHeroSurface(" in detail_components)
check("detail hero typography canonical", "OptimalTypographyRoles.heroTitle" in detail_components)
check("detail status canonical", "OptimalStatusBadge(" in detail_components)
check("detail preserves active/archived labels", '"مؤرشفة"' in detail_components and '"نشطة"' in detail_components)
check("detail grouped with canonical section headers", detail.count("OptimalSectionHeader(") >= 2)
check("detail facts use canonical rows", "OptimalListRow(" in detail_components)
check("detail maintenance callback preserved", "VehicleDetailUiEvent.OpenMaintenanceHistory" in detail)
check("detail activity callback preserved", "VehicleDetailUiEvent.OpenActivity" in detail)
check("detail edit callback preserved", "VehicleDetailUiEvent.Edit" in detail)
check("detail archive request preserved", "VehicleDetailUiEvent.RequestArchive" in detail)
check("detail error uses canonical semantic status", "OptimalInlineStatus(" in detail and "OptimalStatusTone.Danger" in detail)
check("detail error dismiss callback preserved", "VehicleDetailUiEvent.DismissMessage" in detail)
check("detail loading uses canonical state", "state.isLoading -> OptimalLoadingState" in detail_route)
check("detail missing vehicle uses canonical state", "state.vehicle == null -> OptimalEmptyState(" in detail_route)
check("detail missing copy preserved", 'title = "السيارة غير موجودة"' in detail_route)
check("detail route opens archive dialog", "ArchiveVehicleDialog(onEvent)" in detail_route)

# DLG-001 destructive confirmation.
check("archive dialog canonical", "OptimalConfirmationDialog(" in detail_dialogs)
check("archive confirmation destructive", "destructive = true" in detail_dialogs)
check("archive confirm callback preserved", "VehicleDetailUiEvent.ConfirmArchive" in detail_dialogs)
check("archive dismiss callback preserved", "VehicleDetailUiEvent.DismissArchiveConfirmation" in detail_dialogs)
check("archive confirm tag preserved", 'confirmTestTag = "confirm-archive-vehicle"' in detail_dialogs)

# SCR-011 + STA-020..021: one editor implementation, canonical form and persistent actions.
check("VehicleEditorScreen single implementation", editor.count("internal fun VehicleEditorScreen(") == 1)
check("editor distinguishes create/edit in one implementation", "state.isEditing" in editor and '"تعديل السيارة"' in editor and '"إضافة سيارة"' in editor)
check("editor uses canonical form sections", editor.count("OptimalFormSection(") == 3)
check("editor fields use canonical text field", "OptimalTextField(" in editor_components)
check("editor field error remains inline", "supportingText = errorText?.let" in editor_components)
check("editor preserves focus-on-validation behavior", "LaunchedEffect(state.fieldError)" in editor)
check("editor save message uses semantic status", "OptimalInlineStatus(" in editor and "OptimalStatusTone.Danger" in editor)
check("editor message dismiss callback preserved", "VehicleEditorUiEvent.DismissMessage" in editor)
check("editor uses persistent bottom action bar", "OptimalBottomActionBar(" in editor)
check("editor saving state preserved", "state.isSaving" in editor and "primaryEnabled = !state.isSaving" in editor)
check("editor save callback preserved", "VehicleEditorUiEvent.Save" in editor)
check("editor save tag preserved", 'testTag("save-vehicle")' in editor)
check("editor loading uses canonical state", "OptimalLoadingState(" in editor_route)
check("editor loading copy preserved", 'message = "جارٍ تحميل بيانات السيارة"' in editor_route)

# DLG-002 warning semantics + existing reason/confirm/correction behavior.
check("lower odometer dialog canonical", "OptimalDialog(" in editor_dialogs)
check("lower odometer uses warning icon", "Icons.Outlined.WarningAmber" in editor_dialogs)
check("lower odometer uses warning semantic status", "OptimalInlineStatus(" in editor_dialogs and "OptimalStatusTone.Warning" in editor_dialogs)
check("lower odometer reason field canonical", "OptimalTextField(" in editor_dialogs)
check("lower odometer reason callback preserved", "VehicleEditorUiEvent.LowerOdometerReasonChanged(it)" in editor_dialogs)
check("lower odometer confirm callback preserved", "VehicleEditorUiEvent.ConfirmLowerOdometer" in editor_dialogs)
check("lower odometer correction callback preserved", "VehicleEditorUiEvent.DismissLowerOdometerWarning" in editor_dialogs)
check("lower odometer confirm tag preserved", 'confirmTestTag = "confirm-lower-odometer"' in editor_dialogs)

# Connected effect/navigation callback mapping remains present.
for effect in ["OpenCreateVehicle", "OpenVehicle"]:
    check(f"vehicles effect mapping preserved: {effect}", f"VehiclesUiEffect.{effect}" in vehicles_route)
for effect in ["OpenEditor", "OpenActivity", "OpenMaintenanceHistory", "Archived"]:
    check(f"detail effect mapping preserved: {effect}", f"VehicleDetailUiEffect.{effect}" in detail_route)
check("editor saved effect mapping preserved", "VehicleEditorUiEffect.Saved" in editor_route)

# Migration ledger and allowlist.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(
    r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$",
    ledger,
    flags=re.M,
)
statuses = dict(rows)
expected_101 = {
    "SCR-009", "SCR-010", "SCR-011", "DLG-001", "DLG-002",
    *(f"STA-{i:03d}" for i in range(13, 22)),
}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check(
    "all SESSION-101 inventory migrated",
    all(statuses.get(i) == "MIGRATED" for i in expected_101),
    str(sorted(i for i in expected_101 if statuses.get(i) != "MIGRATED")),
)
check("ledger migrated total is 39", sum(status == "MIGRATED" for _, status in rows) == 39)
check("ledger unmigrated total is 84", sum(status == "UNMIGRATED" for _, status in rows) == 84)
check("ledger has no blocked rows", all(status != "BLOCKED" for _, status in rows))

allow = [
    line.strip()
    for line in read("scripts/design-system-migration-allowlist.txt").splitlines()
    if line.strip() and not line.lstrip().startswith("#")
]
check("Vehicles UI removed from allowlist", not any(path.startswith("feature/vehicles/") for path in allow))
check("remaining allowlist is 43 UI files", len(allow) == 43, str(len(allow)))

# No feature-local visual constitution drift in any Vehicle presentation Compose file.
vehicle_ui_files = []
for path in sorted((ROOT / base).glob("*.kt")):
    text = path.read_text(encoding="utf-8")
    if "@Composable" in text:
        vehicle_ui_files.append(path)
        rel = path.relative_to(ROOT).as_posix()
        check(f"{rel} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", text) is None)
        check(f"{rel} has no raw hex color", "Color(0x" not in text)
        check(f"{rel} has no local font family", "FontFamily(" not in text and "fontFamily =" not in text)
        check(f"{rel} has no direct Material text field", re.search(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(", text) is None)
        check(f"{rel} has no direct Material button", re.search(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(", text) is None)
check("Vehicles has 11 Compose presentation files", len(vehicle_ui_files) == 11, str(len(vehicle_ui_files)))

proc = subprocess.run(
    [sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")],
    cwd=ROOT,
    text=True,
    capture_output=True,
)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-101 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
