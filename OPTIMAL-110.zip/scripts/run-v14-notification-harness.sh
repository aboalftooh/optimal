#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$(mktemp -d)"
trap 'rm -rf "$OUT_DIR"' EXIT
kotlinc \
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationModels.kt" \
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationEventPolicy.kt" \
  "$ROOT_DIR/scripts/v14-notification-harness.kt" \
  -include-runtime \
  -d "$OUT_DIR/v14-notification-harness.jar"
java -jar "$OUT_DIR/v14-notification-harness.jar"
