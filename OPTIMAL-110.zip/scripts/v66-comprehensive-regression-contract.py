#!/usr/bin/env python3
"""Static contract for the v66 comprehensive regression gate and its integrations."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "v66-comprehensive-regression.py"


def load_runner():
    spec = importlib.util.spec_from_file_location("v66_regression_runner", RUNNER)
    if spec is None or spec.loader is None:
        raise RuntimeError("unable to load v66 runner")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def contains(path: str, token: str) -> bool:
    return token in (ROOT / path).read_text(encoding="utf-8")


def main() -> int:
    module = load_runner()
    shards = module.SHARDS
    checks: list[tuple[str, bool, str]] = []

    expected_shards = {"foundation", "legacy", "backend", "verto"}
    checks.append(("four named shards", set(shards) == expected_shards, repr(sorted(shards))))

    gates = [(shard, gate) for shard, values in shards.items() for gate in values]
    checks.append(("matrix has 63 gates", len(gates) == 63, f"count={len(gates)}"))
    checks.append(("foundation gate count", len(shards["foundation"]) == 7, f"count={len(shards['foundation'])}"))
    checks.append(("legacy gate count", len(shards["legacy"]) == 2, f"count={len(shards['legacy'])}"))
    checks.append(("backend gate count", len(shards["backend"]) == 10, f"count={len(shards['backend'])}"))
    checks.append(("verto gate count", len(shards["verto"]) == 44, f"count={len(shards['verto'])}"))

    labels = [gate.label for _, gate in gates]
    commands = [gate.command for _, gate in gates]
    checks.append(("labels are unique", len(labels) == len(set(labels)), "duplicate labels detected"))
    checks.append(("commands are unique", len(commands) == len(set(commands)), "duplicate commands detected"))

    for shard, gate in gates:
        command_path = gate.command[1] if gate.command[0] == "python3" else gate.command[0]
        resolved = ROOT / command_path.removeprefix("./")
        checks.append((f"command exists {shard}:{gate.label}", resolved.is_file(), command_path))
        if gate.command[0] != "python3":
            checks.append((f"shell command executable {shard}:{gate.label}", resolved.stat().st_mode & 0o111 != 0 if resolved.exists() else False, command_path))

    legacy_commands = {gate.command for gate in shards["legacy"]}
    checks.append(("v07-v26 compatibility suite restored", ("./scripts/run-v66-legacy-regressions.sh",) in legacy_commands, repr(legacy_commands)))
    legacy_wrapper = (ROOT / "scripts/run-v66-legacy-regressions.sh").read_text(encoding="utf-8")
    checks.append(("retired v10 harness excluded", "run-v10-linking-harness.sh" not in legacy_wrapper, "obsolete write-path harness must stay excluded"))
    checks.append(("v62 retirement contract substitutes v10", "v62-manual-invoice-link-retirement-contract.py" in legacy_wrapper, "current policy contract missing"))
    checks.append(("v62 retirement harness substitutes v10", "v62-manual-invoice-link-retirement-harness.py" in legacy_wrapper, "current policy harness missing"))
    checks.append(("v28-v37 compatibility suite retained", ("./scripts/run-v66-v28-v37-regressions.sh",) in legacy_commands, repr(legacy_commands)))
    v37_wrapper = (ROOT / "scripts/run-v66-v28-v37-regressions.sh").read_text(encoding="utf-8")
    checks.append(("stale v35 literal snapshot excluded", "v35-ui-parity-contract.py" not in v37_wrapper, "exact v34 literal snapshot must stay informational"))
    checks.append(("current v37 static gate substitutes v35", "static-v37-check.py" in v37_wrapper, "current static gate missing"))

    for version in range(39, 66):
        token = f"v{version}"
        checks.append((f"coverage marker {token}", any(token in gate.label or any(token in part for part in gate.command) for _, gate in gates), token))

    required_files = [
        "config/v66-test-baseline.txt",
        "scripts/v66-test-inventory-contract.py",
        "scripts/v66-comprehensive-regression.py",
        "scripts/run-v66-legacy-regressions.sh",
        "scripts/run-v66-v28-v37-regressions.sh",
        "scripts/verify-v66-static.sh",
        "docs/sessions/v66.md",
        "docs/comprehensive-regression-v66.md",
    ]
    for path in required_files:
        checks.append((f"required file {path}", (ROOT / path).is_file(), path))

    wrapper = (ROOT / "scripts/verify-v66-static.sh").read_text(encoding="utf-8")
    checks.append(("wrapper starts with v66 contract", "python3 scripts/v66-comprehensive-regression-contract.py" in wrapper, "contract invocation missing"))
    for shard in ("foundation", "backend", "verto", "legacy"):
        checks.append((f"wrapper runs {shard}", f"--shard {shard}" in wrapper, shard))
    checks.append(("wrapper compiles Python", "python3 -m py_compile" in wrapper, "py_compile missing"))
    checks.append(("wrapper validates Bash", "bash -n scripts/verify-v66-static.sh" in wrapper, "bash -n missing"))

    checks.append(("Gradle inventory task", contains("build.gradle.kts", 'name = "v66TestInventoryCheck"'), "task missing"))
    checks.append(("Gradle contract task", contains("build.gradle.kts", 'name = "v66ComprehensiveRegressionContractCheck"'), "task missing"))
    checks.append(("Gradle full matrix task", contains("build.gradle.kts", 'tasks.register<Exec>("comprehensiveRegressionCheck")'), "task missing"))
    checks.append(("staticQuality includes inventory", contains("build.gradle.kts", "v66TestInventoryCheck,"), "dependency missing"))
    checks.append(("staticQuality includes contract", contains("build.gradle.kts", "v66ComprehensiveRegressionContractCheck,"), "dependency missing"))

    checks.append(("ci-fast uses runner", contains("scripts/ci-fast.sh", "scripts/v66-comprehensive-regression.py"), "runner missing"))
    checks.append(("ci-fast excludes legacy", "--shard legacy" not in (ROOT / "scripts/ci-fast.sh").read_text(encoding="utf-8"), "legacy should stay out of fast CI"))
    checks.append(("ci-full uses full wrapper", contains("scripts/ci-full.sh", "./scripts/verify-v66-static.sh"), "wrapper missing"))
    checks.append(("verify-project static uses full wrapper", contains("scripts/verify-project.sh", "./scripts/verify-v66-static.sh"), "wrapper missing"))

    checks.append(("plan records v66", contains("docs/implementation-plan.md", "## حالة التنفيذ بعد v66"), "plan missing"))
    checks.append(("changelog records v66", contains("docs/implementation-changelog.md", "## v66 — بوابة عدم التراجع الشاملة"), "changelog missing"))
    checks.append(("AGENTS stage updated", contains("AGENTS.md", "V66_COMPREHENSIVE_REGRESSION_GATE_IMPLEMENTED"), "stage missing"))

    # The local matrix must not silently execute environment-dependent or destructive gates.
    runner_text = RUNNER.read_text(encoding="utf-8")
    checks.append(("live database harness excluded", "v65-live-rls-isolation-harness.py" not in runner_text, "live harness must remain explicit"))
    checks.append(("Gradle excluded from local matrix", "./gradlew" not in runner_text, "Gradle belongs to CI external gate"))
    checks.append(("no shell=True", "shell=True" not in runner_text, "unsafe subprocess usage"))
    checks.append(("reports omit command output", '"output"' not in runner_text and "stdout" not in (runner_text[runner_text.find('summary = {'):]), "report may persist output"))

    failures = 0
    for name, ok, detail in checks:
        if ok:
            print(f"PASS: {name}")
        else:
            failures += 1
            print(f"FAIL: {name} ({detail})")

    print(f"V66 comprehensive regression contract: {len(checks)-failures}/{len(checks)} PASS")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
