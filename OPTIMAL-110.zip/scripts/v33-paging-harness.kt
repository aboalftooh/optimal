import com.optimal.fleet.core.model.paging.PageRequest
import com.optimal.fleet.core.model.paging.PageSlice
import com.optimal.fleet.core.model.paging.toPageSlice

private var checks = 0
private fun checkCase(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

fun main() {
    val request = PageRequest(offset = 40, limit = 40)
    checkCase("request keeps offset", request.offset == 40)
    checkCase("request keeps limit", request.limit == 40)
    checkCase("lookahead reports more", (1..41).toList().toPageSlice(40).hasMore)
    checkCase("lookahead trims extra row", (1..41).toList().toPageSlice(40).items.size == 40)
    checkCase("last page reports complete", !(1..12).toList().toPageSlice(40).hasMore)
    checkCase("page mapping preserves hasMore", PageSlice(listOf(1), true).map(Int::toString).hasMore)
    checkCase("empty page is stable", PageSlice.empty<Int>().items.isEmpty())
    checkCase("negative offset rejected", runCatching { PageRequest(-1, 10) }.isFailure)
    checkCase("zero limit rejected", runCatching { PageRequest(0, 0) }.isFailure)
    checkCase("oversized limit rejected", runCatching { PageRequest(0, 101) }.isFailure)
    println("RESULT: $checks/$checks")
}
