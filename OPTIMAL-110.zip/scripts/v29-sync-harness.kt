package v29harness

import com.optimal.fleet.coordinator.sync.DescriptionConflictResolver
import com.optimal.fleet.coordinator.sync.SyncBatchReporter
import com.optimal.fleet.coordinator.sync.SyncConflictCoordinator
import com.optimal.fleet.coordinator.sync.SyncBatchClaimer
import com.optimal.fleet.coordinator.sync.SyncLeaseRecoveryCoordinator
import com.optimal.fleet.coordinator.sync.SyncManager
import com.optimal.fleet.coordinator.sync.SyncOperationDispatcher
import com.optimal.fleet.coordinator.sync.SyncParticipant
import com.optimal.fleet.coordinator.sync.SyncQueuePort
import com.optimal.fleet.coordinator.sync.SyncRetryPolicy
import com.optimal.fleet.core.database.sync.PendingSyncOperationEntity
import com.optimal.fleet.core.database.sync.SyncConflictAuditEntity
import com.optimal.fleet.core.database.sync.SyncQueueState
import com.optimal.fleet.core.model.audit.AuditEventDraft
import com.optimal.fleet.core.model.audit.AuditPort
import com.optimal.fleet.core.network.sync.SyncPushResult
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var passed = 0
private var failed = 0

private fun verify(name: String, condition: Boolean) {
    if (condition) {
        passed++
        println("PASS: $name")
    } else {
        failed++
        println("FAIL: $name")
    }
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var result: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(value: Result<T>) { result = value }
    })
    return result!!.getOrThrow()
}

private val fixedClock = Clock.fixed(Instant.ofEpochMilli(1_000), ZoneOffset.UTC)

private fun operation(
    id: String,
    companyId: String,
    payload: String = "local",
    attemptCount: Int = 0,
) = PendingSyncOperationEntity(
    id = id,
    companyId = companyId,
    aggregateType = "VEHICLE",
    aggregateId = "vehicle-$id",
    operationType = "UPSERT",
    payload = payload,
    idempotencyKey = "VEHICLE:vehicle-$id:UPSERT:10",
    localVersion = 10,
    state = SyncQueueState.PENDING,
    attemptCount = attemptCount,
    nextAttemptAtEpochMillis = 0,
    leaseUntilEpochMillis = null,
    leaseToken = null,
    lastErrorCode = null,
    remoteId = null,
    remoteVersion = null,
    createdAtEpochMillis = 10,
    updatedAtEpochMillis = 10,
)

private class RecordingAudit : AuditPort {
    val events = mutableListOf<AuditEventDraft>()
    override suspend fun append(event: AuditEventDraft) { events += event }
}

private class FakeQueue(
    private val operations: List<PendingSyncOperationEntity>,
    private val expired: List<PendingSyncOperationEntity> = emptyList(),
) : SyncQueuePort {
    val successes = mutableListOf<String>()
    val retries = mutableListOf<String>()
    val permanent = mutableListOf<String>()
    val conflicts = mutableListOf<SyncConflictAuditEntity>()
    var recovered = 0

    override suspend fun findExpiredLeasesForSystem(now: Long, limit: Int) = expired.take(limit)

    override suspend fun claimDueBatchForSystem(
        now: Long,
        leaseDurationMillis: Long,
        limit: Int,
        leaseToken: String,
    ) = operations.take(limit).map {
        it.copy(
            state = SyncQueueState.RUNNING,
            leaseUntilEpochMillis = now + leaseDurationMillis,
            leaseToken = leaseToken,
        )
    }

    override suspend fun markSucceeded(
        companyId: String,
        operationId: String,
        leaseToken: String,
        remoteId: String?,
        remoteVersion: Long?,
        now: Long,
    ): Int {
        if (operationId == "stale") return 0
        successes += operationId
        return 1
    }

    override suspend fun markRetry(
        companyId: String,
        operationId: String,
        leaseToken: String,
        nextAttemptAt: Long,
        code: String,
        now: Long,
    ): Int {
        retries += operationId
        return 1
    }

    override suspend fun markPermanentFailure(
        companyId: String,
        operationId: String,
        leaseToken: String,
        code: String,
        now: Long,
    ): Int {
        permanent += operationId
        return 1
    }

    override suspend fun recoverExpiredLeaseAsRetry(
        operation: PendingSyncOperationEntity,
        nextAttemptAt: Long,
        code: String,
        now: Long,
    ): Int { recovered++; return 1 }

    override suspend fun recoverExpiredLeaseAsPermanentFailure(
        operation: PendingSyncOperationEntity,
        code: String,
        now: Long,
    ): Int { permanent += operation.id; return 1 }

    override suspend fun recordConflictIfLeaseOwned(
        audit: SyncConflictAuditEntity,
        leaseToken: String,
        now: Long,
    ): Boolean {
        conflicts += audit
        return true
    }
}

private class FakeParticipant : SyncParticipant {
    var resolves = 0
    override fun supports(operation: PendingSyncOperationEntity) = true

    override suspend fun push(operation: PendingSyncOperationEntity): SyncPushResult = when (operation.id) {
        "retry" -> SyncPushResult.RetryableFailure("NETWORK_ERROR")
        "permanent" -> SyncPushResult.PermanentFailure("INVALID_PAYLOAD")
        "duplicate" -> SyncPushResult.Conflict(
            remoteVersion = operation.localVersion,
            remotePayload = operation.payload,
            remoteIdempotencyKey = operation.idempotencyKey,
            remoteId = "remote-duplicate",
        )
        else -> SyncPushResult.Success("remote-${operation.id}", operation.localVersion)
    }

    override suspend fun resolveConflict(
        operation: PendingSyncOperationEntity,
        winningPayload: String,
        winningVersion: Long,
    ): SyncPushResult {
        resolves++
        return SyncPushResult.Success("remote-${operation.id}", winningVersion)
    }
}

private fun manager(queue: FakeQueue, participant: FakeParticipant, audit: RecordingAudit): SyncManager {
    val retry = SyncRetryPolicy()
    val dispatcher = SyncOperationDispatcher(setOf(participant))
    return SyncManager(
        queueStore = queue,
        leaseRecoveryCoordinator = SyncLeaseRecoveryCoordinator(queue, retry, fixedClock),
        batchClaimer = SyncBatchClaimer(queue, fixedClock),
        dispatcher = dispatcher,
        conflictCoordinator = SyncConflictCoordinator(
            queueStore = queue,
            resolver = DescriptionConflictResolver(),
            dispatcher = dispatcher,
            clock = fixedClock,
            auditPort = audit,
        ),
        reporter = SyncBatchReporter(fixedClock, audit),
        retryPolicy = retry,
        clock = fixedClock,
    )
}

fun main() {
    val retry = SyncRetryPolicy()
    verify("retry starts at 30 seconds", retry.nextDelayMillis(0) == 30_000L)
    verify("retry doubles", retry.nextDelayMillis(2) == 120_000L)
    verify("retry stops at maximum", retry.shouldStopAfter(SyncRetryPolicy.MAX_ATTEMPTS))
    verify("worker backoff shares retry base", SyncRetryPolicy.WORKER_BACKOFF_SECONDS == 30L)

    val resolver = DescriptionConflictResolver()
    val idempotent = resolver.resolve("same", 2, 10, "key", "same", 2, 20, "key")
    verify("idempotent replay avoids remote rewrite", !idempotent.requiresRemoteWrite && idempotent.resolution == DescriptionConflictResolver.IDEMPOTENT_REPLAY)
    val versionWinner = resolver.resolve("local", 3, 10, "local-key", "remote", 2, 20, "remote-key")
    verify("higher version wins", versionWinner.winningPayload == "local" && versionWinner.resolution == "LOCAL_WINS_VERSION")
    val timeWinner = resolver.resolve("local", 2, 30, "local-key", "remote", 2, 20, "remote-key")
    verify("newer timestamp breaks equal-version conflict", timeWinner.winningPayload == "local" && timeWinner.resolution == "LOCAL_WINS_TIMESTAMP")

    val queue = FakeQueue(
        listOf(
            operation("success", "company-a"),
            operation("retry", "company-b"),
            operation("permanent", "company-b"),
            operation("duplicate", "company-a", payload = "same"),
            operation("stale", "company-a"),
        ),
    )
    val participant = FakeParticipant()
    val audit = RecordingAudit()
    val result = runSuspend { manager(queue, participant, audit).runBatch() }

    verify("batch counts both companies", result.companies.keys == setOf("company-a", "company-b"))
    verify("company A report is isolated", result.companies.getValue("company-a").claimed == 3 && result.companies.getValue("company-a").succeeded == 2)
    verify("company B report is isolated", result.companies.getValue("company-b").claimed == 2 && result.companies.getValue("company-b").retryScheduled == 1 && result.companies.getValue("company-b").permanentFailures == 1)
    verify("partial success remains resumable", result.succeeded == 2 && result.retryScheduled == 1 && result.permanentFailures == 1)
    verify("stale lease cannot finalize", result.leaseLost == 1 && "stale" !in queue.successes)
    verify("duplicate response is not resolved remotely", participant.resolves == 0)
    verify("conflict audit is deterministic and recorded", queue.conflicts.size == 1)
    verify("batch audit has one report per company", audit.events.count { it.action.name == "SYNC_BATCH_COMPLETED" } == 2)

    val expired = operation("dead", "company-a", attemptCount = 2).copy(
        state = SyncQueueState.RUNNING,
        leaseUntilEpochMillis = 999,
        leaseToken = "dead-worker",
    )
    val recoveryQueue = FakeQueue(emptyList(), listOf(expired))
    val recovery = runSuspend { SyncLeaseRecoveryCoordinator(recoveryQueue, retry, fixedClock).recoverExpiredLeases() }
    verify("expired lease is recovered", recovery.retryScheduled == 1 && recoveryQueue.recovered == 1)

    println("V29 sync Kotlin harness: $passed/${passed + failed}")
    if (failed != 0) error("v29 sync harness failed")
}
