#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
OUT="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessageCursor.kt \
  feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoArchiveState.kt \
  feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationModels.kt \
  feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationEventPolicy.kt \
  scripts/v58-verto-daily-cycle-harness.kt \
  -include-runtime -d "$OUT"
java -jar "$OUT"
