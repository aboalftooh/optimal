#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
python3 scripts/static-architecture-check.py
python3 scripts/static-v33-check.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
./scripts/run-v33-paging-harness.sh
python3 scripts/v33-paging-contract.py
python3 scripts/v33-room-query-contract.py
./scripts/run-v33-domain-compile.sh
./scripts/run-v33-presentation-compile.sh
