#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_FILE="$(mktemp)"
OUT_FILE="$(mktemp --suffix=.jar)"
trap 'rm -f "$LOG_FILE" "$OUT_FILE"' EXIT
set +e
kotlinc \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListRoute.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryRoute.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt" \
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt" \
  -d "$OUT_FILE" >"$LOG_FILE" 2>&1
set -e
if grep -Eiq 'expecting|unexpected tokens|syntax error' "$LOG_FILE"; then
  cat "$LOG_FILE"
  echo "FAIL: Kotlin parser error in paged routes" >&2
  exit 1
fi
echo "PASS: VehiclesRoute parser"
echo "PASS: MaintenanceListRoute parser"
echo "PASS: MaintenanceHistoryRoute parser"
echo "PASS: InvoiceListRoute parser"
echo "PASS: NotificationsRoute parser"
echo "PASS: ActivityRoute parser"
echo "V33 route parser checks: 6/6"
