#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=''):
    checks.append((name, bool(condition), detail))

required = [
    'core/database/src/main/java/com/optimal/fleet/core/database/entity/MaintenanceOperationEntity.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceDao.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceVehicleOptionRow.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperation.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationDraft.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationType.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/OperationStatus.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/OperationSource.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationValidation.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MoneyInputParser.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceOperationRepository.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/CreateMaintenanceOperation.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/CalculateOperationTotal.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/ObserveOperationVehicleOptions.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceMappers.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceIdentityFactory.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/di/MaintenanceDataModule.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create/CreateOperationContract.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create/CreateOperationViewModel.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create/CreateOperationRoute.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt',
]
for rel in required:
    check(f'required {rel}', (ROOT / rel).is_file())

entity = (ROOT / required[0]).read_text(encoding='utf-8')
dao = (ROOT / required[1]).read_text(encoding='utf-8')
model = (ROOT / required[3]).read_text(encoding='utf-8')
draft = (ROOT / required[4]).read_text(encoding='utf-8')
status = (ROOT / required[6]).read_text(encoding='utf-8')
validation = (ROOT / required[8]).read_text(encoding='utf-8')
parser = (ROOT / required[9]).read_text(encoding='utf-8')
create_uc = (ROOT / required[11]).read_text(encoding='utf-8')
total_uc = (ROOT / required[12]).read_text(encoding='utf-8')
repo = '\n'.join((ROOT / f'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/{part}.kt').read_text(encoding='utf-8') for part in ['RoomMaintenanceCreateRepository', 'RoomMaintenanceEditRepository', 'RoomMaintenanceCompleteRepository', 'RoomMaintenanceFollowUpRepository'])
contract = (ROOT / required[18]).read_text(encoding='utf-8')
viewmodel = (ROOT / required[19]).read_text(encoding='utf-8')
route = (ROOT / required[20]).read_text(encoding='utf-8')
nav = (ROOT / required[21]).read_text(encoding='utf-8')
migration = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt').read_text(encoding='utf-8')
database = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt').read_text(encoding='utf-8')
db_module = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt').read_text(encoding='utf-8')

for field in [
    'id','companyId','vehicleId','remoteId','clientGeneratedId','type','description','status',
    'startedAtEpochMillis','completedAtEpochMillis','odometerKm','partsCostMinor',
    'serviceCostMinor','source','createdByUserId','updatedByUserId','createdAtEpochMillis',
    'updatedAtEpochMillis','syncState',
]:
    check(f'entity field {field}', f'val {field}:' in entity)

check('operation company foreign key', 'entity = CompanyEntity::class' in entity)
check('operation vehicle composite foreign key', 'entity = VehicleEntity::class' in entity and 'childColumns = ["vehicleId", "companyId"]' in entity)
check('operation creator composite foreign key', 'childColumns = ["createdByUserId", "companyId"]' in entity)
check('operation updater composite foreign key', 'childColumns = ["updatedByUserId", "companyId"]' in entity)
check('operation deletes restricted', entity.count('onDelete = ForeignKey.RESTRICT') == 4)
check('client generated id unique', 'Index(value = ["clientGeneratedId"], unique = true)' in entity)
check('remote id unique', 'Index(value = ["remoteId"], unique = true)' in entity)
check('status and sync indexed separately', '["companyId", "status", "updatedAtEpochMillis"]' in entity and '["companyId", "syncState"]' in entity)

check('DAO vehicle options company scoped', 'WHERE companyId = :companyId' in dao)
check('DAO excludes archived vehicles', 'archivedAtEpochMillis IS NULL' in dao)
check('DAO operation lookup company scoped', 'companyId = :companyId AND id = :operationId' in dao)
check('DAO client id lookup company scoped', 'companyId = :companyId AND clientGeneratedId = :clientGeneratedId' in dao)
check('DAO insert aborts on conflict', '@Insert(onConflict = OnConflictStrategy.ABORT)' in dao)
check('DAO exposes no delete', '@Delete' not in dao and not re.search(r'fun\s+delete', dao))

for field in ['vehicleId','type','description','status','startedAtEpochMillis','odometerKm','partsCostMinor','serviceCostMinor','source','createdByUserId','updatedByUserId']:
    check(f'domain model field {field}', f'val {field}:' in model)
check('draft has exactly required business inputs', all(x in draft for x in ['vehicleId', 'type', 'description']))
check('draft has no status', 'status' not in draft)
check('draft costs default zero', 'partsCostMinor: Long = 0' in draft and 'serviceCostMinor: Long = 0' in draft)
check('only two statuses', 'IN_PROGRESS' in status and 'COMPLETED' in status and all(x not in status for x in ['PENDING','DRAFT','CANCELLED','REJECTED']))
check('operation types are two', all(x in (ROOT / required[5]).read_text(encoding='utf-8') for x in ['PARTS_ONLY','FULL_MAINTENANCE']))
check('manual and Verto sources modeled', all(x in (ROOT / required[7]).read_text(encoding='utf-8') for x in ['MANUAL','VERTO']))

check('vehicle required validation', 'MissingVehicle' in validation and 'draft.vehicleId.isBlank()' in validation)
check('type required validation', 'MissingType' in validation and 'draft.type == null' in validation)
check('description required validation', 'MissingDescription' in validation and 'draft.description.isBlank()' in validation)
check('negative odometer blocked', 'InvalidOdometer' in validation and 'draft.odometerKm < 0' in validation)
check('negative costs blocked', all(x in validation for x in ['InvalidPartsCost','InvalidServiceCost']))
check('description trimmed', 'description = draft.description.trim()' in validation)

check('money parser uses BigDecimal', 'BigDecimal' in parser)
check('money parser avoids Double', 'Double' not in parser and 'Float' not in parser)
check('money parser supports Arabic decimal separator', '"٫"' in parser)
check('money parser supports Arabic digits', "'١'" in parser and "'٩'" in parser)
check('money parser limits scale', 'MINOR_DIGITS = 2' in parser and 'value.scale() > MINOR_DIGITS' in parser)
check('total uses exact addition', 'Math.addExact' in total_uc)
check('total rejects negative amounts', total_uc.count('require(') >= 2)

check('create gets session', 'sessionReader.currentSession()' in create_uc)
check('create gets company from session', 'companyId = session.companyId' in create_uc)
check('create gets actor from session', 'actorUserId = session.userId' in create_uc)
check('create validates before repository', 'MaintenanceOperationValidator.validate' in create_uc)
check('repository verifies vehicle in company', 'vehicleDao.findById(companyId, draft.vehicleId)' in repo)
check('repository rejects archived vehicle', 'vehicle.archivedAtEpochMillis != null' in repo)
check('repository always creates in progress', 'status = OperationStatus.IN_PROGRESS.name' in repo)
check('repository always creates manual source', 'source = OperationSource.MANUAL.name' in repo)
check('repository stores sync pending separately', 'syncState = DatabaseConstants.SYNC_PENDING' in repo)
check('repository stores client generated id', 'clientGeneratedId = identityFactory.newId()' in repo)
check('repository maps Room to domain', 'entity.toDomain()' in repo)

check('UI state has no sync state', 'syncState' not in contract and 'syncStatus' not in contract)
check('UI type starts unselected', 'type: MaintenanceOperationType? = null' in contract)
check('UI has required vehicle selection', 'selectedVehicleId' in contract)
check('UI has free description', 'description: String' in contract)
check('viewmodel caps description', 'take(2_000)' in viewmodel)
check('viewmodel parses money via domain parser', 'MoneyInputParser.parseMinorUnits' in viewmodel)
check('viewmodel creates draft', 'MaintenanceOperationDraft(' in viewmodel)
check('viewmodel has no DAO or entity', all(x not in viewmodel for x in ['MaintenanceDao','MaintenanceOperationEntity','VehicleDao']))
check('route shows free text example', 'ظهر صوت في العجلة الأمامية' in route)
check('route shows two operation types', 'قطع فقط' in route and 'صيانة كاملة' in route)
check('route saves as in progress', 'حفظ كجاري المعالجة' in route)
check('route does not expose save-and-complete', 'حفظ وإكمال' not in route)
check('route does not expose sync state', all(x not in route for x in ['PENDING','SYNC_PENDING','syncState']))
check('route uses SDG label', 'ج.س' in route)
check('offline copy exists', 'سيُحفظ على الهاتف فورًا' in route)

check('maintenance create route exists', 'MAINTENANCE_CREATE_ROUTE' in nav)
check('app owns navigation callback', 'onAddOperation' in nav and 'onOperationSaved' in nav)
check('database version at least 3', bool(re.search(r'version\s*=\s*([3-9]|[1-9][0-9]+)', database)))
check('database registers operation entity', 'MaintenanceOperationEntity::class' in database)
check('database exposes maintenance DAO', 'abstract fun maintenanceDao(): MaintenanceDao' in database)
check('migration 2 to 3', 'MIGRATION_2_3' in migration and 'Migration(2, 3)' in migration)
check('migration creates operation table', 'CREATE TABLE IF NOT EXISTS `maintenance_operations`' in migration)
check('migration keeps prior migration', all(token in migration for token in ['MIGRATION_1_2', 'MIGRATION_2_3']))
check('database module provides DAO', 'provideMaintenanceDao' in db_module)
check('no destructive migration', not any(
    'fallbackToDestructiveMigration' in p.read_text(encoding='utf-8')
    for p in ROOT.rglob('*.kt')
    if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix()
))

feature_root = ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance'
domain_files = list((feature_root / 'domain').rglob('*.kt'))
presentation_files = list((feature_root / 'presentation').rglob('*.kt'))
check('maintenance domain exists', bool(domain_files))
check('maintenance presentation exists', bool(presentation_files))
forbidden_domain=[]
for p in domain_files:
    text=p.read_text(encoding='utf-8')
    if re.search(r'^import (android\.|androidx\.room|retrofit2\.|com\.optimal\.fleet\.core\.database)', text, re.M):
        forbidden_domain.append(str(p.relative_to(ROOT)))
check('maintenance domain pure Kotlin', not forbidden_domain, ', '.join(forbidden_domain))
forbidden_presentation=[]
for p in presentation_files:
    text=p.read_text(encoding='utf-8')
    if re.search(r'^import .*\.(data|dao)\.', text, re.M) or re.search(r'^import .*core\.database', text, re.M):
        forbidden_presentation.append(str(p.relative_to(ROOT)))
check('presentation does not import data/database', not forbidden_presentation, ', '.join(forbidden_presentation))
check('UI does not accept companyId', 'companyId' not in '\n'.join(p.read_text(encoding='utf-8') for p in presentation_files))
check('maintenance has no feature-to-feature imports', not any(
    re.search(r'import com\.optimal\.fleet\.feature\.(?!maintenance\.)', p.read_text(encoding='utf-8'))
    for p in feature_root.rglob('*.kt')
))
build=(ROOT/'feature/maintenance/build.gradle.kts').read_text(encoding='utf-8')
check('maintenance depends on database', 'project(":core:database")' in build)
check('maintenance depends on session', 'project(":core:session")' in build)
check('maintenance does not depend on vehicles feature', 'project(":feature:vehicles")' not in build)
check('maintenance has Hilt', 'libs.plugins.hilt' in build and 'libs.hilt.android' in build)
check('maintenance has no backend SDK', all(x not in build.lower() for x in ['retrofit','supabase','firebase']))

required_tests = [
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/model/OperationStatusTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/OperationTotalTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/CreateMaintenanceOperationTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/presentation/CreateOperationViewModelTest.kt',
    'core/database/src/androidTest/java/com/optimal/fleet/core/database/MaintenanceDaoTest.kt',
    'feature/maintenance/src/androidTest/java/com/optimal/fleet/feature/maintenance/presentation/OfflineCreateUiTest.kt',
    'app/src/test/java/com/optimal/fleet/MaintenanceArchitectureTest.kt',
]
for rel in required_tests:
    check(f'test {rel}', (ROOT / rel).is_file())

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f' — {detail}' if detail and not passed else ''))
passed=sum(1 for _,ok,_ in checks if ok)
print(f'\nV05 static checks: {passed}/{len(checks)}')
sys.exit(0 if passed==len(checks) else 1)
