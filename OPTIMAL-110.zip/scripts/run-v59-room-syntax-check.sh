#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/DatabaseConstants.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/migration/OptimalDatabaseMigrations.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/migration/VertoRoomV3Schema.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceProjectionEntity.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/entity/verto/VertoInvoiceItemEntity.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/entity/verto/VertoMaintenanceProjectionEntity.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/entity/verto/VertoMaintenanceMediaEntity.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoInvoiceItemDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceProjectionDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceMediaDao.kt"
  "$ROOT_DIR/core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV3MigrationTest.kt"
  "$ROOT_DIR/core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV3ProcessRecreationTest.kt"
  "$ROOT_DIR/core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV2ProcessRecreationTest.kt"
  "$ROOT_DIR/core/database/src/androidTest/java/com/optimal/fleet/core/database/FreshDatabaseSchemaTest.kt"
  "$ROOT_DIR/core/database/src/androidTest/java/com/optimal/fleet/core/database/PublishedSchemaContractTest.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/VehicleArchitectureTest.kt"
)
for file in "${FILES[@]}"; do
  [[ -f "$file" ]] || { echo "FAIL: missing v59 Kotlin source: $file" >&2; exit 1; }
done
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: v59 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v59 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} v59 production/test files; unresolved Android symbols were intentionally ignored without Gradle classpath."
