#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs"/{javax/inject,org/junit,androidx/compose/runtime,kotlinx/coroutines/test,com/optimal/fleet/feature/maintenance/presentation/list}
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
KT
cat > "$TMP_DIR/stubs/org/junit/Junit.kt" <<'KT'
package org.junit
@Target(AnnotationTarget.FUNCTION) annotation class Test
object Assert {
    fun assertEquals(expected: Any?, actual: Any?) = Unit
    fun assertTrue(value: Boolean) = Unit
    fun assertFalse(value: Boolean) = Unit
}
KT
cat > "$TMP_DIR/stubs/kotlinx/coroutines/test/RunTest.kt" <<'KT'
package kotlinx.coroutines.test
import kotlinx.coroutines.runBlocking
fun runTest(block: suspend () -> Unit) { runBlocking { block() } }
KT
cat > "$TMP_DIR/stubs/androidx/compose/runtime/Immutable.kt" <<'KT'
package androidx.compose.runtime
@Target(AnnotationTarget.CLASS) annotation class Immutable
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/presentation/list/Format.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.presentation.list
internal fun formatMoney(minorUnits: Long): String = minorUnits.toString()
KT
mapfile -t DOMAIN_FILES < <(find "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain" -type f -name '*.kt' | sort)
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  $(find "$TMP_DIR/stubs" -type f -name '*.kt' | sort) \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionIdentity.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "${DOMAIN_FILES[@]}" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsUiMapper.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsStateReducer.kt" \
  "$ROOT_DIR/feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/PrepareMaintenanceEditTest.kt" \
  "$ROOT_DIR/feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/PrepareMaintenanceCompletionTest.kt" \
  "$ROOT_DIR/feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/complete/CompleteOperationTest.kt" \
  "$ROOT_DIR/feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/complete/CompletionIdempotencyTest.kt" \
  "$ROOT_DIR/feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsStateReducerTest.kt" \
  -d "$TMP_DIR/v34-maintenance-tests.jar"
echo "PASS: new maintenance use-case and reducer tests compile"
echo "V34 focused test compilation: 5/5 files"
