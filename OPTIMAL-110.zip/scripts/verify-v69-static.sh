#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v68_optimal_contract_checks.py
python3 scripts/v69-phone-first-registration-contract.py
python3 -m py_compile scripts/v68_optimal_contract_checks.py scripts/v69-phone-first-registration-contract.py
bash -n scripts/verify-v69-static.sh
