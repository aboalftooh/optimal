#!/usr/bin/env python3
"""Verifies the v35 split retained the v34 UI literal/test-tag contract.

The expected digests were generated from the source-of-truth v34 route/design-system
files before they were split. The digest is over a sorted multiset of Kotlin string
literals, so moving code between files does not change the result.
"""
from __future__ import annotations

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
STRING = re.compile(r'"(?:\\.|[^"\\])*"')

GROUPS = {
    "auth": [
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthScreenContent.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthAccountContent.kt",
    ],
    "home": [
        "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt",
        "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt",
    ],
    "finance-dashboard": [
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardRoute.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreen.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/AddCostDialog.kt",
    ],
    "invoice-list": [
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListComponents.kt",
    ],
    "invoice-details": [
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt",
        "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt",
    ],
    "vehicles": [
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesScreen.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesComponents.kt",
    ],
    "vehicle-editor": [
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorRoute.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorScreen.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorComponents.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorDialogs.kt",
    ],
    "vehicle-detail": [
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailComponents.kt",
        "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailDialogs.kt",
    ],
    "settings": [
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsRoute.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsScreen.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsComponents.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsContract.kt",
    ],
    "members": [
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersRoute.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreen.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersDialogs.kt",
    ],
    "activity": [
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityScreen.kt",
        "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityComponents.kt",
    ],
    "notifications": [
        "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt",
        "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreen.kt",
        "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsComponents.kt",
    ],
    "designsystem": [
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalHeader.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalButtons.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalCards.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalFields.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalDialogs.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalNavigation.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalSegments.kt",
        "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalEmptyCards.kt",
    ],
}

EXPECTED = {
    "auth": ("0a69cfb21f1738634a0732dd395e436599c9885496d5f4e79706f065a26f1690", 80),
    "home": ("c174f7efaaa4af0e3d3962e33ad05f676b42ead0d8e200bd4bc0013fc67f4e35", 23),
    "finance-dashboard": ("b6868fe9101226f1deebcf3e573f1c73e4374760f276ea18126deaa255fa58ea", 47),
    "invoice-list": ("3d6fe973aa6c675703f61af6758a77627d4e2b82fd5863d98099bff807cb0c3f", 29),
    "invoice-details": ("9fbf87cb597b7a2d73f3b37caa9bae7e4b28e2e89f33f52494a0b26959ab6e1a", 35),
    "vehicles": ("f5a8e79d395da209065d4c0df30a2afbc0cea268cf02b5474bef27799bcca12c", 19),
    "vehicle-editor": ("634ebf0bdba69e3c294f617a024741e98f2f4c8381c6f42188bf38f9dea9f413", 28),
    "vehicle-detail": ("446426b2cf2ca7aeab194de7be28fd2ab68e6851f4b40411f7bf2478d27f9cf0", 23),
    "settings": ("e9fbb91fa01060a7712ffc7088d0268c543a3dbd92b4bfeae3d50430f6fd1cfc", 18),
    "members": ("e9625c7696772866434fb5841847e712baa8af1c15ecffc15a9ebcfa1ffcf985", 29),
    "activity": ("cd52d01dbe56d8e7078d75b685b3d4894321e9804517e3f1416725f9506b4e73", 15),
    "notifications": ("a66e265f61a57b33dfb942cd9998057ceebb71d7de483dacdcf5dfacc48f2385", 22),
    "designsystem": ("785ba809a0fb352f78255bd8d7c7edb13c445534759e3fa25baa95bf26ac9dd6", 5),
}


def digest(counter: Counter[str]) -> str:
    payload = json.dumps(sorted(counter.items()), ensure_ascii=False, separators=(",", ":")).encode()
    return sha256(payload).hexdigest()


failed = 0
for name, paths in GROUPS.items():
    text = "\n".join((ROOT / path).read_text(encoding="utf-8") for path in paths)
    counter = Counter(STRING.findall(text))
    if name == "designsystem":
        # ConfirmationDialog is the sole new shared API and adds one default dismiss literal.
        counter['"إلغاء"'] -= 1
        if counter['"إلغاء"'] == 0:
            del counter['"إلغاء"']
    actual = digest(counter)
    expected_digest, expected_count = EXPECTED[name]
    ok = actual == expected_digest and sum(counter.values()) == expected_count
    print(f"{'PASS' if ok else 'FAIL'}: {name} v34 literal contract ({sum(counter.values())}/{expected_count})")
    if not ok:
        failed += 1

print(f"RESULT: {len(GROUPS) - failed}/{len(GROUPS)}")
if failed:
    sys.exit(1)
