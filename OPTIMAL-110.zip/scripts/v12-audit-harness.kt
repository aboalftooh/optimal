import com.optimal.fleet.core.model.audit.AuditAction
import com.optimal.fleet.core.model.audit.AuditActorSource
import com.optimal.fleet.core.model.audit.AuditEntityType
import com.optimal.fleet.core.model.audit.AuditEventDraft
import com.optimal.fleet.core.model.audit.AuditFieldChange
import com.optimal.fleet.core.model.audit.AuditRedactionPolicy

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

fun main() {
    val event = AuditEventDraft(
        companyId = "company-1",
        actorUserId = "user-1",
        actorSource = AuditActorSource.USER,
        action = AuditAction.VEHICLE_UPDATED,
        entityType = AuditEntityType.VEHICLE,
        entityId = "vehicle-1",
        vehicleId = "vehicle-1",
        summary = "تم\nتعديل\tالسيارة",
        changes = listOf(
            AuditFieldChange("odometerKm", "100", "120"),
            AuditFieldChange("password", "old", "new"),
            AuditFieldChange("accessToken", "a", "b"),
            AuditFieldChange("driverName", "أحمد", "محمد"),
            AuditFieldChange("unchanged", "x", "x"),
        ),
        sourceReference = "source\n1",
    )
    val safe = AuditRedactionPolicy.sanitize(event)

    verify("company retained", safe.companyId == "company-1")
    verify("actor retained", safe.actorUserId == "user-1")
    verify("actor source retained", safe.actorSource == AuditActorSource.USER)
    verify("action retained", safe.action == AuditAction.VEHICLE_UPDATED)
    verify("entity type retained", safe.entityType == AuditEntityType.VEHICLE)
    verify("entity retained", safe.entityId == "vehicle-1")
    verify("vehicle retained", safe.vehicleId == "vehicle-1")
    verify("summary controls removed", '\n' !in safe.summary && '\t' !in safe.summary)
    verify("source controls removed", safe.sourceReference == "source 1")
    verify("password removed", safe.changes.none { it.fieldName == "password" })
    verify("token removed", safe.changes.none { it.fieldName == "accessToken" })
    verify("unchanged removed", safe.changes.none { it.fieldName == "unchanged" })
    verify("odometer preserved", safe.changes.any { it.fieldName == "odometerKm" })
    verify("driver preserved", safe.changes.any { it.fieldName == "driverName" })
    verify("change count", safe.changes.size == 2)

    val bounded = AuditRedactionPolicy.sanitize(
        event.copy(
            summary = "x".repeat(600),
            changes = (1..40).map { AuditFieldChange("field$it", null, "y".repeat(500)) },
        ),
    )
    verify("summary bounded", bounded.summary.length == 240)
    verify("change count bounded", bounded.changes.size == 24)
    verify("values bounded", bounded.changes.all { it.afterValue?.length == 160 })
    verify("VERTO source available", AuditActorSource.valueOf("VERTO") == AuditActorSource.VERTO)
    verify("SYSTEM source available", AuditActorSource.valueOf("SYSTEM") == AuditActorSource.SYSTEM)
    verify("required completion action", AuditAction.valueOf("MAINTENANCE_COMPLETED") == AuditAction.MAINTENANCE_COMPLETED)
    verify("required invoice action", AuditAction.valueOf("INVOICE_IMPORTED") == AuditAction.INVOICE_IMPORTED)
    verify("required sync action", AuditAction.valueOf("SYNC_BATCH_COMPLETED") == AuditAction.SYNC_BATCH_COMPLETED)

    println("RESULT: $checks/$checks passed")
}
