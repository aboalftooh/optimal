#!/usr/bin/env python3
import sqlite3

checks = 0

def verify(name, condition):
    global checks
    if not condition:
        raise AssertionError(name)
    checks += 1
    print(f"PASS: {name}")

connection = sqlite3.connect(":memory:")
connection.execute("PRAGMA foreign_keys = ON")
connection.executescript(
    """
    CREATE TABLE companies(id TEXT NOT NULL PRIMARY KEY);
    CREATE TABLE local_users(
      id TEXT NOT NULL,
      companyId TEXT NOT NULL,
      remoteId TEXT,
      displayName TEXT NOT NULL,
      phone TEXT,
      isActive INTEGER NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL,
      PRIMARY KEY(id),
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE UNIQUE INDEX index_local_users_id_companyId ON local_users(id, companyId);
    INSERT INTO companies(id) VALUES ('c1');
    INSERT INTO local_users VALUES ('u1','c1',NULL,'أحمد','+249 912-345-678',1,100,200,'LOCAL_ONLY');
    """
)
connection.execute("ALTER TABLE local_users ADD COLUMN normalizedPhone TEXT")
connection.execute("ALTER TABLE local_users ADD COLUMN lastActiveAtEpochMillis INTEGER NOT NULL DEFAULT 0")
connection.execute(
    """
    UPDATE local_users
    SET normalizedPhone = CASE WHEN phone IS NULL THEN NULL
      ELSE REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', '') END,
      lastActiveAtEpochMillis = updatedAtEpochMillis
    """
)
connection.execute("CREATE UNIQUE INDEX index_local_users_companyId_normalizedPhone ON local_users(companyId, normalizedPhone)")
connection.executescript(
    """
    CREATE TABLE member_invites(
      id TEXT NOT NULL PRIMARY KEY,
      companyId TEXT NOT NULL,
      displayName TEXT NOT NULL,
      phone TEXT NOT NULL,
      normalizedPhone TEXT NOT NULL,
      codeHash TEXT NOT NULL,
      state TEXT NOT NULL,
      expiresAtEpochMillis INTEGER NOT NULL,
      usedAtEpochMillis INTEGER,
      usedByUserId TEXT,
      createdByUserId TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY(createdByUserId, companyId) REFERENCES local_users(id, companyId) ON DELETE RESTRICT
    );
    CREATE INDEX index_member_invites_companyId ON member_invites(companyId);
    CREATE INDEX index_member_invites_companyId_normalizedPhone ON member_invites(companyId, normalizedPhone);
    CREATE UNIQUE INDEX index_member_invites_codeHash ON member_invites(codeHash);
    CREATE INDEX index_member_invites_createdByUserId_companyId ON member_invites(createdByUserId, companyId);
    CREATE INDEX index_member_invites_companyId_state_expiresAtEpochMillis ON member_invites(companyId, state, expiresAtEpochMillis);
    """
)

columns = {row[1] for row in connection.execute("PRAGMA table_info(local_users)")}
verify("normalized phone column", "normalizedPhone" in columns)
verify("last activity column", "lastActiveAtEpochMillis" in columns)
row = connection.execute("SELECT normalizedPhone,lastActiveAtEpochMillis FROM local_users WHERE id='u1'").fetchone()
verify("existing phone normalized", row[0] == "+249912345678")
verify("existing activity backfilled", row[1] == 200)
invite_columns = {row[1] for row in connection.execute("PRAGMA table_info(member_invites)")}
verify("invite table columns", {"codeHash","state","expiresAtEpochMillis","usedAtEpochMillis"}.issubset(invite_columns))

connection.execute(
    "INSERT INTO member_invites VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
    ('i1','c1','محمد','0912345678','0912345678','hash1','PENDING',1000,None,None,'u1',100,100),
)
verify("invite inserted", connection.execute("SELECT COUNT(*) FROM member_invites").fetchone()[0] == 1)
try:
    connection.execute(
        "INSERT INTO member_invites VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        ('i2','c1','علي','0999999999','0999999999','hash1','PENDING',1000,None,None,'u1',100,100),
    )
    duplicate_blocked = False
except sqlite3.IntegrityError:
    duplicate_blocked = True
verify("code hash unique", duplicate_blocked)
connection.execute("UPDATE member_invites SET state='USED',usedAtEpochMillis=500,usedByUserId='u1' WHERE id='i1' AND state='PENDING'")
verify("invite consumed once", connection.total_changes >= 1)
second = connection.execute("UPDATE member_invites SET usedAtEpochMillis=600 WHERE id='i1' AND state='PENDING'").rowcount
verify("used invite cannot be consumed again", second == 0)
indexes = {row[1] for row in connection.execute("PRAGMA index_list(member_invites)")}
verify("invite hash index", "index_member_invites_codeHash" in indexes)
verify("invite status expiry index", "index_member_invites_companyId_state_expiresAtEpochMillis" in indexes)
print(f"RESULT: {checks}/{checks} passed")
