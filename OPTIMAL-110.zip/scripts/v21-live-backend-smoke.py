#!/usr/bin/env python3
"""Non-destructive live smoke tests for the deployed OPTIMAL v21 backend.

Required environment variables:
  SUPABASE_URL, SUPABASE_ANON_KEY, OPTIMAL_ACCESS_TOKEN, OPTIMAL_COMPANY_ID
Optional second-company isolation check:
  OPTIMAL_SECOND_ACCESS_TOKEN, OPTIMAL_SECOND_COMPANY_ID

No secret is printed. The script performs read-only RPC calls.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class HttpResult:
    status: int
    body: str

    def json(self) -> Any:
        return json.loads(self.body or "null")


def required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"missing_environment:{name}")
    return value


def rpc(base_url: str, anon_key: str, bearer: str, name: str, payload: dict[str, Any]) -> HttpResult:
    request = urllib.request.Request(
        url=f"{base_url.rstrip('/')}/rest/v1/rpc/{name}",
        data=json.dumps(payload, separators=(",", ":")).encode("utf-8"),
        method="POST",
        headers={
            "apikey": anon_key,
            "Authorization": f"Bearer {bearer}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return HttpResult(response.status, response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        return HttpResult(error.code, error.read().decode("utf-8", errors="replace"))


def check(label: str, condition: bool, counts: list[int], detail: str = "") -> None:
    counts[1] += 1
    if not condition:
        suffix = f" ({detail})" if detail else ""
        raise AssertionError(f"FAIL: {label}{suffix}")
    counts[0] += 1
    print(f"PASS: {label}")


def first_row(result: HttpResult) -> dict[str, Any]:
    payload = result.json()
    if not isinstance(payload, list) or len(payload) != 1 or not isinstance(payload[0], dict):
        raise AssertionError("backend_contract_invalid_shape")
    return payload[0]


def main() -> int:
    try:
        base_url = required("SUPABASE_URL")
        anon_key = required("SUPABASE_ANON_KEY")
        access_token = required("OPTIMAL_ACCESS_TOKEN")
        company_id = required("OPTIMAL_COMPANY_ID")
    except RuntimeError as error:
        print(f"BLOCKED: {error}", file=sys.stderr)
        return 2

    counts = [0, 0]

    anonymous = rpc(base_url, anon_key, anon_key, "optimal_backend_contract", {})
    check(
        "anonymous backend-contract access is denied",
        anonymous.status in (401, 403),
        counts,
        f"HTTP {anonymous.status}",
    )

    contract_result = rpc(base_url, anon_key, access_token, "optimal_backend_contract", {})
    check("authenticated backend contract responds", contract_result.status == 200, counts, f"HTTP {contract_result.status}")
    contract = first_row(contract_result)
    check("backend contract version is v21 or newer", int(contract.get("contract_version", 0)) >= 21, counts)
    check("v20 client remains compatible", int(contract.get("minimum_android_version_code", 999999)) <= 16, counts)
    check("authenticated member is active", contract.get("member_active") is True, counts)
    check("auth capability is ready", contract.get("auth_ready") is True, counts)
    check("sync capability is ready", contract.get("sync_ready") is True, counts)
    check("Verto ingestion capability is ready", contract.get("verto_ingestion_ready") is True, counts)
    check("contract company matches expected company", contract.get("company_id") == company_id, counts)

    own_feed = rpc(
        base_url,
        anon_key,
        access_token,
        "optimal_verto_invoice_feed",
        {"p_company_id": company_id, "p_updated_after_ms": None, "p_after_invoice_id": None},
    )
    own_feed_allowed = own_feed.status == 200 or (
        own_feed.status in (400, 404) and "verto_company_not_linked" in own_feed.body
    )
    check("own-company Verto feed passes membership gate", own_feed_allowed, counts, f"HTTP {own_feed.status}")

    second_token = os.environ.get("OPTIMAL_SECOND_ACCESS_TOKEN", "").strip()
    second_company = os.environ.get("OPTIMAL_SECOND_COMPANY_ID", "").strip()
    if bool(second_token) != bool(second_company):
        print("BLOCKED: provide both OPTIMAL_SECOND_ACCESS_TOKEN and OPTIMAL_SECOND_COMPANY_ID", file=sys.stderr)
        return 2
    if second_token and second_company:
        cross_feed = rpc(
            base_url,
            anon_key,
            access_token,
            "optimal_verto_invoice_feed",
            {"p_company_id": second_company, "p_updated_after_ms": None, "p_after_invoice_id": None},
        )
        check(
            "first member cannot read second company Verto feed",
            cross_feed.status in (401, 403),
            counts,
            f"HTTP {cross_feed.status}",
        )
        reverse_feed = rpc(
            base_url,
            anon_key,
            second_token,
            "optimal_verto_invoice_feed",
            {"p_company_id": company_id, "p_updated_after_ms": None, "p_after_invoice_id": None},
        )
        check(
            "second member cannot read first company Verto feed",
            reverse_feed.status in (401, 403),
            counts,
            f"HTTP {reverse_feed.status}",
        )
    else:
        print("SKIP: cross-company checks require optional second-company credentials")

    print(f"LIVE RESULT: {counts[0]}/{counts[1]} PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, json.JSONDecodeError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
