#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v65 RLS/isolation/security tests."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKS: list[tuple[str, bool]] = []


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        raise AssertionError(f"missing file: {relative}")
    return path.read_text(encoding="utf-8")


def check(name: str, condition: bool) -> None:
    CHECKS.append((name, bool(condition)))


def contains_all(text: str, tokens: list[str]) -> bool:
    lowered = text.lower()
    return all(token.lower() in lowered for token in tokens)


preflight = read("supabase/tests/v65_rls_isolation_security_preflight.sql")
scenarios = read("supabase/tests/v65_rls_isolation_security_scenarios.sql")
live_harness = read("scripts/v65-live-rls-isolation-harness.py")
wrapper = read("scripts/verify-v65-static.sh")
build = read("build.gradle.kts")
ci_fast = read("scripts/ci-fast.sh")
ci_full = read("scripts/ci-full.sh")
verify_project = read("scripts/verify-project.sh")
security_gate = read("scripts/security-release-check.py")
session = read("docs/sessions/v65.md")
security_report = read("docs/security-verification-v65.md")

for relative in (
    "docs/verifications/verification-v65.md",
    "verification-v65.md",
    "docs/evidence/v65/live-backend-attempt.txt",
):
    check(f"file:{relative}", (ROOT / relative).is_file())

for token in (
    "v65_backend_contract_not_promoted",
    "v65_rls_missing",
    "v65_force_rls_missing",
    "v65_dangerous_direct_table_grant_detected",
    "v65_private_bucket_missing_or_public",
    "v65_storage_upload_policy_missing",
    "v65_rpc_not_hardened",
    "v65_message_page_abuse_bound_missing",
    "v65_caller_owned_company_rpc_signature_detected",
):
    check(f"preflight:{token}", token in preflight)

for table in (
    "optimal_verto_registration_codes",
    "optimal_verto_conversations",
    "optimal_verto_messages",
    "optimal_verto_message_receipts",
    "optimal_verto_conversation_states",
    "optimal_verto_message_attachments",
    "invoices",
    "maintenance_records",
):
    check(f"preflight:table:{table}", table in preflight)

for token in (
    "v65_fixture_requires_first_linked_member",
    "v65_fixture_requires_second_linked_company_member",
    "v65_cross_tenant_message_leaked",
    "v65_cross_tenant_attachment_access_allowed",
    "v65_foreign_message_idor_allowed",
    "v65_message_page_abuse_limit_bypassed",
    "v65_attachment_mime_abuse_allowed",
    "v65_cross_tenant_invoice_leaked",
    "v65_cross_tenant_maintenance_leaked",
    "v65_unauthorized_member_read_allowed",
    "v65_unauthorized_member_send_allowed",
    "v65_authenticated_direct_message_read_allowed",
    "v65_authenticated_direct_attachment_read_allowed",
    "v65_authenticated_direct_invoice_read_allowed",
    "v65_authenticated_direct_maintenance_read_allowed",
    "rollback;",
):
    check(f"scenario:{token}", token in scenarios)

check("scenario:two-companies", contains_all(scenarios, ["company_id <> v_member_a.company_id", "v_conversation_a", "v_conversation_b"]))
check("scenario:server-auth-context", scenarios.count("request.jwt.claim.sub") >= 2)
check("scenario:authenticated-role", contains_all(scenarios, ["set local role authenticated", "reset role"]))
check("scenario:no-service-role", "service_role" not in scenarios.lower())

for token in (
    "V65_DATABASE_URL",
    "--allow-destructive",
    "V65_TEST_DATABASE_ONLY",
    "v65_rls_isolation_security_preflight.sql",
    "v65_rls_isolation_security_scenarios.sql",
    "v49_verto_chat_permissions_scenarios.sql",
    "v44_verto_invoice_scenarios.sql",
    "v45_verto_maintenance_scenarios.sql",
    "PGCONNECT_TIMEOUT",
):
    check(f"harness:{token}", token in live_harness)
check("harness:no-secret-output", "print(database_url" not in live_harness and "print(os.environ" not in live_harness)
check("harness:live-fail-closed", contains_all(live_harness, ["LIVE BLOCKED", "return 2", "allow_destructive"]))

check("wrapper:v65-first", wrapper.find("v65-rls-isolation-security-contract.py") < wrapper.find("verify-v64-static.sh"))
check("wrapper:v64-regression", "verify-v64-static.sh" in wrapper)
check("wrapper:syntax", "python3 -m py_compile" in wrapper and "bash -n" in wrapper)

check("gradle:task", contains_all(build, ["rlsIsolationSecurityContractCheck", "scripts/v65-rls-isolation-security-contract.py"]))
check("gradle:static-quality", "rlsIsolationSecurityContractCheck" in build[build.find('tasks.register("staticQualityCheck")'):])
check("ci-fast:v65", "scripts/v65-rls-isolation-security-contract.py" in ci_fast)
check("ci-full:v65-wrapper", "verify-v65-static.sh" in ci_full)
check("verify-project:v65-wrapper", "verify-v65-static.sh" in verify_project)

check("security:service-role-scan", contains_all(security_gate, ["service role material absent from Android", "SUPABASE_SERVICE_ROLE_KEY", "service_role"]))
check("session:scope", contains_all(session, ["v65", "RLS", "شركتين", "Backend حي"]))
check("report:no-false-live-pass", contains_all(security_report, ["لم تُشغّل", "BLOCKED", "لا أسرار"]))

# v65 is test/security-gate only: no new production migration is allowed.
v65_migrations = list((ROOT / "supabase/migrations").glob("*v65*.sql"))
check("scope:no-v65-production-migration", not v65_migrations)

# Android and repositories must not contain server credentials or service-role clients.
production_files: list[Path] = []
for base in (ROOT / "app", ROOT / "core", ROOT / "feature"):
    production_files.extend(
        path for path in base.rglob("*")
        if path.is_file() and "/src/main/" in path.as_posix() and path.suffix.lower() in {".kt", ".java", ".xml", ".properties", ".json"}
    )
service_role_hits: list[str] = []
patterns = (
    re.compile(r"SUPABASE_SERVICE_ROLE_KEY", re.IGNORECASE),
    re.compile(r"\bservice[_-]?role\b", re.IGNORECASE),
    re.compile(r"\bserviceRole(?:Key|Client)?\b"),
)
for path in production_files:
    text = path.read_text(encoding="utf-8", errors="ignore")
    if any(pattern.search(text) for pattern in patterns):
        service_role_hits.append(str(path.relative_to(ROOT)))
check("android:no-service-role", not service_role_hits)

for label, text in (("preflight", preflight), ("scenarios", scenarios)):
    check(f"syntax:{label}:dollar-quotes", text.count("$$") % 2 == 0)
    check(f"syntax:{label}:merge-markers", not any(marker in text for marker in ("<<<<<<<", "=======", ">>>>>>>")))
    check(f"syntax:{label}:transaction", ("begin;" in text and "rollback;" in text) if label == "scenarios" else True)

failed = [name for name, ok in CHECKS if not ok]
for name, ok in CHECKS:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
print(f"RESULT {len(CHECKS) - len(failed)}/{len(CHECKS)}")
if service_role_hits:
    print("SERVICE_ROLE_HITS: " + ", ".join(service_role_hits), file=sys.stderr)
if failed:
    print("FAILED: " + ", ".join(failed), file=sys.stderr)
    raise SystemExit(1)
