#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import py_compile
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    print(f"{'PASS' if condition else 'FAIL'}: {name}")


required = [
    "supabase/migrations/20260728002100_optimal_backend_readiness.sql",
    "scripts/v21-backend-contract-harness.py",
    "scripts/v21-live-backend-smoke.py",
    "scripts/deploy-v21-supabase.sh",
    "scripts/verify-v21-static.sh",
    "scripts/verify-v21-regressions.sh",
    "docs/sessions/v21-backend-deployment-readiness.md",
    "docs/integrations/supabase-verto-ingestion-contract-v21.md",
    "docs/backend-deployment-v21.md",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
sql = read("supabase/migrations/20260728002100_optimal_backend_readiness.sql")
live_smoke = read("scripts/v21-live-backend-smoke.py")
deploy = read("scripts/deploy-v21-supabase.sh")

version_code_match = re.search(r"versionCode\s*=\s*(\d+)", build)
version_name_match = re.search(r'versionName\s*=\s*"0\.(\d+)\.0-v(\d+)"', build)
check("versionCode 17 or newer", bool(version_code_match and int(version_code_match.group(1)) >= 17))
check(
    "versionName v21 or newer",
    bool(
        version_name_match
        and int(version_name_match.group(1)) >= 21
        and version_name_match.group(1) == version_name_match.group(2)
    ),
)
check("Room remains schema 13", "version = 13" in database)
check("v21 migration sorts after v20", "20260728002100" > "20260728002000")
check("backend contract singleton table", "create table if not exists public.optimal_backend_contracts" in sql and "singleton boolean primary key" in sql)
check("backend contract is v21", re.search(r"\n\s*21,\n\s*16,", sql) is not None)
check("v20 remains minimum compatible client", "minimum_android_version_code" in sql and "21,\n    16," in sql)
check("backend contract table has RLS", "alter table public.optimal_backend_contracts enable row level security" in sql)
check("backend contract table hidden from clients", "revoke all on table public.optimal_backend_contracts from public, anon, authenticated" in sql)
check("backend contract table reserved to service role", "grant select, insert, update on table public.optimal_backend_contracts to service_role" in sql)
check("authenticated contract RPC exists", "create or replace function public.optimal_backend_contract()" in sql)
check("contract RPC reports caller identity", "auth.uid()" in sql[sql.index("optimal_backend_contract()"):])
check("contract RPC reports active membership", "member_active boolean" in sql and "coalesce(m.is_active, false)" in sql)
check("contract RPC reports Verto link", "verto_linked boolean" in sql and "coalesce(l.is_active, false)" in sql)
check("anonymous contract execution revoked", "revoke all on function public.optimal_backend_contract() from public, anon" in sql)
check("contract execution authenticated only", "grant execute on function public.optimal_backend_contract() to authenticated" in sql)

assert_start = sql.index("create or replace function public.optimal_assert_sync_request")
assert_end = sql.index("create or replace function public.optimal_backend_contract")
assert_sql = sql[assert_start:assert_end]
check("sync aggregate allowlist retained", "unsupported_aggregate" in assert_sql)
check("sync operation allowlist retained", "unsupported_operation" in assert_sql)
check("vehicle operation matrix enforced", "p_aggregate_type = 'VEHICLE'" in assert_sql and "('UPSERT', 'ARCHIVE')" in assert_sql)
check("maintenance operation matrix enforced", "p_aggregate_type = 'MAINTENANCE'" in assert_sql and "('UPSERT', 'COMPLETE')" in assert_sql)
check("follow-up operation matrix enforced", "p_aggregate_type = 'FOLLOW_UP'" in assert_sql and "('UPSERT', 'CONVERT')" in assert_sql)
check("aggregate id length bounded", "not between 1 and 128" in assert_sql)
check("payload must be JSON object", "jsonb_typeof(p_payload) <> 'object'" in assert_sql)
check("payload size bounded to 64 KiB", "octet_length(p_payload::text) > 65536" in assert_sql)
check("payload identity must match envelope", "aggregate_id_mismatch" in assert_sql)
check("sync authorization remains membership based", "optimal_is_active_company_member(p_company_id)" in assert_sql)

check("active Verto client link is unique", "optimal_verto_links_one_active_client_idx" in sql and "where is_active = true" in sql)
check("trusted Verto ingestion RPC exists", "optimal_admin_upsert_verto_invoice_snapshot" in sql)
ingest_start = sql.index("create or replace function public.optimal_admin_upsert_verto_invoice_snapshot")
ingest_sql = sql[ingest_start:]
check("ingestion validates linked company", "verto_company_not_linked" in ingest_sql)
check("ingestion validates Verto client ownership", "verto_client_mismatch" in ingest_sql)
check("ingestion rejects negative monetary values", "invalid_verto_snapshot_amount" in ingest_sql and ingest_sql.count("< 0") >= 5)
check("ingestion validates source identity", "invalid_verto_snapshot_identity" in ingest_sql)
check("ingestion upserts by company and invoice", "on conflict (optimal_company_id, verto_invoice_id) do update" in ingest_sql)
check("stale Verto source cannot overwrite", "source_updated_at < excluded.source_updated_at" in ingest_sql)
check("stale result is explicit", "return 'STALE_IGNORED'" in ingest_sql)
check("applied result is explicit", "return 'APPLIED'" in ingest_sql)
check("trusted ingestion revoked from Android roles", "from public, anon, authenticated" in ingest_sql)
check("trusted ingestion granted only to service role", ") to service_role;" in ingest_sql)

check("live smoke is read-only", "optimal_admin_" not in live_smoke and "optimal_apply_sync_operation" not in live_smoke)
check("live smoke never requests service role", "SERVICE_ROLE" not in live_smoke)
check("live smoke checks anonymous denial", "anonymous backend-contract access is denied" in live_smoke)
check("live smoke checks contract version", "backend contract version is v21 or newer" in live_smoke)
check("live smoke supports two-company isolation", "OPTIMAL_SECOND_ACCESS_TOKEN" in live_smoke and "cannot read second company" in live_smoke)
check("deployment defaults to dry-run", 'MODE="${1:---dry-run}"' in deploy and "supabase db push --dry-run" in deploy)
check("deployment requires explicit apply", '[[ "$MODE" == "--apply" ]]' in deploy)
check("deployment requires project reference", "SUPABASE_PROJECT_REF" in deploy)
verification_gates = "\n".join(
    path.read_text(encoding="utf-8")
    for path in (ROOT / "scripts").glob("verify-v*-static.sh")
)
check("current verification retains the v21 gate", "static-v21-check.py" in verification_gates)

for script in ["scripts/v21-backend-contract-harness.py", "scripts/v21-live-backend-smoke.py", "scripts/static-v21-check.py"]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid = True
    except py_compile.PyCompileError:
        valid = False
    check(f"Python syntax valid: {script}", valid)

production_kotlin = "\n".join(path.read_text(encoding="utf-8") for path in ROOT.rglob("src/main/**/*.kt"))
check("service role remains absent from Android production", "service_role" not in production_kotlin.lower())
check("no embedded Supabase secret literal", not re.search(r"eyJ[a-zA-Z0-9_-]{40,}", production_kotlin))

passed = sum(ok for _, ok in checks)
print(f"\nRESULT: {passed}/{len(checks)} passed")
sys.exit(0 if passed == len(checks) else 1)
