#!/usr/bin/env python3
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []
def read(path): return (ROOT / path).read_text(encoding="utf-8")
def check(name, ok): checks.append((name, bool(ok)))

build = read("app/build.gradle.kts")
paging = read("core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt")
check("versionCode 28", re.search(r"\bversionCode\s*=\s*28\b", build))
check("versionName v33", 'versionName = "0.33.0-v33"' in build)
check("pure PageRequest", "data class PageRequest" in paging and not re.search(r"import\s+(android\.|androidx\.)", paging))
check("page size capped", "MAX_PAGE_SIZE" in paging and "1..MAX_PAGE_SIZE" in paging)
check("lookahead slice", "size > requestedLimit" in paging and "take(requestedLimit)" in paging)

page_daos = {
    "vehicles": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt", "loadVehiclesPage"),
    "maintenance": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt", "loadOperationsPage"),
    "history": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt", "loadCompletedHistoryPage"),
    "invoices": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt", "loadInvoicesPage"),
    "notifications": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt", "loadNotificationsPage"),
    "company activity": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/AuditEventDao.kt", "loadCompanyActivityPage"),
    "entity activity": ("core/database/src/main/java/com/optimal/fleet/core/database/dao/AuditEventDao.kt", "loadEntityActivityPage"),
}
for name, (path, method) in page_daos.items():
    text = read(path)
    pos = text.find(method)
    window = text[max(0, pos-1800):pos+500]
    check(f"{name} page DAO", pos >= 0)
    check(f"{name} SQL limit offset", "LIMIT :limitWithLookahead OFFSET :offset" in window)
    check(f"{name} company scoped", "companyId = :companyId" in window)

for path in [
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt",
]:
    check(f"legacy read bounded {Path(path).stem}", "LIMIT 200" in read(path))

use_cases = [
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/LoadVehiclesPage.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/LoadMaintenanceOperationsPage.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/history/LoadMaintenanceHistoryPage.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/LoadInvoiceProjectionsPage.kt",
]
for path in use_cases:
    text = read(path)
    check(f"use case exists {Path(path).stem}", (ROOT/path).is_file())
    check(f"use case uses active company {Path(path).stem}", "session.companyId" in text)
    check(f"use case returns PageSlice {Path(path).stem}", "PageSlice<" in text)

vm_routes = [
    ("vehicles", "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt", "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt"),
    ("maintenance", "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListViewModel.kt", "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListRoute.kt"),
    ("history", "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryViewModel.kt", "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryRoute.kt"),
    ("invoices", "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt", "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt"),
    ("notifications", "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsViewModel.kt", "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt"),
    ("activity", "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityViewModel.kt", "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt"),
]
for name, vm, route in vm_routes:
    vt, rt = read(vm), read(route)
    check(f"{name} viewmodel has first page", "PageRequest(offset = 0" in vt or "loadPage(companyId, offset = 0)" in vt)
    check(f"{name} viewmodel has load more", "loadMore" in vt and "isLoadingMore" in vt)
    check(f"{name} route exposes load more", "تحميل المزيد" in rt and "load-more" in rt)

entity_indexes = {
    "vehicle": ("core/database/src/main/java/com/optimal/fleet/core/database/entity/VehicleEntity.kt", '["companyId", "archivedAtEpochMillis", "updatedAtEpochMillis", "id"]'),
    "maintenance updated": ("core/database/src/main/java/com/optimal/fleet/core/database/entity/MaintenanceOperationEntity.kt", '["companyId", "status", "updatedAtEpochMillis", "id"]'),
    "maintenance completed": ("core/database/src/main/java/com/optimal/fleet/core/database/entity/MaintenanceOperationEntity.kt", '["companyId", "status", "completedAtEpochMillis", "id"]'),
    "invoice": ("core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceProjectionEntity.kt", '["companyId", "invoiceDateEpochMillis", "invoiceNumber", "id"]'),
    "notification": ("core/database/src/main/java/com/optimal/fleet/core/database/entity/NotificationEntity.kt", '["companyId", "occurredAtEpochMillis", "id"]'),
    "activity": ("core/database/src/main/java/com/optimal/fleet/core/database/entity/AuditEventEntity.kt", '["companyId", "occurredAtEpochMillis", "id"]'),
}
for name,(path,columns) in entity_indexes.items(): check(f"composite index {name}", columns in read(path))

schema = json.loads(read("core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/1.json"))
entities = schema["database"]["entities"]
check("Room remains version 1", schema["database"]["version"] == 1)
check("Room index count 95", sum(len(e.get("indices", [])) for e in entities) == 95)
schema_text = json.dumps(schema)
for token in ["archivedAtEpochMillis", "completedAtEpochMillis", "invoiceDateEpochMillis", "occurredAtEpochMillis"]:
    check(f"schema contains paging key {token}", token in schema_text)

invoice_repo = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt")
check("invoice total independent from visible page", "observeOutstandingTotal" in invoice_repo)
for path in [
    "README.md", "AGENTS.md", "docs/sessions/v33.md", "docs/paging-indexes-v33.md",
    "docs/verification-scripts-v33.md", "docs/verifications/verification-v33.md",
    "verification-v33.md", "PATCH_MANIFEST-v33.md", "CHANGED_FILES-v33.txt", "DELETED_FILES-v33.txt",
]: check(f"delivery {path}", (ROOT/path).is_file())
check("Kotlin paging harness", (ROOT/"scripts/run-v33-paging-harness.sh").is_file())
check("paged presentation compile", (ROOT/"scripts/run-v33-presentation-compile.sh").is_file())
check("paged domain compile", (ROOT/"scripts/run-v33-domain-compile.sh").is_file())
check("route parser check", (ROOT/"scripts/run-v33-route-syntax-check.sh").is_file())
check("exact Room query contract", (ROOT/"scripts/v33-room-query-contract.py").is_file())
check("SQLite paging contract", (ROOT/"scripts/v33-paging-contract.py").is_file())

failed=[name for name,ok in checks if not ok]
for name,ok in checks: print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)}")
if failed:
    print("FAILED: "+", ".join(failed), file=sys.stderr)
    sys.exit(1)
