#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v50-verto-permission-management-contract.py
./scripts/run-v50-member-permission-harness.sh
./scripts/run-v32-member-mapper-compile.sh
./scripts/run-v32-member-remote-compile.sh
./scripts/run-v32-member-repository-compile.sh
exec ./scripts/verify-v49-static.sh
