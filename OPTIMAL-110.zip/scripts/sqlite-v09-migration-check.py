#!/usr/bin/env python3
import sqlite3, sys

checks=[]
def check(name, ok):
    checks.append(bool(ok)); print(('PASS' if ok else 'FAIL')+': '+name)

con=sqlite3.connect(':memory:')
con.execute('PRAGMA foreign_keys=ON')
con.execute('CREATE TABLE companies (id TEXT NOT NULL PRIMARY KEY)')
con.execute("INSERT INTO companies(id) VALUES ('company-1')")
con.executescript('''
CREATE TABLE IF NOT EXISTS verto_invoice_projections (
 id TEXT NOT NULL, companyId TEXT NOT NULL, vertoInvoiceId TEXT NOT NULL,
 vertoOrganizationId TEXT NOT NULL, vertoClientId TEXT, invoiceNumber TEXT NOT NULL,
 invoiceType TEXT NOT NULL, description TEXT, category TEXT, totalMinor INTEGER NOT NULL,
 paidMinor INTEGER, remainingMinor INTEGER, partsCostMinor INTEGER, serviceCostMinor INTEGER,
 sourceStatus TEXT NOT NULL, voided INTEGER NOT NULL, invoiceDateEpochMillis INTEGER NOT NULL,
 sourceUpdatedAtEpochMillis INTEGER NOT NULL, cachedAtEpochMillis INTEGER NOT NULL,
 requiresVehicleLink INTEGER NOT NULL, PRIMARY KEY(id),
 FOREIGN KEY(companyId) REFERENCES companies(id) ON UPDATE NO ACTION ON DELETE CASCADE
);
CREATE INDEX index_verto_invoice_projections_companyId ON verto_invoice_projections(companyId);
CREATE UNIQUE INDEX index_verto_invoice_projections_vertoInvoiceId ON verto_invoice_projections(vertoInvoiceId);
CREATE INDEX index_verto_invoice_projections_vertoClientId ON verto_invoice_projections(vertoClientId);
CREATE INDEX index_verto_invoice_projections_companyId_invoiceDateEpochMillis ON verto_invoice_projections(companyId, invoiceDateEpochMillis);
CREATE INDEX index_verto_invoice_projections_companyId_requiresVehicleLink ON verto_invoice_projections(companyId, requiresVehicleLink);
CREATE INDEX index_verto_invoice_projections_companyId_sourceUpdatedAtEpochMillis ON verto_invoice_projections(companyId, sourceUpdatedAtEpochMillis);
CREATE TABLE IF NOT EXISTS invoice_source_audit (
 id TEXT NOT NULL, companyId TEXT NOT NULL, invoiceProjectionId TEXT NOT NULL,
 vertoInvoiceId TEXT NOT NULL, action TEXT NOT NULL, changedFields TEXT NOT NULL,
 previousSourceUpdatedAtEpochMillis INTEGER, newSourceUpdatedAtEpochMillis INTEGER NOT NULL,
 createdAtEpochMillis INTEGER NOT NULL, PRIMARY KEY(id),
 FOREIGN KEY(companyId) REFERENCES companies(id) ON UPDATE NO ACTION ON DELETE CASCADE,
 FOREIGN KEY(invoiceProjectionId) REFERENCES verto_invoice_projections(id) ON UPDATE NO ACTION ON DELETE CASCADE
);
CREATE INDEX index_invoice_source_audit_companyId ON invoice_source_audit(companyId);
CREATE INDEX index_invoice_source_audit_invoiceProjectionId ON invoice_source_audit(invoiceProjectionId);
CREATE INDEX index_invoice_source_audit_vertoInvoiceId ON invoice_source_audit(vertoInvoiceId);
CREATE INDEX index_invoice_source_audit_companyId_createdAtEpochMillis ON invoice_source_audit(companyId, createdAtEpochMillis);
''')

tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
check('projection table created','verto_invoice_projections' in tables)
check('source audit table created','invoice_source_audit' in tables)
idx={r[1]:r[2] for r in con.execute("PRAGMA index_list('verto_invoice_projections')")}
check('remote invoice index exists','index_verto_invoice_projections_vertoInvoiceId' in idx)
check('remote invoice index unique',idx.get('index_verto_invoice_projections_vertoInvoiceId')==1)
check('company date index exists','index_verto_invoice_projections_companyId_invoiceDateEpochMillis' in idx)
check('needs-link index exists','index_verto_invoice_projections_companyId_requiresVehicleLink' in idx)

row=('verto:invoice-1','company-1','invoice-1','org','client','12','SALE','قطع',None,10000,None,None,None,None,'OPEN',0,1000,2000,3000,1)
con.execute('INSERT INTO verto_invoice_projections VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',row)
check('projection inserted',con.execute('SELECT COUNT(*) FROM verto_invoice_projections').fetchone()[0]==1)
try:
    con.execute('INSERT INTO verto_invoice_projections VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('other',)+row[1:])
    duplicate_blocked=False
except sqlite3.IntegrityError:
    duplicate_blocked=True
check('duplicate verto id blocked',duplicate_blocked)

con.execute("INSERT INTO invoice_source_audit VALUES ('audit-1','company-1','verto:invoice-1','invoice-1','IMPORTED','total',NULL,2000,3000)")
check('audit inserted',con.execute('SELECT COUNT(*) FROM invoice_source_audit').fetchone()[0]==1)
con.execute("UPDATE verto_invoice_projections SET totalMinor=15000, sourceUpdatedAtEpochMillis=4000 WHERE vertoInvoiceId='invoice-1'")
con.execute("INSERT INTO invoice_source_audit VALUES ('audit-2','company-1','verto:invoice-1','invoice-1','UPDATED','total',2000,4000,4000)")
check('same projection updated',con.execute("SELECT totalMinor FROM verto_invoice_projections WHERE vertoInvoiceId='invoice-1'").fetchone()[0]==15000)
check('history retained',con.execute('SELECT COUNT(*) FROM invoice_source_audit').fetchone()[0]==2)
check('failed fetch simulation leaves cache',con.execute('SELECT COUNT(*) FROM verto_invoice_projections').fetchone()[0]==1)
check('unknown finance fields remain null',con.execute('SELECT paidMinor,remainingMinor,partsCostMinor,serviceCostMinor FROM verto_invoice_projections').fetchone()==(None,None,None,None))
check('requires vehicle link persisted',con.execute('SELECT requiresVehicleLink FROM verto_invoice_projections').fetchone()[0]==1)

con.execute("DELETE FROM companies WHERE id='company-1'")
check('company cascade removes projection',con.execute('SELECT COUNT(*) FROM verto_invoice_projections').fetchone()[0]==0)
check('projection cascade removes audit',con.execute('SELECT COUNT(*) FROM invoice_source_audit').fetchone()[0]==0)

passed=sum(checks); total=len(checks)
print(f'\nV09 SQLite checks: {passed}/{total}')
sys.exit(0 if passed==total else 1)
