#!/usr/bin/env python3
import sqlite3
import sys

checks=[]
def check(name, ok):
    checks.append((name, bool(ok)))
    print(f"{'PASS' if ok else 'FAIL'}: {name}")

db=sqlite3.connect(":memory:")
db.executescript('''
CREATE TABLE vehicles(id TEXT PRIMARY KEY, companyId TEXT, name TEXT, plateNumber TEXT, brand TEXT, model TEXT, archivedAtEpochMillis INTEGER, updatedAtEpochMillis INTEGER);
CREATE INDEX index_vehicles_companyId_archivedAtEpochMillis_updatedAtEpochMillis_id ON vehicles(companyId, archivedAtEpochMillis, updatedAtEpochMillis, id);
CREATE TABLE maintenance_operations(id TEXT PRIMARY KEY, companyId TEXT, vehicleId TEXT, status TEXT, source TEXT, type TEXT, description TEXT, startedAtEpochMillis INTEGER, completedAtEpochMillis INTEGER, updatedAtEpochMillis INTEGER);
CREATE INDEX index_maintenance_operations_companyId_status_updatedAtEpochMillis_id ON maintenance_operations(companyId,status,updatedAtEpochMillis,id);
CREATE INDEX index_maintenance_operations_companyId_status_completedAtEpochMillis_id ON maintenance_operations(companyId,status,completedAtEpochMillis,id);
CREATE TABLE invoices(id TEXT PRIMARY KEY, companyId TEXT, invoiceNumber TEXT, invoiceType TEXT, category TEXT, sourceStatus TEXT, totalMinor INTEGER, remainingMinor INTEGER, voided INTEGER, requiresVehicleLink INTEGER, invoiceDateEpochMillis INTEGER);
CREATE INDEX index_invoices_companyId_invoiceDateEpochMillis_invoiceNumber_id ON invoices(companyId,invoiceDateEpochMillis,invoiceNumber,id);
CREATE TABLE notifications(id TEXT PRIMARY KEY, companyId TEXT, occurredAtEpochMillis INTEGER);
CREATE INDEX index_notifications_companyId_occurredAtEpochMillis_id ON notifications(companyId,occurredAtEpochMillis,id);
CREATE TABLE audit_events(id TEXT PRIMARY KEY, companyId TEXT, entityType TEXT, entityId TEXT, occurredAtEpochMillis INTEGER);
CREATE INDEX index_audit_events_companyId_occurredAtEpochMillis_id ON audit_events(companyId,occurredAtEpochMillis,id);
CREATE INDEX index_audit_events_companyId_entityType_entityId_occurredAtEpochMillis ON audit_events(companyId,entityType,entityId,occurredAtEpochMillis);
''')
for company in ('A','B'):
    for i in range(250):
        db.execute('INSERT INTO vehicles VALUES(?,?,?,?,?,?,?,?)',(f'{company}-v-{i:03}',company,f'Car {i}',f'P{i}',None,None,None if i%7 else i,10_000+i))
        db.execute('INSERT INTO maintenance_operations VALUES(?,?,?,?,?,?,?,?,?,?)',(f'{company}-m-{i:03}',company,f'{company}-v-{i:03}', 'COMPLETED' if i%3==0 else 'IN_PROGRESS','MANUAL' if i%2 else 'VERTO','FULL_MAINTENANCE',f'job {i}',i,i if i%3==0 else None,20_000+i))
        db.execute('INSERT INTO invoices VALUES(?,?,?,?,?,?,?,?,?,?,?)',(f'{company}-i-{i:03}',company,str(i),'SALE','PARTS','OPEN',1000,0 if i%5==0 else 500,1 if i%11==0 else 0,1 if i%13==0 else 0,30_000+i))
        db.execute('INSERT INTO notifications VALUES(?,?,?)',(f'{company}-n-{i:03}',company,40_000+i))
        db.execute('INSERT INTO audit_events VALUES(?,?,?,?,?)',(f'{company}-a-{i:03}',company,'VEHICLE',f'{company}-v-{i%10:03}',50_000+i))
db.commit()

def rows(sql,args=()): return db.execute(sql,args).fetchall()
def plan(sql,args=()): return ' '.join(str(x) for row in db.execute('EXPLAIN QUERY PLAN '+sql,args) for x in row)

def verify_pages(name, table, order):
    q=f'SELECT id,companyId FROM {table} WHERE companyId=? ORDER BY {order} LIMIT ? OFFSET ?'
    p1=rows(q,('A',41,0)); p2=rows(q,('A',41,40))
    check(f'{name} lookahead 41', len(p1)==41)
    check(f'{name} company isolation', all(r[1]=='A' for r in p1+p2))
    check(f'{name} pages do not overlap', not ({r[0] for r in p1[:40]} & {r[0] for r in p2[:40]}))
    check(f'{name} stable continuation', p1[40][0]==p2[0][0])

verify_pages('vehicles','vehicles','updatedAtEpochMillis DESC,id DESC')
verify_pages('invoices','invoices','invoiceDateEpochMillis DESC,invoiceNumber DESC,id DESC')
verify_pages('notifications','notifications','occurredAtEpochMillis DESC,id DESC')
verify_pages('activity','audit_events','occurredAtEpochMillis DESC,id DESC')
maint='SELECT id,companyId FROM maintenance_operations WHERE companyId=? AND status=? ORDER BY updatedAtEpochMillis DESC,id DESC LIMIT ? OFFSET ?'
m1=rows(maint,('A','IN_PROGRESS',41,0)); m2=rows(maint,('A','IN_PROGRESS',41,40))
check('maintenance status filter', all(r[0].startswith('A-m-') for r in m1))
check('maintenance page size bounded', len(m1)==41)
check('maintenance pages do not overlap', not ({r[0] for r in m1[:40]} & {r[0] for r in m2[:40]}))
check('invoice paid filter', len(rows('SELECT id FROM invoices WHERE companyId=? AND voided=0 AND remainingMinor=0',('A',)))>0)
check('entity activity isolation', all(r[0].startswith('A-a-') for r in rows('SELECT id FROM audit_events WHERE companyId=? AND entityType=? AND entityId=? ORDER BY occurredAtEpochMillis DESC,id DESC LIMIT 31',('A','VEHICLE','A-v-001'))))
for name,sql,args,index in [
 ('vehicle index','SELECT id FROM vehicles WHERE companyId=? AND archivedAtEpochMillis IS NULL ORDER BY updatedAtEpochMillis DESC,id DESC LIMIT 41',('A',),'index_vehicles_companyId_archivedAtEpochMillis_updatedAtEpochMillis_id'),
 ('maintenance index','SELECT id FROM maintenance_operations WHERE companyId=? AND status=? ORDER BY updatedAtEpochMillis DESC,id DESC LIMIT 41',('A','IN_PROGRESS'),'index_maintenance_operations_companyId_status_updatedAtEpochMillis_id'),
 ('invoice index','SELECT id FROM invoices WHERE companyId=? ORDER BY invoiceDateEpochMillis DESC,invoiceNumber DESC,id DESC LIMIT 41',('A',),'index_invoices_companyId_invoiceDateEpochMillis_invoiceNumber_id'),
 ('notification index','SELECT id FROM notifications WHERE companyId=? ORDER BY occurredAtEpochMillis DESC,id DESC LIMIT 41',('A',),'index_notifications_companyId_occurredAtEpochMillis_id'),
 ('activity index','SELECT id FROM audit_events WHERE companyId=? ORDER BY occurredAtEpochMillis DESC,id DESC LIMIT 41',('A',),'index_audit_events_companyId_occurredAtEpochMillis_id'),
]: check(name, index in plan(sql,args))
failed=[n for n,ok in checks if not ok]
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)}")
if failed:
    print('FAILED: '+', '.join(failed),file=sys.stderr); sys.exit(1)
