import com.optimal.fleet.feature.finance.domain.money.Money
import com.optimal.fleet.feature.finance.domain.money.MoneyParser
import com.optimal.fleet.feature.finance.domain.summary.FinancialPeriod
import com.optimal.fleet.feature.finance.domain.summary.FinancialSummary

private var checks = 0
private fun checkCase(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

fun main() {
    checkCase("exact decimal", MoneyParser.parseMinorUnits("10.01") == 1001L)
    checkCase("Arabic decimal", MoneyParser.parseMinorUnits("١٢٫٥٠") == 1250L)
    checkCase("grouping", MoneyParser.parseMinorUnits("1,234.56") == 123456L)
    checkCase("too many decimals rejected", MoneyParser.parseMinorUnits("1.001") == null)
    checkCase("blank rejected", MoneyParser.parseMinorUnits(" ") == null)

    val summary = FinancialSummary(
        companyId = "company",
        period = FinancialPeriod.allTime(),
        isVertoLinked = false,
        hasVertoInvoices = false,
        owed = Money.zero(),
        paid = Money.zero(),
        partsCost = Money(3000, "SDG"),
        serviceCost = Money(2000, "SDG"),
        additionalCosts = Money(500, "SDG"),
    )
    checkCase("operation total", summary.operationTotal.minorUnits == 5500L)
    checkCase("unlinked local finance", !summary.isVertoLinked && summary.partsCost.minorUnits == 3000L)
    checkCase("currency retained", summary.operationTotal.currencyCode == "SDG")

    val mismatchRejected = runCatching { Money(100, "SDG") + Money(100, "USD") }.isFailure
    checkCase("currency mismatch rejected", mismatchRejected)
    val invalidPeriodRejected = runCatching { FinancialPeriod(100, 100) }.isFailure
    checkCase("invalid period rejected", invalidPeriodRejected)

    println("RESULT: $checks/$checks passed")
}
