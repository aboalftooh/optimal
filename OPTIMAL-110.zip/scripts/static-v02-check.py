#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

required_design_files = [
    "OptimalColors.kt",
    "OptimalTypography.kt",
    "OptimalShapes.kt",
    "OptimalSpacing.kt",
    "OptimalTheme.kt",
]
design_root = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem"
for file_name in required_design_files:
    check(f"design token {file_name}", (design_root / file_name).is_file())

component_root = design_root / "component"
required_components = [
    "OptimalPrimaryButton.kt",
    "OptimalMoneyText.kt",
    "OptimalScreenStates.kt",
    "OptimalOfflineStatus.kt",
]
for file_name in required_components:
    check(f"component {file_name}", (component_root / file_name).is_file())

app_source = "\n".join(
    p.read_text(encoding="utf-8")
    for p in (ROOT / "app/src/main/java").rglob("*.kt")
)
check("app scaffold exists", "fun OptimalAppScaffold(" in app_source)
check("five-item navigation bar exists", "topLevelDestinations.forEach" in app_source)
check("RTL forced in shell", "LocalLayoutDirection provides LayoutDirection.Rtl" in app_source)
check("navigation composition remains in app", "fun OptimalNavGraph(" in app_source)
check("48dp touch token exists", "touchTarget = 48.dp" in (design_root / "OptimalSpacing.kt").read_text(encoding="utf-8"))
check("presentation convention documented", (ROOT / "docs/presentation-convention.md").is_file())

features = ["auth", "home", "vehicles", "maintenance", "finance", "notifications", "settings"]
for feature in features:
    src = ROOT / f"feature/{feature}/src/main/java"
    route_files = list(src.rglob("*Route.kt"))
    nav_files = list(src.rglob("*Navigation.kt"))
    check(f"{feature} route exists", len(route_files) >= 1, str(route_files))
    check(f"{feature} graph exists", len(nav_files) == 1, str(nav_files))
    if route_files:
        route_content = "\n".join(p.read_text(encoding="utf-8") for p in route_files)
        feature_content = "\n".join(p.read_text(encoding="utf-8") for p in src.rglob("*.kt"))
        check(f"{feature} initial UiState", bool(re.search(r"state: \w+UiState = \w+UiState\([^)]*\)", route_content)))
        check(f"{feature} UDF event", "sealed interface" in feature_content and "UiEvent" in feature_content)

forbidden = []
for path in (ROOT / "feature").rglob("*.kt"):
    content = path.read_text(encoding="utf-8")
    own = path.relative_to(ROOT / "feature").parts[0]
    for imported in re.findall(r"import com\.optimal\.fleet\.feature\.([a-z]+)\.", content):
        if imported != own:
            forbidden.append(f"{path.relative_to(ROOT)} -> {imported}")
    if "/presentation/" in path.as_posix() and re.search(r"\b(Dao|OptimalDatabase|Retrofit|WorkManager)\b", content):
        forbidden.append(f"{path.relative_to(ROOT)} -> forbidden presentation infrastructure")
check("no feature-to-feature or presentation infrastructure imports", not forbidden, ", ".join(forbidden))

check("Compose previews exist", any((design_root / "preview").rglob("*.kt")))
check("DesignSystemComponentTest exists", any(ROOT.rglob("DesignSystemComponentTest.kt")))
check("NavigationGraphTest exists", any(ROOT.rglob("NavigationGraphTest.kt")))
check("RtlSemanticsTest exists", any(ROOT.rglob("RtlSemanticsTest.kt")))
check("ComposeSmokeTest exists", any(ROOT.rglob("ComposeSmokeTest.kt")))

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f" — {detail}" if detail and not passed else ""))

passed = sum(1 for _, ok, _ in checks if ok)
print(f"\nV02 static checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
