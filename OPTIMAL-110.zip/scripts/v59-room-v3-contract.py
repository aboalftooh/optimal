#!/usr/bin/env python3
"""Static and executable acceptance gate for OPTIMAL v59 Room v3 source projections."""
from __future__ import annotations

import json
from pathlib import Path
import re
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
SCHEMA_V2 = SCHEMA_DIR / "2.json"
SCHEMA_V3 = SCHEMA_DIR / "3.json"
DATABASE = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt"
DATABASE_MODULE = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt"
MIGRATIONS = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/migration/OptimalDatabaseMigrations.kt"
MIGRATION_SCHEMA = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/migration/VertoRoomV3Schema.kt"
INVOICE = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceProjectionEntity.kt"
CONSTANTS = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/DatabaseConstants.kt"

NEW_TABLES = {
    "verto_invoice_items",
    "verto_maintenance_projections",
    "verto_maintenance_media",
}
NEW_ENTITIES = {
    "VertoInvoiceItemEntity",
    "VertoMaintenanceProjectionEntity",
    "VertoMaintenanceMediaEntity",
}
NEW_DAOS = {
    "VertoInvoiceItemDao",
    "VertoMaintenanceProjectionDao",
    "VertoMaintenanceMediaDao",
}
checks: list[tuple[str, bool, str]] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    checks.append((label, condition, detail))
    if not condition:
        raise AssertionError(f"{label}: {detail}")


def read(path: Path) -> str:
    check(f"file:{path.relative_to(ROOT)}", path.is_file())
    return path.read_text(encoding="utf-8")


def entities(schema: dict) -> dict[str, dict]:
    return {entity["tableName"]: entity for entity in schema["database"]["entities"]}


def parse_migration_statements() -> list[str]:
    source = read(MIGRATION_SCHEMA)
    body = source[source.index("listOf(") + len("listOf(") : source.rindex(")")]
    pattern = re.compile(r'"""(.*?)"""\.trimIndent\(\)|"((?:\\.|[^"\\])*)"', re.S)
    statements: list[str] = []
    for triple, quoted in pattern.findall(body):
        if triple:
            statements.append(triple.strip())
        else:
            statements.append(bytes(quoted, "utf-8").decode("unicode_escape"))
    return statements


def install_schema(database: sqlite3.Connection, schema: dict) -> None:
    database.execute("PRAGMA foreign_keys = ON")
    for entity in schema["database"]["entities"]:
        table = entity["tableName"]
        database.execute(entity["createSql"].replace("${TABLE_NAME}", table))
        for index in entity["indices"]:
            database.execute(index["createSql"].replace("${TABLE_NAME}", table))
    database.execute(f"PRAGMA user_version = {schema['database']['version']}")


def table_names(database: sqlite3.Connection) -> set[str]:
    return {
        row[0]
        for row in database.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' AND name NOT IN ('android_metadata','room_master_table')"
        )
    }


def column_shape(database: sqlite3.Connection, table: str) -> list[tuple[str, str, bool, int, object]]:
    return [(row[1], row[2], bool(row[3]), int(row[5]), row[4]) for row in database.execute(f"PRAGMA table_info(`{table}`)")]


def expected_column_shape(entity: dict) -> list[tuple[str, str, bool, int, object]]:
    primary = set(entity["primaryKey"]["columnNames"])
    return [
        (
            field["columnName"],
            field["affinity"],
            bool(field["notNull"]),
            1 if field["columnName"] in primary else 0,
            field.get("defaultValue"),
        )
        for field in entity["fields"]
    ]


def index_shape(database: sqlite3.Connection, table: str) -> dict[str, tuple[bool, tuple[str, ...]]]:
    result: dict[str, tuple[bool, tuple[str, ...]]] = {}
    for _, name, unique, *_ in database.execute(f"PRAGMA index_list(`{table}`)"):
        if name.startswith("sqlite_autoindex_"):
            continue
        columns = tuple(row[2] for row in database.execute(f"PRAGMA index_info(`{name}`)"))
        result[name] = (bool(unique), columns)
    return result


def expected_index_shape(entity: dict) -> dict[str, tuple[bool, tuple[str, ...]]]:
    return {
        index["name"]: (bool(index["unique"]), tuple(index["columnNames"]))
        for index in entity["indices"]
    }


def rejected(database: sqlite3.Connection, sql: str) -> bool:
    try:
        database.execute(sql)
    except sqlite3.IntegrityError:
        return True
    return False


schema2 = json.loads(read(SCHEMA_V2))
schema3 = json.loads(read(SCHEMA_V3))
e2 = entities(schema2)
e3 = entities(schema3)
check("schema:v2-retained", schema2["database"]["version"] == 2)
check("schema:v3-published", schema3["database"]["version"] == 3)
check("schema:26-tables", len(e3) == 26, str(len(e3)))
check("schema:three-new-tables", set(e3) - set(e2) == NEW_TABLES, str(set(e3) - set(e2)))
for table in set(e2) - {"verto_invoice_projections"}:
    check(f"schema:v2-table-unchanged:{table}", e2[table] == e3[table])

invoice2 = e2["verto_invoice_projections"]
invoice3 = e3["verto_invoice_projections"]
fields2 = {field["columnName"] for field in invoice2["fields"]}
fields3 = {field["columnName"]: field for field in invoice3["fields"]}
check("invoice:only-contract-fields-added", set(fields3) - fields2 == {"currencyCode", "contractVersion"})
check("invoice:currency-default", fields3["currencyCode"].get("defaultValue") == "'SDG'")
check("invoice:contract-default", fields3["contractVersion"].get("defaultValue") == "22")

source = read(DATABASE)
check("database:version-3", "version = 3" in source)
for entity in NEW_ENTITIES:
    check(f"database:entity:{entity}", f"{entity}::class" in source)
for dao in NEW_DAOS:
    method = dao[0].lower() + dao[1:]
    check(f"database:dao:{dao}", f"abstract fun {method}()" in source)

module = read(DATABASE_MODULE)
check("migration:registered-v2-v3", "OptimalDatabaseMigrations.MIGRATION_2_3" in module)
check("migration:no-destructive-fallback", "fallbackToDestructiveMigration" not in module)
migrations = read(MIGRATIONS)
check("migration:object-2-3", "object : Migration(2, 3)" in migrations)
check("migration:delegates-schema", "VertoRoomV3Schema.statements.forEach(database::execSQL)" in migrations)

invoice_source = read(INVOICE)
check("invoice:source-currency", '@ColumnInfo(defaultValue = "\'SDG\'")' in invoice_source)
check("invoice:source-contract", '@ColumnInfo(defaultValue = "22")' in invoice_source)
constants = read(CONSTANTS)
check("cursor:invoice-feed-key", 'VERTO_INVOICES_V23_CURSOR = "VERTO_INVOICES_V23"' in constants)
check("cursor:maintenance-feed-key", 'VERTO_MAINTENANCE_V23_CURSOR = "VERTO_MAINTENANCE_V23"' in constants)

for name in NEW_ENTITIES:
    entity_source = read(ROOT / f"core/database/src/main/java/com/optimal/fleet/core/database/entity/verto/{name}.kt")
    check(f"entity:pure:{name}", "androidx.room" in entity_source and "feature." not in entity_source)
for name in NEW_DAOS:
    dao_source = read(ROOT / f"core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/{name}.kt")
    check(f"dao:company-scope:{name}", "companyId" in dao_source)

item_dao = read(ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoInvoiceItemDao.kt")
media_dao = read(ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceMediaDao.kt")
for token in ["@Transaction", "replaceSnapshot", "deleteSnapshot", "duplicate source identities", "crosses its company"]:
    check(f"snapshot:invoice:{token}", token in item_dao)
for token in ["@Transaction", "replaceSnapshot", "deleteSnapshot", 'it.kind == "IMAGE"', "duplicate source identities", "crosses its company"]:
    check(f"snapshot:maintenance:{token}", token in media_dao)

statements = parse_migration_statements()
check("migration:two-alter-statements", sum(sql.upper().startswith("ALTER TABLE") for sql in statements) == 2, str(len(statements)))
check("migration:three-create-table-statements", sum(sql.upper().startswith("CREATE TABLE") for sql in statements) == 3, str(len(statements)))
check("migration:sixteen-index-statements", sum(" INDEX " in sql.upper() for sql in statements) == 16, str(len(statements)))
check("migration:total-statements", len(statements) == 21, str(len(statements)))

with tempfile.TemporaryDirectory(prefix="optimal-v59-room-") as directory:
    database = sqlite3.connect(Path(directory) / "optimal.db")
    try:
        install_schema(database, schema2)
        database.execute(
            "INSERT INTO companies(id,remoteId,name,createdAtEpochMillis,updatedAtEpochMillis,syncStatus,currencyCode,isVertoLinked) "
            "VALUES('company-a','remote-company-a','A',1,1,'SYNCED','SDG',1)"
        )
        database.execute(
            "INSERT INTO companies(id,remoteId,name,createdAtEpochMillis,updatedAtEpochMillis,syncStatus,currencyCode,isVertoLinked) "
            "VALUES('company-b','remote-company-b','B',1,1,'SYNCED','SDG',1)"
        )
        invoice_insert = (
            "INSERT INTO verto_invoice_projections(id,companyId,vertoInvoiceId,vertoOrganizationId,vertoClientId,"
            "invoiceNumber,invoiceType,description,category,totalMinor,paidMinor,remainingMinor,partsCostMinor,serviceCostMinor,"
            "sourceStatus,voided,invoiceDateEpochMillis,sourceUpdatedAtEpochMillis,cachedAtEpochMillis,requiresVehicleLink) VALUES"
        )
        database.execute(invoice_insert + "('invoice-a','company-a','remote-invoice-a','org-a','client-a','A-1','SALE',NULL,NULL,1000,400,600,700,300,'ACTIVE',0,10,20,20,0)")
        database.execute(invoice_insert + "('invoice-b','company-b','remote-invoice-b','org-b','client-b','B-1','SALE',NULL,NULL,1000,400,600,700,300,'ACTIVE',0,10,20,20,0)")
        for statement in statements:
            database.execute(statement)
        database.execute("PRAGMA user_version = 3")

        check("sqlite:table-set", table_names(database) == set(e3), str(table_names(database) ^ set(e3)))
        for table in NEW_TABLES | {"verto_invoice_projections"}:
            check(f"sqlite:columns:{table}", column_shape(database, table) == expected_column_shape(e3[table]))
            check(f"sqlite:indices:{table}", index_shape(database, table) == expected_index_shape(e3[table]))
        check("sqlite:old-invoices-preserved", database.execute("SELECT COUNT(*) FROM verto_invoice_projections").fetchone()[0] == 2)
        check("sqlite:legacy-currency-default", database.execute("SELECT currencyCode FROM verto_invoice_projections WHERE id='invoice-a'").fetchone()[0] == "SDG")
        check("sqlite:legacy-contract-default", database.execute("SELECT contractVersion FROM verto_invoice_projections WHERE id='invoice-a'").fetchone()[0] == 22)

        item_sql = (
            "INSERT INTO verto_invoice_items VALUES('item-a','company-a','invoice-a','source-item-a','Filter','GOODS','2.5',200,500,0,20)"
        )
        database.execute(item_sql)
        database.execute(
            "INSERT INTO verto_maintenance_projections VALUES('maintenance-a','company-a','source-maintenance-a',"
            "'remote-invoice-a','remote-vehicle-a','Hilux','1234','Driver','Service',15000,'COMPLETED',0,30,40,40)"
        )
        database.execute(
            "INSERT INTO verto_maintenance_media VALUES('media-a','company-a','maintenance-a','source-media-a',"
            "'IMAGE','attachment-a','image/jpeg',1024,0)"
        )
        check("sqlite:cross-company-item-rejected", rejected(database,
            "INSERT INTO verto_invoice_items VALUES('item-cross','company-b','invoice-a','source-item-cross','X','GOODS','1',1,1,0,20)"))
        check("sqlite:duplicate-item-rejected", rejected(database,
            "INSERT INTO verto_invoice_items VALUES('item-dup','company-a','invoice-a','source-item-a','X','GOODS','1',1,1,1,20)"))
        check("sqlite:cross-company-media-rejected", rejected(database,
            "INSERT INTO verto_maintenance_media VALUES('media-cross','company-b','maintenance-a','source-media-cross','IMAGE','attachment-x',NULL,NULL,0)"))
        check("sqlite:duplicate-maintenance-source-rejected", rejected(database,
            "INSERT INTO verto_maintenance_projections VALUES('maintenance-b','company-b','source-maintenance-a','remote-invoice-b','remote-vehicle-b',NULL,NULL,NULL,NULL,NULL,'COMPLETED',0,NULL,41,41)"))
        database.execute(
            "INSERT INTO verto_remote_cursors VALUES('cursor-invoice-a','company-a','VERTO_INVOICES_V23',NULL,40,'remote-invoice-a',40)"
        )
        database.execute(
            "INSERT INTO verto_remote_cursors VALUES('cursor-maintenance-a','company-a','VERTO_MAINTENANCE_V23',NULL,40,'source-maintenance-a',40)"
        )
        check("sqlite:independent-feed-cursors", database.execute("SELECT COUNT(*) FROM verto_remote_cursors WHERE companyId='company-a'").fetchone()[0] == 2)
        check("sqlite:foreign-keys-clean", database.execute("PRAGMA foreign_key_check").fetchall() == [])
        check("sqlite:quick-check", database.execute("PRAGMA quick_check(1)").fetchone()[0] == "ok")
    finally:
        database.close()

test_expectations = {
    "VertoRoomV3MigrationTest.kt": ["MIGRATION_2_3", "company-a", "company-b"],
    "VertoRoomV3ProcessRecreationTest.kt": [
        "MIGRATION_2_3",
        "RoomTestData.a.companyId",
        "VERTO_INVOICES_V23_CURSOR",
        "VERTO_MAINTENANCE_V23_CURSOR",
    ],
}
for test_name, tokens in test_expectations.items():
    test = read(ROOT / f"core/database/src/androidTest/java/com/optimal/fleet/core/database/{test_name}")
    for token in tokens:
        check(f"test:{test_name}:{token}", token in test)

build = read(ROOT / "build.gradle.kts")
check("gradle:v59-gate-registered", "vertoRoomV3ContractCheck" in build)
check("gradle:static-quality-depends-v59", "vertoRoomV3ContractCheck," in build)
check("android:version-stable", "versionCode = 32" in read(ROOT / "app/build.gradle.kts"))
check("backend:no-v59-migration", not any((ROOT / "supabase/migrations").glob("*v59*")))
print(f"v59 Room v3 contract: {len(checks)}/{len(checks)} PASS")
