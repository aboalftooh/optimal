#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$(mktemp -d)"
trap 'rm -rf "$OUT_DIR"' EXIT
mkdir -p "$OUT_DIR/stubs/org/junit/rules" "$OUT_DIR/stubs/org/junit/runner" "$OUT_DIR/stubs/org/junit" "$OUT_DIR/stubs/kotlinx/coroutines/test"
cat > "$OUT_DIR/stubs/org/junit/Test.kt" <<'STUB'
package org.junit
@Target(AnnotationTarget.FUNCTION)
annotation class Test
object Assert {
    @JvmStatic fun assertEquals(expected: Any?, actual: Any?) = Unit
    @JvmStatic fun assertNull(actual: Any?) = Unit
    @JvmStatic fun assertNotNull(actual: Any?) = Unit
}
STUB
cat > "$OUT_DIR/stubs/org/junit/runner/Description.kt" <<'STUB'
package org.junit.runner
class Description
STUB
cat > "$OUT_DIR/stubs/org/junit/rules/TestWatcher.kt" <<'STUB'
package org.junit.rules
import org.junit.runner.Description
open class TestWatcher {
    protected open fun starting(description: Description) = Unit
    protected open fun finished(description: Description) = Unit
}
STUB
cat > "$OUT_DIR/stubs/kotlinx/coroutines/test/TestApi.kt" <<'STUB'
package kotlinx.coroutines.test
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
open class TestDispatcher : CoroutineDispatcher() {
    override fun dispatch(context: CoroutineContext, block: Runnable) = block.run()
}
class StandardTestDispatcher : TestDispatcher()
fun Dispatchers.setMain(dispatcher: TestDispatcher) = Unit
fun Dispatchers.resetMain() = Unit
fun runTest(block: suspend () -> Unit) = Unit
STUB
KOTLINC_BIN="$(readlink -f "$(command -v kotlinc)")"
KOTLIN_LIB_DIR="$(cd "$(dirname "$KOTLINC_BIN")/../lib" && pwd)"
COROUTINES_JAR="$KOTLIN_LIB_DIR/kotlinx-coroutines-core-jvm.jar"

kotlinc \
  "$OUT_DIR/stubs/org/junit/Test.kt" \
  "$OUT_DIR/stubs/org/junit/runner/Description.kt" \
  "$OUT_DIR/stubs/org/junit/rules/TestWatcher.kt" \
  "$OUT_DIR/stubs/kotlinx/coroutines/test/TestApi.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditContracts.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/transaction/AtomicWriteTransactionRunner.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/time/MutableTestClock.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/coroutine/MainDispatcherRule.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/contract/TenantRepositoryContract.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fixture/CoreFixtures.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fixture/SequenceValues.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fake/MutableSessionReader.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fake/RecordingPorts.kt" \
  "$ROOT_DIR/scripts/v36-testing-harness.kt" \
  -cp "$COROUTINES_JAR" \
  -include-runtime \
  -d "$OUT_DIR/v36-testing-harness.jar"

java -cp "$OUT_DIR/v36-testing-harness.jar:$COROUTINES_JAR" V36_testing_harnessKt
