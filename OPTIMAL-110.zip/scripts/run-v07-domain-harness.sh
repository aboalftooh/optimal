#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/javax/inject"
cat > "$TEMP/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
STUB
kotlinc \
  "$TEMP/javax/inject/Inject.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationType.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/complete/MaintenanceCompletion.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/complete/MaintenanceCompletionValidation.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/MaintenanceFollowUp.kt" \
  "$ROOT/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/MaintenanceFollowUpClassifier.kt" \
  "$ROOT/scripts/v07-domain-harness.kt" \
  -include-runtime -d "$TEMP/v07-harness.jar"
java -jar "$TEMP/v07-harness.jar"
