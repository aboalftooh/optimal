#!/usr/bin/env python3
import sqlite3

conn = sqlite3.connect(":memory:")
conn.execute("PRAGMA foreign_keys = ON")
conn.executescript("""
CREATE TABLE companies(id TEXT PRIMARY KEY NOT NULL);
CREATE TABLE local_users(
 id TEXT PRIMARY KEY NOT NULL,
 companyId TEXT NOT NULL,
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX index_local_users_id_companyId ON local_users(id, companyId);
CREATE TABLE vehicles(
 id TEXT PRIMARY KEY NOT NULL,
 companyId TEXT NOT NULL,
 remoteId TEXT,
 name TEXT NOT NULL,
 plateNumber TEXT NOT NULL,
 normalizedPlateNumber TEXT NOT NULL,
 brand TEXT, model TEXT, manufactureYear INTEGER, odometerKm INTEGER,
 department TEXT, driverName TEXT, archivedAtEpochMillis INTEGER,
 createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL,
 syncStatus TEXT NOT NULL,
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX index_vehicles_id_companyId ON vehicles(id, companyId);
CREATE UNIQUE INDEX index_vehicles_companyId_normalizedPlateNumber ON vehicles(companyId, normalizedPlateNumber);
CREATE UNIQUE INDEX index_vehicles_remoteId ON vehicles(remoteId);
CREATE TABLE maintenance_operations(
 id TEXT PRIMARY KEY NOT NULL,
 companyId TEXT NOT NULL,
 vehicleId TEXT NOT NULL,
 remoteId TEXT,
 clientGeneratedId TEXT NOT NULL UNIQUE,
 type TEXT NOT NULL,
 description TEXT NOT NULL,
 status TEXT NOT NULL,
 startedAtEpochMillis INTEGER NOT NULL,
 completedAtEpochMillis INTEGER,
 odometerKm INTEGER,
 partsCostMinor INTEGER NOT NULL,
 serviceCostMinor INTEGER NOT NULL,
 source TEXT NOT NULL,
 createdByUserId TEXT NOT NULL,
 updatedByUserId TEXT NOT NULL,
 createdAtEpochMillis INTEGER NOT NULL,
 updatedAtEpochMillis INTEGER NOT NULL,
 syncState TEXT NOT NULL,
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT,
 FOREIGN KEY(vehicleId, companyId) REFERENCES vehicles(id, companyId) ON DELETE RESTRICT,
 FOREIGN KEY(createdByUserId, companyId) REFERENCES local_users(id, companyId) ON DELETE RESTRICT,
 FOREIGN KEY(updatedByUserId, companyId) REFERENCES local_users(id, companyId) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX index_maintenance_operations_id_companyId ON maintenance_operations(id, companyId);
CREATE TABLE verto_invoice_projections(
 id TEXT PRIMARY KEY NOT NULL,
 companyId TEXT NOT NULL,
 vertoInvoiceId TEXT NOT NULL UNIQUE,
 requiresVehicleLink INTEGER NOT NULL,
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
);
""")

# Migration 7 -> 8
conn.executescript("""
ALTER TABLE vehicles ADD COLUMN vin TEXT;
ALTER TABLE vehicles ADD COLUMN normalizedVin TEXT;
CREATE UNIQUE INDEX index_vehicles_companyId_normalizedVin ON vehicles(companyId, normalizedVin);
CREATE UNIQUE INDEX index_verto_invoice_projections_id_companyId ON verto_invoice_projections(id, companyId);
CREATE TABLE verto_invoice_maintenance_links(
 id TEXT PRIMARY KEY NOT NULL,
 companyId TEXT NOT NULL,
 invoiceProjectionId TEXT NOT NULL,
 vehicleId TEXT NOT NULL,
 maintenanceOperationId TEXT NOT NULL,
 linkMethod TEXT NOT NULL,
 serviceMode TEXT NOT NULL,
 linkedByUserId TEXT NOT NULL,
 linkedAtEpochMillis INTEGER NOT NULL,
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE,
 FOREIGN KEY(invoiceProjectionId, companyId) REFERENCES verto_invoice_projections(id, companyId) ON DELETE CASCADE,
 FOREIGN KEY(vehicleId, companyId) REFERENCES vehicles(id, companyId) ON DELETE RESTRICT,
 FOREIGN KEY(maintenanceOperationId, companyId) REFERENCES maintenance_operations(id, companyId) ON DELETE RESTRICT,
 FOREIGN KEY(linkedByUserId, companyId) REFERENCES local_users(id, companyId) ON DELETE RESTRICT
);
CREATE INDEX index_verto_invoice_maintenance_links_companyId ON verto_invoice_maintenance_links(companyId);
CREATE UNIQUE INDEX index_verto_invoice_maintenance_links_invoiceProjectionId ON verto_invoice_maintenance_links(invoiceProjectionId);
CREATE INDEX index_verto_invoice_maintenance_links_invoiceProjectionId_companyId ON verto_invoice_maintenance_links(invoiceProjectionId, companyId);
CREATE INDEX index_verto_invoice_maintenance_links_vehicleId_companyId ON verto_invoice_maintenance_links(vehicleId, companyId);
CREATE INDEX index_verto_invoice_maintenance_links_maintenanceOperationId_companyId ON verto_invoice_maintenance_links(maintenanceOperationId, companyId);
CREATE INDEX index_verto_invoice_maintenance_links_linkedByUserId_companyId ON verto_invoice_maintenance_links(linkedByUserId, companyId);
CREATE TABLE verto_invoice_link_audit(
 id TEXT PRIMARY KEY NOT NULL,
 companyId TEXT NOT NULL,
 invoiceProjectionId TEXT NOT NULL,
 vehicleId TEXT NOT NULL,
 maintenanceOperationId TEXT NOT NULL,
 actorUserId TEXT NOT NULL,
 action TEXT NOT NULL,
 linkMethod TEXT NOT NULL,
 serviceMode TEXT NOT NULL,
 createdAtEpochMillis INTEGER NOT NULL,
 FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE,
 FOREIGN KEY(invoiceProjectionId) REFERENCES verto_invoice_projections(id) ON DELETE CASCADE
);
CREATE INDEX index_verto_invoice_link_audit_companyId ON verto_invoice_link_audit(companyId);
CREATE INDEX index_verto_invoice_link_audit_invoiceProjectionId ON verto_invoice_link_audit(invoiceProjectionId);
CREATE INDEX index_verto_invoice_link_audit_invoiceProjectionId_companyId ON verto_invoice_link_audit(invoiceProjectionId, companyId);
CREATE INDEX index_verto_invoice_link_audit_vehicleId ON verto_invoice_link_audit(vehicleId);
CREATE INDEX index_verto_invoice_link_audit_maintenanceOperationId ON verto_invoice_link_audit(maintenanceOperationId);
CREATE INDEX index_verto_invoice_link_audit_companyId_createdAtEpochMillis ON verto_invoice_link_audit(companyId, createdAtEpochMillis);
""")

checks = 0
def ok(name, condition):
    global checks
    if not condition:
        raise AssertionError(name)
    checks += 1
    print(f"PASS: {name}")

def vehicle_values(i, company, remote, plate, odo, vin=None):
    return (i, company, remote, i, plate, plate.replace('-', ''), None, None, None, odo, None, None, None, 1, 1, 'PENDING', vin, vin)

for company, user in [("c1", "u1"), ("c2", "u2")]:
    conn.execute("INSERT INTO companies VALUES (?)", (company,))
    conn.execute("INSERT INTO local_users VALUES (?,?)", (user, company))
conn.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", vehicle_values("v1", "c1", "rv1", "12-34", 100, "VIN1"))
conn.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", vehicle_values("v2", "c2", "rv2", "12-34", 200, "VIN1"))
ok("same VIN allowed in different companies", conn.execute("SELECT COUNT(*) FROM vehicles").fetchone()[0] == 2)

try:
    conn.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", vehicle_values("v3", "c1", "rv3", "99", 0, "VIN1"))
    duplicate_vin = False
except sqlite3.IntegrityError:
    duplicate_vin = True
ok("duplicate VIN blocked within company", duplicate_vin)

for op, company, vehicle, user, status, kind in [
    ("op1", "c1", "v1", "u1", "IN_PROGRESS", "PARTS_ONLY"),
    ("op2", "c2", "v2", "u2", "COMPLETED", "FULL_MAINTENANCE"),
]:
    conn.execute(
        "INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (op, company, vehicle, None, f"cg-{op}", kind, op, status, 10, 10 if status == "COMPLETED" else None, None, 10, 20, "VERTO", user, user, 1, 1, "PENDING"),
    )
conn.execute("INSERT INTO verto_invoice_projections VALUES ('inv1','c1','remote-inv1',1)")
conn.execute("INSERT INTO verto_invoice_projections VALUES ('inv2','c2','remote-inv2',1)")
conn.execute("INSERT INTO verto_invoice_maintenance_links VALUES ('l1','c1','inv1','v1','op1','MANUAL','PARTS_ONLY','u1',1)")
ok("valid parts link accepted", conn.execute("SELECT COUNT(*) FROM verto_invoice_maintenance_links").fetchone()[0] == 1)

conn.execute("UPDATE verto_invoice_projections SET requiresVehicleLink=0 WHERE id='inv1' AND companyId='c1'")
ok("projection marked linked", conn.execute("SELECT requiresVehicleLink FROM verto_invoice_projections WHERE id='inv1'").fetchone()[0] == 0)

try:
    conn.execute("INSERT INTO verto_invoice_maintenance_links VALUES ('l2','c1','inv1','v1','op1','MANUAL','PARTS_ONLY','u1',2)")
    duplicate_link = False
except sqlite3.IntegrityError:
    duplicate_link = True
ok("same invoice cannot link twice", duplicate_link)

try:
    conn.execute("INSERT INTO verto_invoice_maintenance_links VALUES ('l3','c1','inv2','v1','op1','MANUAL','PARTS_ONLY','u1',2)")
    cross_invoice = False
except sqlite3.IntegrityError:
    cross_invoice = True
ok("cross-company invoice link blocked", cross_invoice)

try:
    conn.execute("INSERT INTO verto_invoice_maintenance_links VALUES ('l4','c2','inv2','v1','op2','MANUAL','FULL_MAINTENANCE','u2',2)")
    cross_vehicle = False
except sqlite3.IntegrityError:
    cross_vehicle = True
ok("cross-company vehicle link blocked", cross_vehicle)

conn.execute("INSERT INTO verto_invoice_maintenance_links VALUES ('l5','c2','inv2','v2','op2','VIN','FULL_MAINTENANCE','u2',2)")
ok("full maintenance link accepted", conn.execute("SELECT serviceMode FROM verto_invoice_maintenance_links WHERE id='l5'").fetchone()[0] == 'FULL_MAINTENANCE')

conn.execute("INSERT INTO verto_invoice_link_audit VALUES ('a1','c1','inv1','v1','op1','u1','VERTO_INVOICE_LINKED','MANUAL','PARTS_ONLY',3)")
ok("manual link audit stored", conn.execute("SELECT COUNT(*) FROM verto_invoice_link_audit").fetchone()[0] == 1)

conn.execute("UPDATE vehicles SET odometerKm=120 WHERE companyId='c1' AND id='v1' AND (odometerKm IS NULL OR odometerKm < 120)")
ok("newer trusted odometer updates", conn.execute("SELECT odometerKm FROM vehicles WHERE id='v1'").fetchone()[0] == 120)
conn.execute("UPDATE vehicles SET odometerKm=110 WHERE companyId='c1' AND id='v1' AND (odometerKm IS NULL OR odometerKm < 110)")
ok("older odometer does not overwrite", conn.execute("SELECT odometerKm FROM vehicles WHERE id='v1'").fetchone()[0] == 120)

ok("parts operation remains in progress", conn.execute("SELECT status FROM maintenance_operations WHERE id='op1'").fetchone()[0] == 'IN_PROGRESS')
ok("full service appears completed", conn.execute("SELECT status FROM maintenance_operations WHERE id='op2'").fetchone()[0] == 'COMPLETED')
ok("link method retained", conn.execute("SELECT linkMethod FROM verto_invoice_maintenance_links WHERE id='l5'").fetchone()[0] == 'VIN')
ok("invoice link table has unique index", any(row[1] == 'index_verto_invoice_maintenance_links_invoiceProjectionId' and row[2] for row in conn.execute("PRAGMA index_list('verto_invoice_maintenance_links')")))
ok("VIN index is unique", any(row[1] == 'index_vehicles_companyId_normalizedVin' and row[2] for row in conn.execute("PRAGMA index_list('vehicles')")))
ok("foreign keys enabled", conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1)
print(f"\nSQLite v10 checks: {checks}/{checks}")
