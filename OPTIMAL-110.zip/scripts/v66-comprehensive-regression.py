#!/usr/bin/env python3
"""Execute the v66 static/non-Android regression matrix with explicit sharding."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from typing import NamedTuple

ROOT = Path(__file__).resolve().parents[1]


class Gate(NamedTuple):
    label: str
    command: tuple[str, ...]
    timeout_seconds: int = 360


def py(label: str, script: str, *args: str, timeout: int = 360) -> Gate:
    return Gate(label, ("python3", script, *args), timeout)


def sh(label: str, script: str, *args: str, timeout: int = 900) -> Gate:
    return Gate(label, (script, *args), timeout)


SHARDS: dict[str, tuple[Gate, ...]] = {
    "foundation": (
        py("v66-test-inventory", "scripts/v66-test-inventory-contract.py"),
        py("architecture", "scripts/static-architecture-check.py"),
        py("release-security", "scripts/security-release-check.py"),
        py("v37-baseline", "scripts/static-v37-check.py"),
        py("room-v3-baseline", "scripts/generate-room-baseline.py", "--check"),
        py("room-schema-drift", "scripts/room-schema-drift-contract.py"),
        py("backend-v21", "scripts/v21-backend-contract-harness.py"),
    ),
    "legacy": (
        sh("v07-v26-compatible", "./scripts/run-v66-legacy-regressions.sh", timeout=1800),
        sh("v28-v37-compatible", "./scripts/run-v66-v28-v37-regressions.sh", timeout=2400),
    ),
    "backend": (
        py("v39-contract-consistency", "scripts/v39-contract-consistency.py"),
        py("v40-registration", "scripts/v40-registration-contract.py"),
        py("v41-conversation-schema", "scripts/v41-conversation-schema-contract.py"),
        py("v42-message-rpc", "scripts/v42-message-rpc-contract.py"),
        py("v43-attachment-backend", "scripts/v43-attachment-contract.py"),
        py("v44-invoice-feed", "scripts/v44-invoice-feed-contract.py"),
        py("v45-maintenance-feed", "scripts/v45-maintenance-feed-contract.py"),
        py("v46-backend-v23", "scripts/verto-backend-contract-v23-harness.py"),
        py("v47-feature-architecture", "scripts/v47-verto-feature-architecture.py"),
        py("v48-room-v2", "scripts/v48-room-v2-contract.py"),
    ),
    "verto": (
        py("v49-chat-permissions", "scripts/v49-verto-chat-permissions-contract.py"),
        py("v50-permission-management", "scripts/v50-verto-permission-management-contract.py"),
        sh("v50-permission-harness", "./scripts/run-v50-member-permission-harness.sh"),
        sh("v50-member-mapper-compile", "./scripts/run-v32-member-mapper-compile.sh"),
        sh("v50-member-remote-compile", "./scripts/run-v32-member-remote-compile.sh"),
        sh("v50-member-repository-compile", "./scripts/run-v32-member-repository-compile.sh"),
        py("v51-home-entry", "scripts/v51-verto-home-entry-contract.py"),
        sh("v51-entry-harness", "./scripts/run-v51-verto-entry-harness.sh"),
        py("v52-chat-read-model", "scripts/v52-verto-chat-read-model-contract.py"),
        sh("v52-chat-harness", "./scripts/run-v52-verto-chat-harness.sh"),
        sh("v52-chat-syntax", "./scripts/run-v52-verto-chat-syntax-check.sh"),
        py("v53-message-sync", "scripts/v53-verto-message-sync-contract.py"),
        sh("v53-message-sync-harness", "./scripts/run-v53-verto-message-sync-harness.sh"),
        sh("v53-sync-syntax", "./scripts/run-v53-verto-sync-syntax-check.sh"),
        py("v54-text-outbox", "scripts/v54-verto-text-outbox-contract.py"),
        py("v54-text-outbox-harness", "scripts/v54-verto-text-outbox-harness.py"),
        sh("v54-text-syntax", "./scripts/run-v54-verto-text-syntax-check.sh"),
        py("v55-local-attachment", "scripts/v55-verto-attachment-contract.py"),
        py("v55-local-attachment-harness", "scripts/v55-verto-attachment-harness.py"),
        sh("v55-attachment-syntax", "./scripts/run-v55-verto-attachment-syntax-check.sh"),
        sh("v55-importer-compile", "./scripts/run-v55-verto-importer-compile-smoke.sh"),
        py("v56-audio", "scripts/v56-verto-audio-contract.py"),
        py("v56-audio-harness", "scripts/v56-verto-audio-harness.py"),
        sh("v56-audio-syntax", "./scripts/run-v56-verto-audio-syntax-check.sh"),
        sh("v56-audio-compile", "./scripts/run-v56-verto-audio-compile-smoke.sh"),
        py("v57-attachment-transfer", "scripts/v57-verto-attachment-transfer-contract.py"),
        py("v57-attachment-transfer-harness", "scripts/v57-verto-attachment-transfer-harness.py"),
        py("v58-daily-cycle", "scripts/v58-verto-daily-cycle-contract.py"),
        sh("v58-daily-cycle-harness", "./scripts/run-v58-verto-daily-cycle-harness.sh"),
        py("v59-room-v3", "scripts/v59-room-v3-contract.py"),
        py("v60-source-ingestion", "scripts/v60-verto-source-ingestion-contract.py"),
        py("v60-source-ingestion-harness", "scripts/v60-verto-source-ingestion-harness.py"),
        py("v61-maintenance-import", "scripts/v61-verto-maintenance-import-contract.py"),
        py("v61-maintenance-import-harness", "scripts/v61-verto-maintenance-import-harness.py"),
        py("v62-manual-link-retirement", "scripts/v62-manual-invoice-link-retirement-contract.py"),
        py("v62-manual-link-harness", "scripts/v62-manual-invoice-link-retirement-harness.py"),
        py("v63-invoice-vehicle-history", "scripts/v63-invoice-vehicle-history-contract.py"),
        py("v63-history-harness", "scripts/v63-invoice-vehicle-history-harness.py"),
        py("v64-unified-sync", "scripts/v64-unified-sync-contract.py"),
        py("v64-unified-sync-harness", "scripts/v64-unified-sync-harness.py"),
        py("v64-kotlin-source", "scripts/v64-kotlin-source-check.py"),
        sh("v64-source-syntax", "./scripts/run-v64-source-syntax-check.sh"),
        sh("v64-semantic-compile", "./scripts/run-v64-unified-semantic-compile.sh"),
        py("v65-rls-security", "scripts/v65-rls-isolation-security-contract.py"),
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard", action="append", choices=tuple(SHARDS) + ("all",), help="Shard to run; repeatable. Default: all.")
    parser.add_argument("--keep-going", action="store_true", help="Run remaining gates after a failure.")
    parser.add_argument("--report", type=Path, help="Write a JSON summary without command output or secrets.")
    parser.add_argument("--start-at", help="Start at this gate label after shard selection.")
    parser.add_argument("--stop-after", help="Stop after this gate label after shard selection.")
    parser.add_argument("--list", action="store_true", help="List selected gates without executing them.")
    return parser.parse_args()


def selected_shards(values: list[str] | None) -> list[str]:
    if not values or "all" in values:
        return list(SHARDS)
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value not in seen:
            result.append(value)
            seen.add(value)
    return result


def main() -> int:
    args = parse_args()
    shard_names = selected_shards(args.shard)
    gates = [(shard, gate) for shard in shard_names for gate in SHARDS[shard]]
    labels = [gate.label for _, gate in gates]
    if args.start_at:
        if args.start_at not in labels:
            raise SystemExit(f"Unknown --start-at label: {args.start_at}")
        gates = gates[labels.index(args.start_at):]
        labels = [gate.label for _, gate in gates]
    if args.stop_after:
        if args.stop_after not in labels:
            raise SystemExit(f"Unknown --stop-after label: {args.stop_after}")
        gates = gates[: labels.index(args.stop_after) + 1]

    if args.list:
        for shard, gate in gates:
            print(f"{shard}\t{gate.label}\t{' '.join(gate.command)}")
        print(f"V66 matrix: {len(gates)} gates across {len(shard_names)} shard(s)")
        return 0

    results: list[dict[str, object]] = []
    failures = 0
    suite_started = time.monotonic()
    for index, (shard, gate) in enumerate(gates, start=1):
        print(f"===== [{index}/{len(gates)}] {shard}:{gate.label} =====", flush=True)
        started = time.monotonic()
        try:
            completed = subprocess.run(
                gate.command,
                cwd=ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=gate.timeout_seconds,
                check=False,
            )
            output = completed.stdout or ""
            if output:
                print(output, end="" if output.endswith("\n") else "\n")
            status = "PASS" if completed.returncode == 0 else "FAIL"
            returncode = completed.returncode
        except subprocess.TimeoutExpired as exc:
            output = (exc.stdout or "") if isinstance(exc.stdout, str) else ""
            if output:
                print(output, end="" if output.endswith("\n") else "\n")
            status = "TIMEOUT"
            returncode = 124
        duration = round(time.monotonic() - started, 3)
        print(f"V66_GATE {status} {shard}:{gate.label} duration={duration}s exit={returncode}", flush=True)
        results.append({"shard": shard, "label": gate.label, "status": status, "exit_code": returncode, "duration_seconds": duration})
        if returncode != 0:
            failures += 1
            if not args.keep_going:
                break

    total_duration = round(time.monotonic() - suite_started, 3)
    summary = {
        "schema_version": 1,
        "session": "v66",
        "selected_shards": shard_names,
        "configured_gate_count": len(gates),
        "executed_gate_count": len(results),
        "passed_gate_count": sum(item["status"] == "PASS" for item in results),
        "failed_gate_count": failures,
        "duration_seconds": total_duration,
        "results": results,
    }
    if args.report:
        report_path = args.report if args.report.is_absolute() else ROOT / args.report
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "V66 comprehensive regression: "
        f"{summary['passed_gate_count']}/{summary['executed_gate_count']} PASS; "
        f"configured={summary['configured_gate_count']}; duration={total_duration}s"
    )
    return 1 if failures or len(results) != len(gates) else 0


if __name__ == "__main__":
    sys.exit(main())
