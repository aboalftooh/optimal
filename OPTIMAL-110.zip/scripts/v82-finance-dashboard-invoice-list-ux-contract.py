#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
paths = {
    'semantics': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/FinancePresentationSemantics.kt',
    'dashboard': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreen.kt',
    'dashboard_components': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt',
    'invoice_list': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt',
    'invoice_components': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListComponents.kt',
    'rows': 'core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalRows.kt',
    'dashboard_tests': 'feature/finance/src/androidTest/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreenTest.kt',
    'invoice_tests': 'feature/finance/src/androidTest/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreenTest.kt',
}
text = {name: (root / rel).read_text() for name, rel in paths.items()}
checks = []

def check(label, cond):
    checks.append((label, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + label)

def sha(rel):
    return hashlib.sha256((root / rel).read_bytes()).hexdigest()

def tree(rel):
    h = hashlib.sha256()
    for f in sorted((root / rel).rglob('*.kt')):
        h.update(str(f.relative_to(root)).encode())
        h.update(b'\0')
        h.update(f.read_bytes())
        h.update(b'\0')
    return h.hexdigest()

for name in ['semantics', 'dashboard', 'dashboard_components', 'invoice_list', 'invoice_components']:
    source = text[name]
    check(f'{name} has no legacy DS import', re.search(r'import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', source) is None)
    check(f'{name} has no AppCard', 'AppCard' not in source)
    check(f'{name} has no direct dp literal', re.search(r'\b\d+(?:\.\d+)?\.dp\b', source) is None)
    check(f'{name} has no raw hex colors', '0xFF' not in source)

for token in ['OptimalSectionHeader', 'FinancialSummarySection', 'AdditionalCostRow', 'FinanceInvoiceRow', 'OptimalLoadingState']:
    check(f'dashboard uses {token}', token in text['dashboard'])
for label in ['الملخص المالي', 'التكاليف الإضافية', 'فواتير Verto']:
    check(f'dashboard section {label}', label in text['dashboard'])
for tag in ['financial-summary', 'refresh-verto-invoices', 'open-additional-cost', 'additional-costs-empty', 'verto-invoices-empty']:
    combined = text['dashboard'] + text['dashboard_components']
    check(f'dashboard tag {tag}', f'"{tag}"' in combined)
for event in ['Refresh', 'OpenAddCost', 'InvoiceSelected']:
    check(f'dashboard event preserved {event}', f'FinanceDashboardUiEvent.{event}' in text['dashboard'])
for token in ['OptimalMetricCard', 'OptimalListRow', 'OptimalStatusBadge', 'OptimalSecondaryButton']:
    check(f'dashboard components use {token}', token in text['dashboard_components'])
for metric in ['عليكم', 'دفعتم', 'تكلفة القطع', 'تكلفة الصيانة', 'تكاليف إضافية', 'إجمالي العملية']:
    check(f'dashboard metric {metric}', f'"{metric}"' in text['dashboard_components'])
check('dashboard unlinked state retained', 'unlinked-company-finance' in text['dashboard_components'])
check('dashboard refresh disabled when unlinked', 'enabled = summary.isVertoLinked && !isRefreshing' in text['dashboard_components'])

for token in ['OptimalSearchField', 'OptimalFilterChip', 'InvoiceSummarySection', 'InvoiceListRow', 'OptimalLoadingState', 'OptimalErrorState', 'OptimalEmptyState']:
    check(f'invoice list uses {token}', token in text['invoice_list'])
for label in ['الكل', 'عليكم', 'مدفوعة', 'ملغاة']:
    check(f'invoice filter {label}', f'"{label}"' in text['invoice_list'])
for event in ['SearchChanged', 'ClearSearch', 'FilterChanged', 'Refresh', 'Retry', 'LoadMore', 'InvoiceSelected']:
    check(f'invoice event preserved {event}', f'InvoiceListUiEvent.{event}' in text['invoice_list'])
for tag in ['invoice-search', 'invoice-filters', 'invoice-loading', 'invoice-error', 'invoice-empty', 'invoices-load-more', 'invoice-load-more-retry']:
    check(f'invoice list tag {tag}', f'"{tag}"' in text['invoice_list'])
check('invoice append error has retry', 'appendErrorMessage' in text['invoice_list'] and 'invoice-load-more-retry' in text['invoice_list'])
check('invoice paging state preserved', 'state.hasMore || state.isLoadingMore' in text['invoice_list'])

check('semantic amount helper uses typography amount role', 'OptimalTypographyRoles.amount' in text['semantics'])
check('voided invoice maps to danger', 'isVoided) return OptimalStatusTone.Danger' in text['semantics'])
check('paid invoice maps to success', 'OptimalStatusTone.Success' in text['semantics'])
check('outstanding invoice maps to warning', 'OptimalStatusTone.Warning' in text['semantics'])
check('invoice rows use semantic status helper', 'financeInvoiceStatusTone' in text['invoice_components'] and 'financeInvoiceStatusTone' in text['dashboard_components'])
check('invoice rows use semantic money helper', 'FinanceAmountText' in text['invoice_components'] and 'FinanceAmountText' in text['dashboard_components'])

check('section header action modifier is backward compatible', 'actionModifier: Modifier = Modifier' in text['rows'])
check('section header applies action modifier', 'modifier = actionModifier' in text['rows'])

check('dashboard existing add-cost UI test preserved', 'addCostActionOpensTheExistingDialogContract' in text['dashboard_tests'])
check('dashboard metric/status UI coverage added', 'dashboardPrioritizesFinancialMetricsAndSemanticInvoiceStatus' in text['dashboard_tests'])
check('invoice list selection UI coverage added', 'invoiceListUsesV2SearchFiltersAndPreservesSelectionEvent' in text['invoice_tests'])
check('invoice filter UI coverage added', 'invoiceFilterPreservesExistingFilterContract' in text['invoice_tests'])

protected_files = {
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardContract.kt': '5e683ce7edf66627cfa801b6bb64d2de4d5b5e42ab72ac2d12d181a26ed1d256',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardViewModel.kt': '5a2b5745b9bf0875c103a810adfd5e48d8fba2bb2222344e42638a1e663ffd44',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardRoute.kt': '410617f86e4f5ebe8cbf4646d383fb02c0a02a548d69fd06f3263b73e00775ff',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/AddCostDialog.kt': '5039feaa8db946daae23481e008d7cf36b997db4e16ec44e567549044dba3f5e',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListContract.kt': 'f2e2da2e64b1e1fc5ccc13e00cff8a903a0c874afe3d59e32d4d4149ff2bd579',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt': '5e1a51d4e262dbaa6f44c1588de71c5b1fc2fde59818f9152d5b57826d370a80',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt': '1e5b7d34fbf6b9bb2f469b54163b1aa7e5731ee41cc7d177dd80fe6d17f3966f',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt': '5996c5f0695ad26a506f04995c2ef6a1c99fe56387080a8a61bd3cf871991ac6',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt': '66a37dadaade9d7e59ea7220f24e4d403273bab52682426b0cf226aa3fe28297',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt': 'a34b1d68f660536e19311b907cf352d2c6fd99f32480fe3c7493b4a4a41e5c43',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt': 'ccd925b24d9e64767ddb313fc503c297672ca3f4bdbbc17c30bf67004376abfc',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt': 'caa42fbea7bb0d8b83bf9dfdd8c3c79ea21158f39ecc01a1714f1d0adbefd675',
}
protected_trees = {
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain': 'cf35dc56144df412c34ad3369e96f66df33a2943ccbd169ef5ffba23e6314719',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data': '22274749f891e4fd08e614be3bd0ae7e17da0ad5fc9e6d1a03de63ebc84cce1e',
}
for rel, digest in protected_files.items():
    check('protected file unchanged ' + rel, sha(rel) == digest)
for rel, digest in protected_trees.items():
    check('protected tree unchanged ' + rel, tree(rel) == digest)

failed = [item for item in checks if not item[1]]
print(f'v82 Finance Dashboard + Invoice List UX contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
