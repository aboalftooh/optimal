#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ALLOWLIST_PATH = ROOT / "scripts/design-system-migration-allowlist.txt"

RULES: list[tuple[str, re.Pattern[str]]] = [
    ("raw-color", re.compile(r"\bColor\s*\(\s*0x[0-9A-Fa-f]+")),
    ("local-font-family", re.compile(r"\b(?:fontFamily\s*=|FontFamily\s*\()")),
    ("raw-font-size", re.compile(r"\bfontSize\s*=\s*[^,\n]+\.sp\b")),
    ("raw-rounded-shape", re.compile(r"\bRoundedCornerShape\s*\(")),
    ("raw-dp", re.compile(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b")),
    ("direct-material-button", re.compile(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(")),
    ("direct-material-field", re.compile(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(")),
    ("direct-alert-dialog", re.compile(r"(?<![A-Za-z0-9_])AlertDialog\s*\(")),
]

CANONICAL_NAMES = [
    "OptimalSurfaceCard", "OptimalMetricCard", "OptimalActionCard", "OptimalFormSection",
    "OptimalListRow", "OptimalSectionHeader", "OptimalLoadingState", "OptimalEmptyState",
    "OptimalErrorState", "OptimalDialog", "OptimalConfirmationDialog",
]
CANONICAL_REIMPLEMENTATION = re.compile(
    r"\bfun\s+(?:" + "|".join(map(re.escape, CANONICAL_NAMES)) + r")\s*\("
)


def feature_ui_files() -> list[Path]:
    result: list[Path] = []
    for path in sorted((ROOT / "feature").glob("**/src/main/java/**/*.kt")):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "@Composable" in text:
            result.append(path)
    return result


def load_allowlist() -> set[str]:
    if not ALLOWLIST_PATH.is_file():
        raise SystemExit(f"Missing allowlist: {ALLOWLIST_PATH.relative_to(ROOT)}")
    lines = ALLOWLIST_PATH.read_text(encoding="utf-8").splitlines()
    return {line.strip() for line in lines if line.strip() and not line.lstrip().startswith("#")}


def line_number(text: str, start: int) -> int:
    return text.count("\n", 0, start) + 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", action="store_true", help="SESSION-97 gate: require every current feature UI file to be allowlisted")
    args = parser.parse_args()

    files = feature_ui_files()
    rels = {p.relative_to(ROOT).as_posix() for p in files}
    allow = load_allowlist()

    unknown = sorted(allow - rels)
    if unknown:
        print("FAIL: allowlist contains non-feature-UI or missing paths:")
        for path in unknown:
            print(f"  {path}")
        return 1

    if args.baseline:
        missing = sorted(rels - allow)
        if missing:
            print("FAIL: SESSION-97 baseline allowlist does not cover all feature UI files:")
            for path in missing:
                print(f"  {path}")
            return 1

    active: list[tuple[str, str, int, str]] = []
    allowed: list[tuple[str, str, int, str]] = []
    for path in files:
        rel = path.relative_to(ROOT).as_posix()
        text = path.read_text(encoding="utf-8", errors="ignore")
        for rule_name, pattern in RULES:
            for match in pattern.finditer(text):
                record = (rel, rule_name, line_number(text, match.start()), match.group(0).strip())
                (allowed if rel in allow else active).append(record)
        for match in CANONICAL_REIMPLEMENTATION.finditer(text):
            record = (rel, "canonical-component-reimplementation", line_number(text, match.start()), match.group(0).strip())
            (allowed if rel in allow else active).append(record)

    print(f"Feature Compose UI files scanned: {len(files)}")
    print(f"Allowlisted not-yet-migrated files: {len(allow)}")
    print(f"Allowlisted violations observed: {len(allowed)}")
    for rel, rule, line, sample in allowed:
        print(f"ALLOWLIST {rule}: {rel}:{line}: {sample}")
    print(f"Active violations: {len(active)}")
    for rel, rule, line, sample in active:
        print(f"FAIL {rule}: {rel}:{line}: {sample}")

    if active:
        return 1
    print("PASS: no compliance violations exist outside the migration allowlist.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
