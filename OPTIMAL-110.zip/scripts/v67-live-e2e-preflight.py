#!/usr/bin/env python3
"""Fail-closed preflight for the external v67 E2E environment.

No secret value is printed. This tool only reports which prerequisite names are
missing before a human-operated, isolated Staging acceptance run can start.
"""
from __future__ import annotations

import os
import shutil
import sys

REQUIRED_ENV = [
    "V65_DATABASE_URL",
    "V67_SUPABASE_URL",
    "V67_SUPABASE_ANON_KEY",
    "V67_OWNER_A_EMAIL",
    "V67_OWNER_B_EMAIL",
    "V67_EMPLOYEE_EMAIL",
    "V67_VERTO_TEST_CLIENT_ID",
]
REQUIRED_TOOLS = ["psql", "java"]

missing_env = [name for name in REQUIRED_ENV if not os.environ.get(name, "").strip()]
missing_tools = [name for name in REQUIRED_TOOLS if shutil.which(name) is None]

if missing_env:
    print("E2E BLOCKED: missing environment variables: " + ", ".join(missing_env))
if missing_tools:
    print("E2E BLOCKED: missing executables: " + ", ".join(missing_tools))
if missing_env or missing_tools:
    sys.exit(2)

print("E2E PREFLIGHT PASS: external credentials and required tools are present")
print("Continue with docs/manual-test-scenarios-v67.md; no secret values were printed.")
