#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLINC_BIN="$(readlink -f "$(command -v kotlinc)")"
KOTLIN_LIB_DIR="$(cd "$(dirname "$KOTLINC_BIN")/../lib" && pwd)"
COROUTINES_JAR="$KOTLIN_LIB_DIR/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs/javax/inject" "$TMP_DIR/stubs/kotlinx/serialization" "$TMP_DIR/stubs/com/optimal/fleet/feature/auth/data/remote"
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
@Target(AnnotationTarget.CLASS)
annotation class Singleton
STUB
cat > "$TMP_DIR/stubs/kotlinx/serialization/Serialization.kt" <<'STUB'
package kotlinx.serialization
@Target(AnnotationTarget.CLASS)
annotation class Serializable
@Target(AnnotationTarget.PROPERTY)
annotation class SerialName(val value: String)
STUB
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/auth/data/remote/MapperDtos.kt" <<'STUB'
package com.optimal.fleet.feature.auth.data.remote
internal data class JoinCodeProfileDto(val companyId: String, val companyName: String, val status: String)
internal data class VertoCompanyCodeProfileDto(val vertoClientId: String, val companyName: String, val status: String)
STUB
kotlinc -cp "$COROUTINES_JAR" \
  "$TMP_DIR/stubs/javax/inject/Inject.kt" \
  "$TMP_DIR/stubs/kotlinx/serialization/Serialization.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/auth/data/remote/MapperDtos.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseAuthSession.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/time/MutableTestClock.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/OnboardingRepository.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/mapper/OnboardingMapper.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/AuthRemoteDataSource.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OnboardingRemoteDataSource.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/LocalSessionStore.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/PendingChallengeStore.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/RemoteProfileStore.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/audit/MembershipAuditPort.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/SupabaseOnboardingRepository.kt" \
  "$ROOT_DIR/scripts/v36-auth-process-death-harness.kt" \
  -include-runtime -d "$TMP_DIR/v36-auth-process-death-harness.jar"
java -cp "$TMP_DIR/v36-auth-process-death-harness.jar:$COROUTINES_JAR" com.optimal.fleet.feature.auth.data.V36_auth_process_death_harnessKt
