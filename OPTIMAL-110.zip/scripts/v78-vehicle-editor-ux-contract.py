#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
base = root / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation"
screen_path = base / "VehicleEditorScreen.kt"
components_path = base / "VehicleEditorComponents.kt"
dialogs_path = base / "VehicleEditorDialogs.kt"
route_path = base / "VehicleEditorRoute.kt"
test_path = root / "feature/vehicles/src/androidTest/java/com/optimal/fleet/feature/vehicles/presentation/VehicleScreensTest.kt"
bottom_actions_path = root / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalBottomActions.kt"

screen = screen_path.read_text()
components = components_path.read_text()
dialogs = dialogs_path.read_text()
route = route_path.read_text()
tests = test_path.read_text()
bottom_actions = bottom_actions_path.read_text()
editor_ui = "\n".join([screen, components, dialogs, route])
checks = []


def check(label: str, condition: bool):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + ": " + label)


def sha256(path: str) -> str:
    return hashlib.sha256((root / path).read_bytes()).hexdigest()


protected = {
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesScreen.kt": "882a36f45a14ff9f05897ba9bcb6153f3ffeb77a819fba32055b719bdabf0ffb",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesComponents.kt": "cd695e1af019d2786370910d02de652642d07c108d9caeff5fc962a040f25db0",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesContract.kt": "79cc6e0c41121497fad8cf486a76132c2a62c5e033b7910ed1ef2e7efe11687e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt": "1fb69e68ec9d9a4fb19ba9950ff5b1645459033c53d0b7c1de307be8a80ea1c8",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt": "c342c80ee0231f1f6d5e2168cb8dd8a066170ca4093b00b408515a56fc9bfaad",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailComponents.kt": "2f54a7d516ef653fb230dfd6e06146e23cbb77597059d4c8899ec84d299b762d",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt": "22a79f67f294eea5ababf7adad925af00f3c40189c83b0a99e975c4e9926a87e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailDialogs.kt": "db64c9645ed4c3c9533e0f126bad21d4015d5158307d806adfe409cd03292de0",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt": "127c40a81e2a8a808117ba77ce33ad5357b173831f479452874116c5ce92932a",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt": "a9c2fa1085e1a8154768c1975b80b8fd20907591a30da5fcc1216a8410f12357",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailViewModel.kt": "f8fcd64282d0c8ce414a61130e7207c84fa71e5dd8ed3e056b5b43605604c589",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorContract.kt": "0d8f7e2ac8fcae26cd0a9fe2ef62cadf314b782fae66e0a1a3be29cc85c806a8",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorViewModel.kt": "4fb687f8dcdf6cad2dfce840b3696d69b29963e5fd6e4eca37b9732a00aeb492",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/navigation/VehiclesNavigation.kt": "1d40ab4412c0251852c8714db9b2f898517ee2ebf11089c2ee290ecd8056e893",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt": "43a48d6f088044bad462fa4966b14a7b536be1d0a58b882700a621ffbf134e0f",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleDraft.kt": "de8d9108f5ebbaf7ecd1985cfab6eb0ffb65dd560aad626fd65f9ecc00190140",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleValidation.kt": "d631aa06a96f883da0156b1fc70ff54f7e6642984582703144c71cc285af3e59",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/SaveVehicleUseCase.kt": "7fbcf63d6c3da5e8d7cc2d5ec0493bcf606cf019549b538d66698247279fa6c5",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt": "55ccef40d2b60f0e974d9350d063cec27b4690939447df3308b91b9141178393",
}

check("Vehicle Editor screen exists", screen_path.is_file())
check("Vehicle Editor components exist", components_path.is_file())
check("Vehicle Editor dialogs exist", dialogs_path.is_file())
check("Vehicle Editor route exists", route_path.is_file())
check("Vehicles UI test exists", test_path.is_file())

check("screen uses v2 form sections", "component.v2.OptimalFormSection" in screen)
check("screen uses v2 persistent bottom action", "component.v2.OptimalBottomActionBar" in screen)
check("screen uses v2 flat message row", "component.v2.OptimalListRow" in screen)
check("screen uses v2 status badge", "component.v2.OptimalStatusBadge" in screen)
check("fields use v2 OptimalTextField", "component.v2.OptimalTextField" in components)
check("dialog uses v2 OptimalDialog", "component.v2.OptimalDialog" in dialogs)
check("dialog field uses v2 OptimalTextField", "component.v2.OptimalTextField" in dialogs)
check("route uses v2 loading state", "component.v2.OptimalLoadingState" in route)
check("legacy Design System imports removed", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", editor_ui) is None)
check("legacy AppCard removed", "AppCard" not in editor_ui)
check("legacy AppTextField removed", "AppTextField" not in editor_ui)
check("legacy AppDialog removed", re.search(r"\bAppDialog\b", editor_ui) is None)
check("no direct dp literals", re.search(r"\b\d+(?:\.\d+)?\.dp\b", editor_ui) is None)
check("no raw hex colors", "0xFF" not in editor_ui)

check("page horizontal inset token used", "OptimalContentInsets.horizontal" in screen)
check("page vertical inset token used", "OptimalContentInsets.vertical" in screen)
check("section gap token used", "OptimalContentInsets.sectionGap" in screen)
check("field spacing token used", "OptimalSpacing.medium" in screen)
check("page title typography role used", "OptimalTypographyRoles.pageTitle" in screen)
check("body typography role used", "OptimalTypographyRoles.body" in screen)

for section in ["البيانات الأساسية", "مواصفات السيارة", "بيانات التشغيل"]:
    check(f"form section exists: {section}", f'"{section}"' in screen)
check("identity section test tag exists", 'testTag("vehicle-editor-identity-section")' in screen)
check("specs section test tag exists", 'testTag("vehicle-editor-specs-section")' in screen)
check("operation section test tag exists", 'testTag("vehicle-editor-operation-section")' in screen)
check("required-fields explanation exists", '"الاسم ورقم اللوحة مطلوبان لحفظ السيارة."' in screen)
check("optional completion guidance exists", "يمكن إكمال التفاصيل الاختيارية الآن أو لاحقًا." in screen)

check("name remains required", 'label = "اسم أو وصف السيارة *"' in screen)
check("plate remains required", 'label = "رقم اللوحة *"' in screen)
check("VIN remains optional", 'label = "رقم الهيكل VIN — اختياري"' in screen)
check("brand remains free text", "VehicleEditorUiEvent.BrandChanged(it)" in screen)
check("model remains free text", "VehicleEditorUiEvent.ModelChanged(it)" in screen)
check("year remains free text event", "VehicleEditorUiEvent.ManufactureYearChanged(it)" in screen)
check("odometer event preserved", "VehicleEditorUiEvent.OdometerChanged(it)" in screen)
check("department event preserved", "VehicleEditorUiEvent.DepartmentChanged(it)" in screen)
check("driver event preserved", "VehicleEditorUiEvent.DriverChanged(it)" in screen)
check("no invented selector contract", "OptimalSelectionField" not in editor_ui)

check("name test tag preserved", 'tag = "vehicle-name"' in screen)
check("plate test tag preserved", 'tag = "vehicle-plate"' in screen)
check("VIN test tag preserved", 'tag = "vehicle-vin"' in screen)
check("odometer test tag preserved", 'tag = "vehicle-odometer"' in screen)
check("editor root test tag preserved", 'testTag("vehicle-editor")' in screen)
check("loading test tag preserved", 'testTag("vehicle-editor-loading")' in route)
check("lower odometer dialog tag preserved", 'testTag("lower-odometer-dialog")' in dialogs)
check("lower odometer reason tag preserved", 'testTag = "lower-odometer-reason"' in dialogs)
check("lower odometer confirm tag preserved", 'confirmTestTag = "confirm-lower-odometer"' in dialogs)

check("field errors use supporting text", "supportingText = errorText" in components)
check("field error helper maps existing message", "message.takeIf { fieldError == field }" in components)
for field in ["Name", "PlateNumber", "Vin", "ManufactureYear", "Odometer"]:
    check(f"field validation presentation retained: {field}", f"VehicleEditorField.{field}" in screen)
check("lower odometer validation presentation retained", "VehicleEditorField.LowerOdometerReason" in dialogs)
check("non-field failure remains visible", 'title = "تعذر حفظ السيارة"' in screen)
check("non-field failure can be dismissed", "VehicleEditorUiEvent.DismissMessage" in screen)
check("failure is textual not color-only", 'text = "تنبيه"' in screen and "OptimalStatusTone.Danger" in screen)

check("persistent action bar is outside scroll content", screen.find("OptimalBottomActionBar(") > screen.find("verticalScroll(rememberScrollState())"))
check("save event preserved", "VehicleEditorUiEvent.Save" in screen)
check("save disabled while saving", "primaryEnabled = !state.isSaving" in screen)
check("saving label preserved", '"جارٍ الحفظ…"' in screen)
check("save label preserved", '"حفظ السيارة"' in screen)
check("save test tag preserved on primary action", 'primaryModifier = Modifier.testTag("save-vehicle")' in screen)
check("bottom action bar exposes primary modifier", "primaryModifier: Modifier = Modifier" in bottom_actions)
check("bottom action applies primary modifier", "primaryModifier.weight(1f)" in bottom_actions)
check("action bar owns IME padding", ".imePadding()" in bottom_actions)
check("action bar owns navigation padding", ".navigationBarsPadding()" in bottom_actions)

check("keyboard Next is explicit", "ImeAction.Next" in components)
check("final driver field uses Done", "imeAction = ImeAction.Done" in screen)
check("numeric odometer keyboard preserved", "keyboardType = KeyboardType.Number" in screen)
check("focus requesters exist", screen.count("FocusRequester()") >= 5)
check("validation focus effect exists", "LaunchedEffect(state.fieldError)" in screen)
check("name validation focuses name", "VehicleEditorField.Name -> nameFocus" in screen)
check("plate validation focuses plate", "VehicleEditorField.PlateNumber -> plateFocus" in screen)
check("VIN validation focuses VIN", "VehicleEditorField.Vin -> vinFocus" in screen)
check("year validation focuses year", "VehicleEditorField.ManufactureYear -> yearFocus" in screen)
check("odometer validation focuses odometer", "VehicleEditorField.Odometer -> odometerFocus" in screen)
check("validation requests focus", ".requestFocus()" in screen)

check("lower odometer title preserved", 'title = "قراءة العداد أقل"' in dialogs)
check("lower odometer warning values preserved", "warning.requestedOdometerKm" in dialogs and "warning.previousOdometerKm" in dialogs)
check("lower odometer dismiss event preserved", "VehicleEditorUiEvent.DismissLowerOdometerWarning" in dialogs)
check("lower odometer confirm event preserved", "VehicleEditorUiEvent.ConfirmLowerOdometer" in dialogs)
check("lower odometer reason event preserved", "VehicleEditorUiEvent.LowerOdometerReasonChanged(it)" in dialogs)
check("lower odometer dialog has Done IME", "ImeAction.Done" in dialogs)
check("lower odometer reason requests focus", "reasonFocus.requestFocus()" in dialogs and "focusRequester(reasonFocus)" in dialogs)

check("structured editor UI test added", "editorShowsStructuredSectionsAndPersistentSaveAction" in tests)
check("field validation UI test added", "editorValidationMessageIsPresentedAtItsField" in tests)
check("save dispatch UI test added", "editorSaveActionPreservesSaveEvent" in tests)
check("required fields UI test retained", "editorShowsOnlyNameAndPlateAsRequired" in tests)
check("lower odometer UI test retained", "lowerOdometerDialogRequestsReason" in tests)
check("vehicle list tests retained", "vehicleRowPreservesSelectionEvent" in tests)
check("vehicle detail tests retained", "detailArchiveRequiresConfirmation" in tests)

for path, expected in protected.items():
    check(f"protected unchanged: {path}", sha256(path) == expected)

failed = [label for label, ok in checks if not ok]
print(f"\nSESSION-78 static contract: {len(checks) - len(failed)}/{len(checks)} PASS")
if failed:
    raise SystemExit("Failed checks: " + "; ".join(failed))
