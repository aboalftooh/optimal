#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v53 Verto pull, Realtime hints and read state."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "cursor": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessageCursor.kt",
    "repository_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt",
    "usecases": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt",
    "remote_models": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoMessageRemoteModels.kt",
    "remote_api": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/OptimalVertoMessagesApi.kt",
    "remote_source": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoMessageRemoteDataSource.kt",
    "realtime": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoRealtimeHintSource.kt",
    "mapper": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoRemoteMessageMapper.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "message_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMessageDao.kt",
    "message_entity": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity/verto/VertoMessageEntity.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "entry": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "cursor_test": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoMessageCursorTest.kt",
}

CHAT_PRESENTATION_DIR = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation"
CHAT_PRESENTATION_FILES = (
    "VertoChatScreen.kt",
    "VertoChatChrome.kt",
    "VertoChatMessages.kt",
    "VertoChatAttachments.kt",
    "VertoChatComposer.kt",
    "VertoChatFormatting.kt",
)

def chat_presentation_text() -> str:
    return "\n".join(
        (CHAT_PRESENTATION_DIR / name).read_text(encoding="utf-8")
        for name in CHAT_PRESENTATION_FILES
    )

checks = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    if not condition:
        raise AssertionError(name)

def text(key: str) -> str:
    if key == "screen":
        return chat_presentation_text()
    return FILES[key].read_text(encoding="utf-8")

for name, path in FILES.items():
    check(f"exists:{name}", path.is_file())

cursor = text("cursor")
for token in ["createdAtEpochMillis", "remoteId", "Comparable<VertoMessageCursor>", "timeComparison", "remoteId.compareTo"]:
    check(f"composite cursor:{token}", token in cursor)

api = text("remote_api")
check("pull RPC", "optimal_verto_message_feed" in api)
check("read RPC", "optimal_verto_mark_messages_read" in api)
models = text("remote_models")
for token in ["p_after_created_at", "p_after_message_id", "p_limit", "p_through_created_at", "p_through_message_id"]:
    check(f"wire field:{token}", token in models)

source = text("remote_source")
for token in ["after?.createdAtEpochMillis", "after?.remoteId", "limit.coerceIn(1, MAX_PAGE_SIZE)", "formatTimestamp", "VertoRemoteResult"]:
    check(f"remote source:{token}", token in source)

entity = text("message_entity")
check("remote id unique", 'Index(value = ["remoteId"], unique = true)' in entity)
mapper = text("mapper")
for token in ["existingMessage?.id ?: remoteId", "deliveryState = \"SENT\"", "serverCreatedAtEpochMillis = serverTime", "existingAttachments", "VertoMessageCursor(serverTime, remoteId)"]:
    check(f"mapper:{token}", token in mapper)
check("mapper rejects malformed rows", "require(" in mapper and "validateContent" in mapper)
check("mapper rejects cross-tenant identity reuse", "belongs to another tenant or conversation" in mapper)

repo = text("repository")
for token in [
    "AtomicWriteTransactionRunner",
    "transactionRunner.run",
    "remoteDataSource.pull(cursor, PAGE_SIZE)",
    "sortedBy { it.cursor }",
    "messageDao.findByRemoteId",
    "messageDao.findByClientMessageId",
    "messageDao.upsert",
    "attachmentDao.upsertAll",
    "cursorDao.upsert",
    "maxOfCursor(previousCursor, pageCursor)",
    "MESSAGE_FEED_KEY = \"VERTO_MESSAGES\"",
    "syncReadCheckpointBestEffort",
]:
    check(f"repository:{token}", token in repo)
transaction_boundary = min(repo.index(token) for token in ("database.withTransaction", "transactionRunner.run") if token in repo)
check("cursor and page persist in same transaction", transaction_boundary < repo.index("cursorDao.upsert"))
check("pull serialized", "pullMutex.withLock" in repo)
check("read serialized", "readMutex.withLock" in repo)
check("local read before remote", repo.index("upsertUserState(", repo.index("override suspend fun markRead")) < repo.index("remoteDataSource.markRead", repo.index("override suspend fun markRead")))

message_dao = text("message_dao")
for token in ["countUnread", "senderSide = 'VERTO'", "remoteStatus = 'ACTIVE'", "serverCreatedAtEpochMillis >", "remoteId > COALESCE"]:
    check(f"unread query:{token}", token in message_dao)

realtime = text("realtime")
for token in ["Flow<Unit>", "postgres_changes", "trySend(Unit)", ".conflate()", ".retryWhen", "optimal_verto_messages", "heartbeatPayload"]:
    check(f"realtime hint:{token}", token in realtime)
check("realtime is not message source", "VertoMessageDto" not in realtime and "messageDao" not in realtime)

usecases = text("usecases")
for token in ["class PullVertoMessagesUseCase", "class ObserveVertoRealtimeHints", "class MarkVertoMessagesRead"]:
    check(f"use case:{token}", token in usecases)

vm = text("viewmodel")
for token in ["PullVertoMessagesUseCase", "ObserveVertoRealtimeHints", "MarkVertoMessagesRead", "result.stream.collect { pullNow() }", "PERIODIC_PULL_INTERVAL_MILLIS", "pullMutex.withLock", "MessagesVisible"]:
    check(f"viewmodel:{token}", token in vm)
check("presentation has no data source", ".data." not in vm and "Retrofit" not in vm and "core.database" not in vm)

screen = text("screen")
for token in ["rememberLazyListState", "snapshotFlow", "visibleItemsInfo", "VertoMessageCursor", "onMessagesVisible", "distinctUntilChanged"]:
    check(f"visible read:{token}", token in screen)
check("screen has no network", all(x not in screen for x in ["Retrofit", "Supabase", "core.network", ".data."]))
entry = text("entry")
check("entry forwards visible checkpoint", "VertoChatUiEvent.MessagesVisible" in entry)

test = text("cursor_test")
check("equal-time cursor test", "equalTimesAdvanceByRemoteIdentity" in test)
check("newer-time cursor test", "newerTimeWinsEvenWhenIdentitySortsLower" in test)

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains immutable", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version remains stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("no v53 database migration", not any((ROOT / "supabase/migrations").glob("*v53*")))
check("no merge markers", not any(mark in "\n".join(text(k) for k in FILES) for mark in ("<<<<<<<", "=======", ">>>>>>>")))

print(f"v53 Verto message sync contract: {len(checks)}/{len(checks)} PASS")
