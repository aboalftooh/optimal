#!/usr/bin/env python3
"""Offline contract gate for OPTIMAL v69 phone-first registration."""

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKS = 0


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(message)


def main() -> int:
    models = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt")
    contract = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt")
    steps = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt")
    content = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthScreenContent.kt")
    view_model = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt")
    repository = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/SupabaseOnboardingRepository.kt")
    repository_contract = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/OnboardingRepository.kt")
    api = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OptimalOnboardingApi.kt")
    remote = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseOnboardingRemoteDataSource.kt")
    mapper = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/mapper/OnboardingMapper.kt")
    policy = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt")
    migration = read("supabase/migrations/20260801210000_optimal_v69_phone_first_registration.sql")
    otp_verify = read("supabase/functions/optimal-verify-phone-otp/index.ts")
    tests = read("feature/auth/src/test/java/com/optimal/fleet/feature/auth/presentation/AuthViewModelTest.kt")

    # UI starts with phone and contains no user-selected registration mode.
    require("val step: OnboardingStep = OnboardingStep.Phone" in contract, "auth must start on phone entry")
    require("OnboardingStep.Phone -> PhoneStep" in content, "phone step is not the first rendered state")
    require("شركة جديدة" not in steps.split("internal fun PhoneStep", 1)[1].split("internal fun OtpStep", 1)[0],
            "phone step still exposes a company-mode choice")
    require("EntryChoice" not in models + contract + view_model, "obsolete entry-choice state remains")
    require("ModeSelected" not in contract + view_model, "client still selects onboarding mode")

    # OTP determines existing-versus-new membership.
    require("data class ExistingMember" in models and "data object NewMember" in models,
            "OTP result does not distinguish existing and new users")
    require("OtpVerificationResult.ExistingMember" in view_model and "ContinueToApp" in view_model,
            "existing member is not sent directly into the app")
    require("OtpVerificationResult.NewMember" in view_model and "step = OnboardingStep.JoinCode" in view_model,
            "new member is not routed to join-code entry")
    require("currentMemberProfile()" in repository and "resolveVerifiedMember()" in repository,
            "repository does not resolve membership after OTP")
    require(re.search(r"suspend fun requestOtp\(normalizedPhone: String\)", repository_contract) is not None,
            "OTP request still depends on a preselected code or mode")

    # One opaque code is classified only by the server.
    require("optimal_resolve_registration_code" in api and "optimal_complete_registration" in api,
            "Android is not using the unified registration RPCs")
    require("codeSource" in mapper and "SOURCE_VERTO" in mapper and "SOURCE_OPTIMAL" in mapper,
            "server code source is not mapped to both outcomes")
    require("completeOnboarding(joinCode, userDisplayName)" in repository,
            "completion still sends a client-selected registration mode")
    completion_contract = repository_contract.split("suspend fun completeOnboarding", 1)[1].split("): OnboardingCompletionResult", 1)[0]
    require("OnboardingMode" not in completion_contract and "mode:" not in completion_contract,
            "domain completion contract still accepts a client-selected mode")
    require("mode" not in read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OptimalOnboardingApi.kt").split("CompleteOnboardingRequest", 1)[1].split(")", 1)[0],
            "unified completion request leaks client-selected mode")
    require("optimal_complete_onboarding(p_code, p_display_name)" in migration,
            "Optimal employee code is not delegated to employee onboarding")
    require("optimal_complete_company_registration(p_code, p_display_name)" in migration,
            "Verto company code is not delegated to company creation")
    require("v_has_invite and v_has_verto" in migration and "ambiguous_registration_code" in migration,
            "cross-namespace code collision does not fail closed")

    # Security boundaries.
    require("auth.uid() is null" in migration, "registration resolver is not authenticated")
    require("revoke all on function public.optimal_resolve_registration_code(text) from public, anon" in migration,
            "anon can resolve registration codes")
    require("grant execute on function public.optimal_resolve_registration_code(text) to authenticated" in migration,
            "authenticated users cannot resolve registration codes")
    require("revoke execute on function public.optimal_validate_join_code(text) from anon" in migration,
            "legacy Optimal code resolver remains anonymous")
    require("revoke execute on function public.optimal_validate_invite_phone(text, text) from anon" in migration,
            "legacy invite-phone resolver remains anonymous")
    require("revoke execute on function public.optimal_validate_verto_company_code(text) from anon" in migration,
            "legacy Verto code resolver remains anonymous")
    require("v_invite.normalized_phone <> v_normalized_phone" in migration,
            "Optimal employee invitation is not bound to the verified phone")
    require("security definer" in migration and "set search_path = pg_catalog, public" in migration,
            "registration RPC hardening is missing")
    require(".from('optimal_phone_otps')" in otp_verify, "Optimal OTP verifier does not use its isolated table")
    require(".from('phone_otps')" not in otp_verify, "Optimal OTP verifier still touches a shared/legacy OTP table")
    require("autodrive" not in otp_verify.lower(), "Optimal OTP flow references AutoDrive")
    require("^00249[0-9]{9}$" in policy, "Android phone validation does not use the canonical 00249 Sudan format")

    # Regression tests explicitly cover all three outcomes.
    require("newUserFlowRoutesVertoCodeToCompanyCreation" in tests, "Verto company-creation test missing")
    require("newUserFlowRoutesOptimalCodeToEmployeeMembership" in tests, "Optimal employee-join test missing")
    require("existingUserEntersWithoutJoinCode" in tests, "existing-user direct-login test missing")

    # Lightweight delimiter sanity for changed Kotlin sources.
    kotlin_paths = [
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/SupabaseOnboardingRepository.kt",
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseOnboardingRemoteDataSource.kt",
    ]
    for path in kotlin_paths:
        source = read(path)
        require(source.count("{") == source.count("}"), f"unbalanced braces: {path}")
        require(source.count("(") == source.count(")"), f"unbalanced parentheses: {path}")

    print(f"PASS: v69 phone-first registration contract ({CHECKS} assertions)")
    print("PASS: existing login, Verto company creation, Optimal employee join, OTP isolation")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        raise SystemExit(1)
