#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLINC_BIN="$(readlink -f "$(command -v kotlinc)")"
KOTLIN_LIB_DIR="$(cd "$(dirname "$KOTLINC_BIN")/../lib" && pwd)"
COROUTINES_JAR="$KOTLIN_LIB_DIR/kotlinx-coroutines-core-jvm.jar"
mkdir -p \
  "$TMP_DIR/stubs/androidx/room" \
  "$TMP_DIR/stubs/javax/inject" \
  "$TMP_DIR/stubs/org/junit" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity" \
  "$TMP_DIR/stubs/kotlinx/coroutines/test"
cat > "$TMP_DIR/stubs/androidx/room/Room.kt" <<'STUB'
package androidx.room
import kotlin.reflect.KClass
@Target(AnnotationTarget.CLASS)
annotation class Dao
@Target(AnnotationTarget.CLASS)
annotation class Entity(
    val tableName: String = "",
    val foreignKeys: Array<ForeignKey> = [],
    val indices: Array<Index> = [],
)
@Target(AnnotationTarget.ANNOTATION_CLASS, AnnotationTarget.CLASS)
annotation class ForeignKey(
    val entity: KClass<*>,
    val parentColumns: Array<String>,
    val childColumns: Array<String>,
    val onDelete: Int = 0,
) {
    companion object { const val RESTRICT = 1; const val CASCADE = 2 }
}
@Target(AnnotationTarget.ANNOTATION_CLASS, AnnotationTarget.CLASS)
annotation class Index(val value: Array<String>, val unique: Boolean = false)
@Target(AnnotationTarget.PROPERTY)
annotation class PrimaryKey
@Target(AnnotationTarget.FUNCTION)
annotation class Query(val value: String)
@Target(AnnotationTarget.FUNCTION)
annotation class Insert(val onConflict: Int = 0)
@Target(AnnotationTarget.FUNCTION)
annotation class Update
@Target(AnnotationTarget.FUNCTION)
annotation class Transaction
object OnConflictStrategy { const val ABORT = 1 }
STUB
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
STUB
cat > "$TMP_DIR/stubs/org/junit/Junit.kt" <<'STUB'
package org.junit
@Target(AnnotationTarget.FUNCTION)
annotation class Test
@Target(AnnotationTarget.FUNCTION)
annotation class Before
object Assert {
    @JvmStatic fun assertEquals(expected: Any?, actual: Any?) { check(expected == actual) { "expected=$expected actual=$actual" } }
    @JvmStatic fun assertTrue(value: Boolean) { check(value) }
    @JvmStatic fun assertNull(value: Any?) { check(value == null) { "expected null, actual=$value" } }
    @JvmStatic fun assertNotNull(value: Any?) { check(value != null) }
}
STUB
cat > "$TMP_DIR/stubs/kotlinx/coroutines/test/TestApi.kt" <<'STUB'
package kotlinx.coroutines.test
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine
fun runTest(block: suspend () -> Unit) {
    var result: Result<Unit>? = null
    block.startCoroutine(object : Continuation<Unit> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(value: Result<Unit>) { result = value }
    })
    requireNotNull(result).getOrThrow()
}
STUB
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/References.kt" <<'STUB'
package com.optimal.fleet.core.database.entity
class CompanyEntity
class LocalUserEntity
STUB
kotlinc -cp "$COROUTINES_JAR" \
  "$TMP_DIR/stubs/androidx/room/Room.kt" \
  "$TMP_DIR/stubs/javax/inject/Inject.kt" \
  "$TMP_DIR/stubs/org/junit/Junit.kt" \
  "$TMP_DIR/stubs/kotlinx/coroutines/test/TestApi.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/References.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditContracts.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/transaction/AtomicWriteTransactionRunner.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/DatabaseConstants.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/entity/VehicleEntity.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/entity/VehicleAuditEntity.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/PendingSyncOperationEntity.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/LocalWriteVersion.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueConstants.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncOutboxEntryFactory.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/time/MutableTestClock.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fake/MutableSessionReader.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fixture/CoreFixtures.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fake/RecordingPorts.kt" \
  "$ROOT_DIR/core/testing/src/main/kotlin/com/optimal/fleet/core/testing/contract/TenantRepositoryContract.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleDraft.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleValidation.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/repository/VehicleRepository.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleIdentityFactory.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleMappers.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleSyncOperationFactory.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/SaveVehicleUseCase.kt" \
  "$ROOT_DIR/feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/domain/usecase/SaveVehicleUseCaseTest.kt" \
  "$ROOT_DIR/feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryTest.kt" \
  "$ROOT_DIR/feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryContractTest.kt" \
  "$ROOT_DIR/scripts/v36-vehicle-contract-harness.kt" \
  -include-runtime -d "$TMP_DIR/v36-vehicle-contract-harness.jar"
java -cp "$TMP_DIR/v36-vehicle-contract-harness.jar:$COROUTINES_JAR" com.optimal.fleet.feature.vehicles.data.V36_vehicle_contract_harnessKt
