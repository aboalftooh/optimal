#!/usr/bin/env python3
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []
def read(path): return (ROOT / path).read_text(encoding="utf-8")
def check(name, ok): checks.append((name, bool(ok)))

build = read("app/build.gradle.kts")
repo = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SupabaseMemberRepository.kt")
models = read("core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt")
policy = models
mapper = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/mapper/MemberMapper.kt")
local_user = read("core/database/src/main/java/com/optimal/fleet/core/database/entity/LocalUserEntity.kt")
invite = read("core/database/src/main/java/com/optimal/fleet/core/database/entity/MemberInviteEntity.kt")
sql = read("supabase/migrations/20260730003200_optimal_member_permissions_rls.sql")

check("versionCode 27", re.search(r"\bversionCode\s*=\s*27\b", build))
check("versionName v32", 'versionName = "0.32.0-v32"' in build)
check("repository coordinator reduced", len(repo.splitlines()) <= 360)
check("repository contains no DAO", "Dao" not in repo and "database." not in repo)
check("repository contains no Retrofit", "retrofit" not in repo.lower())
for path in [
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/MemberRemoteDataSource.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/local/MemberLocalDataSource.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/mapper/MemberMapper.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/audit/MemberAuditDataSource.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt",
]: check(f"exists {Path(path).name}", (ROOT/path).is_file())
check("one domain policy", "object MemberAccessPolicy" in policy and "defaultsByRole" in policy)
check("corrupt local permission JSON fails closed", "denyAllCapabilities()" in mapper and "return denyAllCapabilities()" in mapper)
check("all six roles modeled", all(role in models for role in ["OWNER", "MANAGER", "ENGINEER", "ACCOUNTANT", "DRIVER", "MEMBER"]))
check("five capabilities modeled", models.count('(\"') >= 0 and all(cap in models for cap in ["VIEW_MEMBER_DIRECTORY", "CREATE_MEMBER_INVITE", "RESEND_MEMBER_INVITE", "REVOKE_MEMBER_INVITE", "CHANGE_MEMBER_STATUS"]))
check("Room member role", "val role: String" in local_user)
check("Room member permissions", "val permissionsJson: String" in local_user)
check("Room invite role", "val role: String" in invite)
check("Room invite permissions", "val permissionsJson: String" in invite)
check("SQL capability helper", "optimal_member_has_capability" in sql)
check("SQL fixed search paths", sql.count("set search_path =") >= 8)
check("SQL no direct writes", "revoke insert, update, delete" in sql)
check("cross-company target guards", sql.count("company_id = v_actor.company_id") >= 8)
check("invite revocation supported", "optimal_revoke_member_invite" in sql)
check("permission unit test", (ROOT/"feature/settings/src/test/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicyTest.kt").is_file())
check("security contract harness", (ROOT/"scripts/v32-member-security-contract.py").is_file())
schema = json.loads(read("core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/1.json"))
schema_text = json.dumps(schema)
check("Room schema has role columns", schema_text.count('role') >= 2)
check("Room schema has permission columns", schema_text.count('permissionsJson') >= 2)
for path in ["README.md", "AGENTS.md", "docs/sessions/v32.md", "verification-v32.md", "PATCH_MANIFEST-v32.md", "CHANGED_FILES-v32.txt", "DELETED_FILES-v32.txt"]:
    check(f"delivery {path}", (ROOT/path).is_file())

failed=[name for name,ok in checks if not ok]
for name,ok in checks: print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)}")
if failed:
    print("FAILED: "+", ".join(failed), file=sys.stderr)
    sys.exit(1)
