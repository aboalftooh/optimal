#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/1.json"
checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


def create_database() -> sqlite3.Connection:
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))["database"]
    connection = sqlite3.connect(":memory:")
    connection.execute("PRAGMA foreign_keys = ON")
    for entity in schema["entities"]:
        table = entity["tableName"]
        connection.execute(entity["createSql"].replace("${TABLE_NAME}", table))
        for index in entity.get("indices", []):
            connection.execute(index["createSql"].replace("${TABLE_NAME}", table))
    return connection


def seed_company(db: sqlite3.Connection, company_id: str) -> None:
    db.execute(
        "INSERT INTO companies(id, remoteId, name, createdAtEpochMillis, updatedAtEpochMillis, syncStatus) VALUES (?, NULL, ?, 1, 1, 'PENDING')",
        (company_id, company_id),
    )


def seed_operation(db: sqlite3.Connection, operation_id: str, company_id: str, key: str, attempt: int = 0) -> None:
    db.execute(
        """
        INSERT INTO pending_sync_operations(
            id, companyId, aggregateType, aggregateId, operationType, payload,
            idempotencyKey, localVersion, state, attemptCount,
            nextAttemptAtEpochMillis, leaseUntilEpochMillis, leaseToken,
            lastErrorCode, remoteId, remoteVersion, createdAtEpochMillis, updatedAtEpochMillis
        ) VALUES (?, ?, 'VEHICLE', ?, 'UPSERT', '{}', ?, 1, 'PENDING', ?, 0, NULL, NULL, NULL, NULL, NULL, 1, 1)
        """,
        (operation_id, company_id, f"vehicle-{operation_id}", key, attempt),
    )


def claim(db: sqlite3.Connection, token: str, now: int, lease_until: int) -> int:
    due = db.execute(
        "SELECT id, companyId FROM pending_sync_operations WHERE state IN ('PENDING','RETRY') AND nextAttemptAtEpochMillis <= ? ORDER BY createdAtEpochMillis, id",
        (now,),
    ).fetchall()
    changed = 0
    for operation_id, company_id in due:
        cursor = db.execute(
            """
            UPDATE pending_sync_operations
            SET state='RUNNING', leaseUntilEpochMillis=?, leaseToken=?, updatedAtEpochMillis=?
            WHERE id=? AND companyId=? AND state IN ('PENDING','RETRY')
            """,
            (lease_until, token, now, operation_id, company_id),
        )
        changed += cursor.rowcount
    return changed


def main() -> int:
    db = create_database()
    seed_company(db, "company-a")
    seed_company(db, "company-b")
    seed_operation(db, "a", "company-a", "key-a")
    seed_operation(db, "b", "company-b", "key-b")
    db.commit()

    check("one batch can lease two companies", claim(db, "worker-1", 100, 200) == 2)
    check("second worker cannot claim running rows", claim(db, "worker-2", 100, 200) == 0)
    leased = db.execute("SELECT companyId, leaseToken FROM pending_sync_operations ORDER BY companyId").fetchall()
    check("claimed rows retain company identity", leased == [("company-a", "worker-1"), ("company-b", "worker-1")])

    succeeded_a = db.execute(
        """
        UPDATE pending_sync_operations
        SET state='SUCCEEDED', leaseUntilEpochMillis=NULL, leaseToken=NULL
        WHERE id='a' AND companyId='company-a' AND state='RUNNING'
          AND leaseToken='worker-1' AND leaseUntilEpochMillis > 150
        """,
    ).rowcount
    check("active lease owner can finalize", succeeded_a == 1)

    recovered_b = db.execute(
        """
        UPDATE pending_sync_operations
        SET state='RETRY', attemptCount=attemptCount+1, nextAttemptAtEpochMillis=250,
            leaseUntilEpochMillis=NULL, leaseToken=NULL, lastErrorCode='PROCESS_DEATH_RECOVERY'
        WHERE id='b' AND companyId='company-b' AND state='RUNNING'
          AND leaseToken='worker-1' AND leaseUntilEpochMillis <= 201
        """,
    ).rowcount
    check("expired lease is recovered without deleting operation", recovered_b == 1)
    check("process death consumes one retry attempt", db.execute("SELECT attemptCount FROM pending_sync_operations WHERE id='b'").fetchone()[0] == 1)

    check("recovered operation waits for backoff", claim(db, "worker-2", 249, 400) == 0)
    check("recovered operation resumes when due", claim(db, "worker-2", 250, 400) == 1)
    stale_finalize = db.execute(
        """
        UPDATE pending_sync_operations SET state='SUCCEEDED'
        WHERE id='b' AND companyId='company-b' AND state='RUNNING'
          AND leaseToken='worker-1' AND leaseUntilEpochMillis > 260
        """,
    ).rowcount
    check("stale worker cannot finalize new owner's lease", stale_finalize == 0)
    new_finalize = db.execute(
        """
        UPDATE pending_sync_operations SET state='SUCCEEDED', leaseToken=NULL, leaseUntilEpochMillis=NULL
        WHERE id='b' AND companyId='company-b' AND state='RUNNING'
          AND leaseToken='worker-2' AND leaseUntilEpochMillis > 260
        """,
    ).rowcount
    check("new lease owner can finalize", new_finalize == 1)

    duplicate_blocked = False
    try:
        seed_operation(db, "duplicate", "company-a", "key-a")
    except sqlite3.IntegrityError:
        duplicate_blocked = True
    check("idempotency key blocks duplicate logical send", duplicate_blocked)

    audit_sql = """
        INSERT OR IGNORE INTO sync_conflict_audit(
            id, companyId, operationId, aggregateType, aggregateId,
            localVersion, remoteVersion, losingPayload, winningPayload,
            resolution, createdAtEpochMillis
        ) VALUES ('stable-audit', 'company-a', 'a', 'VEHICLE', 'vehicle-a', 1, 2, '{}', '{}', 'REMOTE_WINS_VERSION', 300)
    """
    db.execute(audit_sql)
    db.execute(audit_sql)
    check("duplicate conflict response creates one audit row", db.execute("SELECT COUNT(*) FROM sync_conflict_audit WHERE id='stable-audit'").fetchone()[0] == 1)

    company_a = db.execute("SELECT COUNT(*) FROM pending_sync_operations WHERE companyId='company-a' AND state='SUCCEEDED'").fetchone()[0]
    company_b = db.execute("SELECT COUNT(*) FROM pending_sync_operations WHERE companyId='company-b' AND state='SUCCEEDED'").fetchone()[0]
    check("company reports are isolated", company_a == 1 and company_b == 1)

    passed = sum(ok for _, ok in checks)
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}: {name}")
    print(f"\nV29 SQLite lease contract: {passed}/{len(checks)}")
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    sys.exit(main())
