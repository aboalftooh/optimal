#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
python3 scripts/static-architecture-check.py
python3 scripts/static-v35-check.py
python3 scripts/v35-ui-parity-contract.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
./scripts/run-v35-ui-syntax-check.sh
