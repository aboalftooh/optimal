#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKS: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    CHECKS.append((name, ok, detail))


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


# Coverage/closure must not regress.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, re.M)
check("ledger still has exactly 123 inventory rows", len(rows) == 123, str(len(rows)))
check("ledger inventory IDs remain unique", len({r[0] for r in rows}) == 123, str(len({r[0] for r in rows})))
check("ledger remains 123/123 MIGRATED", len(rows) == 123 and all(status == "MIGRATED" for _, status in rows))
check("ledger summary remains 123/123", "| **TOTAL** | **123** | **123** | **0** | **0** |" in ledger)

manifest = [
    line.strip() for line in read("docs/design-system/SESSION-108-UI-SOURCE-MANIFEST.txt").splitlines()
    if line.strip() and not line.lstrip().startswith("#")
]
feature_compose = sorted(
    p.relative_to(ROOT).as_posix()
    for p in (ROOT / "feature").glob("**/src/main/java/**/*.kt")
    if "@Composable" in p.read_text(encoding="utf-8", errors="ignore")
)
app_compose = sorted(
    p.relative_to(ROOT).as_posix()
    for p in (ROOT / "app").glob("**/src/main/java/**/*.kt")
    if "@Composable" in p.read_text(encoding="utf-8", errors="ignore")
)
core_runtime = sorted(
    p.relative_to(ROOT).as_posix()
    for p in (ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2").glob("*.kt")
) + [
    "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTheme.kt",
    "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTypography.kt",
]
discovered = feature_compose + app_compose + core_runtime
check("frozen production UI manifest remains 81 files", len(manifest) == 81 and set(manifest) == set(discovered), f"manifest={len(manifest)} discovered={len(discovered)}")
check("feature Compose source count remains 64", len(feature_compose) == 64, str(len(feature_compose)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("design-system compliance guard passes", proc.returncode == 0)
check("compliance guard reports zero active violations", "Active violations: 0" in proc.stdout)
allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("migration allowlist remains empty", not allow, str(allow))

# Required matrix is frozen as executable UI-test intent.
test_rel = "core/designsystem/src/androidTest/java/com/optimal/fleet/designsystem/ResponsiveRtlAccessibilityV109Test.kt"
test = read(test_rel)
check("SESSION-109 Android test source exists", (ROOT / test_rel).is_file())
check("required width matrix is frozen", "listOf(320, 360, 412, 600, 840)" in test)
check("required font-scale matrix is frozen", "listOf(1.0f, 1.3f, 2.0f)" in test)
check("matrix tests force Arabic RTL direction", "LayoutDirection.Rtl" in test)
check("matrix tests assert 48dp-equivalent touch target", "assertHeightIsAtLeast(OptimalTouchTarget.minimum)" in test)

# Responsive foundation and shared primitives.
foundations = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalFoundations.kt")
rows_src = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalRows.kt")
check("responsive compact threshold is centralized", "compactStackMaxWidth = 300.dp" in foundations)
check("fontScale 2.0 accessibility threshold is centralized", "accessibilityFontScale = 2.0f" in foundations)
check("adaptive layout inspects available width", "BoxWithConstraints" in rows_src and "maxWidth <= OptimalResponsiveLayout.compactStackMaxWidth" in rows_src)
check("adaptive layout inspects font scale", "LocalDensity.current.fontScale >= OptimalResponsiveLayout.accessibilityFontScale" in rows_src)
check("responsive pair stacks in compact mode", "fun OptimalResponsivePair(" in rows_src and "first(Modifier.fillMaxWidth())" in rows_src and "second(Modifier.fillMaxWidth())" in rows_src)
check("section headers adapt instead of forcing action into one row", "fun OptimalSectionHeader(" in rows_src and "OptimalAdaptiveLayout(" in rows_src)
check("list trailing content adapts at compact/large text", "trailingContent?.let" in rows_src and "horizontalArrangement = Arrangement.End" in rows_src)

responsive_consumers = {
    "Home metrics": "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt",
    "Finance metrics": "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt",
    "Invoice money": "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt",
    "Maintenance details costs": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContent.kt",
    "Maintenance edit costs": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceEditContent.kt",
    "Maintenance completion costs": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceCompletionContent.kt",
    "Vehicle actions": "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt",
    "Member invite actions": "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt",
}
for label, rel in responsive_consumers.items():
    check(f"{label} use responsive pair", "OptimalResponsivePair(" in read(rel))

notifications = read("feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsComponents.kt")
check("notification header adapts at compact/large text", "OptimalAdaptiveLayout(" in notifications and "NotificationRefreshButton" in notifications and "NotificationReadAllButton" in notifications)

cards = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalCards.kt")
status = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalStatus.kt")
check("action cards adapt when action label competes for width", "fun OptimalActionCard(" in cards and "OptimalAdaptiveLayout(" in cards)
check("inline statuses adapt when action competes for width", "fun OptimalInlineStatus(" in status and "OptimalAdaptiveLayout(" in status)

# Dynamic text: fixed product content heights are prohibited except intentional spacers/timeline intrinsic sizing.
fixed_hits: list[str] = []
for base in [ROOT / "feature", ROOT / "app", ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2"]:
    for p in base.glob("**/*.kt"):
        text = p.read_text(encoding="utf-8", errors="ignore")
        lines = text.splitlines()
        for i, line in enumerate(lines, start=1):
            if re.search(r"\.(?:height|requiredHeight|requiredWidth|requiredSize)\(", line):
                window = "\n".join(lines[max(0, i-4):min(len(lines), i+2)])
                if "Spacer(" in window or "IntrinsicSize.Min" in line:
                    continue
                fixed_hits.append(f"{p.relative_to(ROOT)}:{i}")
check("critical dynamic content has no rigid height/required-size constraint", not fixed_hits, ", ".join(fixed_hits))
fields = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt")
check("OTP cells use minimum height, not rigid height", ".defaultMinSize(minHeight = OptimalComponentDefaults.fieldMinHeight)" in fields and ".height(OptimalComponentDefaults.fieldMinHeight)" not in fields)

# Dialog and bottom action resilience.
dialogs = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalDialogs.kt")
bottom = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalBottomActions.kt")
check("dialog content scrolls under large text", "verticalScroll(rememberScrollState())" in dialogs)
check("dialog confirm action meets touch target", dialogs.count("defaultMinSize(minHeight = OptimalTouchTarget.minimum)") >= 2, str(dialogs.count("defaultMinSize(minHeight = OptimalTouchTarget.minimum)")))
check("dialogs remain dismissible", "onDismissRequest = onDismissRequest" in dialogs and "dismissButton" in dialogs)
check("bottom actions retain IME padding", ".imePadding()" in bottom)
check("bottom actions retain navigation-bar padding", ".navigationBarsPadding()" in bottom)
check("two-button bottom actions become responsive", "OptimalResponsivePair(" in bottom)
check("bottom primary enablement remains hoisted", "enabled = primaryEnabled" in bottom)

# RTL and accessibility semantics.
app = read("app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt")
check("production app forces RTL at root", "LocalLayoutDirection provides LayoutDirection.Rtl" in app)
production_files = [ROOT / p for p in manifest if p.startswith(("feature/", "app/"))]
production_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in production_files)
check("no production LTR override exists", "LayoutDirection.Ltr" not in production_text)
forbidden_directional = re.findall(r"Icons\.(?:Outlined|Default)\.(?:ArrowBack|ArrowForward|ChevronLeft|ChevronRight|KeyboardArrowLeft|KeyboardArrowRight)", production_text)
check("no fixed-direction production navigation icon exists", not forbidden_directional, ", ".join(sorted(set(forbidden_directional))))
check("canonical minimum touch target remains 48dp", "val minimum = 48.dp" in foundations)
check("product UI uses no raw Material IconButton", re.search(r"(?<!Optimal)IconButton\(", production_text) is None)

# All direct feature/app clickables must carry role/label and explicit minimum size.
direct_clicks: list[str] = []
bad_clicks: list[str] = []
for p in [x for x in (ROOT / "feature").glob("**/*.kt") if "/src/main/" in x.as_posix()] + list((ROOT / "app/src/main/java").glob("**/*.kt")):
    lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
    for idx, line in enumerate(lines):
        if ".clickable(" not in line:
            continue
        rel = p.relative_to(ROOT).as_posix()
        direct_clicks.append(f"{rel}:{idx+1}")
        window = "\n".join(lines[max(0, idx-5):min(len(lines), idx+9)])
        if "role = Role.Button" not in window or "onClickLabel" not in window or "defaultMinSize(minHeight = OptimalTouchTarget." not in window:
            bad_clicks.append(f"{rel}:{idx+1}")
check("direct product clickables are fully audited", len(direct_clicks) == 3, str(direct_clicks))
check("direct product clickables expose role, label and >=48dp target", not bad_clicks, ", ".join(bad_clicks))

# All direct Switch uses receive explicit TalkBack labels.
switches: list[str] = []
bad_switches: list[str] = []
for p in [x for x in (ROOT / "feature").glob("**/*.kt") if "/src/main/" in x.as_posix()] + list((ROOT / "app/src/main/java").glob("**/*.kt")):
    lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
    for idx, line in enumerate(lines):
        if re.search(r"\bSwitch\(", line):
            rel = p.relative_to(ROOT).as_posix()
            switches.append(f"{rel}:{idx+1}")
            window = "\n".join(lines[idx:min(len(lines), idx+14)])
            if "semantics { contentDescription =" not in window:
                bad_switches.append(f"{rel}:{idx+1}")
check("all four product Switch controls are audited", len(switches) == 4, str(switches))
check("all product Switch controls have explicit TalkBack labels", not bad_switches, ", ".join(bad_switches))

# Status must not be color-only.
check("canonical status badge always renders readable text", "Text(text, style = MaterialTheme.typography.labelMedium)" in status)
check("notification read state exposes stateDescription", "stateDescription = statusText" in notifications)
check("notification read state also exposes visible text", 'val statusText = if (item.isRead) "مقروء" else "جديد"' in notifications)

# Session handoff/document state.
current = read("docs/design-system/CURRENT-DESIGN-STATE.md")
check("current design state identifies SESSION-109", "CURRENT DESIGN STATE — SESSION-109" in current)
check("next session advances only to SESSION-110", "Next session:** SESSION-110" in current)
check("SESSION-109 verification exists", (ROOT / "docs/design-system/SESSION-109-VERIFICATION.md").is_file())
check("SESSION-109 handoff exists", (ROOT / "SESSION-HANDOFF-v109.md").is_file())

failed = [item for item in CHECKS if not item[1]]
for name, ok, detail in CHECKS:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-109 static acceptance: {len(CHECKS)-len(failed)}/{len(CHECKS)}")
sys.exit(1 if failed else 0)
