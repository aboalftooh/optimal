import com.optimal.fleet.feature.settings.domain.members.InviteCodePolicy
import com.optimal.fleet.feature.settings.domain.members.InviteConsumptionDecision
import com.optimal.fleet.feature.settings.domain.members.InviteConsumptionPolicy
import com.optimal.fleet.feature.settings.domain.members.MemberDisableDecision
import com.optimal.fleet.feature.settings.domain.members.MemberDisablePolicy

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

fun main() {
    verify("code normalization", InviteCodePolicy.normalizeCode("12 34-5678") == "12345678")
    verify("valid eight digit code", InviteCodePolicy.isValidCode("12345678"))
    verify("short code rejected", !InviteCodePolicy.isValidCode("1234"))
    verify("phone normalization", InviteCodePolicy.normalizePhone("+249 912-345-678") == "+249912345678")
    verify("valid phone", InviteCodePolicy.isValidPhone("0912345678"))
    verify("pending invite allowed", InviteConsumptionPolicy.decide("PENDING", 2000, 1000) == InviteConsumptionDecision.ALLOW)
    verify("used invite blocked", InviteConsumptionPolicy.decide("USED", 2000, 1000) == InviteConsumptionDecision.USED)
    verify("expired invite blocked", InviteConsumptionPolicy.decide("PENDING", 1000, 1000) == InviteConsumptionDecision.EXPIRED)
    verify("self disable blocked", MemberDisablePolicy.decide("u1", "u1", true, 3) == MemberDisableDecision.SELF_BLOCKED)
    verify("last member blocked", MemberDisablePolicy.decide("u1", "u2", true, 1) == MemberDisableDecision.LAST_ACTIVE_MEMBER_BLOCKED)
    verify("other member allowed", MemberDisablePolicy.decide("u1", "u2", true, 2) == MemberDisableDecision.ALLOW)
    println("RESULT: $checks/$checks passed")
}
