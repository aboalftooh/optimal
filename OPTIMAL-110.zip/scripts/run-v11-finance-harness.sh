#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/money/Money.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/money/MoneyParser.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/summary/FinancialPeriod.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/summary/FinancialSummary.kt" \
  "$ROOT/scripts/v11-finance-harness.kt" \
  -include-runtime -d "$OUT/v11-finance-harness.jar"
java -jar "$OUT/v11-finance-harness.jar"
