package com.optimal.fleet.v10harness

import com.optimal.fleet.coordinator.verto.VertoInvoiceMaintenanceCoordinator
import com.optimal.fleet.coordinator.verto.VertoLinkAuditCommand
import com.optimal.fleet.coordinator.verto.VertoLinkAuditPort
import com.optimal.fleet.coordinator.verto.VertoLinkTransactionRunner
import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.core.session.SessionReader
import com.optimal.fleet.feature.finance.domain.linking.InvoiceLinkState
import com.optimal.fleet.feature.finance.domain.linking.InvoiceServiceMode
import com.optimal.fleet.feature.finance.domain.linking.LinkVertoInvoiceCommand
import com.optimal.fleet.feature.finance.domain.linking.LinkVertoInvoiceResult
import com.optimal.fleet.feature.finance.domain.ports.FinanceInvoiceForLink
import com.optimal.fleet.feature.finance.domain.ports.FinanceProjectionPort
import com.optimal.fleet.feature.finance.domain.ports.SaveInvoiceLinkCommand
import com.optimal.fleet.feature.maintenance.data.importing.ImportedCostAllocator
import com.optimal.fleet.feature.maintenance.domain.importing.ImportVertoMaintenanceCommand
import com.optimal.fleet.feature.maintenance.domain.importing.ImportVertoMaintenanceResult
import com.optimal.fleet.feature.maintenance.domain.importing.ImportedMaintenanceMode
import com.optimal.fleet.feature.maintenance.domain.importing.MaintenanceImportPort
import com.optimal.fleet.feature.vehicles.domain.matching.LinkableVehicle
import com.optimal.fleet.feature.vehicles.domain.matching.VehicleMatchCandidates
import com.optimal.fleet.feature.vehicles.domain.matching.VehicleMatchHints
import com.optimal.fleet.feature.vehicles.domain.matching.VehicleMatchMethod
import com.optimal.fleet.feature.vehicles.domain.matching.VehicleMatchPolicy
import com.optimal.fleet.feature.vehicles.domain.matching.VehicleMatchResult
import com.optimal.fleet.feature.vehicles.domain.matching.VehicleMatcherPort
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking

private var checks = 0

private fun check(name: String, condition: Boolean) {
    require(condition) { "FAIL: $name" }
    checks += 1
    println("PASS: $name")
}

private class FakeSessionReader(
    var session: ActiveSession? = ActiveSession("user", "company", "أحمد", "OPTIMAL"),
) : SessionReader {
    override fun observeActiveSession(): Flow<ActiveSession?> = flowOf(session)
    override suspend fun currentSession(): ActiveSession? = session
}

private class FakeFinancePort : FinanceProjectionPort {
    var invoice: FinanceInvoiceForLink? = FinanceInvoiceForLink(
        id = "projection",
        vertoInvoiceId = "verto-1",
        invoiceNumber = "101",
        description = "تغيير زيت وفلاتر",
        totalMinor = 100_000,
        partsCostMinor = 60_000,
        serviceCostMinor = 40_000,
        invoiceDateEpochMillis = 1_000,
        voided = false,
    )
    var link: InvoiceLinkState? = null
    var saves = 0

    override suspend fun findInvoice(companyId: String, invoiceProjectionId: String) =
        invoice?.takeIf { companyId == "company" && it.id == invoiceProjectionId }

    override suspend fun findInvoiceByVertoId(companyId: String, vertoInvoiceId: String) =
        invoice?.takeIf { companyId == "company" && it.vertoInvoiceId == vertoInvoiceId }

    override suspend fun findLink(companyId: String, invoiceProjectionId: String) =
        link?.takeIf { companyId == "company" && it.invoiceProjectionId == invoiceProjectionId }

    override fun observeLink(companyId: String, invoiceProjectionId: String): Flow<InvoiceLinkState?> =
        flowOf(link)

    override suspend fun saveLink(command: SaveInvoiceLinkCommand) {
        saves += 1
        link = InvoiceLinkState(
            invoiceProjectionId = command.invoiceProjectionId,
            vehicleId = command.vehicleId,
            maintenanceOperationId = command.maintenanceOperationId,
            serviceMode = command.serviceMode,
            linkMethod = command.linkMethod,
            linkedAtEpochMillis = command.linkedAtEpochMillis,
        )
    }
}

private class FakeImportPort : MaintenanceImportPort {
    var calls = 0
    var last: ImportVertoMaintenanceCommand? = null
    var existing = false

    override suspend fun importInvoice(command: ImportVertoMaintenanceCommand): ImportVertoMaintenanceResult {
        calls += 1
        last = command
        val completed = command.mode == ImportedMaintenanceMode.FULL_MAINTENANCE
        return if (existing) {
            ImportVertoMaintenanceResult.Existing("operation", completed)
        } else {
            ImportVertoMaintenanceResult.Created("operation", completed)
        }
    }
}

private class FakeMatcherPort : VehicleMatcherPort {
    val vehicle = LinkableVehicle("vehicle", "هايلوكس", "12-34", 90_000)
    var manualCalls = 0
    var autoCalls = 0
    var odometerUpdates = 0
    var notFound = false

    override fun observeLinkableVehicles(companyId: String): Flow<List<LinkableVehicle>> =
        flowOf(listOf(vehicle))

    override suspend fun match(companyId: String, hints: VehicleMatchHints): VehicleMatchResult {
        autoCalls += 1
        return if (notFound) VehicleMatchResult.NotFound
        else VehicleMatchResult.Matched(vehicle, VehicleMatchMethod.PLATE)
    }

    override suspend fun selectManual(companyId: String, vehicleId: String): VehicleMatchResult {
        manualCalls += 1
        return if (!notFound && vehicleId == vehicle.id) {
            VehicleMatchResult.Matched(vehicle, VehicleMatchMethod.MANUAL)
        } else VehicleMatchResult.NotFound
    }

    override suspend fun updateOdometerIfNewer(companyId: String, vehicleId: String, odometerKm: Long): Boolean {
        odometerUpdates += 1
        return odometerKm > (vehicle.odometerKm ?: 0)
    }
}

private class FakeAuditPort : VertoLinkAuditPort {
    var calls = 0
    var last: VertoLinkAuditCommand? = null
    override suspend fun recordLink(command: VertoLinkAuditCommand) {
        calls += 1
        last = command
    }
}

private object DirectRunner : VertoLinkTransactionRunner {
    override suspend fun <T> run(block: suspend () -> T): T = block()
}

private fun coordinator(
    session: FakeSessionReader = FakeSessionReader(),
    finance: FakeFinancePort = FakeFinancePort(),
    importer: FakeImportPort = FakeImportPort(),
    matcher: FakeMatcherPort = FakeMatcherPort(),
    audit: FakeAuditPort = FakeAuditPort(),
): VertoInvoiceMaintenanceCoordinator = VertoInvoiceMaintenanceCoordinator(
    sessionReader = session,
    financeProjectionPort = finance,
    maintenanceImportPort = importer,
    vehicleMatcherPort = matcher,
    auditPort = audit,
    transactionRunner = DirectRunner,
    clock = Clock.fixed(Instant.ofEpochMilli(2_000), ZoneOffset.UTC),
)

fun main() = runBlocking {
    val remote = VehicleMatchPolicy.resolve(VehicleMatchCandidates("remote", "vin", "plate"))
    check("trusted remote id wins", remote == ("remote" to VehicleMatchMethod.TRUSTED_REMOTE_ID))
    val vin = VehicleMatchPolicy.resolve(VehicleMatchCandidates<String>(vin = "vin", plate = "plate"))
    check("VIN wins before plate", vin == ("vin" to VehicleMatchMethod.VIN))
    val plate = VehicleMatchPolicy.resolve(VehicleMatchCandidates<String>(plate = "plate"))
    check("plate is final automatic fallback", plate == ("plate" to VehicleMatchMethod.PLATE))
    check("no hints requires manual link", VehicleMatchPolicy.resolve(VehicleMatchCandidates<String>()) == null)

    val parts = ImportedCostAllocator.allocate(ImportedMaintenanceMode.PARTS_ONLY, 80_000, null, null)
    check("parts-only assigns invoice total to parts", parts.partsMinor == 80_000L && parts.serviceMinor == 0L)
    val full = ImportedCostAllocator.allocate(ImportedMaintenanceMode.FULL_MAINTENANCE, 100_000, 60_000, 40_000)
    check("full-service preserves explicit split", full.partsMinor == 60_000L && full.serviceMinor == 40_000L)
    val normalized = ImportedCostAllocator.allocate(ImportedMaintenanceMode.FULL_MAINTENANCE, 100_000, 80_000, 40_000)
    check(
        "mismatched source split is normalized to invoice total",
        normalized.partsMinor + normalized.serviceMinor == 100_000L,
    )
    val rejectedNegative = runCatching {
        ImportedCostAllocator.allocate(ImportedMaintenanceMode.PARTS_ONLY, -1, null, null)
    }.isFailure
    check("negative invoice total rejected", rejectedNegative)

    run {
        val finance = FakeFinancePort()
        val importer = FakeImportPort()
        val matcher = FakeMatcherPort()
        val audit = FakeAuditPort()
        val result = coordinator(finance = finance, importer = importer, matcher = matcher, audit = audit)(
            LinkVertoInvoiceCommand(
                invoiceProjectionId = "projection",
                serviceMode = InvoiceServiceMode.FULL_MAINTENANCE,
                manualVehicleId = "vehicle",
                sourceOdometerKm = 100_000,
                sourceOdometerTrusted = true,
            ),
        )
        check("manual full-service link succeeds", result is LinkVertoInvoiceResult.Success)
        check("manual matching used exactly once", matcher.manualCalls == 1 && matcher.autoCalls == 0)
        check("maintenance imported exactly once", importer.calls == 1)
        check("full-service import marked completed", importer.last?.mode == ImportedMaintenanceMode.FULL_MAINTENANCE)
        check("invoice link persisted once", finance.saves == 1)
        check("audit written once", audit.calls == 1)
        check("trusted newer odometer delegated", matcher.odometerUpdates == 1)
        check("audit records manual method", audit.last?.linkMethod == VehicleMatchMethod.MANUAL.name)
    }

    run {
        val finance = FakeFinancePort()
        val importer = FakeImportPort()
        val matcher = FakeMatcherPort()
        val audit = FakeAuditPort()
        val c = coordinator(finance = finance, importer = importer, matcher = matcher, audit = audit)
        val command = LinkVertoInvoiceCommand(
            invoiceProjectionId = "projection",
            serviceMode = InvoiceServiceMode.PARTS_ONLY,
            plateNumber = "12-34",
            sourceOdometerKm = 110_000,
            sourceOdometerTrusted = true,
        )
        val first = c(command)
        val second = c(command)
        check("automatic parts-only link succeeds", first is LinkVertoInvoiceResult.Success)
        check("automatic matcher used", matcher.autoCalls == 1)
        check("parts-only remains incomplete", (first as LinkVertoInvoiceResult.Success).completed.not())
        check("parts-only does not update odometer", matcher.odometerUpdates == 0)
        check("second call returns existing link", second is LinkVertoInvoiceResult.AlreadyLinked)
        check("idempotency prevents second import", importer.calls == 1)
        check("idempotency prevents second link save", finance.saves == 1)
        check("idempotency prevents second audit", audit.calls == 1)
    }

    run {
        val session = FakeSessionReader(null)
        val result = coordinator(session = session)(
            LinkVertoInvoiceCommand("projection", InvoiceServiceMode.PARTS_ONLY),
        )
        check("missing session rejected", result == LinkVertoInvoiceResult.SessionMissing)
    }

    run {
        val finance = FakeFinancePort().also { it.invoice = null }
        val result = coordinator(finance = finance)(
            LinkVertoInvoiceCommand("projection", InvoiceServiceMode.PARTS_ONLY, manualVehicleId = "vehicle"),
        )
        check("missing invoice rejected", result == LinkVertoInvoiceResult.InvoiceNotFound)
    }

    run {
        val finance = FakeFinancePort().also { it.invoice = it.invoice?.copy(voided = true) }
        val result = coordinator(finance = finance)(
            LinkVertoInvoiceCommand("projection", InvoiceServiceMode.PARTS_ONLY, manualVehicleId = "vehicle"),
        )
        check("void invoice rejected", result == LinkVertoInvoiceResult.InvoiceVoided)
    }

    run {
        val matcher = FakeMatcherPort().also { it.notFound = true }
        val result = coordinator(matcher = matcher)(
            LinkVertoInvoiceCommand("projection", InvoiceServiceMode.PARTS_ONLY, manualVehicleId = "missing"),
        )
        check("unknown vehicle rejected", result == LinkVertoInvoiceResult.VehicleNotFound)
    }

    run {
        val result = coordinator()(
            LinkVertoInvoiceCommand(
                "projection",
                InvoiceServiceMode.FULL_MAINTENANCE,
                manualVehicleId = "vehicle",
                sourceOdometerKm = -1,
                sourceOdometerTrusted = true,
            ),
        )
        check("negative odometer rejected", result == LinkVertoInvoiceResult.InvalidOdometer)
    }

    println("\nV10 harness checks: $checks/$checks")
}
