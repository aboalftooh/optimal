#!/usr/bin/env python3
"""Static acceptance gate for OPTIMAL v58 Verto archive, notifications and deep links."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "archive_model": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoArchiveState.kt",
    "archive_usecases": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoArchiveUseCases.kt",
    "authorization": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/access/VertoChatAuthorization.kt",
    "repository_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "message_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMessageDao.kt",
    "user_state": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity/verto/VertoConversationUserStateEntity.kt",
    "queue": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueConstants.kt",
    "participant": ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncParticipant.kt",
    "remote_api": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/OptimalVertoMessagesApi.kt",
    "remote_models": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoMessageRemoteModels.kt",
    "remote": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoMessageRemoteDataSource.kt",
    "notification_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt",
    "notification_entity": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity/NotificationEntity.kt",
    "candidate_source": ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data/RoomNotificationCandidateSource.kt",
    "notification_gateway": ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data/RoomNotificationCenterGateway.kt",
    "notification_contracts": ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationContracts.kt",
    "notification_policy": ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationEventPolicy.kt",
    "notification_models": ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationModels.kt",
    "notification_usecases": ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationUseCases.kt",
    "deep_link": ROOT / "app/src/main/java/com/optimal/fleet/navigation/deeplink/NotificationDeepLink.kt",
    "optimal_app": ROOT / "app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt",
    "main_activity": ROOT / "app/src/main/java/com/optimal/fleet/MainActivity.kt",
    "worker": ROOT / "app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt",
    "worker_entry": ROOT / "app/src/main/java/com/optimal/fleet/work/SyncWorkerEntryPoint.kt",
    "unified_sync": ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt",
    "chat_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt",
    "chat_screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "chat_vm": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "home": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoHomeEntry.kt",
    "backend": ROOT / "supabase/migrations/20260731004200_optimal_verto_message_rpcs.sql",
    "archive_test": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoArchivePolicyTest.kt",
    "notification_test": ROOT / "feature/notifications/src/test/java/com/optimal/fleet/feature/notifications/VertoMessageNotificationPolicyTest.kt",
}
checks: list[str] = []

def text(name: str) -> str:
    path = FILES[name]
    assert path.is_file(), f"missing {path.relative_to(ROOT)}"
    return path.read_text(encoding="utf-8")

def check(label: str, condition: bool) -> None:
    assert condition, label
    checks.append(label)

archive_model = text("archive_model")
for token in ["VertoArchiveSyncCommand", "VertoArchivePolicy", "remainsArchived", "latestRemoteMessage <= archivedThrough"]:
    check(f"archive policy:{token}", token in archive_model)
check("domain archive model stays pure", not any(x in archive_model for x in ("android.", "androidx.", "kotlinx.serialization")))

usecases = text("archive_usecases")
for token in ["SET_CONVERSATION_ARCHIVED", "enqueueArchiveState", "scheduler.schedule(grant.userId, grant.companyId)", "SyncPendingVertoArchiveUseCase", "ARCHIVE_SESSION_MISMATCH"]:
    check(f"archive usecase:{token}", token in usecases)

auth = text("authorization")
check("archive requires view capability", "SET_CONVERSATION_ARCHIVED(MemberCapability.VIEW_VERTO_CHAT)" in auth)

contract = text("repository_contract")
for token in ["enqueueArchiveState", "syncPendingArchiveState", "VertoArchiveEnqueueResult", "VertoArchiveSyncResult", "Superseded"]:
    check(f"repository contract:{token}", token in contract)

repo = text("repository")
for token in [
    "archiveMutex.withLock", "VertoArchiveSyncCommand", "VERTO_CONVERSATION_STATE", "SET_ARCHIVED",
    "transactionRunner.run", "syncQueueDao.enqueueRequired", "latestRemoteActive", "VertoArchivePolicy.remainsArchived",
    "VertoArchiveRemoteResult", "ARCHIVE_SESSION_MISMATCH", "archiveCursorOrNull", "remoteCursorOrNull",
]:
    check(f"repository:{token}", token in repo)
check("archive is local-first before scheduling", repo.index("userStateDao.upsert") < repo.index("syncQueueDao.enqueueRequired"))
check("archive cursor is per current user", 'aggregateId = "${conversation.id}:${grant.userId}"' in repo)
check("newer message clears archive cursor", "if (remainsArchived)" in repo and "else {\n                    null" in repo)

message_dao = text("message_dao")
for token in ["latestRemoteActive", "remoteStatus = 'ACTIVE'", "ORDER BY serverCreatedAtEpochMillis DESC, remoteId DESC"]:
    check(f"message dao:{token}", token in message_dao)

state = text("user_state")
for token in ["userId", "archived", "archivedThroughCreatedAtEpochMillis", "archivedThroughMessageRemoteId", 'Index(value = ["conversationId", "userId"], unique = true)']:
    check(f"per-user state:{token}", token in state)

queue = text("queue")
check("archive aggregate exists", 'VERTO_CONVERSATION_STATE = "VERTO_CONVERSATION_STATE"' in queue)
check("archive operation exists", 'SET_ARCHIVED = "SET_ARCHIVED"' in queue)
participant = text("participant")
for token in ["VERTO_CONVERSATION_STATE", "SET_ARCHIVED", "SyncPendingVertoArchiveUseCase", "INVALID_VERTO_ARCHIVE_PAYLOAD", "Superseded"]:
    check(f"sync participant:{token}", token in participant)

api = text("remote_api")
check("archive RPC endpoint", "optimal_verto_set_conversation_archived" in api)
models = text("remote_models")
for token in ["p_archived", "p_through_created_at", "p_through_message_id", "archived_through_created_at", "archived_through_message_id"]:
    check(f"archive DTO:{token}", token in models)
remote = text("remote")
for token in ["setArchived", "VertoArchiveRemoteResult", "archive_cursor_not_latest", "message_cursor_invalid", "VERTO_ARCHIVE_CURSOR_STALE"]:
    check(f"archive remote:{token}", token in remote)

backend = text("backend")
for token in ["optimal_verto_set_conversation_archived", "v_context.auth_user_id", "archive_cursor_not_latest", "delete from public.optimal_verto_conversation_states"]:
    check(f"backend contract:{token}", token in backend)
check("no new v58 migration", not any((ROOT / "supabase/migrations").glob("*v58*")))

notification_dao = text("notification_dao")
for token in ["findUnreadVertoMessages", "state.userId = :userId", "state.canView = 1", "message.senderSide = 'VERTO'", "message.remoteStatus = 'ACTIVE'", "lastReadCreatedAtEpochMillis"]:
    check(f"notification candidate query:{token}", token in notification_dao)
source = text("candidate_source")
for token in ["findUnreadVertoMessages", "vertoMessageKey(userId, messageRemoteId)", "VERTO_MESSAGE", "VERTO_CONVERSATION", "فتح المحادثة"]:
    check(f"notification source:{token}", token in source)
check("Verto notification target is user-scoped", "NotificationTarget(NotificationTargetType.VERTO_CONVERSATION, userId)" in source)
notification_gateway = text("notification_gateway")
for token in ["observeNotificationsForUser", "loadNotificationsPageForUser", "observeUnreadCountForUser", "findUndeliveredForUser", "markDeliveredForUser", "markReadForUser", "markAllReadForUser"]:
    check(f"notification gateway scope:{token}", token in notification_gateway)
notification_contracts = text("notification_contracts")
check("notification center contract carries user id", "observeNotifications(companyId: String, userId: String)" in notification_contracts)
for token in ["observeNotificationsForUser", "loadNotificationsPageForUser", "observeUnreadCountForUser", "findUndeliveredForUser", "markDeliveredForUser", "markReadForUser", "markAllReadForUser"]:
    check(f"notification DAO scope:{token}", token in notification_dao)
check("user-scoped SQL excludes other Verto targets", "targetType != 'VERTO_CONVERSATION' OR targetId = :userId" in notification_dao)
policy = text("notification_policy")
check("dedup key includes user and message", '"verto-message:$userId:$messageRemoteId"' in policy)
entity = text("notification_entity")
check("database dedup unique index", 'Index(value = ["companyId", "eventKey"], unique = true)' in entity)
models = text("notification_models")
check("message notification type", "VERTO_MESSAGE" in models)
check("conversation target type", "VERTO_CONVERSATION" in models)
notification_usecases = text("notification_usecases")
check("candidate collection gets active user", "userId = session.userId" in notification_usecases)

deep_link = text("deep_link")
check("Verto target maps directly to conversation", "NotificationTargetType.VERTO_CONVERSATION -> VertoDestination.CONVERSATION" in deep_link)
check("intent target enum is validated", "runCatching { NotificationTargetType.valueOf(value) }" in deep_link)
optimal_app = text("optimal_app")
main_activity = text("main_activity")
check("signed-out deep link remains pending", "if (gateState !is SessionGateState.SignedIn) return@LaunchedEffect" in optimal_app)
check("deep link is consumed only after route handling", optimal_app.index("if (gateState !is SessionGateState.SignedIn)") < optimal_app.index("onNotificationNavigationConsumed()"))
check("activity retains pending navigation request", "pendingNotificationNavigation by mutableStateOf" in main_activity)
check("new intents replace pending navigation request", "pendingNotificationNavigation = NotificationNavigationRequest.fromIntent(intent)" in main_activity)

worker = text("worker")
worker_entry = text("worker_entry")
unified_sync = text("unified_sync")
check("worker exposes unified sync", "unifiedSyncCoordinator" in worker_entry)
check("background worker pulls messages", "MessagePullUnifiedSyncParticipant" in unified_sync and "pullMessages(session)" in unified_sync)
check("pull happens before notification generation", worker.index("unifiedSyncCoordinator") < worker.index("generateAndDeliverNotifications"))
check("unavailable pull retries worker", "VertoRefreshResult.Unavailable" in unified_sync and "UnifiedSyncStepResult.RetryRequired" in unified_sync)

chat_contract = text("chat_contract")
check("archive UI event exists", "ToggleArchived" in chat_contract)
check("archive busy state exists", "archiveOperationInProgress" in chat_contract)
chat_vm = text("chat_vm")
for token in ["SetVertoConversationArchivedUseCase", "toggleArchived", "!current.linkState.archived"]:
    check(f"view model:{token}", token in chat_vm)
screen = text("chat_screen")
for token in ["verto-archive-toggle", "Icons.Outlined.Archive", "Icons.Outlined.Unarchive", "مؤرشفة لهذا المستخدم"]:
    check(f"screen:{token}", token in screen)
home = text("home")
check("archived state remains reachable from home", "مؤرشفة لهذا المستخدم" in home)

archive_test = text("archive_test")
for token in ["emptyConversationRemainsArchivedUntilFirstRemoteMessage", "newerRemoteMessageAutomaticallyUnarchives", "explicitUnarchiveAlwaysWins"]:
    check(f"archive test:{token}", token in archive_test)
notification_test = text("notification_test")
for token in ["sameMessageForSameUserHasStableDeduplicationKey", "usersDoNotSuppressEachOthersMessageNotification"]:
    check(f"notification test:{token}", token in notification_test)

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains immutable", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version remains stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
all_text = "\n".join(path.read_text(encoding="utf-8") for path in FILES.values())
check("no merge markers", not any(marker in all_text for marker in ("<<<<<<<", "=======", ">>>>>>>")))
check("no service role in client changes", "service_role" not in "\n".join(text(name).lower() for name in FILES if name != "backend"))

build = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
check("Gradle registers v58 gate", "vertoDailyCycleContractCheck" in build)
check("staticQualityCheck depends on v58", "vertoDailyCycleContractCheck," in build)
print(f"v58 Verto daily-cycle contract: {len(checks)}/{len(checks)} PASS")
