#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []
def read(path): return (ROOT / path).read_text(encoding='utf-8')
def check(name, ok, detail=''): checks.append((name, bool(ok), detail))

build = read('app/build.gradle.kts')
check('versionCode 29', re.search(r'\bversionCode\s*=\s*29\b', build))
check('versionName v34', 'versionName = "0.34.0-v34"' in build)
old_repo = ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceOperationRepository.kt'
check('monolithic repository removed', not old_repo.exists())

repo_paths = {
    'query': 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceQueryRepository.kt',
    'create': 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt',
    'edit': 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt',
    'complete': 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt',
    'follow-up': 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt',
}
for name, path in repo_paths.items():
    text = read(path)
    check(f'{name} repository exists', (ROOT/path).is_file())
    check(f'{name} repository focused size', len(text.splitlines()) <= 160, str(len(text.splitlines())))
for name in ['create', 'edit', 'complete', 'follow-up']:
    text = read(repo_paths[name])
    check(f'{name} transaction boundary', 'transactionRunner.run' in text)
    check(f'{name} unified audit', 'auditPort.append' in text)

query = read(repo_paths['query'])
check('query repository implements read contracts', all(x in query for x in ['MaintenanceOperationQuery', 'MaintenanceHistoryQuery', 'MaintenanceOperationLookup']))
check('query repository contains no write method', not re.search(r'fun\s+(create|update|complete|convert)', query))

di = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/di/MaintenanceDataModule.kt')
for binding in ['RoomMaintenanceCreateRepository','RoomMaintenanceQueryRepository','RoomMaintenanceEditRepository','RoomMaintenanceCompleteRepository','RoomMaintenanceFollowUpRepository']:
    check(f'Hilt binds {binding}', binding in di)
check('old repository absent from active source and tests', 'RoomMaintenanceOperationRepository' not in '\n'.join(
    p.read_text(encoding='utf-8') for base in [ROOT/'app/src', ROOT/'feature/maintenance/src']
    for p in base.rglob('*') if p.is_file() and p.suffix in {'.kt','.py','.sh'}
))

for path in [
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/ValidateMaintenanceEdit.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/PrepareMaintenanceEdit.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/ValidateMaintenanceCompletion.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/PrepareMaintenanceCompletion.kt',
]: check(f'use case exists {Path(path).stem}', (ROOT/path).is_file())
update_uc = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/UpdateMaintenanceOperation.kt')
complete_uc = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/complete/CompleteMaintenanceOperation.kt')
check('edit validation precedes session lookup', update_uc.index('validateEdit(edit)') < update_uc.index('currentSession()'))
check('completion validation precedes session lookup', complete_uc.index('validateCompletion(completion)') < complete_uc.index('currentSession()'))
check('use cases read current operation', 'lookup.findOperation' in update_uc and 'lookup.findOperation' in complete_uc)

vm_path = 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt'
vm = read(vm_path)
check('ViewModel reduced below 250 lines', len(vm.splitlines()) <= 250, str(len(vm.splitlines())))
check('ViewModel uses reducer', 'MaintenanceDetailsStateReducer.reduce' in vm)
check('ViewModel separates effects', 'Channel<MaintenanceDetailsUiEffect>' in vm and 'receiveAsFlow()' in vm)
check('ViewModel has no DAO Entity or data adapter', not re.search(r'(Dao|Entity|\.data\.)', vm))
check('ViewModel delegates form parsing', 'MaintenanceDetailsFormParser' in vm)

route = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsRoute.kt')
check('route reduced below 100 lines', len(route.splitlines()) <= 100, str(len(route.splitlines())))
for file in ['MaintenanceDetailsContent.kt','MaintenanceCompletionContent.kt','MaintenanceEditContent.kt','MaintenanceDetailsComponents.kt']:
    check(f'UI split {file}', (ROOT/'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details'/file).is_file())
ui_text = '\n'.join(read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/'+f) for f in [
    'MaintenanceDetailsRoute.kt','MaintenanceDetailsContent.kt','MaintenanceCompletionContent.kt','MaintenanceEditContent.kt','MaintenanceDetailsComponents.kt'])
check('Composable has no validator or repository', not re.search(r'(Validator|Repository|Dao|Entity)', ui_text))
check('stable details branches retained', all(token in ui_text for token in ['maintenance-details-loading','maintenance-details-error','maintenance-details-empty']))

for path in [
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/PrepareMaintenanceEditTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/PrepareMaintenanceCompletionTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsStateReducerTest.kt',
]: check(f'test exists {Path(path).name}', (ROOT/path).is_file())

for path in [
    'README.md','AGENTS.md','docs/sessions/v34.md','docs/verifications/verification-v34.md',
    'verification-v34.md','PATCH_MANIFEST-v34.md','CHANGED_FILES-v34.txt','DELETED_FILES-v34.txt',
]: check(f'delivery {path}', (ROOT/path).is_file())
for script in [
    'run-v34-maintenance-domain-compile.sh','run-v34-maintenance-data-compile.sh',
    'run-v34-maintenance-presentation-compile.sh','run-v34-maintenance-tests-compile.sh',
    'run-v34-maintenance-route-syntax-check.sh',
]: check(f'gate {script}', (ROOT/'scripts'/script).is_file())

failed = [(n,d) for n,ok,d in checks if not ok]
for name,ok,detail in checks:
    suffix=f' ({detail})' if detail and not ok else ''
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)}')
if failed:
    print('FAILED: '+', '.join(n for n,_ in failed), file=sys.stderr)
    sys.exit(1)
