#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

component_dir = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2"
component_text = "\n".join(p.read_text(encoding="utf-8") for p in sorted(component_dir.glob("*.kt")))
required = [
    "OptimalAppTopBar", "OptimalBottomNavigation", "OptimalSyncStatus",
    "OptimalPrimaryButton", "OptimalSecondaryButton", "OptimalTertiaryButton",
    "OptimalDestructiveButton", "OptimalIconButton", "OptimalHeroButton", "OptimalBottomActionBar",
    "OptimalSurfaceCard", "OptimalMetricCard", "OptimalActionCard", "OptimalFormSection",
    "OptimalListRow", "OptimalSectionHeader", "OptimalTextField", "OptimalMoneyField",
    "OptimalSelectionField", "OptimalSearchField", "OptimalFilterChip", "OptimalSegmentedControl",
    "OptimalStatusBadge", "OptimalInlineStatus", "OptimalLoadingState", "OptimalEmptyState",
    "OptimalErrorState", "OptimalDialog", "OptimalConfirmationDialog",
]
for name in required:
    check(f"shared component {name}", bool(re.search(rf"\bfun\s+(?:<[^>]+>\s+)?{re.escape(name)}\s*\(", component_text)))

app_shell = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalAppShell.kt")
check("top bar uses locked appBarBrand role", "style = OptimalTypographyRoles.appBarBrand" in app_shell)
check("top bar uses locked appBarTitle role", "style = OptimalTypographyRoles.appBarTitle" in app_shell)
check("top bar icon wells use canonical primary container", "containerColor = MaterialTheme.colorScheme.primaryContainer" in app_shell)
check("bottom nav has subtle top divider", "HorizontalDivider(" in app_shell)
check("bottom nav selected indicator uses primary container", "indicatorColor = MaterialTheme.colorScheme.primaryContainer" in app_shell)
check("bottom nav inactive items use onSurfaceVariant", app_shell.count("unselected") >= 2 and "MaterialTheme.colorScheme.onSurfaceVariant" in app_shell)

sync_expectations = {
    "SavedLocally": ("تم الحفظ على الهاتف", "Success"),
    "WaitingForNetwork": ("بانتظار الشبكة", "Warning"),
    "Syncing": ("جاري المزامنة", "Info"),
    "TemporaryFailure": ("تعذر مؤقتًا؛ سنعيد المحاولة", "Danger"),
}
for state, (label, tone) in sync_expectations.items():
    block_ok = state in app_shell and label in app_shell and f"OptimalStatusTone.{tone}" in app_shell
    check(f"sync state {state} canonical semantic path", block_ok)

scaffold = read("app/src/main/java/com/optimal/fleet/ui/OptimalAppScaffold.kt")
for name in ["OptimalAppTopBar", "OptimalBottomNavigation", "OptimalSyncStatus"]:
    check(f"app scaffold consumes {name}", name in scaffold)
check("secondary routes can suppress branded top-level label", "showBrand = showTopLevelNavigation" in scaffold)

app = read("app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt")
check("STA-001 uses canonical loading state", "OptimalLoadingState(" in app and "session-initializing-state" in app)
check("STA-001 has explicit initialization copy", "جارٍ تهيئة الجلسة" in app)

nav = read("app/src/main/java/com/optimal/fleet/navigation/AppDestination.kt")
labels = re.findall(r'label = "([^"]+)"', nav)
check("bottom navigation still has five destinations", labels[:5] == ["الرئيسية", "السيارات", "الصيانة", "المالية", "المزيد"], str(labels[:5]))

check("no design-system Bottom Sheet primitive introduced", "ModalBottomSheet" not in component_text and "fun OptimalBottomSheet" not in component_text)

ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
check("ledger still has 123 inventory rows", len(rows) == 123, str(len(rows)))
statuses = dict(rows)
expected_migrated = {"STA-001", "STA-085", "STA-086", "STA-087", "STA-088"}
actual_migrated = {item for item, status in rows if status == "MIGRATED"}
check("only SESSION-98 global states migrated", actual_migrated == expected_migrated, str(sorted(actual_migrated)))
check("remaining ledger count is 118 UNMIGRATED", sum(status == "UNMIGRATED" for _, status in rows) == 118)
check("no blocked ledger rows", all(status != "BLOCKED" for _, status in rows))

allowlist = [
    line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines()
    if line.strip() and not line.lstrip().startswith("#")
]
check("feature allowlist unchanged at 64 not-yet-migrated UI files", len(allowlist) == 64, str(len(allowlist)))

proc = subprocess.run(
    [sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")],
    cwd=ROOT,
    text=True,
    capture_output=True,
)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard has zero active violations", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-98 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
