#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/javax/inject"
cat > "$TMP_DIR/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION) annotation class Inject
KT
kotlinc -nowarn -cp "$COROUTINES_JAR" \
 "$TMP_DIR/javax/inject/Inject.kt" \
 "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
 "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt" \
 "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditContracts.kt" \
 "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
 "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
 "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt" \
 "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleDraft.kt" \
 "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleFilter.kt" \
 "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/repository/VehicleRepository.kt" \
 "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/LoadVehiclesPage.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationSummary.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperation.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationDetails.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceAttachment.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceAuditEvent.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationType.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/OperationSource.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/OperationStatus.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/query/MaintenanceOperationFilter.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/query/SearchMaintenance.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceOperationQuery.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceHistoryQuery.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/LoadMaintenanceOperationsPage.kt" \
 "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/history/LoadMaintenanceHistoryPage.kt" \
 "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjection.kt" \
 "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/VertoInvoiceSnapshot.kt" \
 "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/query/InvoiceSearch.kt" \
 "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/InvoiceProjectionRepository.kt" \
 "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/LoadInvoiceProjectionsPage.kt" \
 "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/ObserveInvoiceOutstandingTotal.kt" \
 "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationModels.kt" \
 "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationContracts.kt" \
 "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationUseCases.kt" \
 -d "$TMP_DIR/v33-domain.jar"
echo "PASS: vehicle paging domain compiles"
echo "PASS: maintenance paging domain compiles"
echo "PASS: invoice paging domain compiles"
echo "PASS: notification paging domain compiles"
echo "PASS: activity paging contract compiles"
echo "V33 focused domain compilation: 5/5"
