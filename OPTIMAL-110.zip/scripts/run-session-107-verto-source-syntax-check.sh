#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mapfile -t FILES < <(find "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation" -name '*.kt' -print | sort)
FILES+=("$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt")
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 90s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: SESSION-107 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: SESSION-107 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} Verto/design-system source files; unresolved Android/Compose symbols were intentionally ignored without Gradle classpath."
