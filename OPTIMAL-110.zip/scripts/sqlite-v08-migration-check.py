#!/usr/bin/env python3
import sqlite3
import tempfile
from pathlib import Path

passed = 0
checks = 0

def verify(name, condition):
    global passed, checks
    checks += 1
    if not condition:
        raise AssertionError(name)
    passed += 1
    print(f"PASS: {name}")

with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "optimal-v08.db"
    db = sqlite3.connect(path)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(
        """
        CREATE TABLE companies(
            id TEXT NOT NULL PRIMARY KEY,
            remoteId TEXT,
            name TEXT NOT NULL,
            createdAtEpochMillis INTEGER NOT NULL,
            updatedAtEpochMillis INTEGER NOT NULL,
            syncState TEXT NOT NULL
        );
        INSERT INTO companies VALUES ('c1', NULL, 'شركة 1', 1, 1, 'PENDING');

        CREATE TABLE pending_sync_operations (
            id TEXT NOT NULL,
            companyId TEXT NOT NULL,
            aggregateType TEXT NOT NULL,
            aggregateId TEXT NOT NULL,
            operationType TEXT NOT NULL,
            payload TEXT NOT NULL,
            idempotencyKey TEXT NOT NULL,
            localVersion INTEGER NOT NULL,
            state TEXT NOT NULL,
            attemptCount INTEGER NOT NULL,
            nextAttemptAtEpochMillis INTEGER NOT NULL,
            leaseUntilEpochMillis INTEGER,
            lastErrorCode TEXT,
            remoteId TEXT,
            remoteVersion INTEGER,
            createdAtEpochMillis INTEGER NOT NULL,
            updatedAtEpochMillis INTEGER NOT NULL,
            PRIMARY KEY(id),
            FOREIGN KEY(companyId) REFERENCES companies(id) ON UPDATE NO ACTION ON DELETE CASCADE
        );
        CREATE INDEX index_pending_sync_operations_companyId ON pending_sync_operations(companyId);
        CREATE UNIQUE INDEX index_pending_sync_operations_idempotencyKey ON pending_sync_operations(idempotencyKey);
        CREATE INDEX index_pending_sync_operations_companyId_state_nextAttemptAtEpochMillis ON pending_sync_operations(companyId,state,nextAttemptAtEpochMillis);
        CREATE INDEX index_pending_sync_operations_aggregateType_aggregateId_localVersion ON pending_sync_operations(aggregateType,aggregateId,localVersion);
        CREATE INDEX index_pending_sync_operations_leaseUntilEpochMillis ON pending_sync_operations(leaseUntilEpochMillis);

        CREATE TABLE sync_conflict_audit (
            id TEXT NOT NULL,
            companyId TEXT NOT NULL,
            operationId TEXT NOT NULL,
            aggregateType TEXT NOT NULL,
            aggregateId TEXT NOT NULL,
            localVersion INTEGER NOT NULL,
            remoteVersion INTEGER NOT NULL,
            losingPayload TEXT NOT NULL,
            winningPayload TEXT NOT NULL,
            resolution TEXT NOT NULL,
            createdAtEpochMillis INTEGER NOT NULL,
            PRIMARY KEY(id),
            FOREIGN KEY(companyId) REFERENCES companies(id) ON UPDATE NO ACTION ON DELETE CASCADE
        );
        CREATE INDEX index_sync_conflict_audit_companyId ON sync_conflict_audit(companyId);
        CREATE INDEX index_sync_conflict_audit_operationId ON sync_conflict_audit(operationId);
        CREATE INDEX index_sync_conflict_audit_aggregateType_aggregateId ON sync_conflict_audit(aggregateType,aggregateId);
        CREATE INDEX index_sync_conflict_audit_createdAtEpochMillis ON sync_conflict_audit(createdAtEpochMillis);
        """
    )

    verify("queue table created", db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='pending_sync_operations'").fetchone() is not None)
    verify("conflict audit table created", db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sync_conflict_audit'").fetchone() is not None)
    verify("idempotency unique index exists", db.execute("SELECT name FROM sqlite_master WHERE name='index_pending_sync_operations_idempotencyKey'").fetchone() is not None)

    row = ('op1','c1','VEHICLE','v1','UPSERT','{}','VEHICLE:v1:1',1,'PENDING',0,0,None,None,None,None,1,1)
    db.execute("INSERT INTO pending_sync_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)
    db.commit()
    try:
        duplicate = ('op2',) + row[1:]
        db.execute("INSERT INTO pending_sync_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", duplicate)
        db.commit()
        duplicate_rejected = False
    except sqlite3.IntegrityError:
        db.rollback()
        duplicate_rejected = True
    verify("duplicate idempotency key rejected", duplicate_rejected)
    verify("one queue row remains", db.execute("SELECT COUNT(*) FROM pending_sync_operations").fetchone()[0] == 1)

    due = db.execute("SELECT id FROM pending_sync_operations WHERE state IN ('PENDING','RETRY') AND nextAttemptAtEpochMillis <= 100 ORDER BY createdAtEpochMillis,id LIMIT 10").fetchall()
    verify("due operation selected", due == [('op1',)])
    claimed = db.execute("UPDATE pending_sync_operations SET state='RUNNING',leaseUntilEpochMillis=200,updatedAtEpochMillis=100 WHERE id='op1' AND state IN ('PENDING','RETRY')").rowcount
    verify("operation claimed once", claimed == 1)
    verify("second claim rejected", db.execute("UPDATE pending_sync_operations SET state='RUNNING' WHERE id='op1' AND state IN ('PENDING','RETRY')").rowcount == 0)

    recovered = db.execute("UPDATE pending_sync_operations SET state='RETRY',leaseUntilEpochMillis=NULL,nextAttemptAtEpochMillis=201,lastErrorCode='PROCESS_DEATH_RECOVERY',updatedAtEpochMillis=201 WHERE state='RUNNING' AND leaseUntilEpochMillis IS NOT NULL AND leaseUntilEpochMillis <= 201").rowcount
    verify("expired lease recovered after process death", recovered == 1)
    verify("recovered row is retryable", db.execute("SELECT state,lastErrorCode FROM pending_sync_operations WHERE id='op1'").fetchone() == ('RETRY','PROCESS_DEATH_RECOVERY'))

    db.execute("UPDATE pending_sync_operations SET state='RUNNING',leaseUntilEpochMillis=300 WHERE id='op1'")
    retried = db.execute("UPDATE pending_sync_operations SET state='RETRY',attemptCount=attemptCount+1,nextAttemptAtEpochMillis=400,leaseUntilEpochMillis=NULL,lastErrorCode='TIMEOUT',updatedAtEpochMillis=250 WHERE id='op1' AND state='RUNNING'").rowcount
    verify("temporary failure schedules retry", retried == 1)
    verify("retry increments attempt", db.execute("SELECT attemptCount,nextAttemptAtEpochMillis FROM pending_sync_operations WHERE id='op1'").fetchone() == (1,400))

    db.execute("UPDATE pending_sync_operations SET state='RUNNING',leaseUntilEpochMillis=500 WHERE id='op1'")
    succeeded = db.execute("UPDATE pending_sync_operations SET state='SUCCEEDED',leaseUntilEpochMillis=NULL,lastErrorCode=NULL,remoteId='rv1',remoteVersion=2,updatedAtEpochMillis=450 WHERE id='op1' AND state='RUNNING'").rowcount
    verify("success transition succeeds", succeeded == 1)
    verify("success metadata retained", db.execute("SELECT state,remoteId,remoteVersion FROM pending_sync_operations WHERE id='op1'").fetchone() == ('SUCCEEDED','rv1',2))
    verify("succeeded operation not due again", db.execute("SELECT COUNT(*) FROM pending_sync_operations WHERE state IN ('PENDING','RETRY')").fetchone()[0] == 0)

    db.execute("INSERT INTO sync_conflict_audit VALUES (?,?,?,?,?,?,?,?,?,?,?)", ('a1','c1','op1','VEHICLE','v1',2,3,'local','remote','REMOTE_WINS',500))
    verify("conflict losing payload preserved", db.execute("SELECT losingPayload,winningPayload,resolution FROM sync_conflict_audit WHERE id='a1'").fetchone() == ('local','remote','REMOTE_WINS'))

    db.execute("DELETE FROM companies WHERE id='c1'")
    verify("company cascade removes queue", db.execute("SELECT COUNT(*) FROM pending_sync_operations").fetchone()[0] == 0)
    verify("company cascade removes conflict audit", db.execute("SELECT COUNT(*) FROM sync_conflict_audit").fetchone()[0] == 0)

print(f"SQLite v08 checks: {passed}/{checks}")
