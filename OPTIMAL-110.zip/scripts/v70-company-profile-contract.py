#!/usr/bin/env python3
"""Static acceptance contract for Optimal company registration/profile changes."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def check(name: str, ok: bool) -> None:
    checks.append((name, bool(ok)))

models = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt")
for field in [
    "companyName", "businessActivity", "managerName", "companyAddress",
    "vehicleCount", "employeeCount", "usesMaintenanceWorkshop", "maintenanceWorkshopName",
]:
    check(f"registration model contains {field}", re.search(rf"\bval\s+{field}\s*:", models) is not None)

form = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt")
for label in [
    "اسم الشركة *", "النشاط — اختياري", "اسم المدير *", "عنوان الشركة — اختياري",
    "عدد السيارات — اختياري", "عدد الموظفين — اختياري",
    "هل تتعاملون مع ورشة للصيانة؟", "اسم الورشة *",
]:
    check(f"registration form shows {label}", label in form)
check("company name is read-only in registration", 'value = state.companyName' in form and 'enabled = false' in form)
check("workshop name is conditional", "if (state.usesMaintenanceWorkshop)" in form)

repository = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomAccountProfileRepository.kt")
check("owner and manager may edit company", "setOf(MemberRole.OWNER, MemberRole.MANAGER)" in repository)
check("employee company edits are rejected", "SaveAccountProfileResult.NotAllowed" in repository)
check("personal profile update exists", "updatePersonalProfile" in repository)
check("company update is audited as business activity", "AuditAction.COMPANY_UPDATED" in repository)

dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/AuditEventDao.kt")
for action in ["SYNC_BATCH_COMPLETED", "SYNC_CONFLICT_RESOLVED", "VERTO_CHAT_ACCESS_DENIED"]:
    check(f"activity queries exclude {action}", action in dao)
check("all user activity queries apply exclusion", dao.count("action NOT IN") >= 7)

forbidden = ("على هذا الجهاز", "محليًا", "نسخة محلية", "Supabase", "بيانات الاختبار", "رسالة تطوير")
hits = []
for base in [ROOT / "feature", ROOT / "app/src/main"]:
    for path in base.rglob("*Presentation*.kt"):
        source = path.read_text(encoding="utf-8", errors="ignore")
        for value in re.findall(r'"(?:[^"\\]|\\.)*"', source):
            if any(term in value for term in forbidden):
                hits.append(f"{path.relative_to(ROOT)}:{value}")
    for path in base.rglob("*ViewModel.kt"):
        source = path.read_text(encoding="utf-8", errors="ignore")
        for value in re.findall(r'"(?:[^"\\]|\\.)*"', source):
            if any(term in value for term in forbidden):
                hits.append(f"{path.relative_to(ROOT)}:{value}")
check("user-facing development messages are absent", not hits)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\nCompany profile contract: {len(checks)-len(failed)}/{len(checks)}")
if hits:
    print("Forbidden messages:")
    print("\n".join(hits))
if failed:
    print("FAILED: " + ", ".join(failed), file=sys.stderr)
    sys.exit(1)
