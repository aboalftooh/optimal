#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v57 private Verto attachment transfer."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "remote_models": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoAttachmentRemoteModels.kt",
    "api": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/OptimalVertoAttachmentsApi.kt",
    "remote": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoAttachmentRemoteDataSource.kt",
    "file_store": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/VertoPrivateAttachmentFileStore.kt",
    "coordinator": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/VertoAttachmentSendCoordinator.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "repo_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt",
    "policy": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoAttachmentTransfer.kt",
    "usecases": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAttachmentUseCases.kt",
    "participant": ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncParticipant.kt",
    "queue": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueConstants.kt",
    "open": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentOpenContract.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "route": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "tests": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAttachmentTransferPolicyTest.kt",
}
CHAT_PRESENTATION_DIR = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation"
CHAT_PRESENTATION_FILES = (
    "VertoChatScreen.kt",
    "VertoChatChrome.kt",
    "VertoChatMessages.kt",
    "VertoChatAttachments.kt",
    "VertoChatComposer.kt",
    "VertoChatFormatting.kt",
)

def chat_presentation_text() -> str:
    return "\n".join(
        (CHAT_PRESENTATION_DIR / name).read_text(encoding="utf-8")
        for name in CHAT_PRESENTATION_FILES
    )

checks: list[str] = []

def text(name: str) -> str:
    path = FILES[name]
    assert path.is_file(), f"missing {path.relative_to(ROOT)}"
    if name == "screen":
        return chat_presentation_text()
    return path.read_text(encoding="utf-8")

def check(label: str, condition: bool) -> None:
    assert condition, label
    checks.append(label)

models = text("remote_models")
for token in ["p_client_attachment_id", "p_idempotency_key", "p_kind", "p_mime_type", "p_size_bytes", "p_attachment_id", "signed_url", "expires_at"]:
    check(f"remote model:{token}", token in models)

api = text("api")
for token in ["optimal_verto_begin_attachment", "storage/v1/object/{bucketId}/{objectPath}", "x-upsert: false", "optimal_verto_finalize_attachment", "functions/v1/verto-attachment-access"]:
    check(f"api:{token}", token in api)

remote = text("remote")
for token in ["optimal-verto-private", "OBJECT_PATH", "file.asRequestBody", "AlreadyExists", "ATTACHMENT_SIZE_REJECTED", "ATTACHMENT_MIME_REJECTED", "resolveAccess", "INVALID_SIGNED_URL_RESPONSE", "CancellationException"]:
    check(f"remote:{token}", token in remote)
check("only server path accepted", 'safeBucket != PRIVATE_BUCKET || !OBJECT_PATH.matches(safePath)' in remote)
check("signed URL limited to HTTP(S)", 'uri.scheme?.lowercase() in setOf("https", "http")' in remote)
check("service role absent from client", "SERVICE_ROLE" not in remote and "service_role" not in remote)

store = text("file_store")
for token in ["canonicalFile", "verto/attachments", "expectedSizeBytes", "SizeMismatch", "InvalidPath", 'it == ".."']:
    check(f"private file store:{token}", token in store)

policy = text("policy")
for token in ["PENDING_UPLOAD", "UPLOADED", "READY", "REJECTED", "ABANDONED", "requiresUpload", "requiresFinalize", "retryState", "LOCAL_MISSING"]:
    check(f"policy:{token}", token in policy)
check("ephemeral access validates URL", "data class VertoAttachmentAccess" in policy and "signedUrl" in policy)

coordinator = text("coordinator")
for token in ["attachmentRemote.begin", "attachmentRemote.upload", "attachmentRemote.finalize", "messageRemote.sendAttachment", "persistBeginTarget", "persistFinalizedAttachment", "retryableFailure", "terminalFailure", "VertoAttachmentTransferState.UPLOADING", "VertoAttachmentTransferState.FINALIZING", "VertoRemoteAttachmentState.READY"]:
    check(f"coordinator:{token}", token in coordinator)
check("upload precedes finalize", coordinator.index("attachmentRemote.upload") < coordinator.index("attachmentRemote.finalize"))
check("finalize precedes message send", coordinator.index("attachmentRemote.finalize") < coordinator.index("messageRemote.sendAttachment"))
check("local source size is verified", "LOCAL_ATTACHMENT_SIZE_CHANGED" in coordinator)
check("single attachment invariant", "attachments.size != 1" in coordinator)

repo = text("repository")
for token in ["SyncOperationType.SEND_ATTACHMENT", "VertoAttachmentOutboxPayload", "syncPendingAttachmentMessage", "resolveAttachmentAccess", "attachmentSendCoordinator.sync", "VertoAttachmentTransferPolicy.retryState"]:
    check(f"repository:{token}", token in repo)
check("attachment outbox and Room write share transaction", "transactionRunner.run" in repo and "syncQueueDao.enqueueRequired" in repo)
check("signed URL not written to Room", "signedUrl = dto.signedUrl" in repo and "remoteObjectPath = dto.signedUrl" not in repo)

participant = text("participant")
for token in ["SEND_TEXT", "SEND_ATTACHMENT", "SyncPendingVertoAttachmentMessageUseCase", "VertoAttachmentSyncResult"]:
    check(f"participant:{token}", token in participant)
queue = text("queue")
check("queue operation exists", 'const val SEND_ATTACHMENT = "SEND_ATTACHMENT"' in queue)

usecases = text("usecases")
for token in ["scheduler.schedule(grant.userId, grant.companyId)", "SyncPendingVertoAttachmentMessageUseCase", "ResolveVertoAttachmentAccessUseCase", "OBSERVE_MESSAGES"]:
    check(f"usecase:{token}", token in usecases)

open_contract = text("open")
check("remote opener validates scheme", 'uri.scheme?.lowercase() !in setOf("https", "http")' in open_contract)
check("remote opener uses ACTION_VIEW", "Intent.ACTION_VIEW" in open_contract)
viewmodel = text("viewmodel")
for token in ["ResolveVertoAttachmentAccessUseCase", "mutableEffects", "OpenRemoteAttachment", "resolveAttachmentAccess"]:
    check(f"viewmodel:{token}", token in viewmodel)
route = text("route")
check("effect is consumed once", "viewModel.effects.collect" in route)
check("signed URL remains UI effect", "effect.signedUrl" in route)
screen = text("screen")
for token in ["onOpenRemoteAttachment", "VertoAttachmentTransferState.READY", "جارٍ الرفع", "جارٍ التحقق", "تعذر الرفع مؤقتًا"]:
    check(f"screen:{token}", token in screen)

tests = text("tests")
for token in ["pendingUploadRequiresUploadAndFinalize", "uploadedSkipsUploadButRequiresFinalize", "readyRetryDoesNotReupload", "signedAccessRejectsNonHttpScheme"]:
    check(f"test:{token}", token in tests)

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains immutable", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version remains stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("no v57 Supabase migration", not any((ROOT / "supabase/migrations").glob("*v57*")))
all_text = "\n".join(path.read_text(encoding="utf-8") for path in FILES.values())
check("no merge markers", not any(marker in all_text for marker in ("<<<<<<<", "=======", ">>>>>>>")))
check("no public attachment URL persisted", "publicUrl" not in all_text and "getPublicUrl" not in all_text)

build = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
check("Gradle registers v57 gate", "vertoAttachmentTransferContractCheck" in build)
check("staticQualityCheck depends on v57", "vertoAttachmentTransferContractCheck," in build)

print(f"v57 Verto attachment transfer contract: {len(checks)}/{len(checks)} PASS")
