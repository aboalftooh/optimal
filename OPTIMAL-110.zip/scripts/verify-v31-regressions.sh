#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# v31 changes auth domain contracts, coordinator behavior, and presentation
# restoration. Keep this gate focused so repeated kotlinc startup remains bounded.
./scripts/run-v31-auth-harness.sh
./scripts/run-v30-presentation-compile.sh
python3 scripts/v29-sync-contract.py
