#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
python3 scripts/static-architecture-check.py
python3 scripts/static-v21-check.py
python3 scripts/static-v20-check.py
python3 scripts/sqlite-v20-migration-check.py
python3 scripts/sqlite-v16-all-published-migrations.py
python3 scripts/v21-backend-contract-harness.py
./scripts/run-v08-sync-harness.sh
./scripts/run-v09-invoice-harness.sh
./scripts/run-v20-domain-harness.sh
