#!/usr/bin/env python3
"""Session 96 enforceable architecture gates for OPTIMAL generic sync.

Standard-library only: this script is intentionally runnable without Gradle,
Android SDK, network access, or a live backend. It freezes the architecture
rules required by OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


def read(relative: str) -> str:
    path = ROOT / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def imports(path: Path) -> list[str]:
    return re.findall(r"^import\s+([^\s]+)", path.read_text(encoding="utf-8"), re.M)


def prod_kotlin_under(relative: str) -> list[Path]:
    base = ROOT / relative
    if not base.exists():
        return []
    return sorted(
        p for p in base.rglob("*.kt")
        if "/src/main/" in p.as_posix() and not any(x in p.parts for x in {"build", ".gradle"})
    )


# 1. UI/ViewModels may not reach transport, WebSocket source, or DAOs.
ui_violations: list[str] = []
ui_candidates: set[Path] = set()
for area in (ROOT / "app", ROOT / "feature"):
    if not area.exists():
        continue
    for path in area.rglob("*.kt"):
        posix = path.as_posix()
        if "/src/main/" not in posix:
            continue
        if "/presentation/" in posix or "/ui/" in posix or path.name.endswith("ViewModel.kt"):
            ui_candidates.add(path)

banned_ui_exact = {
    "com.optimal.fleet.coordinator.sync.remote.OptimalSyncApi",
    "com.optimal.fleet.core.network.sync.SyncPullTransport",
    "com.optimal.fleet.coordinator.sync.realtime.OptimalRealtimeHintSource",
    "com.optimal.fleet.coordinator.sync.realtime.SupabaseOptimalRealtimeHintSource",
}
for path in sorted(ui_candidates):
    for imported in imports(path):
        if (
            imported in banned_ui_exact
            or ".database.dao." in imported
            or imported.endswith("Dao")
            or imported.startswith("androidx.room.")
        ):
            ui_violations.append(f"{path.relative_to(ROOT)} -> {imported}")
check("01 UI/ViewModels do not import sync transport/WebSocket source/DAO", not ui_violations, "; ".join(ui_violations))


# 2. Domain stays free of Android and infrastructure frameworks.
domain_violations: list[str] = []
for area in (ROOT / "core", ROOT / "feature"):
    if not area.exists():
        continue
    for path in area.rglob("*.kt"):
        posix = path.as_posix()
        if "/src/main/" not in posix or "/domain/" not in posix:
            continue
        for imported in imports(path):
            if imported.startswith(("android.", "androidx.room.", "retrofit2.", "okhttp3.", "androidx.work.")):
                domain_violations.append(f"{path.relative_to(ROOT)} -> {imported}")
check("02 domain does not import Android/Room/Retrofit/OkHttp/WorkManager", not domain_violations, "; ".join(domain_violations))


# 3. Feature implementation modules are isolated from each other.
feature_dirs = sorted(p for p in (ROOT / "feature").iterdir() if p.is_dir())
feature_names = {p.name for p in feature_dirs}
feature_dependency_violations: list[str] = []
for module in feature_dirs:
    build = module / "build.gradle.kts"
    if build.is_file():
        content = build.read_text(encoding="utf-8")
        for target in re.findall(r'project\("(:feature:[^\"]+)"\)', content):
            feature_dependency_violations.append(f"feature/{module.name} -> {target}")
    own_prefix = f"com.optimal.fleet.feature.{module.name}."
    for path in prod_kotlin_under(f"feature/{module.name}"):
        for imported in imports(path):
            match = re.match(r"com\.optimal\.fleet\.feature\.([^.]+)\.", imported)
            if match and match.group(1) in feature_names and not imported.startswith(own_prefix):
                feature_dependency_violations.append(f"{path.relative_to(ROOT)} -> {imported}")
check("03 feature modules do not depend on another feature implementation", not feature_dependency_violations, "; ".join(feature_dependency_violations))


# 4. Generic Realtime is hint-only; it cannot mutate aggregate DAOs directly.
realtime_files = [
    "app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/RealtimeSyncHintCoordinator.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/SupabaseOptimalRealtimeHintSource.kt",
]
realtime_text = "\n".join(read(p) for p in realtime_files)
aggregate_dao_markers = (
    "VehicleDao", "MaintenanceReadDao", "MaintenanceWriteDao", "MaintenanceFollowUpDao",
    "RemoteChangeApplier", "VehicleRemoteChangeApplier", "MaintenanceRemoteChangeApplier", "FollowUpRemoteChangeApplier",
)
mutation_markers = (".insert(", ".upsert(", ".update(", ".delete(", ".apply(change")
realtime_direct_mutation = [m for m in aggregate_dao_markers + mutation_markers if m in realtime_text]
realtime_hint_path_ok = (
    "deltaPullCoordinator::run" in realtime_text
    and "scheduleNormalSync" in realtime_text
    and "debounce(HINT_COALESCE_MILLIS)" in realtime_text
    and ".conflate()" in realtime_text
)
check("04 Realtime has no direct aggregate DAO mutation path", not realtime_direct_mutation and realtime_hint_path_ok, ", ".join(realtime_direct_mutation))


# 5. OptimalDeltaPullCoordinator is the sole generic remote->Room delta coordinator.
sync_prod_dir = ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync"
delta_coordinators = sorted(p.relative_to(ROOT).as_posix() for p in sync_prod_dir.rglob("*DeltaPullCoordinator.kt"))
applier_orchestrators: list[str] = []
for path in sync_prod_dir.rglob("*.kt"):
    text = path.read_text(encoding="utf-8")
    if (
        "RemoteChangeApplier" in text
        and "SyncPullTransport" in text
        and "appliersByType" in text
        and ".apply(change)" in text
    ):
        applier_orchestrators.append(path.relative_to(ROOT).as_posix())
expected_delta = "app/src/main/java/com/optimal/fleet/coordinator/sync/OptimalDeltaPullCoordinator.kt"
check(
    "05 OptimalDeltaPullCoordinator is the only generic remote-to-Room delta coordinator",
    delta_coordinators == [expected_delta] and applier_orchestrators == [expected_delta],
    f"delta={delta_coordinators}; orchestrators={applier_orchestrators}",
)


# 6. Normal Sync participant ordering is frozen.
unified = read("app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt")
delta = read(expected_delta)
expected_pairs = {
    "outbox_messages_attachments": 10,
    "optimal_delta_pull": 15,
    "verto_invoice_feed": 20,
    "verto_maintenance_feed": 30,
    "verto_message_pull": 40,
}
order_failures: list[str] = []
for key, order in expected_pairs.items():
    text = delta if key == "optimal_delta_pull" else unified
    key_match = re.search(rf'override val key:\s*String\s*=\s*"{re.escape(key)}"', text)
    order_match = re.search(rf'override val order:\s*Int\s*=\s*{order}\b', text)
    if not (key_match and order_match):
        order_failures.append(f"{key}:{order}")
ordering_engine_ok = "participants.sortedWith(compareBy({ it.order }, { it.key }))" in unified
check("06 UnifiedSyncCoordinator order is 10 Outbox / 15 Delta / 20 Invoice / 30 Maintenance / 40 Messages", not order_failures and ordering_engine_ok, ", ".join(order_failures))


# 7. WorkManager periodic fallback remains wired at application startup.
scheduler = read("app/src/main/java/com/optimal/fleet/work/SyncScheduler.kt")
application = read("app/src/main/java/com/optimal/fleet/OptimalApplication.kt")
periodic_ok = all(
    marker in scheduler
    for marker in (
        "enqueueUniquePeriodicWork(",
        "UNIQUE_PERIODIC_WORK",
        "PeriodicWorkRequestBuilder<OptimalSyncWorker>(15, TimeUnit.MINUTES)",
        "NetworkType.CONNECTED",
    )
) and "syncScheduler.schedulePeriodic()" in application
check("07 WorkManager periodic fallback still exists", periodic_ok)


# 8. Immediate local-write kick remains present for generic synced aggregates.
kick_port = read("core/model/src/main/kotlin/com/optimal/fleet/core/model/sync/SyncKickPort.kt")
kick_adapter = read("app/src/main/java/com/optimal/fleet/coordinator/sync/WorkManagerSyncKickPort.kt")
kick_repositories = [
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt",
]
missing_kicks = [p for p in kick_repositories if "syncKickPort.request(companyId)" not in read(p)]
immediate_kick_ok = (
    "fun interface SyncKickPort" in kick_port
    and "fun request(companyId: String)" in kick_port
    and "syncScheduler.scheduleNow(companyId = companyId)" in kick_adapter
    and not missing_kicks
)
check("08 immediate local-write sync kick still exists", immediate_kick_ok, ", ".join(missing_kicks))


# 9. Cursor/deferred/replica metadata remain database sidecars; aggregate domain models stay clean.
sidecars = {
    "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullCursorEntity.kt": "sync_pull_cursors",
    "core/database/src/main/java/com/optimal/fleet/core/database/sync/DeferredRemoteChangeEntity.kt": "sync_deferred_remote_changes",
    "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncReplicaMetadataEntity.kt": "sync_replica_metadata",
}
missing_sidecars = [p for p, table in sidecars.items() if table not in read(p)]
aggregate_domain_models = [
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperation.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/MaintenanceFollowUp.kt",
]
server_cursor_tokens = ("serverRevision", "lastAppliedRevision", "lastAppliedServerRevision", "remoteVersion", "syncCursor")
domain_cursor_violations = [
    f"{p}:{token}"
    for p in aggregate_domain_models
    for token in server_cursor_tokens
    if token in read(p)
]
check("09 generic cursor/deferred state remains sidecar-only", not missing_sidecars and not domain_cursor_violations, f"missing={missing_sidecars}; domain={domain_cursor_violations}")


# 10. Specialized Verto Realtime remains independent of generic sync.
verto_realtime = "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoRealtimeHintSource.kt"
verto_realtime_text = read(verto_realtime)
verto_generic_imports: list[str] = []
for path in prod_kotlin_under("feature/verto"):
    for imported in imports(path):
        if imported.startswith("com.optimal.fleet.coordinator.sync") or imported == "com.optimal.fleet.core.network.sync.SyncPullTransport":
            verto_generic_imports.append(f"{path.relative_to(ROOT)} -> {imported}")
verto_independent = (
    "interface VertoRealtimeHintSource" in verto_realtime_text
    and 'put("table", "optimal_verto_messages")' in verto_realtime_text
    and "OptimalDeltaPullCoordinator" not in verto_realtime_text
    and not verto_generic_imports
)
check("10 specialized Verto Realtime remains independent of generic sync", verto_independent, "; ".join(verto_generic_imports))


# 11. Tenant checks exist on server contract and Android apply/hint boundaries.
migration = read("backend/supabase/migrations/20260815000100_optimal_sync_delta_feed.sql")
pull = read(expected_delta)
realtime_source = read("app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/SupabaseOptimalRealtimeHintSource.kt")
server_tenant_ok = all(
    marker in migration
    for marker in (
        "enable row level security",
        "public.optimal_is_active_company_member(company_id)",
        "public.optimal_is_active_company_member(p_company_id)",
        "where c.company_id = p_company_id",
    )
)
android_tenant_ok = (
    "isValidOptimalDeltaPage(session.companyId, page.changes)" in pull
    and "if (change.companyId != companyId) return false" in pull
    and 'put("filter", "company_id=eq.$remoteCompanyId")' in realtime_source
    and "if (remoteCompanyId != expectedRemoteCompanyId) return@runCatching null" in realtime_source
)
check("11 tenant checks exist at server and Android apply/hint boundaries", server_tenant_ok and android_tenant_ok)


# 12. Android/client source contains no service-role material or secret key values.
client_files = []
for base in ("app", "core", "feature"):
    client_files.extend(prod_kotlin_under(base))
secret_patterns = [
    re.compile(r"SUPABASE_SERVICE_ROLE_KEY", re.I),
    re.compile(r"\bsb_secret_[A-Za-z0-9_-]+", re.I),
    re.compile(r"\bserviceRole(?:Key|Client)?\b"),
    re.compile(r"\bservice_role\b", re.I),
]
secret_hits: list[str] = []
for path in client_files:
    text = path.read_text(encoding="utf-8")
    if any(pattern.search(text) for pattern in secret_patterns):
        secret_hits.append(str(path.relative_to(ROOT)))
check("12 no secret/service-role key exists in Android/client production source", not secret_hits, ", ".join(secret_hits))


for name, passed, detail in checks:
    status = "PASS" if passed else "FAIL"
    print(f"{status}: {name}" + (f" — {detail}" if detail and not passed else ""))

passed = sum(1 for _, ok, _ in checks if ok)
print(f"\nSESSION96_ARCHITECTURE_GATES={'PASS' if passed == len(checks) else 'FAIL'} {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
