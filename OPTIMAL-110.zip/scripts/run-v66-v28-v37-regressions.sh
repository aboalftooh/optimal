#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# v35 hashed the exact v34 UI string multiset. Later approved sessions changed
# those screens, so that immutable literal snapshot is no longer a valid gate.
# Retain all behavioral/compile regressions and use the current v37 static gate.
COMMANDS=(
  "./scripts/run-v19-domain-harness.sh"
  "./scripts/run-v33-paging-harness.sh"
  "python3 scripts/v33-paging-contract.py"
  "python3 scripts/v33-room-query-contract.py"
  "./scripts/run-v32-member-policy-harness.sh"
  "python3 scripts/v32-member-security-contract.py"
  "./scripts/run-v31-auth-harness.sh"
  "./scripts/run-v30-error-harness.sh"
  "python3 scripts/v29-sync-contract.py"
  "python3 scripts/v28-atomic-contract.py"
  "./scripts/run-v34-maintenance-domain-compile.sh"
  "./scripts/run-v34-maintenance-data-compile.sh"
  "./scripts/run-v34-maintenance-presentation-compile.sh"
  "./scripts/run-v34-maintenance-route-syntax-check.sh"
  "./scripts/run-v34-maintenance-tests-compile.sh"
  "python3 scripts/static-v37-check.py"
)

passed=0
for command in "${COMMANDS[@]}"; do
  echo "===== $command ====="
  timeout --kill-after=10s 360s bash -lc "$command"
  passed=$((passed + 1))
  rm -rf .tmp-v*-harness
  echo "V66_LEGACY PASS $command"
done

echo "V66 v28-v37 compatibility regressions: $passed/${#COMMANDS[@]} PASS"
