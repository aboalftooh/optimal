#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/di/TemporaryVertoAttachmentModule.kt"
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/navigation/AppDestination.kt"
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceProjectionDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceOperationDetailsRow.kt"
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/verto/TemporaryVertoAttachmentAccess.kt"
  "$ROOT_DIR/core/network/src/main/java/com/optimal/fleet/core/network/verto/SupabaseTemporaryVertoAttachmentAccess.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjectionDetails.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/InvoiceProjectionRepository.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/ObserveInvoiceProjectionDetails.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt"
  "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/InvoiceProjectionRepositoryTestFixtures.kt"
  "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/VertoInvoicePageCommitTest.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceMappers.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceQueryRepository.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/history/LoadMaintenanceHistoryPage.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationDetails.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceHistoryQuery.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/source/VertoMaintenanceSourceModels.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsComponents.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContent.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsRoute.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsUiMapper.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryContract.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryRoute.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryViewModel.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/navigation/VehiclesNavigation.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailViewModel.kt"
)
for file in "${FILES[@]}"; do [[ -f "$file" ]] || { echo "FAIL: missing v63 Kotlin source: $file" >&2; exit 1; }; done
OUT="$(mktemp)"; JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
PATTERN='error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)'
if grep -Eiq "$PATTERN" "$OUT"; then
  grep -Ein "$PATTERN" "$OUT"
  echo "FAIL: v63 Kotlin parser diagnostics found" >&2
  exit 1
fi
[[ $STATUS -ne 124 ]] || { echo "FAIL: v63 Kotlin parser timed out" >&2; exit 1; }
printf 'PASS: Kotlin parser accepted %s v63 files; unresolved Android/Gradle symbols were intentionally ignored.\n' "${#FILES[@]}"
