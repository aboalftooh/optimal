#!/usr/bin/env python3
"""Focused state-machine harness for v57 idempotent attachment transfer."""
from dataclasses import dataclass

@dataclass
class State:
    remote: str | None = None
    local: str = "LOCAL_READY"
    upload_calls: int = 0
    finalize_calls: int = 0
    send_calls: int = 0


def sync(state: State, upload="ok", finalize="READY", send="ok") -> str:
    if state.remote is None:
        state.remote = "PENDING_UPLOAD"
    if state.remote in {"REJECTED", "ABANDONED"}:
        state.local = "FAILED_TERMINAL"
        return "terminal"
    if state.remote == "PENDING_UPLOAD":
        state.local = "UPLOADING"
        state.upload_calls += 1
        if upload == "retry":
            state.local = "FAILED_RETRYABLE"
            return "retry"
        if upload == "terminal":
            state.local = "FAILED_TERMINAL"
            return "terminal"
        state.remote = "UPLOADED"
        state.local = "UPLOADED"
    if state.remote == "UPLOADED":
        state.local = "FINALIZING"
        state.finalize_calls += 1
        if finalize == "retry":
            state.local = "FAILED_RETRYABLE"
            return "retry"
        if finalize in {"REJECTED", "ABANDONED"}:
            state.remote = finalize
            state.local = "FAILED_TERMINAL"
            return "terminal"
        state.remote = "READY"
        state.local = "READY"
    if state.remote == "READY":
        state.send_calls += 1
        return "sent" if send == "ok" else "retry"
    return "retry"

checks = []
def check(label, condition):
    assert condition, label
    checks.append(label)

s = State()
check("happy path sent", sync(s) == "sent")
check("happy path uploads once", s.upload_calls == 1)
check("happy path finalizes once", s.finalize_calls == 1)
check("happy path sends once", s.send_calls == 1)
check("happy path ready", (s.remote, s.local) == ("READY", "READY"))

s = State()
check("upload interruption retryable", sync(s, upload="retry") == "retry")
check("upload interruption persisted", s.local == "FAILED_RETRYABLE")
check("retry uploads again", sync(s) == "sent" and s.upload_calls == 2)

s = State(remote="UPLOADED", local="FAILED_RETRYABLE")
check("uploaded retry resumes", sync(s) == "sent")
check("uploaded retry skips upload", s.upload_calls == 0)
check("uploaded retry finalizes", s.finalize_calls == 1)

s = State(remote="READY", local="READY")
check("ready retry sends", sync(s) == "sent")
check("ready retry skips upload", s.upload_calls == 0)
check("ready retry skips finalize", s.finalize_calls == 0)

s = State()
check("finalize interruption retryable", sync(s, finalize="retry") == "retry")
check("finalize interruption preserves uploaded", s.remote == "UPLOADED")
check("finalize retry skips duplicate upload", sync(s) == "sent" and s.upload_calls == 1)

s = State()
check("rejected finalize terminal", sync(s, finalize="REJECTED") == "terminal")
check("rejected finalize not sent", s.send_calls == 0)

s = State(remote="ABANDONED")
check("abandoned terminal", sync(s) == "terminal")
check("abandoned no network writes", (s.upload_calls, s.finalize_calls, s.send_calls) == (0, 0, 0))

s = State(remote="READY", local="READY")
check("send interruption retryable", sync(s, send="retry") == "retry")
check("send retry reuses ready object", sync(s) == "sent" and s.upload_calls == 0 and s.finalize_calls == 0)

print(f"v57 Verto attachment transfer harness: {len(checks)}/{len(checks)} PASS")
