#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
route_path = root / "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt"
components_path = root / "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt"
route = route_path.read_text()
components = components_path.read_text()
home_ui = route + "\n" + components
checks = []


def check(label: str, condition: bool):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + ": " + label)


def sha256(path: str) -> str:
    return hashlib.sha256((root / path).read_bytes()).hexdigest()


protected = {
    "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeContract.kt": "b68babedf3884bfed76bf4813f987c713c02af2ebb2cf79d960cb0459efaedf4",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeViewModel.kt": "53a333a50334d782c36a881e292def1656bde33c8552a0652ee34102e461375a",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/domain/HomeDashboard.kt": "f5fefafd9cd68dda5c49fad6ed53f7217c3ab89cbb575ff4a5b87ee8e981adf9",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/domain/HomeDashboardQuery.kt": "a66b5059a7a78b8db607b2e2aca2f5f1d1862705df5ad64819e492df6ebe0720",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/data/RoomHomeDashboardQuery.kt": "e07b107dcdea9a33c723f0bfa0fc02055726ebd742256b1050706f158803f09b",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/di/HomeDataModule.kt": "233a895a4e78d8b407d0ef9c798f40c08ca67dd0618bd1e9adab356fb8a5755c",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/navigation/HomeNavigation.kt": "b8e106f0dfbf35c9599c9ae060bffe16173b46729c75b616f30148506ccd7987",
}

check("Home route exists", route_path.is_file())
check("Home components exist", components_path.is_file())
check("Home imports v2 loading state", "component.v2.OptimalLoadingState" in route)
check("Home imports v2 error state", "component.v2.OptimalErrorState" in route)
check("Home imports v2 primary button", "component.v2.OptimalPrimaryButton" in route)
check("Home uses v2 section header", "component.v2.OptimalSectionHeader" in components)
check("Home uses v2 list row", "component.v2.OptimalListRow" in components)
check("Home uses v2 metric card", "component.v2.OptimalMetricCard" in components)
check("legacy AppCard removed", "AppCard" not in home_ui)
check("legacy component imports removed", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", home_ui) is None)
check("legacy palette aliases removed", all(token not in home_ui for token in ["OptimalBlueSoft", "OptimalSuccessSoft", "OptimalSuccess\n"]))
check("no direct dp literals in Home presentation", re.search(r"\b\d+(?:\.\d+)?\.dp\b", home_ui) is None)
check("no raw hexadecimal colors in Home presentation", "0xFF" not in home_ui)
check("Home uses content inset token", "OptimalContentInsets.horizontal" in route)
check("Home uses section gap token", "OptimalContentInsets.sectionGap" in route)
check("Home uses bottom safe content token", "OptimalContentInsets.bottomSafeContent" in route)
check("Home uses typography roles", "OptimalTypographyRoles.pageTitle" in components and "OptimalTypographyRoles.body" in components)
check("Home uses semantic status colors", "OptimalSemanticColors.warningContainer" in components and "OptimalSemanticColors.successContainer" in components)
check("Home uses icon size token", "OptimalIconSize.standard" in components)
check("Home uses touch target token", "OptimalTouchTarget.minimum" in components)
check("hero image removed", "optimal_home_hero" not in home_ui and "painterResource" not in home_ui)
check("obsolete Home hero resource removed", not (root / "core/designsystem/src/main/res/drawable-nodpi/optimal_home_hero.png").exists())
check("welcome hierarchy is text-first", "fun HomeWelcome(" in components and "جاهز لليوم" in components)
check("primary action remains Add Operation", 'text = "إضافة عملية"' in route)
check("primary action tag preserved", 'testTag("home-add-operation")' in route)
check("destination tag preserved", 'testTag("destination-home")' in route)
check("Verto slot preserved", 'item(key = "verto-entry")' in route)
check("follow-ups appear before in-progress work", route.find("HomeFollowUpSection(") < route.find('title = "العمليات الجارية"'))
check("finance appears before completed history", route.find("HomeFinanceSection(") < route.find('title = "آخر العمليات المكتملة"'))
check("Home lists are capped for scanability", "items.take(HOME_PREVIEW_ITEM_LIMIT)" in components)
check("preview limit remains three", "HOME_PREVIEW_ITEM_LIMIT = 3" in components)
check("ordinary operation rows are not cards", "OptimalListRow(" in components and "HomeOperationSection" in components)
check("finance uses metric pattern", components.count("OptimalMetricCard(") == 2)
check("finance exposes unlinked invoice count", "finance.unlinkedInvoiceCount" in components)
check("overdue follow-ups have textual state", 'text = "متأخرة"' in components and '"متأخرة • ${item.dueLabel}"' in components)
check("status is not color-only", "warning = item.overdue" in components and 'text = "متأخرة"' in components)
check("section actions remain explicit", 'actionLabel = "عرض الكل"' in components)
check("finance action remains explicit", 'actionLabel = "فتح المالية"' in components)
check("operation callback preserved", "is HomeUiEffect.OpenOperation -> onOpenOperation(effect.id)" in route)
check("follow-up callback preserved", "is HomeUiEffect.OpenFollowUp -> onOpenFollowUp(effect.id)" in route)
check("maintenance callback preserved", "HomeUiEffect.OpenMaintenance -> onOpenMaintenance()" in route)
check("finance callback preserved", "HomeUiEffect.OpenFinance -> onOpenFinance()" in route)
check("create operation callback preserved", "HomeUiEffect.OpenCreateOperation -> onAddOperation()" in route)
check("no chart rendering introduced", all(token not in home_ui for token in ["Canvas(", "Chart(", "LineChart", "BarChart", "PieChart"]))
check("no DAO imports in Home presentation", ".dao." not in home_ui and "Dao" not in home_ui)
check("no repository implementation imports in Home presentation", ".data." not in home_ui)
check("screen keeps loading/error/content tri-state", all(token in route for token in ["state.isLoading", "state.errorMessage != null", "else -> LazyColumn"]))
check("completed section remains available", 'title = "آخر العمليات المكتملة"' in route)
check("in-progress section remains available", 'title = "العمليات الجارية"' in route)
check("follow-up section remains available", 'title = "المتابعة المستحقة"' in components)
check("finance remains optional", "state.finance?.let" in route)

for path, expected in protected.items():
    check(f"business/source contract unchanged: {Path(path).name}", sha256(path) == expected)

passed = sum(ok for _, ok in checks)
print(f"\nSESSION-75 static contract: {passed}/{len(checks)}")
raise SystemExit(0 if passed == len(checks) else 1)
