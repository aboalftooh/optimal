#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v42 secure message RPCs."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
V32 = ROOT / "supabase/migrations/20260730003200_optimal_member_permissions_rls.sql"
V41 = ROOT / "supabase/migrations/20260731004100_optimal_verto_conversation_message_schema.sql"
V42 = ROOT / "supabase/migrations/20260731004200_optimal_verto_message_rpcs.sql"
PREFLIGHT = ROOT / "supabase/tests/v42_verto_message_rpc_preflight.sql"
SCENARIOS = ROOT / "supabase/tests/v42_verto_message_rpc_scenarios.sql"
SESSION = ROOT / "docs/sessions/v42.md"
DEPLOYMENT = ROOT / "docs/integrations/verto-message-rpc-deployment-v42.md"
ADR = ROOT / "docs/adr/ADR-verto-integration-v23.md"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
MATRIX = ROOT / "docs/integrations/verto-contract-matrix-v23.md"
APP_GRADLE = ROOT / "app/build.gradle.kts"
ROOT_GRADLE = ROOT / "build.gradle.kts"
CI_FAST = ROOT / "scripts/ci-fast.sh"
CI_FULL = ROOT / "scripts/ci-full.sh"
VERIFY_PROJECT = ROOT / "scripts/verify-project.sh"

checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, condition))


def contains_all(text: str, values: list[str]) -> bool:
    return all(value in text for value in values)


def function_block(sql: str, name: str, next_name: str | None = None) -> str:
    marker = f"create or replace function public.{name}("
    start = sql.find(marker)
    if start < 0:
        return ""
    if next_name:
        end = sql.find(f"create or replace function public.{next_name}(", start + len(marker))
        if end >= 0:
            return sql[start:end]
    end = sql.find("\ncomment on function", start)
    return sql[start:] if end < 0 else sql[start:end]


required = [
    V32,
    V41,
    V42,
    PREFLIGHT,
    SCENARIOS,
    SESSION,
    DEPLOYMENT,
    ADR,
    CONTRACT,
    MATRIX,
    APP_GRADLE,
    ROOT_GRADLE,
    CI_FAST,
    CI_FULL,
    VERIFY_PROJECT,
]
for path in required:
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())

if not all(path.is_file() for path in required):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

v32 = V32.read_text(encoding="utf-8")
v41 = V41.read_text(encoding="utf-8")
v42 = V42.read_text(encoding="utf-8")
preflight = PREFLIGHT.read_text(encoding="utf-8")
scenarios = SCENARIOS.read_text(encoding="utf-8")
session = SESSION.read_text(encoding="utf-8")
deployment = DEPLOYMENT.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
matrix = MATRIX.read_text(encoding="utf-8")
app_gradle = APP_GRADLE.read_text(encoding="utf-8")
root_gradle = ROOT_GRADLE.read_text(encoding="utf-8")
ci_fast = CI_FAST.read_text(encoding="utf-8")
ci_full = CI_FULL.read_text(encoding="utf-8")
verify_project = VERIFY_PROJECT.read_text(encoding="utf-8")

context = function_block(v42, "optimal_verto_current_context", "optimal_verto_message_json")
serializer = function_block(v42, "optimal_verto_message_json", "optimal_verto_send_message")
send = function_block(v42, "optimal_verto_send_message", "optimal_verto_message_feed")
feed = function_block(v42, "optimal_verto_message_feed", "optimal_verto_mark_messages_read")
mark_read = function_block(v42, "optimal_verto_mark_messages_read", "optimal_verto_set_conversation_archived")
archive = function_block(v42, "optimal_verto_set_conversation_archived")
capability = function_block(v42, "optimal_member_has_capability", "optimal_verto_current_context")
permission_validator = function_block(v42, "optimal_permissions_are_valid", "optimal_member_has_capability")

# Migration order and non-Android scope.
migrations = sorted(p.name for p in (ROOT / "supabase/migrations").glob("*.sql"))
check("order:v42-after-v41", migrations.index(V42.name) > migrations.index(V41.name))
check("scope:no-kotlin", not any(token in v42 for token in (".kt", "OptimalDatabase", "Room")))
check("scope:no-room-version", "Migration 1" not in v42 and "schemaVersion" not in v42)
check("scope:android-version-stable", 'versionCode = 32' in app_gradle and 'versionName = "0.37.0-v37"' in app_gradle)
check("scope:contract-version-stays-22", "set contract_version = 23" not in v42 and "contract_version = 23" not in v42)
check("scope:minimum-client-stable", "minimum_android_version_code =" not in v42)
check("scope:no-attachment-table", "create table if not exists public.optimal_verto_message_attachments" not in v42)
check("scope:no-message-delete", not re.search(r"delete\s+from\s+public\.optimal_verto_messages", v42, re.I))
check("scope:no-destructive-schema", "drop table" not in v42.lower() and "drop column" not in v42.lower())
check("scope:readiness-closed", contains_all(v42, ["set verto_chat_ready = false", "where singleton = true"]))

# Permission schema and accepted defaults.
check("permission:validator-replaced", bool(permission_validator))
for key in (
    "VIEW_MEMBER_DIRECTORY",
    "CREATE_MEMBER_INVITE",
    "RESEND_MEMBER_INVITE",
    "REVOKE_MEMBER_INVITE",
    "CHANGE_MEMBER_STATUS",
    "VIEW_VERTO_CHAT",
    "SEND_VERTO_CHAT",
):
    check(f"permission:key:{key}", f"'{key}'" in permission_validator)
check("permission:booleans-only", "jsonb_typeof(entry.value) <> 'boolean'" in permission_validator)
check("permission:legacy-capabilities-preserved", contains_all(capability, ["p_capability in (", "coalesce((m.permissions ->> p_capability)::boolean, true)"]))
check("permission:active-only", "m.is_active = true" in capability)
check("permission:owner-manager-view-default", contains_all(capability, ["p_capability = 'VIEW_VERTO_CHAT'", "m.role in ('OWNER', 'MANAGER')"]))
check("permission:owner-manager-send-default", contains_all(capability, ["p_capability = 'SEND_VERTO_CHAT'", "m.permissions ->> 'SEND_VERTO_CHAT'"]))
check("permission:send-requires-view", capability.count("m.permissions ->> 'VIEW_VERTO_CHAT'") >= 2)
check("permission:unknown-denied", "else false" in capability)
check("permission:security-definer", contains_all(capability, ["security definer", "set search_path = pg_catalog, public, auth"]))

# Trust boundary resolver.
check("context:exists", bool(context))
for trusted_field in ("member_id uuid", "company_id uuid", "auth_user_id uuid", "display_name text", "member_role text", "link_id uuid", "conversation_id uuid", "verto_client_id uuid"):
    check(f"context:return:{trusted_field.split()[0]}", trusted_field in context)
check("context:auth-derived", "auth.uid()" in context)
check("context:no-company-input", "p_company_id" not in context)
check("context:no-member-input", "p_member_id" not in context)
check("context:no-sender-input", "p_display_name" not in context and "p_role" not in context)
check("context:active-membership", contains_all(context, ["where m.auth_user_id = auth.uid()", "not v_member.is_active"]))
check("context:company-link", "l.optimal_company_id = v_member.company_id" in context)
check("context:active-link", "if not v_link.is_active" in context)
check("context:conversation-by-link", "where c.link_id = v_link.id" in context)
check("context:view-check", "VIEW_VERTO_CHAT" in context)
check("context:send-check", "SEND_VERTO_CHAT" in context)
check("context:fixed-search-path", contains_all(context, ["security definer", "set search_path = pg_catalog, public, auth"]))
check("context:internal-revoked", contains_all(v42, ["revoke all on function public.optimal_verto_current_context(boolean, boolean)", "from public, anon, authenticated"]))

# DTO serialization is server-owned and attachment-safe before v43.
check("dto:exists", bool(serializer))
for field in ("'id'", "'sender_side'", "'sender_user_id'", "'sender_display_name'", "'sender_role'", "'kind'", "'body_text'", "'status'", "'client_message_id'", "'server_created_at'", "'attachments'"):
    check(f"dto:field:{field}", field in serializer)
check("dto:attachments-empty", "'[]'::jsonb" in serializer)
check("dto:internal-revoked", contains_all(v42, ["revoke all on function public.optimal_verto_message_json(uuid)", "from public, anon, authenticated"]))

# Send RPC.
check("send:exists", bool(send))
for param in ("p_client_message_id uuid", "p_idempotency_key uuid", "p_kind text", "p_body_text text default null", "p_attachment_ids uuid[] default '{}'::uuid[]"):
    check(f"send:param:{param.split()[0]}", param in send)
check("send:security-definer", contains_all(send, ["security definer", "set search_path = pg_catalog, public, auth"]))
check("send:requires-view-send", "optimal_verto_current_context(true, true)" in send)
check("send:no-trusted-identity-params", not any(token in send.split("returns jsonb", 1)[0] for token in ("p_company_id", "p_member_id", "p_sender", "p_role", "p_created_at")))
check("send:identity-required", contains_all(send, ["p_client_message_id is null", "p_idempotency_key is null"]))
check("send:closed-kinds", contains_all(send, ["'TEXT'", "'IMAGE'", "'VIDEO'", "'AUDIO'", "'DOCUMENT'"]))
check("send:v42-text-only", contains_all(send, ["if v_kind <> 'TEXT'", "verto_attachments_not_ready"]))
check("send:text-no-attachments", contains_all(send, ["cardinality(p_attachment_ids) <> 0", "text_message_must_not_have_attachments"]))
check("send:trim-body", "btrim(coalesce(p_body_text, ''))" in send)
check("send:nonblank-body", "char_length(v_body) = 0" in send)
check("send:advisory-lock", contains_all(send, ["pg_advisory_xact_lock", "p_idempotency_key::text"]))
check("send:idempotency-query", contains_all(send, ["m.conversation_id = v_context.conversation_id", "m.idempotency_key = p_idempotency_key"]))
check("send:idempotency-payload-match", contains_all(send, ["v_message.client_message_id is distinct from p_client_message_id", "v_message.body_text is distinct from v_body"]))
check("send:client-id-conflict", contains_all(send, ["m.client_message_id = p_client_message_id", "client_message_identity_conflict"]))
check("send:server-side-snapshot", contains_all(send, ["v_context.display_name", "v_context.member_role", "v_context.auth_user_id"]))
check("send:side-fixed", "'OPTIMAL'" in send)
check("send:status-fixed", "'ACTIVE'" in send)
check("send:server-time-default", "server_created_at" not in re.search(r"insert into public\.optimal_verto_messages\((.*?)\) values", send, re.S).group(1))
check("send:retry-returns-existing", send.count("return public.optimal_verto_message_json(v_message.id)") >= 2)
check("send:unique-race-handled", "when unique_violation then" in send)

# Feed RPC.
check("feed:exists", bool(feed))
for param in ("p_after_created_at timestamptz default null", "p_after_message_id uuid default null", "p_limit integer default null"):
    check(f"feed:param:{param.split()[0]}", param in feed)
check("feed:security-definer", contains_all(feed, ["security definer", "set search_path = pg_catalog, public, auth"]))
check("feed:view-only", "optimal_verto_current_context(true, false)" in feed)
check("feed:cursor-pair", "(p_after_created_at is null) <> (p_after_message_id is null)" in feed)
check("feed:tuple-greater", "(m.server_created_at, m.id) > (p_after_created_at, p_after_message_id)" in feed)
check("feed:ascending", "order by m.server_created_at asc, m.id asc" in feed)
check("feed:no-offset", "offset" not in feed.lower())
check("feed:bounded", contains_all(feed, ["coalesce(p_limit, 50)", "v_limit > 100"]))
check("feed:tenant-conversation", "m.conversation_id = v_context.conversation_id" in feed)
check("feed:stable-json-order", "jsonb_agg(page.message_json order by page.server_created_at, page.id)" in feed)
check("feed:empty-array", "'[]'::jsonb" in feed)

# Read checkpoint.
check("read:exists", bool(mark_read))
check("read:view-only", "optimal_verto_current_context(true, false)" in mark_read)
check("read:cursor-required", contains_all(mark_read, ["p_through_created_at is null", "p_through_message_id is null"]))
check("read:cursor-owned", contains_all(mark_read, ["m.conversation_id = v_context.conversation_id", "m.id = p_through_message_id", "m.server_created_at = p_through_created_at"]))
check("read:per-user", "v_context.auth_user_id" in mark_read)
check("read:upsert", "on conflict (conversation_id, user_id) do update" in mark_read)
check("read:forward-only", contains_all(mark_read, ["last_read_created_at is null", "last_read_message_id", ") < ("]))
check("read:incoming-only-count", contains_all(mark_read, ["m.sender_side = 'VERTO'", "m.status = 'ACTIVE'"]))
check("read:tuple-unread", "(m.server_created_at, m.id) >" in mark_read)
check("read:response", contains_all(mark_read, ["'last_read_created_at'", "'last_read_message_id'", "'unread_count'"]))

# Archive/unarchive.
check("archive:exists", bool(archive))
check("archive:view-only", "optimal_verto_current_context(true, false)" in archive)
check("archive:per-user-delete", contains_all(archive, ["delete from public.optimal_verto_conversation_states", "s.user_id = v_context.auth_user_id"]))
check("archive:no-message-delete", "delete from public.optimal_verto_messages" not in archive.lower())
check("archive:empty-null-cursor", "empty_conversation_archive_cursor_must_be_null" in archive)
check("archive:nonempty-requires-cursor", "archive_cursor_required" in archive)
check("archive:cursor-owned", contains_all(archive, ["m.conversation_id = v_context.conversation_id", "m.id = p_through_message_id", "m.server_created_at = p_through_created_at"]))
check("archive:latest-only", contains_all(archive, ["archive_cursor_not_latest", "(m.server_created_at, m.id) > (p_through_created_at, p_through_message_id)"]))
check("archive:per-user-upsert", contains_all(archive, ["on conflict (conversation_id, user_id) do update", "v_context.auth_user_id"]))
check("archive:empty-row-semantics", "row presence represents an archived empty conversation" in v42)

# RPC grants and direct table isolation.
rpc_signatures = [
    "optimal_verto_send_message(uuid, uuid, text, text, uuid[])",
    "optimal_verto_message_feed(timestamptz, uuid, integer)",
    "optimal_verto_mark_messages_read(timestamptz, uuid)",
    "optimal_verto_set_conversation_archived(boolean, timestamptz, uuid)",
]
for signature in rpc_signatures:
    check(f"grant:{signature}:revoke", f"revoke all on function public.{signature}" in v42)
    check(f"grant:{signature}:authenticated", f"grant execute on function public.{signature}" in v42)
check("security:no-anon-grant", not re.search(r"grant\s+execute[\s\S]{0,180}\bto\s+anon\b", v42, re.I))
check("security:no-public-grant", not re.search(r"grant\s+execute[\s\S]{0,180}\bto\s+public\b", v42, re.I))
check("security:no-table-grants", "grant select on table public.optimal_verto_" not in v42.lower())
check("security:no-client-policies", "create policy" not in v42.lower())
check("security:no-service-role-client", "service_role" not in v42)

# Realtime is a hint, not source truth.
check("realtime:publication-guard", contains_all(v42, ["pg_publication", "pubname = 'supabase_realtime'", "pg_publication_tables"]))
check("realtime:add-message-table", "alter publication supabase_realtime add table public.optimal_verto_messages" in v42)
check("realtime:pull-hint-comment", contains_all(v42, ["wake-up hint", "cursor RPC", "source of truth"]))

# Preflight and staging scenario coverage.
for rpc in ("optimal_verto_send_message", "optimal_verto_message_feed", "optimal_verto_mark_messages_read", "optimal_verto_set_conversation_archived"):
    check(f"preflight:rpc:{rpc}", rpc in preflight)
check("preflight:authenticated-execute", "has_function_privilege('authenticated'" in preflight)
check("preflight:anon-denied", "has_function_privilege('anon'" in preflight)
check("preflight:helpers-private", "v42_internal_helper_exposed" in preflight)
check("preflight:security-definer", "v42_security_definer_or_search_path_missing" in preflight)
check("preflight:table-isolation", "v42_direct_table_privilege_exposed" in preflight)
check("preflight:no-policies", "v42_direct_client_policy_exposed" in preflight)
check("preflight:realtime", "v42_realtime_publication_missing_message_table" in preflight)
check("preflight:readiness-false", "v42_chat_readiness_promoted_before_live_gate" in preflight)

scenario_markers = [
    "v42_sender_snapshot_not_server_owned",
    "v42_idempotent_retry_created_second_message",
    "v42_changed_idempotent_payload_was_accepted",
    "v42_attachment_message_was_accepted_before_v43",
    "v42_composite_cursor_lost_equal_timestamp_message",
    "v42_half_cursor_was_accepted",
    "v42_read_checkpoint_moved_backward",
    "v42_archive_state_not_written",
    "v42_unarchive_state_not_cleared",
    "v42_member_default_view_was_allowed",
    "v42_cross_tenant_message_leaked",
    "v42_view_only_member_sent_message",
    "v42_send_without_view_was_allowed",
    "v42_inactive_member_view_was_allowed",
]
for marker in scenario_markers:
    check(f"scenario:{marker}", marker in scenarios)
check("scenario:auth-derived", "request.jwt.claim.sub" in scenarios)
check("scenario:rollback", scenarios.strip().endswith("rollback;"))

# Documentation and CI integration.
check("docs:contract-v42-status", "RPC الرسائل v42" in contract or "RPCs الرسائل v42" in contract)
check("docs:contract-readiness-closed", "verto_chat_ready" in contract and "false" in contract)
check("docs:matrix-rpcs", all(name in matrix for name in ("optimal_verto_send_message", "optimal_verto_message_feed", "optimal_verto_mark_messages_read", "optimal_verto_set_conversation_archived")))
check("docs:session-result", "STATIC PASS" in session and "LIVE BACKEND BLOCKED" in session)
check("docs:deployment-order", contains_all(deployment, [V41.name, V42.name, PREFLIGHT.name, SCENARIOS.name]))
check("gradle:v42-gate", "scripts/v42-message-rpc-contract.py" in root_gradle)
check("gradle:static-quality-dep", "vertoMessageRpcContractCheck" in root_gradle)
check("ci-fast:v42", "scripts/v42-message-rpc-contract.py" in ci_fast)
check("ci-full:v42-wrapper", any(name in ci_full for name in ("verify-v42-static.sh", "verify-v43-static.sh", "verify-v44-static.sh", "verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh")))
check("verify-project:v42-wrapper", any(name in verify_project for name in ("verify-v42-static.sh", "verify-v43-static.sh", "verify-v44-static.sh", "verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh")))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
print(f"SUMMARY {len(checks) - len(failed)}/{len(checks)} PASS")
if failed:
    print("FAILED:", ", ".join(failed), file=sys.stderr)
    sys.exit(1)
