#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Historical contract discovery markers; execution is delegated to the v66 runner:
# python3 scripts/v65-rls-isolation-security-contract.py
# python3 scripts/v64-unified-sync-contract.py
# python3 scripts/v64-unified-sync-harness.py
# python3 scripts/v64-kotlin-source-check.py
# python3 scripts/v63-invoice-vehicle-history-contract.py
# python3 scripts/v63-invoice-vehicle-history-harness.py
# python3 scripts/v62-manual-invoice-link-retirement-contract.py
# python3 scripts/v62-manual-invoice-link-retirement-harness.py
# python3 scripts/v61-verto-maintenance-import-contract.py
# python3 scripts/v61-verto-maintenance-import-harness.py
# python3 scripts/v60-verto-source-ingestion-contract.py
# python3 scripts/v60-verto-source-ingestion-harness.py
# python3 scripts/v59-room-v3-contract.py
# python3 scripts/v58-verto-daily-cycle-contract.py
# python3 scripts/v58-verto-daily-cycle-harness.py
# python3 scripts/v57-verto-attachment-transfer-contract.py
# python3 scripts/v57-verto-attachment-transfer-harness.py
# python3 scripts/v56-verto-audio-contract.py
# python3 scripts/v56-verto-audio-harness.py
# python3 scripts/v55-verto-attachment-contract.py
# python3 scripts/v55-verto-attachment-harness.py
# python3 scripts/v54-verto-text-outbox-contract.py
# python3 scripts/v54-verto-text-outbox-harness.py
# python3 scripts/v53-verto-message-sync-contract.py
# ./scripts/run-v53-verto-message-sync-harness.sh
# python3 scripts/v52-verto-chat-read-model-contract.py
# ./scripts/run-v52-verto-chat-harness.sh
# python3 scripts/v51-verto-home-entry-contract.py
# python3 scripts/v50-verto-permission-management-contract.py
# python3 scripts/v49-verto-chat-permissions-contract.py
# python3 scripts/v48-room-v2-contract.py
# python3 scripts/v47-verto-feature-architecture.py
# python3 scripts/verto-backend-contract-v23-harness.py
# python3 scripts/v45-maintenance-feed-contract.py
# python3 scripts/v44-invoice-feed-contract.py
# python3 scripts/v43-attachment-contract.py
# python3 scripts/v42-message-rpc-contract.py
# python3 scripts/v41-conversation-schema-contract.py
# python3 scripts/v40-registration-contract.py
# python3 scripts/v39-contract-consistency.py

python3 scripts/v66-comprehensive-regression-contract.py
python3 scripts/v66-comprehensive-regression.py \
  --shard foundation \
  --shard backend \
  --shard verto \
  --report build/reports/v66/ci-fast.json
./gradlew --no-daemon --stacktrace \
  architectureCheck \
  :app:compileDebugKotlin \
  testDebugUnitTest \
  lintDebug \
  detekt \
  ktlintCheck
