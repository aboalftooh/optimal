#!/usr/bin/env python3
"""Audit an OPTIMAL v67 source ZIP after delivery packaging."""
from __future__ import annotations

import argparse
from pathlib import Path, PurePosixPath
import sys
import zipfile

REQUIRED = {
    "AGENTS.md",
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradlew",
    "verification-v67.md",
    "BUILD-REPORT-v67.md",
    "PATCH_MANIFEST-v67.md",
    "CHANGED_FILES-v67.txt",
    "DELETED_FILES-v67.txt",
    "docs/sessions/v67.md",
    "docs/release-notes-v67.md",
    "docs/final-migration-list-v67.md",
    "scripts/verify-v67-static.sh",
}
FORBIDDEN_PARTS = {".gradle", ".git", "build", "__pycache__"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("zip_path", type=Path)
    args = parser.parse_args()
    if not args.zip_path.is_file():
        print(f"FAIL: ZIP missing: {args.zip_path}", file=sys.stderr)
        return 1
    with zipfile.ZipFile(args.zip_path) as archive:
        bad = archive.testzip()
        if bad:
            print(f"FAIL: corrupt entry: {bad}", file=sys.stderr)
            return 1
        names = {name.rstrip("/") for name in archive.namelist() if not name.endswith("/")}
        missing = sorted(REQUIRED - names)
        forbidden = sorted(
            name for name in names
            if any(part in FORBIDDEN_PARTS for part in PurePosixPath(name).parts)
        )
        nested = [name for name in names if name.startswith("optimal_v67_work/")]
    if missing:
        print("FAIL: missing required entries: " + ", ".join(missing), file=sys.stderr)
        return 1
    if forbidden:
        print("FAIL: forbidden generated entries: " + ", ".join(forbidden[:10]), file=sys.stderr)
        return 1
    if nested:
        print("FAIL: project was wrapped in an unexpected parent directory", file=sys.stderr)
        return 1
    print(f"PACKAGE PASS: {len(names)} files, ZIP integrity and delivery inventory valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
