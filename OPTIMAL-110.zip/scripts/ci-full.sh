#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Historical wrapper discovery markers; v66 supersedes and executes their leaf gates:
# verify-v39-static.sh verify-v40-static.sh verify-v41-static.sh verify-v42-static.sh
# verify-v43-static.sh verify-v44-static.sh verify-v45-static.sh verify-v46-static.sh
# verify-v47-static.sh verify-v48-static.sh verify-v49-static.sh verify-v50-static.sh
# verify-v51-static.sh verify-v52-static.sh verify-v53-static.sh verify-v54-static.sh
# verify-v55-static.sh verify-v56-static.sh verify-v57-static.sh verify-v58-static.sh
# verify-v59-static.sh verify-v60-static.sh verify-v61-static.sh verify-v62-static.sh
# verify-v63-static.sh verify-v64-static.sh verify-v65-static.sh

# v67 adds final release acceptance on top of the v66 matrix; external Gradle/Android gates follow.
# v66 historical wrapper retained through v67: ./scripts/verify-v66-static.sh
run_android=true
if [[ "${1:-}" == "--without-android" ]]; then
  run_android=false
elif [[ -n "${1:-}" ]]; then
  echo "Usage: $0 [--without-android]" >&2
  exit 2
fi

./scripts/verify-v67-static.sh
./gradlew --no-daemon --stacktrace clean \
  staticQualityCheck \
  testDebugUnitTest \
  lintRelease \
  detekt \
  ktlintCheck \
  koverHtmlReport \
  koverXmlReport \
  koverVerify \
  koverVerifyDomain \
  koverVerifyCriticalData \
  assembleRelease \
  bundleRelease

if [[ "$run_android" == true ]]; then
  ./scripts/ci-android.sh
fi
