#!/usr/bin/env python3
"""Static acceptance gate for OPTIMAL v61 automatic Verto maintenance import."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []


def check(label: str, condition: bool) -> None:
    checks.append((label, condition))
    if not condition:
        raise AssertionError(label)


def read(relative: str) -> str:
    path = ROOT / relative
    check(f"file:{relative}", path.is_file())
    return path.read_text(encoding="utf-8")


coordinator = read("app/src/main/java/com/optimal/fleet/coordinator/verto/VertoMaintenanceAutoImportCoordinator.kt")
worker = read("app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt")
entry = read("app/src/main/java/com/optimal/fleet/work/SyncWorkerEntryPoint.kt")
unified_sync = read("app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt")
projection_contract = read(
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/source/"
    "VertoMaintenanceProjectionRepository.kt"
)
projection_repository = read(
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/"
    "RoomVertoMaintenanceProjectionRepository.kt"
)
projection_dao = read(
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/"
    "VertoMaintenanceProjectionDao.kt"
)
finance_port = read(
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/ports/FinanceProjectionPort.kt"
)
finance_adapter = read(
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomFinanceProjectionPort.kt"
)
test = read(
    "app/src/test/java/com/optimal/fleet/coordinator/verto/"
    "VertoMaintenanceAutoImportCoordinatorTest.kt"
)
root_build = read("build.gradle.kts")
ci_fast = read("scripts/ci-fast.sh")
ci_full = read("scripts/ci-full.sh")
verify_project = read("scripts/verify-project.sh")
verify_v61 = read("scripts/verify-v61-static.sh")
app_build = read("app/build.gradle.kts")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")

# Domain/data boundary and keyset reading.
for token in (
    "data class VertoMaintenanceImportCandidate",
    "val sourceMaintenanceId: String",
    "val sourceInvoiceId: String",
    "val optimalVehicleRemoteId: String",
    "val completedAtEpochMillis: Long?",
    "val cursor: VertoMaintenanceCursor",
    "suspend fun loadImportCandidates",
):
    check(f"contract:{token}", token in projection_contract)
check(
    "contract:pure-domain",
    not any(token in projection_contract for token in ("android.", "androidx.", "Room", "Dao", "Entity")),
)
for token in (
    "WHERE companyId = :companyId",
    "sourceUpdatedAtEpochMillis > :afterUpdatedAtEpochMillis",
    "sourceUpdatedAtEpochMillis = :afterUpdatedAtEpochMillis",
    "sourceMaintenanceId > :afterMaintenanceId",
    "ORDER BY sourceUpdatedAtEpochMillis ASC, sourceMaintenanceId ASC",
    "LIMIT :limit",
):
    check(f"dao:keyset:{token}", token in projection_dao)
check("repository:bounded-page", "limit in 1..MAX_IMPORT_PAGE_SIZE" in projection_repository)
check("repository:entity-hidden", "toImportCandidate" in projection_repository)
check("repository:dao-keyset", "projectionDao.loadImportCandidates" in projection_repository)

# Finance lookup remains behind the Finance domain port.
check("finance:remote-id-contract", "findInvoiceByVertoId" in finance_port)
check("finance:remote-id-adapter", "findByVertoInvoiceId" in finance_adapter)
check("finance:no-dao-in-app-coordinator", "InvoiceProjectionDao" not in coordinator)

# Coordinator composition and architecture.
for token in (
    "SyncVertoMaintenanceProjections",
    "VertoMaintenanceProjectionRepository",
    "FinanceProjectionPort",
    "MaintenanceImportPort",
    "VehicleMatcherPort",
    "VertoLinkAuditPort",
    "VertoLinkTransactionRunner",
    "SessionReader",
):
    check(f"coordinator:contract:{token}", token in coordinator)
check("coordinator:no-data-import", ".data." not in coordinator)
check("coordinator:no-dao", "Dao" not in coordinator)
check("coordinator:no-database", "OptimalDatabase" not in coordinator)
check("coordinator:singleton", "@Singleton" in coordinator)
check("coordinator:mutex", "Mutex()" in coordinator and "withLock" in coordinator)
check(
    "coordinator:sync-before-import",
    coordinator.index("syncSourceProjections(") < coordinator.index("loadImportCandidates"),
)
check("coordinator:keyset-pages", "after = candidates.last().cursor" in coordinator)
check("coordinator:page-cap", "MAX_IMPORT_PAGES_PER_RUN" in coordinator)

# Import policy and cross-feature transaction.
check("policy:skip-voided", "if (candidate.voided) return CandidateImportResult.SkippedVoided" in coordinator)
check(
    "policy:require-completed-at",
    "candidate.completedAtEpochMillis" in coordinator and "SkippedIncomplete" in coordinator,
)
check(
    "policy:invoice-by-source-id",
    "candidate.sourceInvoiceId" in coordinator and "findInvoiceByVertoId" in coordinator,
)
check("policy:skip-voided-invoice", "if (invoice.voided)" in coordinator)
check(
    "policy:trusted-vehicle-only",
    "VehicleMatchHints(trustedRemoteId = candidate.optimalVehicleRemoteId)" in coordinator,
)
check("policy:full-maintenance", "ImportedMaintenanceMode.FULL_MAINTENANCE" in coordinator)
check("policy:source-description", "description = description ?: invoice.description" in coordinator)
check("policy:completion-date", "invoiceDateEpochMillis = completedAtEpochMillis" in coordinator)
check("policy:trusted-odometer", "odometerKm = odometerKm" in coordinator)
check("policy:transaction", "return transactionRunner.run" in coordinator)
check("policy:link-recheck", "findLink(session.companyId, invoice.id)" in coordinator)
check("policy:operation-idempotency", "ImportVertoMaintenanceResult.Existing" in coordinator)
check("policy:stable-link-id", 'stableId("verto-auto-link"' in coordinator)
check("policy:stable-audit-id", 'stableId("verto-auto-link-audit"' in coordinator)
check("policy:save-link", "financeProjectionPort.saveLink" in coordinator)
check("policy:update-odometer", "updateOdometerIfNewer" in coordinator)
check("policy:audit", "auditPort.recordLink" in coordinator)
check(
    "policy:no-delete",
    not any(token in coordinator for token in ("deleteOperation", "deleteProjection", "DELETE FROM")),
)

# Worker activation and ordering. v64 composes the v61 coordinator through the unified sync pipeline.
check("worker:entry-point", "unifiedSyncCoordinator" in entry)
check("worker:coordinator-run", "unifiedSyncCoordinator().run(activeSession)" in worker)
check("worker:maintenance-participant", "MaintenanceFeedUnifiedSyncParticipant" in unified_sync)
check(
    "worker:after-invoice",
    unified_sync.index('key: String = "verto_invoice_feed"') <
    unified_sync.index('key: String = "verto_maintenance_feed"'),
)
check(
    "worker:before-message-pull",
    unified_sync.index('key: String = "verto_maintenance_feed"') <
    unified_sync.index('key: String = "verto_message_pull"'),
)
check(
    "worker:retry-unavailable",
    "VertoMaintenanceAutoImportResult.Unavailable" in unified_sync and
    "UnifiedSyncStepResult.RetryRequired" in unified_sync,
)

# Tests and evidence.
for token in (
    "completedProjectionCreatesFullMaintenanceAndTrustedLink",
    "repeatedRunUsesExistingLinkAndDoesNotDuplicateOperation",
    "voidedAndIncompleteProjectionsAreSkippedWithoutSideEffects",
    "missingInvoiceOrVehicleIsDeferredAndCanBeRetriedLater",
    "unavailableSourceDoesNotImportCachedProjection",
):
    check(f"test:{token}", token in test)
for relative in (
    "scripts/v61-verto-maintenance-import-harness.py",
    "scripts/run-v61-verto-maintenance-import-harness.sh",
    "scripts/run-v61-source-syntax-check.sh",
    "scripts/verify-v61-static.sh",
):
    check(f"evidence:{relative}", (ROOT / relative).is_file())

# Release gates and invariants.
check("gradle:v61-gate", "vertoMaintenanceAutoImportContractCheck" in root_build)
check("gradle:v61-script", "scripts/v61-verto-maintenance-import-contract.py" in root_build)
check("gradle:static-quality-v61", "vertoMaintenanceAutoImportContractCheck," in root_build)
check("ci-fast:v61-contract", "v61-verto-maintenance-import-contract.py" in ci_fast)
check("ci-fast:v61-harness", "v61-verto-maintenance-import-harness.py" in ci_fast)
check("ci-full:v61-route", any(name in ci_full for name in ("verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-project:v61-route", any(name in verify_project for name in ("verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-v61:v60-regression", "verify-v60-static.sh" in verify_v61)
check("android:version-stable", "versionCode = 32" in app_build and 'versionName = "0.37.0-v37"' in app_build)
check("room:version-stable", "version = 3" in database)
check("backend:no-v61-migration", not any((ROOT / "supabase/migrations").glob("*v61*")))

print(f"v61 Verto maintenance auto-import contract: {len(checks)}/{len(checks)} PASS")
