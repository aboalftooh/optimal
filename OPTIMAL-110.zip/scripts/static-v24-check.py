#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "docs/sessions/v24.md",
    "docs/baseline-v24.md",
    "docs/verification-scripts-v24.md",
    "docs/source-archive-v24.sha256",
    "docs/UI_REDESIGN_V23.md",
    "scripts/static-v24-check.py",
    "scripts/verify-v24-static.sh",
    "scripts/verify-v24-regressions.sh",
    "PATCH_MANIFEST-v24.md",
    "CHANGED_FILES-v24.txt",
    "DELETED_FILES-v24.txt",
    "verification-v24.md",
    "docs/verifications/verification-v24.md",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
version_code_match = re.search(r"versionCode\s*=\s*(\d+)", build)
version_name_match = re.search(r'versionName\s*=\s*"0\.(\d+)\.0-v(\d+)"', build)
version_code = int(version_code_match.group(1)) if version_code_match else -1
version_number = int(version_name_match.group(1)) if version_name_match else -1
version_suffix = int(version_name_match.group(2)) if version_name_match else -2
check("versionCode is 19 or newer", version_code >= 19, str(version_code))
check("versionName is v24 or newer", version_number >= 24 and version_number == version_suffix, str(version_number))

current_version = f"0.{version_number}.0-v{version_number}" if version_number >= 0 else ""
for document in ["README.md", "AGENTS.md", "docs/release-notes.md"]:
    text = read(document)
    check(f"{document} states current version", current_version in text, current_version)

readme = read("README.md")
agents = read("AGENTS.md")
plan = read("docs/implementation-plan.md")
changelog = read("docs/implementation-changelog.md")
check("README identifies v24 baseline", "خط أساس" in readme and "v24" in readme)
check("AGENTS current phase is v24", "V24_BASELINE_GOVERNANCE_BLOCKED" in agents)
check("implementation plan records v22, v23 and v24", all(token in plan for token in ["بعد v22", "بعد v23", "بعد v24"]))
check("implementation changelog records v22, v23 and v24", all(token in changelog for token in ["## v22", "## v23", "## v24"]))
check("v23 UI-only history is explicit", "واجهات" in read("docs/UI_REDESIGN_V23.md") and "لا تغيير" in plan)

baseline = read("docs/baseline-v24.md")
for label, token in [
    ("15 modules", "الوحدات: **15**"),
    ("339 production files", "ملفات الإنتاج: **339**"),
    ("102 test files", "ملفات الاختبار: **102**"),
    ("246 tests", "الاختبارات المعرفة بـ`@Test`: **246**"),
]:
    check(f"baseline records {label}", token in baseline)

architecture = read("scripts/static-architecture-check.py")
check("architecture gate protects domain infrastructure", "domain is independent from Room/network/serialization/Supabase" in architecture)
check("architecture gate protects presentation infrastructure", "presentation/UI does not import network/data adapters/WorkManager" in architecture)
check("architecture gate contains 24 checks", len(re.findall(r"\bcheck\(", architecture)) >= 24)

verify_project = read("scripts/verify-project.sh")
verify_static = read("scripts/verify-v24-static.sh")
verify_regressions = read("scripts/verify-v24-regressions.sh")
check("verify-project invokes v24 static gate", "verify-v24-static.sh" in verify_project)
check("verify-project invokes v24 regression gate", "verify-v24-regressions.sh" in verify_project)
check("verify-project includes all required Gradle commands", all(command in verify_project for command in [
    "./gradlew clean",
    "./gradlew testDebugUnitTest",
    "./gradlew lintDebug",
    "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))
check("v24 static gate retains v20 and v21 contracts", "static-v20-check.py" in verify_static and "static-v21-check.py" in verify_static)
check("regression harnesses run sequentially", not re.search(r"&\s*(?:p\d+|$)", verify_regressions, re.M) and "for script" in verify_regressions)
check("regression harnesses have timeout", bool(re.search(r"timeout[^\n]+240s", verify_regressions)))

for script in [
    "scripts/verify-project.sh",
    "scripts/verify-v24-static.sh",
    "scripts/verify-v24-regressions.sh",
    "scripts/static-architecture-check.py",
    "scripts/static-v24-check.py",
]:
    path = ROOT / script
    check(f"active script is executable: {script}", path.is_file() and bool(path.stat().st_mode & 0o111))

# Every script command advertised in README must resolve to an executable file.
readme_scripts = sorted(set(re.findall(r"\./(scripts/[A-Za-z0-9._/-]+)", readme)))
missing_or_inert = [
    script for script in readme_scripts
    if not (ROOT / script).is_file() or not bool((ROOT / script).stat().st_mode & 0o111)
]
check("README script commands are executable", not missing_or_inert, ", ".join(missing_or_inert))

for script in ["scripts/static-architecture-check.py", "scripts/static-v24-check.py", "scripts/static-v21-check.py"]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid = True
    except py_compile.PyCompileError as error:
        valid = False
        detail = str(error)
    else:
        detail = ""
    check(f"Python syntax valid: {script}", valid, detail)

for script in [
    "scripts/verify-project.sh",
    "scripts/verify-v24-static.sh",
    "scripts/verify-v24-regressions.sh",
    "scripts/verify-v21-regressions.sh",
    "scripts/run-v11-finance-harness.sh",
    "scripts/run-v12-audit-harness.sh",
    "scripts/run-v13-member-harness.sh",
    "scripts/run-v14-notification-harness.sh",
    "scripts/run-v18-onboarding-harness.sh",
    "scripts/run-v19-domain-harness.sh",
]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result.returncode == 0, result.stderr.strip())

hash_line = read("docs/source-archive-v24.sha256").strip()
check(
    "source archive SHA-256 is recorded",
    bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-v23-unified-ui\.zip", hash_line)),
    hash_line,
)

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV24 baseline checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
