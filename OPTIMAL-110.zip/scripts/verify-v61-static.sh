#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v61-verto-maintenance-import-contract.py
./scripts/run-v61-verto-maintenance-import-harness.sh
./scripts/verify-v60-static.sh
bash scripts/run-v61-source-syntax-check.sh
