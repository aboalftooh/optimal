package com.optimal.fleet.feature.vehicles.data

import com.optimal.fleet.feature.vehicles.domain.usecase.SaveVehicleUseCaseTest

private var checks = 0

private fun runCase(name: String, block: () -> Unit) {
    block()
    checks += 1
    println("PASS: $name")
}

fun main() {
    val useCaseTests = SaveVehicleUseCaseTest()
    runCase("vehicle use case derives tenant from session") { useCaseTests.companyIdAlwaysComesFromSession() }
    runCase("vehicle use case enforces odometer reason") { useCaseTests.lowerOdometerIsBlockedUntilReasonExists() }

    val repositoryTests = VehicleRepositoryTest()
    runCase("vehicle create persists and audits") { repositoryTests.createPersistsVehicleAndAudit() }
    runCase("duplicate plate is rejected per company") { repositoryTests.duplicatePlateWithinCompanyIsRejected() }
    runCase("same plate is isolated between companies") { repositoryTests.samePlateCanExistInDifferentCompanies() }
    runCase("vehicle archive remains queryable") { repositoryTests.archiveKeepsVehicleAndAddsAudit() }

    fun contract(block: VehicleRepositoryContractTest.() -> Unit) {
        VehicleRepositoryContractTest().apply {
            setUpRepository()
            block()
        }
    }
    runCase("tenant contract reads owning company") { contract { createdRecordCanBeReadInsideOwningCompany() } }
    runCase("tenant contract blocks another company") { contract { recordCannotBeReadThroughAnotherCompany() } }
    runCase("write boundary records transaction and audit") { contract { writeBoundaryRecordsTransactionAndSanitizedAudit() } }
    runCase("duplicate plate remains company scoped") { contract { duplicatePlateRuleIsScopedToCompany() } }

    println("V36 vehicle repository contract harness: $checks/$checks")
}
