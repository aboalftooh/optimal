#!/usr/bin/env python3
"""Executable v56 model for local audio lifecycle and cancellation invariants."""
from dataclasses import dataclass

checks = 0
def check(condition, label):
    global checks
    assert condition, label
    checks += 1

@dataclass
class Draft:
    path: str
    duration: int
    size: int

class Model:
    def __init__(self):
        self.recording = False
        self.staging = False
        self.draft = None
        self.messages = []
    def start(self, allowed):
        if not allowed: return "denied"
        if self.recording: return "already"
        self.recording = self.staging = True
        return "started"
    def cancel(self):
        self.recording = self.staging = False
    def stop(self, duration, size):
        if not self.recording: return "not-recording"
        self.recording = self.staging = False
        if duration <= 0 or size <= 0: return "rejected"
        self.draft = Draft("verto/attachments/id.m4a", duration, size)
        return "ready"
    def save(self, allowed=True, room_ok=True):
        if not allowed: return "denied"
        if not room_ok: return "retry"
        self.messages.append(("AUDIO", self.draft.path, self.draft.duration, "LOCAL_READY"))
        self.draft = None
        return "saved"
    def discard(self):
        self.draft = None

m = Model()
check(m.start(False) == "denied", "permission fails closed")
check(not m.recording and not m.staging, "denied start creates no file")
check(m.start(True) == "started", "authorized start")
check(m.start(True) == "already", "double start is idempotent")
m.cancel()
check(not m.recording and not m.staging, "cancel removes active draft")
check(m.stop(1000, 200) == "not-recording", "stop without recording")
check(m.start(True) == "started", "restart after cancel")
check(m.stop(0, 200) == "rejected" and m.draft is None, "zero duration rejected")
check(m.start(True) == "started", "start valid recording")
check(m.stop(3456, 12000) == "ready", "valid audio becomes preview draft")
check(m.draft.duration == 3456 and m.draft.path.endswith(".m4a"), "actual metadata retained")
check(m.save(room_ok=False) == "retry" and m.draft is not None, "Room failure retains retryable draft")
check(m.save(allowed=False) == "denied" and m.draft is not None, "revoked permission retains draft")
check(m.save() == "saved" and m.draft is None, "successful local save consumes draft")
check(m.messages == [("AUDIO", "verto/attachments/id.m4a", 3456, "LOCAL_READY")], "audio local-ready without upload")
check(m.start(True) == "started" and m.stop(800, 100) == "ready", "second draft ready")
m.discard()
check(m.draft is None and len(m.messages) == 1, "explicit discard never writes Room")
print(f"v56 local audio harness: {checks}/{checks} PASS")
