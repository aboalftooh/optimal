#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
passed = 0
failed = 0

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f"PASS: {name}")
    else:
        failed += 1
        print(f"FAIL: {name}")

required = [
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/NotificationEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/model/NotificationCandidateRows.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationModels.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationContracts.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationUseCases.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain/NotificationEventPolicy.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data/RoomNotificationCenterGateway.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data/RoomNotificationCandidateSource.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/di/NotificationDataModule.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsViewModel.kt",
    "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/notifications/AndroidNotificationDeliveryPort.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/notifications/NotificationChannelManager.kt",
    "app/src/main/java/com/optimal/fleet/work/FollowUpNotificationWorker.kt",
    "app/src/main/java/com/optimal/fleet/work/NotificationScheduler.kt",
    "app/src/main/java/com/optimal/fleet/navigation/deeplink/NotificationDeepLink.kt",
    "app/src/main/java/com/optimal/fleet/navigation/deeplink/NotificationTapViewModel.kt",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
migration = read("core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt")
entity = read(required[0])
dao = read(required[1])
models = read(required[3])
contracts = read(required[4])
usecases = read(required[5])
policy = read(required[6])
gateway = read(required[7])
source = read(required[8])
view_model = read(required[10])
route = read(required[11])
delivery = read(required[12])
channel = read(required[13])
worker = read(required[14])
scheduler = read(required[15])
deep_link = read(required[16])
manifest = read("app/src/main/AndroidManifest.xml")
application = read("app/src/main/java/com/optimal/fleet/OptimalApplication.kt")
main_activity = read("app/src/main/java/com/optimal/fleet/MainActivity.kt")
nav_graph = read("app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt")
notification_nav = read("feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/navigation/NotificationsNavigation.kt")
maintenance_nav = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt")
maintenance_route = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpRoute.kt")
build = read("app/build.gradle.kts")

check("Room version 12", "version = 12" in database)
check("notification entity registered", "NotificationEntity::class" in database)
check("notification dao exposed", "abstract fun notificationDao(): NotificationDao" in database)
check("migration 11 to 12 exists", "MIGRATION_11_12" in migration)
check("migration included", re.search(r"MIGRATION_11_12,\s*\)", migration) is not None)
check("notification table created", "CREATE TABLE IF NOT EXISTS `notifications`" in migration)
check("company event key unique migration", "index_notifications_companyId_eventKey" in migration)
check("company event key unique entity", 'Index(value = ["companyId", "eventKey"], unique = true)' in entity)
check("notification company foreign key", "CompanyEntity::class" in entity and "onDelete = ForeignKey.CASCADE" in entity)
check("notification read state", "readAtEpochMillis" in entity and "markRead" in dao)
check("notification delivery state", "deliveredAtEpochMillis" in entity and "findUndelivered" in dao and "markDelivered" in dao)
check("notification insert ignore", "OnConflictStrategy.IGNORE" in dao)
check("notification company scoped reads", "WHERE companyId = :companyId" in dao)
check("due follow-up read model", "findDueFollowUps" in dao)
check("invoice candidate read model", "findInvoiceCandidates" in dao)
check("sync failure after attempts", "attemptCount >= :minimumRetryAttempts" in dao)

for type_name in ["FOLLOW_UP_DUE", "FOLLOW_UP_OVERDUE", "INVOICE_NEW", "INVOICE_REQUIRES_LINK", "SYNC_FAILED"]:
    check(f"notification type {type_name}", type_name in models)
for target in ["FOLLOW_UP", "INVOICE", "HOME"]:
    check(f"target type {target}", target in models)
check("action label required", "val actionLabel: String" in models)
check("candidate source contract", "interface NotificationCandidateSource" in contracts)
check("delivery port contract", "interface NotificationDeliveryPort" in contracts)
check("center gateway contract", "interface NotificationCenterGateway" in contracts)
check("generator uses active session", "sessionReader.currentSession()" in usecases)
check("generator deduplicates candidate list", "distinctBy(NotificationEventDraft::eventKey)" in usecases)
check("generator retries undelivered", "findUndelivered" in usecases)
check("delivered marked only after publish", usecases.index("deliveryPort.deliver") < usecases.index("markDelivered"))
check("stable follow-up keys", "followUpKey" in policy and "follow-up:$followUpId:due" in policy)
check("stable invoice keys", "invoiceNewKey" in policy and "invoiceRequiresLinkKey" in policy)
check("stable sync key", "syncFailedKey" in policy)
check("overdue policy", "FOLLOW_UP_OVERDUE" in policy and "currentOdometerKm > dueOdometerKm" in policy)
check("same invoice not noisy", "if (invoice.requiresVehicleLink)" in source and "else if" in source)
check("new invoice window", "NEW_INVOICE_WINDOW_MILLIS" in source)
check("minimum retries three", "MINIMUM_RETRY_ATTEMPTS = 3" in source)
check("company included in deterministic id", '"${draft.companyId}:${draft.eventKey}"' in gateway)

check("notification screen connected", "NotificationsConnected" in route)
check("unread count displayed", "notification-unread-count" in route)
check("mark all read action", "mark-all-notifications-read" in route)
check("notification action button", "notification-action-${item.id}" in route)
check("viewmodel observes unread", "unreadCount()" in view_model)
check("viewmodel marks item read", "markNotificationRead" in view_model)
check("viewmodel marks all read", "markAllNotificationsRead" in view_model)
check("viewmodel opens target effect", "OpenTarget" in view_model)

check("local Android adapter", "NotificationManagerCompat" in delivery)
check("post notification permission guarded", "POST_NOTIFICATIONS" in manifest and "notificationsAllowed" in delivery)
check("stable Android notification id", "eventKey.hashCode()" in delivery)
check("notification only alerts once", "setOnlyAlertOnce(true)" in delivery)
check("notification has action", "addAction" in delivery)
check("channel has actionable description", "الفواتير والمتابعات المستحقة" in channel)
check("channel created at startup", "notificationChannelManager.ensureChannels()" in application)
check("immediate notification work scheduled", "notificationScheduler.scheduleNow()" in application)
check("periodic notification work scheduled", "notificationScheduler.schedulePeriodic()" in application)
check("worker has no DAO", "Dao" not in worker)
check("worker invokes use case only", "generateAndDeliverNotifications().invoke()" in worker)
check("scheduler has no network constraint", "NetworkType" not in scheduler)
check("scheduler uses unique work", "enqueueUniqueWork" in scheduler and "enqueueUniquePeriodicWork" in scheduler)

check("deep-link intent validated", "isSafeIdentifier" in deep_link)
check("unsafe route rejected", "return null" in deep_link)
check("invoice exact route", "invoiceDetailsRoute" in deep_link)
check("follow-up exact route", "maintenanceFollowUpRoute" in deep_link)
check("home route supported", "HOME_ROUTE" in deep_link)
check("tap marks read", "markOpened" in read(required[17]))
check("main activity handles new intent", "onNewIntent" in main_activity)
check("app navigation consumes request", "onNotificationNavigationConsumed" in read("app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt"))
check("notification graph callback", "onOpenTarget" in notification_nav and "toValidatedRoute" in nav_graph)
check("follow-up route has focus argument", "focusId" in maintenance_nav)
check("follow-up target scrolls", "animateScrollToItem" in maintenance_route)

feature_domain = ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain"
violations = []
for file in feature_domain.rglob("*.kt"):
    text = file.read_text(encoding="utf-8")
    if re.search(r"^import (android\.|androidx\.room|com\.optimal\.fleet\.core\.database)", text, re.MULTILINE):
        violations.append(str(file.relative_to(ROOT)))
check("notification domain is platform independent", not violations)

presentation = ROOT / "feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation"
presentation_violations = []
for file in presentation.rglob("*.kt"):
    text = file.read_text(encoding="utf-8")
    if "core.database" in text or "NotificationDao" in text or "NotificationManagerCompat" in text:
        presentation_violations.append(str(file.relative_to(ROOT)))
check("presentation has no data or Android notification manager", not presentation_violations)

for test in ["NotificationDeduplicationTest.kt", "FollowUpNotificationTest.kt", "DeepLinkTest.kt", "NotificationCenterViewModelTest.kt", "NotificationArchitectureTest.kt"]:
    check(f"test exists {test}", any(path.name == test for path in ROOT.rglob("*.kt")))

check("version v14 or later", bool(re.search(r'versionName = "0\.(1[4-9]|[2-9][0-9])\.0-v[0-9]+"', build)))
check("version code 10 or later", bool(re.search(r"versionCode = (1[0-9]|[2-9][0-9]+)", build)))
check("FCM absent from production", not any("firebase.messaging" in p.read_text(encoding="utf-8") for p in ROOT.rglob("*.kt") if "src/main" in str(p)))

print(f"RESULT: {passed}/{passed + failed} passed")
raise SystemExit(1 if failed else 0)
