#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v54 Local-first Verto text sending."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "identity": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingMessageIdentity.kt",
    "identity_factory": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/UuidVertoMessageIdentityFactory.kt",
    "usecases": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoTextMessageUseCases.kt",
    "repository_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "remote_models": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoMessageRemoteModels.kt",
    "remote_api": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/OptimalVertoMessagesApi.kt",
    "remote_source": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/remote/VertoMessageRemoteDataSource.kt",
    "message_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMessageDao.kt",
    "queue_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt",
    "queue_constants": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueConstants.kt",
    "participant": ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncParticipant.kt",
    "scheduler": ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncSchedulerAdapter.kt",
    "sync_module": ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt",
    "contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "entry": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "tests": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoTextMessageUseCaseTest.kt",
    "ui_state_tests": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoChatUiStateTest.kt",
}

CHAT_PRESENTATION_DIR = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation"
CHAT_PRESENTATION_FILES = (
    "VertoChatScreen.kt",
    "VertoChatChrome.kt",
    "VertoChatMessages.kt",
    "VertoChatAttachments.kt",
    "VertoChatComposer.kt",
    "VertoChatFormatting.kt",
)

def chat_presentation_text() -> str:
    return "\n".join(
        (CHAT_PRESENTATION_DIR / name).read_text(encoding="utf-8")
        for name in CHAT_PRESENTATION_FILES
    )

checks = []

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    if not condition:
        raise AssertionError(name)

def text(key: str) -> str:
    if key == "screen":
        return chat_presentation_text()
    return FILES[key].read_text(encoding="utf-8")

for name, path in FILES.items():
    check(f"exists:{name}", path.is_file())

identity = text("identity")
for token in ["localId", "clientMessageId", "idempotencyKey", "createdAtEpochMillis", "VertoMessageIdentityFactory"]:
    check(f"identity:{token}", token in identity)
factory = text("identity_factory")
check("three stable UUID identities", factory.count("UUID.randomUUID().toString()") == 3)
check("identity timestamp", "clock.millis()" in factory)

usecases = text("usecases")
for token in [
    "class SendVertoTextMessageUseCase",
    "authorizeSend()",
    "rawText.trim()",
    "VertoTextEnqueueResult.Queued",
    "scheduler.schedule(grant.userId, grant.companyId)",
    "class RetryVertoTextMessageUseCase",
    "class SyncPendingVertoTextMessageUseCase",
    "SEND_PERMISSION_DENIED",
    "SESSION_COMPANY_MISMATCH",
]:
    check(f"usecase:{token}", token in usecases)
check("permission checked before trim", usecases.index("authorizeSend()") < usecases.index("rawText.trim()"))

repo = text("repository")
for token in [
    "override suspend fun enqueueTextMessage",
    "VertoDeliveryState.PENDING.name",
    "SyncAggregateType.VERTO_MESSAGE",
    "SyncOperationType.SEND_TEXT",
    "SyncOutboxEntryFactory.create",
    "AtomicWriteTransactionRunner",
    "transactionRunner.run",
    "messageDao.upsert(message)",
    "syncQueueDao.enqueueRequired(outbox)",
    "override suspend fun syncPendingTextMessage",
    "VertoDeliveryState.SENDING.name",
    "remoteDataSource.sendText",
    "VertoRemoteMessageMapper.map",
    "VertoDeliveryState.FAILED_RETRYABLE.name",
    "VertoDeliveryState.FAILED_TERMINAL.name",
    "override suspend fun retryTextMessage",
    "syncQueueDao.retryNow",
]:
    check(f"repository:{token}", token in repo)
enqueue_start = repo.index("override suspend fun enqueueTextMessage")
transaction_start = min(
    repo.index(token, enqueue_start)
    for token in ("database.withTransaction", "transactionRunner.run")
    if token in repo[enqueue_start:]
)
message_insert = repo.index("messageDao.upsert(message)", transaction_start)
outbox_insert = repo.index("syncQueueDao.enqueueRequired(outbox)", transaction_start)
check("message and outbox same transaction", transaction_start < message_insert < outbox_insert)
check("remote identity survives retry", "clientMessageId = identity.clientMessageId" in repo and "idempotencyKey = identity.idempotencyKey" in repo)

models = text("remote_models")
for token in ["p_client_message_id", "p_idempotency_key", "p_kind", "p_body_text", "p_attachment_ids"]:
    check(f"wire:{token}", token in models)
api = text("remote_api")
check("send RPC", "optimal_verto_send_message" in api)
source = text("remote_source")
for token in ["sendText", "VertoSendRemoteResult", "VERTO_NETWORK_UNAVAILABLE", "RetryableFailure", "PermissionDenied"]:
    check(f"remote:{token}", token in source)

message_dao = text("message_dao")
for token in ["findByLocalId", "updateDeliveryState", "deliveryState = :deliveryState", "failureCode = :failureCode"]:
    check(f"message dao:{token}", token in message_dao)
queue_dao = text("queue_dao")
check("manual retry resets queue", "suspend fun retryNow" in queue_dao and "state IN ('RETRY', 'PERMANENT_FAILURE')" in queue_dao)
constants = text("queue_constants")
check("Verto aggregate", 'const val VERTO_MESSAGE = "VERTO_MESSAGE"' in constants)
check("text operation", 'const val SEND_TEXT = "SEND_TEXT"' in constants)

participant = text("participant")
for token in ["SyncPendingVertoTextMessageUseCase", "SyncAggregateType.VERTO_MESSAGE", "SyncOperationType.SEND_TEXT", "SyncPushResult.Success", "RetryableFailure", "PermanentFailure"]:
    check(f"participant:{token}", token in participant)
scheduler = text("scheduler")
check("WorkManager scheduling adapter", "VertoMessageSyncScheduler" in scheduler and "syncScheduler.scheduleNow(userId, companyId)" in scheduler)
module = text("sync_module")
check("scheduler bound", "bindVertoMessageSyncScheduler" in module)
check("participant multibound", "bindVertoMessageSyncParticipant" in module and "@IntoSet" in module)

contract = text("contract")
for token in ["sendAuthorized", "composerText", "sendEnabled", "ComposerChanged", "SendText", "RetryMessage"]:
    check(f"ui contract:{token}", token in contract)
viewmodel = text("viewmodel")
for token in ["AuthorizeVertoMessageSend", "sendAuthorized", "SendVertoTextMessageUseCase", "RetryVertoTextMessageUseCase", "composerText = \"\"", "SendText", "RetryMessage"]:
    check(f"viewmodel:{token}", token in viewmodel)
screen = text("screen")
for token in ["OutlinedTextField", "verto-text-composer", "verto-send-text", "ابدأ برسالة", "FAILED_RETRYABLE", "onRetryMessage"]:
    check(f"screen:{token}", token in screen)
check("presentation remains local-only", all(x not in screen + viewmodel for x in ["Retrofit", "Supabase", "core.database", ".data.remote"]))
entry = text("entry")
for token in ["ComposerChanged", "SendText", "RetryMessage"]:
    check(f"entry:{token}", token in entry)

tests = text("tests")
ui_state_tests = text("ui_state_tests")
check("fresh authorization enables composer", "freshAuthorizationEnablesComposerEvenWhenLegacyReadFlagIsFalse" in ui_state_tests)
check("blank composer stays disabled", "blankComposerNeverEnablesSend" in ui_state_tests)

for token in [
    "blankTextIsRejectedWithoutLocalInsert",
    "permissionIsCheckedBeforeLocalInsert",
    "textIsTrimmedQueuedWithStableIdentityAndWorkerScheduled",
    "failedMessageRetryKeepsSameOutboxIdentity",
    "revokedPermissionWhilePendingMarksTerminalFailure",
]:
    check(f"test:{token}", token in tests)

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains immutable", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("no v54 Supabase migration", not any((ROOT / "supabase/migrations").glob("*v54*")))
all_text = "\n".join(path.read_text(encoding="utf-8") for path in FILES.values())
check("no merge markers", not any(marker in all_text for marker in ("<<<<<<<", "=======", ">>>>>>>")))

print(f"v54 Verto Local-first text outbox contract: {len(checks)}/{len(checks)} PASS")
