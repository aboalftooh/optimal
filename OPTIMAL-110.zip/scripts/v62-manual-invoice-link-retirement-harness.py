#!/usr/bin/env python3
"""Executable policy harness for OPTIMAL v62 invoice-link compatibility."""
from __future__ import annotations

from dataclasses import dataclass

checks = 0


def check(condition: bool, label: str) -> None:
    global checks
    checks += 1
    if not condition:
        raise AssertionError(label)


@dataclass(frozen=True)
class Invoice:
    invoice_id: str
    contract_version: int
    requires_vehicle_link: bool
    voided: bool = False


@dataclass(frozen=True)
class Link:
    invoice_id: str
    operation_id: str


def presentation(invoice: Invoice, link: Link | None) -> dict[str, bool]:
    return {
        "financial_visible": True,
        "existing_link_visible": link is not None,
        "legacy_notice_visible": link is None and invoice.contract_version < 23 and invoice.requires_vehicle_link and not invoice.voided,
        "manual_picker_visible": False,
        "manual_action_visible": False,
    }


def invoke_manual_link(invoice: Invoice, link: Link | None) -> str:
    if link is not None:
        return "ALREADY_LINKED"
    return "MANUAL_LINKING_DISABLED"


def invoice_notification(invoice: Invoice, now: int, cached_at: int) -> str | None:
    if invoice.voided or cached_at < now - 86_400_000:
        return None
    return "INVOICE_NEW"


v22 = Invoice("old", 22, True)
v23_with_maintenance = Invoice("official", 23, False)
v23_without_maintenance = Invoice("financial-only", 23, False)
legacy_link = Link("old", "operation-old")

old_unlinked_ui = presentation(v22, None)
check(old_unlinked_ui["financial_visible"], "v22 financial invoice disappeared")
check(old_unlinked_ui["legacy_notice_visible"], "v22 read-only notice missing")
check(not old_unlinked_ui["manual_picker_visible"], "v22 manual picker still visible")
check(not old_unlinked_ui["manual_action_visible"], "v22 manual action still visible")
check(invoke_manual_link(v22, None) == "MANUAL_LINKING_DISABLED", "v22 write path not disabled")

old_linked_ui = presentation(v22, legacy_link)
check(old_linked_ui["existing_link_visible"], "legacy link is no longer readable")
check(not old_linked_ui["legacy_notice_visible"], "legacy linked invoice shows wrong notice")
check(invoke_manual_link(v22, legacy_link) == "ALREADY_LINKED", "legacy idempotency changed")

v23_official_ui = presentation(v23_with_maintenance, Link("official", "operation-official"))
check(v23_official_ui["financial_visible"], "v23 official invoice disappeared")
check(v23_official_ui["existing_link_visible"], "v23 official maintenance link missing")
check(not v23_official_ui["manual_action_visible"], "v23 official invoice exposes manual action")

v23_financial_ui = presentation(v23_without_maintenance, None)
check(v23_financial_ui["financial_visible"], "v23 invoice without maintenance disappeared")
check(not v23_financial_ui["legacy_notice_visible"], "v23 invoice shows legacy prompt")
check(invoke_manual_link(v23_without_maintenance, None) == "MANUAL_LINKING_DISABLED", "v23 manual link accepted")

now = 200_000_000
check(invoice_notification(v23_without_maintenance, now, now - 1_000) == "INVOICE_NEW", "new invoice notification changed")
check(invoice_notification(v22, now, now - 86_400_001) is None, "legacy link request became persistent notification")
check(invoice_notification(Invoice("void", 23, False, True), now, now) is None, "voided invoice notified")

print(f"v62 invoice-link retirement harness: {checks}/{checks} PASS")
