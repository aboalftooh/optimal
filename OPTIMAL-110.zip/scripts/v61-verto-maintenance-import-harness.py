#!/usr/bin/env python3
"""Executable policy/transaction harness for OPTIMAL v61 automatic maintenance import."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass

checks = 0


def check(condition: bool, label: str) -> None:
    global checks
    checks += 1
    if not condition:
        raise AssertionError(label)


@dataclass(frozen=True)
class Candidate:
    maintenance_id: str
    invoice_id: str
    vehicle_remote_id: str
    updated_at: int
    completed_at: int | None
    voided: bool = False


conn = sqlite3.connect(":memory:")
conn.execute("pragma foreign_keys=on")
conn.executescript(
    """
    create table projections(
      company_id text not null,
      maintenance_id text not null,
      invoice_id text not null,
      vehicle_remote_id text not null,
      updated_at integer not null,
      completed_at integer,
      voided integer not null,
      primary key(company_id, maintenance_id)
    );
    create table invoices(
      company_id text not null,
      projection_id text not null,
      invoice_id text not null,
      total_minor integer not null,
      voided integer not null,
      primary key(company_id, projection_id),
      unique(company_id, invoice_id)
    );
    create table vehicles(
      company_id text not null,
      vehicle_id text not null,
      remote_id text not null,
      odometer integer,
      primary key(company_id, vehicle_id),
      unique(company_id, remote_id)
    );
    create table operations(
      company_id text not null,
      operation_id text not null,
      invoice_id text not null,
      vehicle_id text not null,
      status text not null,
      total_minor integer not null,
      primary key(company_id, operation_id),
      unique(company_id, invoice_id)
    );
    create table links(
      company_id text not null,
      projection_id text not null,
      operation_id text not null,
      vehicle_id text not null,
      method text not null,
      primary key(company_id, projection_id)
    );
    create table audits(
      audit_id text primary key,
      company_id text not null,
      projection_id text not null
    );
    """
)

company = "c1"
other = "c2"
rows = [
    Candidate("m1", "i1", "rv1", 10, 100),
    Candidate("m2", "i2", "rv1", 10, 110, True),
    Candidate("m3", "i3", "rv1", 11, None),
    Candidate("m4", "missing-invoice", "rv1", 12, 120),
    Candidate("m5", "i5", "missing-vehicle", 13, 130),
]
for c in rows:
    conn.execute(
        "insert into projections values(?,?,?,?,?,?,?)",
        (company, c.maintenance_id, c.invoice_id, c.vehicle_remote_id, c.updated_at, c.completed_at, c.voided),
    )
conn.execute("insert into projections values(?,?,?,?,?,?,?)", (other, "foreign", "fi", "frv", 1, 1, 0))
for invoice_id in ("i1", "i2", "i3", "i5"):
    conn.execute("insert into invoices values(?,?,?,?,0)", (company, f"p-{invoice_id}", invoice_id, 100_000))
conn.execute("insert into vehicles values(?,?,?,?)", (company, "v1", "rv1", 80_000))
conn.commit()

# Exact keyset paging and tenant isolation.
after_updated = None
after_id = None
seen: list[str] = []
while True:
    page = conn.execute(
        """
        select maintenance_id, updated_at from projections
        where company_id=? and (
          ? is null or updated_at>? or (updated_at=? and maintenance_id>?)
        )
        order by updated_at asc, maintenance_id asc
        limit 2
        """,
        (company, after_updated, after_updated, after_updated, after_id),
    ).fetchall()
    if not page:
        break
    seen.extend(row[0] for row in page)
    after_id, after_updated = page[-1][0], page[-1][1]
check(seen == ["m1", "m2", "m3", "m4", "m5"], "keyset order or tenant isolation failed")
check("foreign" not in seen, "foreign company leaked")


def import_all() -> dict[str, int]:
    stats = {"imported": 0, "existing": 0, "voided": 0, "incomplete": 0, "invoice": 0, "vehicle": 0}
    for mid, iid, remote, updated, completed, voided in conn.execute(
        "select maintenance_id,invoice_id,vehicle_remote_id,updated_at,completed_at,voided "
        "from projections where company_id=? order by updated_at,maintenance_id",
        (company,),
    ):
        if voided:
            stats["voided"] += 1
            continue
        if completed is None:
            stats["incomplete"] += 1
            continue
        invoice = conn.execute(
            "select projection_id,total_minor,voided from invoices where company_id=? and invoice_id=?",
            (company, iid),
        ).fetchone()
        if invoice is None:
            stats["invoice"] += 1
            continue
        projection_id, total_minor, invoice_voided = invoice
        if invoice_voided:
            stats["voided"] += 1
            continue
        if conn.execute(
            "select 1 from links where company_id=? and projection_id=?",
            (company, projection_id),
        ).fetchone():
            stats["existing"] += 1
            continue
        vehicle = conn.execute(
            "select vehicle_id from vehicles where company_id=? and remote_id=?",
            (company, remote),
        ).fetchone()
        if vehicle is None:
            stats["vehicle"] += 1
            continue
        vehicle_id = vehicle[0]
        operation_id = f"verto-operation:{company}:{iid}"
        with conn:
            conn.execute(
                "insert or ignore into operations values(?,?,?,?,?,?)",
                (company, operation_id, iid, vehicle_id, "COMPLETED", total_minor),
            )
            conn.execute(
                "insert into links values(?,?,?,?,?)",
                (company, projection_id, operation_id, vehicle_id, "TRUSTED_REMOTE_ID"),
            )
            conn.execute(
                "insert into audits values(?,?,?)",
                (f"verto-auto-link-audit:{company}:{mid}", company, projection_id),
            )
        stats["imported"] += 1
    return stats


first = import_all()
expected_counts = {
    "imported": 1,
    "existing": 0,
    "voided": 1,
    "incomplete": 1,
    "invoice": 1,
    "vehicle": 1,
}
check(first == expected_counts, "policy counts mismatch")
check(conn.execute("select count(*) from operations").fetchone()[0] == 1, "operation missing")
check(conn.execute("select status from operations").fetchone()[0] == "COMPLETED", "not full completed maintenance")
check(conn.execute("select method from links").fetchone()[0] == "TRUSTED_REMOTE_ID", "untrusted link method")
check(conn.execute("select count(*) from audits").fetchone()[0] == 1, "audit missing")
second = import_all()
check(second["existing"] == 1 and second["imported"] == 0, "idempotency failed")
check(conn.execute("select count(*) from operations").fetchone()[0] == 1, "duplicate operation")
check(conn.execute("select count(*) from links").fetchone()[0] == 1, "duplicate link")

# A failed audit must roll back operation and link together.
conn.execute("insert into invoices values(?,?,?,?,0)", (company, "p-i6", "i6", 50_000))
conn.execute("insert into projections values(?,?,?,?,?,?,?)", (company, "m6", "i6", "rv1", 14, 140, 0))
conn.commit()
try:
    with conn:
        conn.execute("insert into operations values(?,?,?,?,?,?)", (company, "op6", "i6", "v1", "COMPLETED", 50_000))
        conn.execute("insert into links values(?,?,?,?,?)", (company, "p-i6", "op6", "v1", "TRUSTED_REMOTE_ID"))
        conn.execute("insert into audits values(?,?,?)", ("verto-auto-link-audit:c1:m1", company, "p-i6"))
except sqlite3.IntegrityError:
    pass
operation_count = conn.execute(
    "select count(*) from operations where operation_id='op6'",
).fetchone()[0]
check(operation_count == 0, "operation rollback failed")
link_count = conn.execute(
    "select count(*) from links where operation_id='op6'",
).fetchone()[0]
check(link_count == 0, "link rollback failed")

print(f"v61 maintenance auto-import harness: {checks}/{checks} PASS")
