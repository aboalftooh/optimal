#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

required = [
    "core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt",
    "core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt",
    "core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionWriter.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/DatabaseConstants.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/CompanyEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/LocalUserEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/ActiveSessionEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/CompanyDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/LocalUserDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/SessionDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/CompanyBootstrapCommand.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/CompanyBootstrapResult.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/CompanyBootstrapRepository.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/CreateLocalCompanyUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RestoreSessionUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/SignOutUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomCompanyBootstrapRepository.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomSessionStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/di/AuthDataModule.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt",
    "app/src/main/java/com/optimal/fleet/session/SessionGateViewModel.kt",
]
for rel in required:
    check(f"required {rel}", (ROOT / rel).is_file())

session_text = (ROOT / required[0]).read_text(encoding="utf-8")
reader_text = (ROOT / required[1]).read_text(encoding="utf-8")
writer_text = (ROOT / required[2]).read_text(encoding="utf-8")
check("session owns companyId", "val companyId: String" in session_text)
check("session exposes user and company names", all(x in session_text for x in ["userDisplayName", "companyName"]))
check("session reader exposes flow", "observeActiveSession" in reader_text and "Flow<ActiveSession?>" in reader_text)
check("session writer can persist and clear", "saveActiveSession" in writer_text and "clearActiveSession" in writer_text)

entity_root = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity"
company = (entity_root / "CompanyEntity.kt").read_text(encoding="utf-8")
user = (entity_root / "LocalUserEntity.kt").read_text(encoding="utf-8")
session = (entity_root / "ActiveSessionEntity.kt").read_text(encoding="utf-8")
check("company prepared for later sync", all(x in company for x in ["remoteId", "updatedAtEpochMillis", "syncStatus"]))
check("user prepared for later sync", all(x in user for x in ["remoteId", "updatedAtEpochMillis", "syncStatus"]))
check("user is company scoped", "val companyId: String" in user and "Index(value = [\"companyId\"])" in user)
check("user foreign key protects company", "entity = CompanyEntity::class" in user and "childColumns = [\"companyId\"]" in user)
check("user exposes composite uniqueness", "Index(value = [\"id\", \"companyId\"], unique = true)" in user)
check("session is company scoped", "val companyId: String" in session and "val userId: String" in session)
check("session has both foreign keys", session.count("ForeignKey(") == 2)
check("session user FK is company-composite", "parentColumns = [\"id\", \"companyId\"]" in session and "childColumns = [\"userId\", \"companyId\"]" in session)

session_dao = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/SessionDao.kt").read_text(encoding="utf-8")
check("session query joins user on company", "u.companyId = s.companyId" in session_dao)
check("session query requires active user", "u.isActive = 1" in session_dao)
check("session query joins company", "c.id = s.companyId" in session_dao)
check("single session slot", "WHERE s.slot = :slot" in session_dao and "LIMIT 1" in session_dao)

database = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room version is explicit and migrated", bool(re.search(r"version = (?:[2-9]|[1-9][0-9]+)", database)) and "MIGRATION_1_2" in "\n".join(p.read_text(encoding="utf-8") for p in ROOT.rglob("*.kt")))
check("Room schema exported", "exportSchema = true" in database)
check("all v03 entities registered", all(x in database for x in ["CompanyEntity::class", "LocalUserEntity::class", "ActiveSessionEntity::class"]))
check(
    "no destructive migration",
    not any(
        "fallbackToDestructiveMigration" in p.read_text(encoding="utf-8")
        for base in [ROOT / "app/src/main", ROOT / "core", ROOT / "feature"]
        for p in base.rglob("*.kt")
        if "/src/test/" not in p.as_posix() and "/src/androidTest/" not in p.as_posix()
    ),
)

presentation_files = list((ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation").rglob("*.kt"))
domain_files = list((ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain").rglob("*.kt"))
check("auth presentation exists", bool(presentation_files))
check("auth domain exists", bool(domain_files))

presentation_forbidden = []
for p in presentation_files:
    text = p.read_text(encoding="utf-8")
    if re.search(r"^import .*(\.data\.|core\.database|\.dao\.)", text, re.M):
        presentation_forbidden.append(str(p.relative_to(ROOT)))
check("presentation has no data/database imports", not presentation_forbidden, ", ".join(presentation_forbidden))

ui_contract = (ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt").read_text(encoding="utf-8")
check("UI cannot submit companyId", "companyId" not in ui_contract)
check("UI state is immutable", "@Immutable" in ui_contract and "data class AuthUiState" in ui_contract)
check("UDF events are sealed", "sealed interface AuthUiEvent" in ui_contract)

domain_forbidden = []
for p in domain_files:
    text = p.read_text(encoding="utf-8")
    if re.search(r"^import (android\.|androidx\.room|retrofit2\.|com\.optimal\.fleet\.core\.database)", text, re.M):
        domain_forbidden.append(str(p.relative_to(ROOT)))
check("domain is pure Kotlin", not domain_forbidden, ", ".join(domain_forbidden))

all_feature_files = list((ROOT / "feature/auth/src/main/java").rglob("*.kt"))
feature_to_feature = []
for p in all_feature_files:
    imports = re.findall(r"import com\.optimal\.fleet\.feature\.([a-z]+)\.", p.read_text(encoding="utf-8"))
    if any(x != "auth" for x in imports):
        feature_to_feature.append(str(p.relative_to(ROOT)))
check("auth does not import another feature", not feature_to_feature, ", ".join(feature_to_feature))

adapter = (ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomCompanyBootstrapRepository.kt").read_text(encoding="utf-8")
check("transaction is owned by data adapter", "database.withTransaction" in adapter)
check("companyId generated inside adapter", "val companyId = UUID.randomUUID" in adapter)
check("user companyId comes from generated company", "companyId = companyId" in adapter)
check("session written atomically", "sessionDao.upsert" in adapter and "database.withTransaction" in adapter)

build = (ROOT / "feature/auth/build.gradle.kts").read_text(encoding="utf-8").lower()
check("auth depends on session", 'project(":core:session")' in build)
check("auth depends on database only for data adapter", 'project(":core:database")' in build)
check("no backend SDK in auth", all(x not in build for x in ["retrofit", "supabase", "firebase"]))
check("Hilt binding module exists", "@Binds" in (ROOT / required[20]).read_text(encoding="utf-8"))
check("database provider module exists", "Room.databaseBuilder" in (ROOT / required[11]).read_text(encoding="utf-8"))

root_app = (ROOT / "app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt").read_text(encoding="utf-8")
nav = (ROOT / "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt").read_text(encoding="utf-8")
check("root observes session", "SessionGateViewModel" in root_app and "collectAsState" in root_app)
check("signed out starts at account", "AUTH_ROUTE" in root_app and "SignedOut" in root_app)
check("signed in starts at home", "HOME_ROUTE" in root_app and "SignedIn" in root_app)
check("navigation receives start destination", "startDestination: String" in nav)

all_source = "\n".join(
    p.read_text(encoding="utf-8")
    for base in [ROOT / "app/src/main", ROOT / "core", ROOT / "feature"]
    for p in base.rglob("*.kt")
    if "/src/test/" not in p.as_posix() and "/src/androidTest/" not in p.as_posix()
)
check("no Supabase code added", "supabase" not in all_source.lower())
check("no Retrofit code added", "retrofit2" not in all_source.lower())
database_persistence_source = "\n".join(
    p.read_text(encoding="utf-8")
    for base in [ROOT / "core/database/src/main"]
    for p in base.rglob("*.kt")
)
check("no password persisted locally", "password" not in database_persistence_source.lower())

required_tests = [
    "core/session/src/test/kotlin/com/optimal/fleet/core/session/ActiveSessionTest.kt",
    "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/CreateLocalCompanyUseCaseTest.kt",
    "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/SessionUseCasesTest.kt",
    "feature/auth/src/test/java/com/optimal/fleet/feature/auth/presentation/AuthViewModelTest.kt",
    "app/src/test/java/com/optimal/fleet/CompanyIsolationArchitectureTest.kt",
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/OptimalDatabaseTest.kt",
    "feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AuthScreenTest.kt",
]
for rel in required_tests:
    check(f"test {rel}", (ROOT / rel).is_file())

questions = (ROOT / "docs/questions.md").read_text(encoding="utf-8")
check("v03 local decision documented", "Room المحلي" in questions or "Room محلي" in questions)
check("Supabase deferred documented", "المزامنة لاحقًا" in questions or "مؤجلة" in questions)

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f" — {detail}" if detail and not passed else ""))

passed = sum(1 for _, ok, _ in checks if ok)
print(f"\nV03 static checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
