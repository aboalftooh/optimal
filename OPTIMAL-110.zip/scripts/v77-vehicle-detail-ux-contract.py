#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
base = root / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation"
screen_path = base / "VehicleDetailScreen.kt"
components_path = base / "VehicleDetailComponents.kt"
dialogs_path = base / "VehicleDetailDialogs.kt"
route_path = base / "VehicleDetailRoute.kt"
test_path = root / "feature/vehicles/src/androidTest/java/com/optimal/fleet/feature/vehicles/presentation/VehicleScreensTest.kt"

screen = screen_path.read_text()
components = components_path.read_text()
dialogs = dialogs_path.read_text()
route = route_path.read_text()
tests = test_path.read_text()
detail_ui = "\n".join([screen, components, dialogs, route])
checks = []


def check(label: str, condition: bool):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + ": " + label)


def sha256(path: str) -> str:
    return hashlib.sha256((root / path).read_bytes()).hexdigest()


protected = {
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesScreen.kt": "882a36f45a14ff9f05897ba9bcb6153f3ffeb77a819fba32055b719bdabf0ffb",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesComponents.kt": "cd695e1af019d2786370910d02de652642d07c108d9caeff5fc962a040f25db0",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesContract.kt": "79cc6e0c41121497fad8cf486a76132c2a62c5e033b7910ed1ef2e7efe11687e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt": "1fb69e68ec9d9a4fb19ba9950ff5b1645459033c53d0b7c1de307be8a80ea1c8",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt": "c342c80ee0231f1f6d5e2168cb8dd8a066170ca4093b00b408515a56fc9bfaad",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt": "22a79f67f294eea5ababf7adad925af00f3c40189c83b0a99e975c4e9926a87e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailViewModel.kt": "f8fcd64282d0c8ce414a61130e7207c84fa71e5dd8ed3e056b5b43605604c589",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorComponents.kt": "8c4457268bcf292a4a0bef66d09185ad9a8232d165835f80fd9241a5767d4a69",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorContract.kt": "0d8f7e2ac8fcae26cd0a9fe2ef62cadf314b782fae66e0a1a3be29cc85c806a8",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorDialogs.kt": "40fa0cdfb8d3c1429927e51b22b0a9529bf1b6b6e4c46bf5b22134a189896e1f",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorRoute.kt": "2d0ce5841a8d421e9b58673a79ba86f42f267fd93f978fbec61567e19baa41e7",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorScreen.kt": "c28814b4cf1a921f7ffc76aff1515ecdd016afab90e10b09bb60170eb287c5b7",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorViewModel.kt": "4fb687f8dcdf6cad2dfce840b3696d69b29963e5fd6e4eca37b9732a00aeb492",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/navigation/VehiclesNavigation.kt": "1d40ab4412c0251852c8714db9b2f898517ee2ebf11089c2ee290ecd8056e893",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt": "43a48d6f088044bad462fa4966b14a7b536be1d0a58b882700a621ffbf134e0f",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/ArchiveVehicleUseCase.kt": "bd4827d3021ad95dd7da316953b86102ef04454e909e3627bf75f6125c46cd71",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/ObserveVehicleUseCase.kt": "21cc10edf0c345d70eec66e886854e6c9c90e4e949ade30c7c159bee99bc2c4b",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt": "55ccef40d2b60f0e974d9350d063cec27b4690939447df3308b91b9141178393",
}

check("Vehicle Detail screen exists", screen_path.is_file())
check("Vehicle Detail components exist", components_path.is_file())
check("Vehicle Detail dialogs exist", dialogs_path.is_file())
check("Vehicle Detail route exists", route_path.is_file())
check("Vehicles UI test exists", test_path.is_file())

for name in ["OptimalPrimaryButton", "OptimalDestructiveButton", "OptimalSectionHeader", "OptimalListRow", "OptimalStatusBadge"]:
    check(f"screen uses v2 {name}", f"component.v2.{name}" in screen)
check("components use v2 OptimalListRow", "component.v2.OptimalListRow" in components)
check("components use v2 OptimalStatusBadge", "component.v2.OptimalStatusBadge" in components)
check("dialog uses v2 OptimalConfirmationDialog", "component.v2.OptimalConfirmationDialog" in dialogs)
check("route uses v2 loading state", "component.v2.OptimalLoadingState" in route)
check("route uses v2 empty state", "component.v2.OptimalEmptyState" in route)
check("legacy Design System imports removed from Vehicle Detail", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", detail_ui) is None)
check("legacy AppCard removed from Vehicle Detail", "AppCard" not in detail_ui)
check("legacy ConfirmationDialog removed", re.search(r"\bConfirmationDialog\b", dialogs) is None)
check("no direct dp literals in Vehicle Detail", re.search(r"\b\d+(?:\.\d+)?\.dp\b", detail_ui) is None)
check("no raw hex colors in Vehicle Detail", "0xFF" not in detail_ui)
check("content inset horizontal token used", "OptimalContentInsets.horizontal" in screen)
check("content inset vertical token used", "OptimalContentInsets.vertical" in screen)
check("section gap token used", "OptimalContentInsets.sectionGap" in screen)
check("bottom safe content token used", "OptimalContentInsets.bottomSafeContent" in screen)
check("summary header function exists", "fun VehicleSummaryHeader" in components)
check("summary header is rendered", "VehicleSummaryHeader(vehicle)" in screen)
check("summary test tag retained", 'testTag("vehicle-detail-summary")' in components)
check("vehicle name appears in summary", "text = vehicle.name" in components)
check("plate appears in summary", "text = vehicle.plateNumber" in components)
check("active textual status exists", '"نشطة"' in components)
check("archived textual status exists", '"مؤرشفة"' in components)
check("active status uses success tone", "OptimalStatusTone.Success" in components)
check("archived status uses neutral tone", "OptimalStatusTone.Neutral" in components)
check("status has test tag", 'testTag("vehicle-status")' in components)
check("facts section header exists", 'title = "بيانات السيارة"' in screen)
for label in ["الماركة والموديل", "سنة الصنع", "العداد", "القسم", "السائق"]:
    check(f"fact preserved: {label}", f'"{label}"' in screen)
check("missing fact fallback remains", 'value ?: "غير محدد"' in components)
check("facts use flat list rows", "OptimalListRow(" in components)
check("history section header exists", 'title = "السجلات"' in screen)
check("maintenance shortcut remains", 'title = "سجل صيانة السيارة"' in screen)
check("activity shortcut remains", 'title = "سجل نشاط السيارة"' in screen)
check("maintenance event preserved", "VehicleDetailUiEvent.OpenMaintenanceHistory" in screen)
check("activity event preserved", "VehicleDetailUiEvent.OpenActivity" in screen)
check("maintenance test tag preserved", 'testTag = "vehicle-maintenance-history"' in screen)
check("activity test tag preserved", 'testTag = "vehicle-activity"' in screen)
check("shortcuts use click-capable list rows", "onClick = onClick" in components)
check("edit event preserved", "VehicleDetailUiEvent.Edit" in screen)
check("archive request event preserved", "VehicleDetailUiEvent.RequestArchive" in screen)
check("edit test tag preserved", 'testTag("edit-vehicle")' in screen)
check("archive test tag preserved", 'testTag("archive-vehicle")' in screen)
check("edit disabled for archived vehicle", "enabled = !vehicle.isArchived" in screen)
check("archive uses destructive v2 action", "OptimalDestructiveButton(" in screen)
check("archive dialog title preserved", 'title = "أرشفة السيارة؟"' in dialogs)
check("archive dialog message preserved", 'message = "ستختفي من القائمة العادية مع بقاء سجلها محفوظًا."' in dialogs)
check("archive dialog is explicitly destructive", "destructive = true" in dialogs)
check("archive dialog dismiss event preserved", "VehicleDetailUiEvent.DismissArchiveConfirmation" in dialogs)
check("archive dialog confirm event preserved", "VehicleDetailUiEvent.ConfirmArchive" in dialogs)
check("confirm archive test tag preserved", 'confirmTestTag = "confirm-archive-vehicle"' in dialogs)
check("archive dialog test tag preserved", 'testTag("archive-vehicle-dialog")' in dialogs)
check("detail loading test tag preserved", 'testTag("vehicle-detail-loading")' in route)
check("detail empty test tag preserved", 'testTag("vehicle-detail-empty")' in route)
check("vehicle detail screen test tag preserved", 'testTag("vehicle-detail")' in screen)
check("message dismissal event is reachable", "VehicleDetailUiEvent.DismissMessage" in screen)
check("message has explicit danger text badge", "OptimalStatusTone.Danger" in screen)
check("summary/status UI test added", "detailShowsSummaryFactsAndActiveStatus" in tests)
check("maintenance shortcut event UI test added", "detailMaintenanceShortcutPreservesEvent" in tests)
check("archived detail UI test added", "archivedDetailShowsArchivedStatusAndDisablesEdit" in tests)
check("archive confirmation dispatch test retained", "detailArchiveRequiresConfirmation" in tests)
check("editor required-fields test retained", "editorShowsOnlyNameAndPlateAsRequired" in tests)
check("lower odometer editor dialog test retained", "lowerOdometerDialogRequestsReason" in tests)

for path, expected in protected.items():
    check(f"protected unchanged: {path}", sha256(path) == expected)

failed = [label for label, ok in checks if not ok]
print(f"v77 Vehicle Detail UX contract: {len(checks) - len(failed)}/{len(checks)} PASS")
if failed:
    raise SystemExit("Failed checks: " + "; ".join(failed))
