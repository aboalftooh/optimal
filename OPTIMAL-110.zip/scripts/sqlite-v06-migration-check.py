#!/usr/bin/env python3
import sqlite3
import tempfile
from pathlib import Path

passed = 0

def verify(name, condition):
    global passed
    if not condition:
        raise AssertionError(name)
    passed += 1
    print(f"PASS: {name}")

with tempfile.TemporaryDirectory() as tmp:
    db_path = Path(tmp) / "optimal-v06.db"
    db = sqlite3.connect(db_path)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript('''
    CREATE TABLE companies (
      id TEXT NOT NULL PRIMARY KEY,
      remoteId TEXT,
      name TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL
    );
    CREATE TABLE local_users (
      id TEXT NOT NULL PRIMARY KEY,
      companyId TEXT NOT NULL,
      remoteId TEXT,
      displayName TEXT NOT NULL,
      phone TEXT,
      isActive INTEGER NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL,
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE UNIQUE INDEX index_local_users_id_companyId ON local_users(id, companyId);
    CREATE TABLE vehicles (
      id TEXT NOT NULL PRIMARY KEY,
      companyId TEXT NOT NULL,
      remoteId TEXT,
      name TEXT NOT NULL,
      plateNumber TEXT NOT NULL,
      normalizedPlateNumber TEXT NOT NULL,
      brand TEXT,
      model TEXT,
      manufactureYear INTEGER,
      odometerKm INTEGER,
      department TEXT,
      driverName TEXT,
      archivedAtEpochMillis INTEGER,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL,
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT
    );
    CREATE UNIQUE INDEX index_vehicles_id_companyId ON vehicles(id, companyId);
    CREATE TABLE maintenance_operations (
      id TEXT NOT NULL,
      companyId TEXT NOT NULL,
      vehicleId TEXT NOT NULL,
      remoteId TEXT,
      clientGeneratedId TEXT NOT NULL,
      type TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL,
      startedAtEpochMillis INTEGER NOT NULL,
      completedAtEpochMillis INTEGER,
      odometerKm INTEGER,
      partsCostMinor INTEGER NOT NULL,
      serviceCostMinor INTEGER NOT NULL,
      source TEXT NOT NULL,
      createdByUserId TEXT NOT NULL,
      updatedByUserId TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncState TEXT NOT NULL,
      PRIMARY KEY(id),
      FOREIGN KEY(companyId) REFERENCES companies(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(vehicleId, companyId) REFERENCES vehicles(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(createdByUserId, companyId) REFERENCES local_users(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(updatedByUserId, companyId) REFERENCES local_users(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT
    );
    CREATE UNIQUE INDEX index_maintenance_operations_id_companyId ON maintenance_operations(id, companyId);
    ''')

    # Apply v06 migration 3 -> 4.
    db.executescript('''
    CREATE TABLE IF NOT EXISTS maintenance_audit_events (
      id TEXT NOT NULL,
      companyId TEXT NOT NULL,
      operationId TEXT NOT NULL,
      actorUserId TEXT NOT NULL,
      action TEXT NOT NULL,
      changedFields TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      syncState TEXT NOT NULL,
      PRIMARY KEY(id),
      FOREIGN KEY(operationId, companyId) REFERENCES maintenance_operations(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(actorUserId, companyId) REFERENCES local_users(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT
    );
    CREATE INDEX index_maintenance_audit_events_companyId ON maintenance_audit_events(companyId);
    CREATE INDEX index_maintenance_audit_events_operationId_companyId ON maintenance_audit_events(operationId, companyId);
    CREATE INDEX index_maintenance_audit_events_actorUserId_companyId ON maintenance_audit_events(actorUserId, companyId);
    CREATE INDEX index_maintenance_audit_events_createdAtEpochMillis ON maintenance_audit_events(createdAtEpochMillis);
    ''')
    verify("audit table created", db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='maintenance_audit_events'").fetchone()[0] == 1)
    verify("operation composite index preserved", db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='index_maintenance_operations_id_companyId'").fetchone()[0] == 1)

    for c in ("c1", "c2"):
        db.execute("INSERT INTO companies VALUES (?,?,?,?,?,?)", (c, None, c, 1, 1, "PENDING"))
    db.execute("INSERT INTO local_users VALUES (?,?,?,?,?,?,?,?,?)", ("u1", "c1", None, "أحمد", None, 1, 1, 1, "PENDING"))
    db.execute("INSERT INTO local_users VALUES (?,?,?,?,?,?,?,?,?)", ("u2", "c2", None, "محمد", None, 1, 1, 1, "PENDING"))
    db.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("v1","c1",None,"هايلوكس","12-3456","123456",None,None,None,None,None,None,None,1,1,"PENDING"))
    db.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("v2","c2",None,"كامري","88-7777","887777",None,None,None,None,None,None,None,1,1,"PENDING"))
    in_progress = ("o1","c1","v1",None,"client-1","FULL_MAINTENANCE","تغيير زيت","IN_PROGRESS",1000,None,10000,12000,5000,"MANUAL","u1","u1",1000,1000,"PENDING")
    completed = ("o2","c1","v1",None,"client-2","PARTS_ONLY","فلتر","COMPLETED",900,950,None,3000,0,"MANUAL","u1","u1",900,950,"PENDING")
    other_company = ("o3","c2","v2",None,"client-3","FULL_MAINTENANCE","فرامل","IN_PROGRESS",800,None,None,0,0,"MANUAL","u2","u2",800,800,"PENDING")
    db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", in_progress)
    db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", completed)
    db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", other_company)
    db.commit()

    rows = db.execute('''
      SELECT operation.id, vehicle.name, vehicle.plateNumber
      FROM maintenance_operations operation
      JOIN vehicles vehicle ON vehicle.id=operation.vehicleId AND vehicle.companyId=operation.companyId
      WHERE operation.companyId='c1'
      ORDER BY operation.updatedAtEpochMillis DESC
    ''').fetchall()
    verify("list join is company scoped", rows == [("o1", "هايلوكس", "12-3456"), ("o2", "هايلوكس", "12-3456")])
    verify("two business states remain", set(r[0] for r in db.execute("SELECT DISTINCT status FROM maintenance_operations")) == {"IN_PROGRESS", "COMPLETED"})

    # Simulate the DAO transaction: guarded update then audit insert.
    with db:
        changed = db.execute('''
          UPDATE maintenance_operations
          SET description=?, partsCostMinor=?, updatedByUserId=?, updatedAtEpochMillis=?, syncState=?
          WHERE companyId=? AND id=? AND status='IN_PROGRESS'
        ''', ("وصف معدل", 15000, "u1", 2000, "PENDING", "c1", "o1")).rowcount
        if changed == 1:
            db.execute("INSERT INTO maintenance_audit_events VALUES (?,?,?,?,?,?,?,?)", ("a1","c1","o1","u1","UPDATED","description,partsCostMinor",2000,"PENDING"))
    verify("in-progress row updated", db.execute("SELECT description FROM maintenance_operations WHERE id='o1'").fetchone()[0] == "وصف معدل")
    verify("audit inserted with edit", db.execute("SELECT changedFields FROM maintenance_audit_events WHERE id='a1'").fetchone()[0] == "description,partsCostMinor")
    verify("audit actor joins to name", db.execute('''SELECT u.displayName FROM maintenance_audit_events a JOIN local_users u ON u.id=a.actorUserId AND u.companyId=a.companyId WHERE a.id='a1' ''').fetchone()[0] == "أحمد")

    before = db.execute("SELECT description FROM maintenance_operations WHERE id='o2'").fetchone()[0]
    with db:
        changed = db.execute('''UPDATE maintenance_operations SET description='غير مسموح' WHERE companyId='c1' AND id='o2' AND status='IN_PROGRESS' ''').rowcount
        if changed == 1:
            db.execute("INSERT INTO maintenance_audit_events VALUES (?,?,?,?,?,?,?,?)", ("a2","c1","o2","u1","UPDATED","description",3000,"PENDING"))
    verify("completed update blocked", changed == 0 and db.execute("SELECT description FROM maintenance_operations WHERE id='o2'").fetchone()[0] == before)
    verify("completed update writes no audit", db.execute("SELECT COUNT(*) FROM maintenance_audit_events WHERE operationId='o2'").fetchone()[0] == 0)

    try:
        db.execute("INSERT INTO maintenance_audit_events VALUES (?,?,?,?,?,?,?,?)", ("bad1","c1","o3","u1","UPDATED","description",4,"PENDING"))
        db.commit(); cross_operation_blocked = False
    except sqlite3.IntegrityError:
        db.rollback(); cross_operation_blocked = True
    verify("cross-company operation audit blocked", cross_operation_blocked)

    try:
        db.execute("INSERT INTO maintenance_audit_events VALUES (?,?,?,?,?,?,?,?)", ("bad2","c1","o1","u2","UPDATED","description",4,"PENDING"))
        db.commit(); cross_actor_blocked = False
    except sqlite3.IntegrityError:
        db.rollback(); cross_actor_blocked = True
    verify("cross-company actor audit blocked", cross_actor_blocked)

    try:
        db.execute("DELETE FROM maintenance_operations WHERE id='o1'")
        db.commit(); delete_blocked = False
    except sqlite3.IntegrityError:
        db.rollback(); delete_blocked = True
    verify("audit protects edited operation from deletion", delete_blocked)

    db.close()
    reopened = sqlite3.connect(db_path)
    verify("audit survives reopen", reopened.execute("SELECT COUNT(*) FROM maintenance_audit_events WHERE id='a1'").fetchone()[0] == 1)
    reopened.close()

print(f"SQLite v06 migration checks: {passed}/{passed}")
