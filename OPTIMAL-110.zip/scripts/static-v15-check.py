#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

required = [
    "core/common/src/main/kotlin/com/optimal/fleet/core/common/analytics/AnalyticsEvent.kt",
    "core/common/src/main/kotlin/com/optimal/fleet/core/common/analytics/AnalyticsTracker.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/HomeDashboardDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/model/HomeFinanceRow.kt",
    "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalSearchAndFilters.kt",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/domain/HomeDashboard.kt",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/domain/HomeDashboardQuery.kt",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/data/RoomHomeDashboardQuery.kt",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeViewModel.kt",
    "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt",
    "app/src/main/java/com/optimal/fleet/analytics/PrivacySafeAnalyticsTracker.kt",
]
for rel in required:
    check(f"exists {rel}", (ROOT / rel).is_file())

home_route = (ROOT / required[9]).read_text(encoding="utf-8")
home_vm = (ROOT / required[8]).read_text(encoding="utf-8")
home_dao = (ROOT / required[2]).read_text(encoding="utf-8")
analytics = (ROOT / required[0]).read_text(encoding="utf-8")
nav = (ROOT / "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt").read_text(encoding="utf-8")
app_build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
db = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")

for label in ["إضافة عملية", "العمليات الجارية", "المتابعة المستحقة", "آخر العمليات المكتملة", "الملخص المالي"]:
    check(f"home contains {label}", label in home_route)
check("home shows owed and paid", "عليكم:" in home_route and "دفعتم:" in home_route)
check("home shows invoices needing link", "فاتورة تحتاج ربطًا بسيارة" in home_route)
check("home has no charts", not re.search(r"Chart|Canvas|رسم بياني", home_route, re.I))
check("home reads query contract", "HomeDashboardQuery" in home_vm and "Repository" not in home_vm)
check("home presentation has no DAO", "Dao" not in home_vm and "Dao" not in home_route)
check("home app navigation wired", "homeGraph(" in nav and "onOpenFinance" in nav and "maintenanceFollowUpRoute" in nav)
check("home queries limited", home_dao.count("LIMIT :limit") >= 3)
check("home company scoped", home_dao.count("companyId = :companyId") >= 3 and "company.id = :companyId" in home_dao)
check("home database exposed", "homeDashboardDao" in db)
check("Room schema unchanged", "version = 12" in db)

check("analytics has no free text fields", "String" not in analytics and "description" not in analytics.lower())
check("analytics uses sealed event", "sealed interface AnalyticsEvent" in analytics)
check("analytics has at least two feature consumers", sum(
    1 for p in [
        ROOT / "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeViewModel.kt",
        ROOT / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt",
    ] if "AnalyticsTracker" in p.read_text(encoding="utf-8")
) >= 2)

search_component = "OptimalSearchField"
for rel in [
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListRoute.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt",
]:
    check(f"unified search {rel}", search_component in (ROOT / rel).read_text(encoding="utf-8"))

states = (ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalScreenStates.kt").read_text(encoding="utf-8")
check("shared loading state", "OptimalLoadingState" in states)
check("shared empty state", "OptimalEmptyState" in states)
check("shared error state", "OptimalErrorState" in states)
check("48dp search clear target", "OptimalSpacing.touchTarget" in (ROOT / required[4]).read_text(encoding="utf-8"))
check("home headings semantics", "heading()" in home_route)
check("home primary action test tag", "home-add-operation" in home_route)
check("query lengths capped", ".take(120)" in (ROOT / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt").read_text(encoding="utf-8"))
check("vehicle query debounced", "debounce(250)" in (ROOT / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt").read_text(encoding="utf-8"))
check("invoice filtering pure", (ROOT / "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/query/InvoiceSearch.kt").is_file())
check("version is v15 or later", bool(re.search(r'versionName = \"0\.(?:1[5-9]|[2-9]\d)\.', app_build)))
check("version code 11 or later", int(re.search(r"versionCode = (\d+)", app_build).group(1)) >= 11)

for rel in [
    "feature/home/src/test/java/com/optimal/fleet/feature/home/presentation/HomeViewModelTest.kt",
    "feature/home/src/androidTest/java/com/optimal/fleet/feature/home/HomeAccessibilityTest.kt",
    "feature/finance/src/test/java/com/optimal/fleet/feature/finance/domain/invoice/query/InvoiceSearchTest.kt",
    "app/src/test/java/com/optimal/fleet/analytics/AnalyticsPrivacyTest.kt",
]:
    check(f"test exists {rel}", (ROOT / rel).is_file())

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f" — {detail}" if detail and not passed else ""))
passed = sum(1 for _, ok, _ in checks if ok)
print(f"RESULT: {passed}/{len(checks)} passed")
sys.exit(0 if passed == len(checks) else 1)
