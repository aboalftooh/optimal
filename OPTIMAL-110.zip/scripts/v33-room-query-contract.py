#!/usr/bin/env python3
from pathlib import Path
import json
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/1.json"

def extract_query(path: str, method: str) -> str:
    text = (ROOT / path).read_text(encoding="utf-8")
    marker = f"fun {method}("
    pos = text.find(marker)
    if pos < 0:
        marker = f"suspend fun {method}("
        pos = text.find(marker)
    if pos < 0:
        raise AssertionError(f"missing method {method}")
    close = text.rfind('"""', 0, pos)
    open_ = text.rfind('"""', 0, close)
    if open_ < 0 or close < 0:
        raise AssertionError(f"missing SQL for {method}")
    return text[open_ + 3:close].strip()

schema = json.loads(SCHEMA.read_text(encoding="utf-8"))["database"]
db = sqlite3.connect(":memory:")
db.execute("PRAGMA foreign_keys=OFF")
for entity in schema["entities"]:
    db.execute(entity["createSql"].replace("${TABLE_NAME}", entity["tableName"]))
for entity in schema["entities"]:
    for index in entity.get("indices", []):
        db.execute(index["createSql"].replace("${TABLE_NAME}", entity["tableName"]))

cases = [
    ("vehicles", "core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt", "loadVehiclesPage", dict(companyId="A", includeArchived=0, query="", limitWithLookahead=41, offset=0)),
    ("maintenance", "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt", "loadOperationsPage", dict(companyId="A", status="IN_PROGRESS", source=None, type=None, startedAtEpochMillis=None, query="", limitWithLookahead=41, offset=0)),
    ("history", "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt", "loadCompletedHistoryPage", dict(companyId="A", vehicleId=None, query="", limitWithLookahead=41, offset=0)),
    ("invoices", "core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt", "loadInvoicesPage", dict(companyId="A", query="", filter="ALL", limitWithLookahead=41, offset=0)),
    ("notifications", "core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt", "loadNotificationsPage", dict(companyId="A", limitWithLookahead=41, offset=0)),
    ("company activity", "core/database/src/main/java/com/optimal/fleet/core/database/dao/AuditEventDao.kt", "loadCompanyActivityPage", dict(companyId="A", limitWithLookahead=51, offset=0)),
    ("entity activity", "core/database/src/main/java/com/optimal/fleet/core/database/dao/AuditEventDao.kt", "loadEntityActivityPage", dict(companyId="A", entityType="VEHICLE", entityId="v1", limitWithLookahead=31, offset=0)),
]
failed=[]
for name,path,method,params in cases:
    try:
        sql=extract_query(path,method)
        db.execute("EXPLAIN QUERY PLAN "+sql, params).fetchall()
        db.execute(sql, params).fetchall()
        print(f"PASS: {name} Room SQL prepares and executes")
    except Exception as exc:
        failed.append((name,str(exc)))
        print(f"FAIL: {name}: {exc}")
print(f"RESULT: {len(cases)-len(failed)}/{len(cases)}")
if failed:
    print("FAILED: "+", ".join(f"{n} ({e})" for n,e in failed), file=sys.stderr)
    sys.exit(1)
