#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    print(f"{'PASS' if condition else 'FAIL'}: {name}")

required = [
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseConfig.kt",
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseAuthSession.kt",
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/AuthSessionStore.kt",
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/AndroidKeystoreAuthSessionStore.kt",
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseNetworking.kt",
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseNetworkFactory.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/supabase/AppSupabaseConfig.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/supabase/SupabaseNetworkModule.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/SupabaseOnboardingRepository.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthApi.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OptimalOnboardingApi.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SupabaseMemberRepository.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/OptimalMembersApi.kt",
    "supabase/migrations/20260728001900_optimal_auth_membership_rls.sql",
    "docs/integrations/supabase-auth-membership-contract-v19.md",
    "supabase.properties.example",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

build = text("app/build.gradle.kts")
manifest = text("app/src/main/AndroidManifest.xml")
network = text("core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseNetworking.kt")
secure = text("core/network/src/main/java/com/optimal/fleet/core/network/supabase/AndroidKeystoreAuthSessionStore.kt")
auth_repo = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/SupabaseOnboardingRepository.kt")
auth_api = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthApi.kt")
onboarding_api = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OptimalOnboardingApi.kt")
member_repo = text("feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SupabaseMemberRepository.kt")
member_api = text("feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/OptimalMembersApi.kt")
sql = text("supabase/migrations/20260728001900_optimal_auth_membership_rls.sql")
auth_di = text("feature/auth/src/main/java/com/optimal/fleet/feature/auth/di/AuthDataModule.kt")
member_di = text("feature/settings/src/main/java/com/optimal/fleet/feature/settings/di/MemberDataModule.kt")
database = text("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")

check("versionCode 15", "versionCode = 15" in build)
check("versionName v19", 'versionName = "0.19.0-v19"' in build)
check("Room remains schema 12", "version = 12" in database)
check("internet permission declared", "android.permission.INTERNET" in manifest)
check("Supabase values injected from property or environment", all(x in build for x in ["gradleProperty(\"SUPABASE_URL\")", "environmentVariable(\"SUPABASE_URL\")", "gradleProperty(\"SUPABASE_ANON_KEY\")"]))
check("no service role in production Kotlin", not any("service_role" in p.read_text(encoding="utf-8").lower() for p in ROOT.rglob("src/main/**/*.kt")))
check("tokens encrypted with Android Keystore", all(x in secure for x in ["AndroidKeyStore", "AES/GCM/NoPadding", "KeyGenParameterSpec", "GCMParameterSpec"]))
check("access token not stored in Room", "accessToken" not in "\n".join(p.read_text(encoding="utf-8") for p in (ROOT / "core/database").rglob("*.kt")))
check("network sends apikey and bearer", all(x in network for x in ['header("apikey"', 'header("Authorization"', 'Bearer']))
check("invalid configuration fails closed", "SupabaseNotConfiguredException" in network and "supabase.invalid" in text("core/network/src/main/java/com/optimal/fleet/core/network/supabase/SupabaseNetworkFactory.kt"))
check("Supabase OTP request endpoint", '@POST("auth/v1/otp")' in auth_api)
check("Supabase OTP verify endpoint", '@POST("auth/v1/verify")' in auth_api)
check("refresh token endpoint", '@POST("auth/v1/token")' in auth_api and "refresh_token" in auth_api)
check("logout endpoint", '@POST("auth/v1/logout")' in auth_api)
check("join code validated by RPC", "optimal_validate_join_code" in onboarding_api)
check("anonymous join-code response hides phone", "normalizedPhone" not in onboarding_api.split("internal data class JoinCodeProfileDto", 1)[1].split(")", 1)[0])
check("onboarding completed by authenticated RPC", "optimal_complete_onboarding" in onboarding_api)
check("session restored against server profile", "optimal_current_member_profile" in onboarding_api and "currentMemberProfile" in auth_repo)
check("remote identity persisted transactionally", "database.withTransaction" in auth_repo and "bindRemoteIdentity" in auth_repo)
check("disabled server member clears session", "clearLocalAndRemoteSession" in auth_repo and "!profile.isActive" in auth_repo)
check("local OTP implementation removed", not (ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/InMemoryLocalOtpRepository.kt").exists())
check("local bootstrap implementation removed", not (ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomCompanyBootstrapRepository.kt").exists())
check("no debug OTP field", "debugCode" not in "\n".join(p.read_text(encoding="utf-8") for p in (ROOT / "feature/auth/src/main").rglob("*.kt")))
check("auth DI binds Supabase repository", "SupabaseOnboardingRepository" in auth_di and "OnboardingRepository" in auth_di)
check("member DI binds Supabase repository", "SupabaseMemberRepository" in member_di and "MemberRepository" in member_di)
check("client-side invite generator removed", not (ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SecureInviteCodeGenerator.kt").exists())
check("member directory RPC", "optimal_member_directory" in member_api)
check("invite creation RPC", "optimal_create_member_invite" in member_api)
check("invite resend RPC", "optimal_resend_member_invite" in member_api)
check("member activation RPC", "optimal_set_member_active" in member_api)
check("Room remains display source for members", "observeMembers" in member_repo and "observePendingInvites" in member_repo)
check("server member refresh cached in transaction", "cacheDirectory" in member_repo and "database.withTransaction" in member_repo)
check("member writes audited", ".append(" in member_repo and "MEMBER_INVITED" in member_repo and "MEMBER_DISABLED" in member_repo)
check("onboarding join audited", ".append(" in auth_repo and "MEMBER_JOINED" in auth_repo)
check("RLS enabled on all membership tables", all(f"alter table public.{table} enable row level security" in sql for table in ["optimal_companies", "optimal_members", "optimal_member_invites"]))
check("direct table writes revoked", all(f"revoke all on table public.{table} from anon, authenticated" in sql for table in ["optimal_companies", "optimal_members", "optimal_member_invites"]))
check("same-company select policies", all(x in sql for x in ["optimal_companies_select_active_member", "optimal_members_select_same_company", "optimal_invites_select_same_company"]))
check("RPCs use security definer", sql.count("security definer") >= 7)
check("RPCs pin search_path", sql.count("set search_path") >= 8)
check("invite codes are hashed", "digest(p_code, 'sha256')" in sql and "digest(v_code, 'sha256')" in sql)
check("invite is consumed once", "state = 'USED'" in sql and "for update" in sql)
check("invite expiry enforced", "expires_at <= now()" in sql and "state = 'EXPIRED'" in sql)
check("invite expiry owned by server", sql.count("now() + interval '72 hours'") == 2 and "p_expires_at_ms" not in sql)
check("invite RPC payloads match SQL signatures", "p_expires_at_ms" not in member_api and "optimal_create_member_invite(text, text)" in sql and "optimal_resend_member_invite(uuid)" in sql)
check("server member-exists error mapped", "member_exists" in member_repo and "ActiveMemberAlreadyExists" in member_repo)
check("OTP phone must match invitation", "optimal_validate_invite_phone" in sql and "invite_phone_mismatch" in sql and "normalized_phone <> v_invite.normalized_phone" in sql)
check("self-disable blocked server-side", "self_disable_blocked" in sql)
check("last active member protected server-side", "last_active_member_blocked" in sql)
check("anonymous access is limited to invite validation RPCs", all(x in sql for x in ["grant execute on function public.optimal_validate_join_code(text) to anon, authenticated", "grant execute on function public.optimal_validate_invite_phone(text, text) to anon, authenticated"]))
check("membership mutations authenticated only", all(f"grant execute on function public.{fn}" in sql and "to authenticated" in sql[sql.index(f"grant execute on function public.{fn}"):sql.index(f"grant execute on function public.{fn}")+220] for fn in ["optimal_complete_onboarding", "optimal_create_member_invite", "optimal_resend_member_invite", "optimal_set_member_active"]))
check("domain excludes Retrofit", not any(re.search(r"^import retrofit2", p.read_text(encoding="utf-8"), re.M) for p in (ROOT / "feature").rglob("domain/**/*.kt")))
check("presentation excludes Retrofit and DAO", not any(re.search(r"^import (retrofit2|androidx\.room|.*\.dao\.)", p.read_text(encoding="utf-8"), re.M) for p in (ROOT / "feature").rglob("presentation/**/*.kt")))
check("onboarding use-case tests present", (ROOT / "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingUseCasesTest.kt").is_file())
check("server-backed ViewModel flow tested", "serverBackedOnboardingCreatesSession" in text("feature/auth/src/test/java/com/optimal/fleet/feature/auth/presentation/AuthViewModelTest.kt"))
check("member refresh ViewModel wired", "RefreshMembers" in text("feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt"))
check("session gate validates remote session first", "RestoreSessionUseCase" in text("app/src/main/java/com/optimal/fleet/session/SessionGateViewModel.kt"))

passed = sum(ok for _, ok in checks)
print(f"\nRESULT: {passed}/{len(checks)} passed")
sys.exit(0 if passed == len(checks) else 1)
