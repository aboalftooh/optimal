#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${TMPDIR:-/tmp}/optimal-v30-error-harness"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

kotlinc \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorMapper.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorPresentation.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/SafeErrorReporter.kt" \
  "$ROOT_DIR/scripts/v30-error-harness.kt" \
  -include-runtime \
  -d "$BUILD_DIR/v30-error-harness.jar"

java -jar "$BUILD_DIR/v30-error-harness.jar"
