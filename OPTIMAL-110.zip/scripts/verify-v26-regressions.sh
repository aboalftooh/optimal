#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Same historical coverage as verify-v25-regressions.sh. Two-process batches keep
# compiler wall time bounded without the high contention of full parallel execution.
SCRIPTS=(
  scripts/run-v07-domain-harness.sh
  scripts/run-v10-linking-harness.sh
  scripts/run-v11-finance-harness.sh
  scripts/run-v12-audit-harness.sh
  scripts/run-v13-member-harness.sh
  scripts/run-v14-notification-harness.sh
  scripts/run-v15-domain-harness.sh
  scripts/run-v18-onboarding-harness.sh
  scripts/run-v19-domain-harness.sh
)
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR" .tmp-v*-harness' EXIT
passed_checks=0

for ((start=0; start<${#SCRIPTS[@]}; start+=2)); do
  pids=()
  names=()
  batch=()
  for ((offset=0; offset<2 && start+offset<${#SCRIPTS[@]}; offset++)); do
    script="${SCRIPTS[start+offset]}"
    name="$(basename "$script" .sh)"
    log="$TMP_DIR/$name.log"
    batch+=("$script")
    names+=("$name")
    timeout --kill-after=10s 300s "$script" >"$log" 2>&1 &
    pids+=("$!")
  done

  for ((i=0; i<${#pids[@]}; i++)); do
    script="${batch[i]}"
    name="${names[i]}"
    log="$TMP_DIR/$name.log"
    echo "===== $script ====="
    if wait "${pids[i]}"; then
      cat "$log"
      count="$(grep -c '^PASS:' "$log" || true)"
      passed_checks=$((passed_checks + count))
    else
      status=$?
      cat "$log"
      echo "FAIL: $script exited with status $status" >&2
      exit "$status"
    fi
  done
  rm -rf .tmp-v*-harness
done

if [[ "$passed_checks" -ne 140 ]]; then
  echo "FAIL: expected 140 historical assertions, got $passed_checks" >&2
  exit 1
fi

echo "V26 regression harnesses: ${passed_checks}/140 PASS"
