#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

fields = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt")
onboarding = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt")
components = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt")
account = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountRoute.kt")
summary = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthAccountContent.kt")
route = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt")
screen_content = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthScreenContent.kt")

check("canonical OTP primitive exists", "fun OptimalOtpField(" in fields)
check("OTP primitive owns six-box default", "length: Int = 6" in fields and "repeat(length)" in fields)
check("OTP primitive uses central field size", "OptimalComponentDefaults.fieldMinHeight" in fields)
check("OTP primitive uses central shape", "MaterialTheme.shapes.medium" in fields)
check("OTP primitive uses semantic branded/error colors", "OptimalSemanticColors.brandSubtle" in fields and "OptimalSemanticColors.dangerContainer" in fields)
check("OtpStep consumes canonical OTP primitive", "OptimalOtpField(" in onboarding and 'testTag = "auth-otp"' in onboarding)
check("OTP callback remains OtpChanged", "AuthUiEvent.OtpChanged(it)" in onboarding)
check("verify callback remains VerifyOtp", "AuthUiEvent.VerifyOtp" in onboarding)

for token in ["PhoneStep", "OtpStep", "JoinCodeStep", "CompanyDataStep", "SuccessStep"]:
    check(f"screen {token} still exists", f"fun {token}(" in onboarding)
check("AccountSummary still exists", "fun AccountSummary(" in summary)
check("AccountRoute still exists", "fun AccountRoute(" in account)

check("auth messages use canonical inline status", "OptimalInlineStatus(" in components and "AuthMessageBanner" in components)
check("auth loading no longer uses feature-local spinner", "CircularProgressIndicator" not in components)
check("auth loading uses canonical primary action", "OptimalPrimaryButton(" in components and '"جارٍ التنفيذ"' in components)
check("account loading uses canonical state", "OptimalLoadingState(" in account and 'testTag("account-loading")' in account)
check("account save preserves saving state", 'if (state.isSaving) "جارٍ الحفظ" else "حفظ التغييرات"' in account and "enabled = !state.isSaving" in account)
check("account messages use canonical semantic feedback", "OptimalInlineStatus(" in account and "OptimalStatusTone.Success" in account and "OptimalStatusTone.Danger" in account)
check("success screen uses semantic feedback", "AccountStatusFeedback(" in onboarding and "OptimalInlineStatus(" in components)
check("company workshop setting uses canonical row", 'OptimalListRow(\n                title = "ورشة الصيانة"' in onboarding)
check("account workshop setting uses canonical row", 'OptimalListRow(\n                title = "ورشة الصيانة"' in account)
check("account summary uses form sections and rows", "OptimalFormSection(" in summary and "OptimalListRow(" in summary)
check("account route uses form sections", account.count("OptimalFormSection(") >= 3)
check("auth route keeps screen content dispatch", "AuthScreenContent(state = state, onEvent = onEvent)" in route)
check("auth form width is centrally bounded", "OptimalContentWidth.compactMax" in route and "Alignment.TopCenter" in route)
check("account form width is centrally bounded", "OptimalContentWidth.compactMax" in account and "Alignment.TopCenter" in account)

for event in [
    "RequestOtp", "VerifyOtp", "ResendOtp", "SubmitJoinCode", "CompleteOnboarding",
    "Continue", "Restart", "Back", "SignOut",
]:
    check(f"auth event preserved: {event}", f"AuthUiEvent.{event}" in onboarding + components + summary + screen_content)

ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_99 = {*(f"SCR-{i:03d}" for i in range(1, 8)), *(f"STA-{i:03d}" for i in range(2, 8))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("all SESSION-99 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_99), str(sorted(i for i in expected_99 if statuses.get(i) != "MIGRATED")))
check("ledger migrated total is 18", sum(status == "MIGRATED" for _, status in rows) == 18)
check("ledger unmigrated total is 105", sum(status == "UNMIGRATED" for _, status in rows) == 105)
check("ledger has no blocked rows", all(status != "BLOCKED" for _, status in rows))

allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("auth feature removed from allowlist", not any(path.startswith("feature/auth/") for path in allow))
check("remaining allowlist is 58 UI files", len(allow) == 58, str(len(allow)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-99 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
