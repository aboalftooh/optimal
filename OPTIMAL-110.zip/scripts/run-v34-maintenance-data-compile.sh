#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs"/{javax/inject,com/optimal/fleet/core/database/dao/verto,com/optimal/fleet/core/database/entity/verto,com/optimal/fleet/core/database/dao,com/optimal/fleet/core/database/entity,com/optimal/fleet/core/database/model,com/optimal/fleet/core/database/sync,com/optimal/fleet/core/database/maintenance,com/optimal/fleet/core/database,com/optimal/fleet/feature/maintenance/data}
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/Database.kt" <<'KT'
package com.optimal.fleet.core.database
object DatabaseConstants { const val SYNC_PENDING = "PENDING" }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/Entities.kt" <<'KT'
package com.optimal.fleet.core.database.entity

data class MaintenanceOperationEntity(
    val id: String,
    val companyId: String,
    val vehicleId: String,
    val remoteId: String?,
    val clientGeneratedId: String,
    val type: String,
    val description: String,
    val status: String,
    val startedAtEpochMillis: Long,
    val completedAtEpochMillis: Long?,
    val odometerKm: Long?,
    val partsCostMinor: Long,
    val serviceCostMinor: Long,
    val source: String,
    val createdByUserId: String,
    val updatedByUserId: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val syncState: String,
)
data class MaintenanceFollowUpEntity(
    val id: String,
    val companyId: String,
    val vehicleId: String,
    val sourceOperationId: String,
    val reason: String,
    val dueDateEpochMillis: Long?,
    val dueOdometerKm: Long?,
    val convertedOperationId: String?,
    val createdByUserId: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val syncState: String,
)
data class MaintenanceAuditEntity(
    val id: String,
    val companyId: String,
    val operationId: String,
    val actorUserId: String,
    val action: String,
    val changedFields: String,
    val createdAtEpochMillis: Long,
    val syncState: String,
)
data class VehicleEntity(val id: String, val archivedAtEpochMillis: Long?)
data class InvoiceProjectionEntity(val invoiceNumber: String)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/model/Models.kt" <<'KT'
package com.optimal.fleet.core.database.model
class MaintenanceVehicleOptionRow
class MaintenanceOperationListRow
data class MaintenanceOperationDetailsRow(val remoteId: String?, val source: String)
class MaintenanceAuditRow
class MaintenanceFollowUpRow
enum class MaintenanceUpdateDbResult { UPDATED, NOT_FOUND, NOT_EDITABLE }
enum class MaintenanceCompletionDbResult { COMPLETED, NOT_FOUND, ALREADY_COMPLETED }
enum class FollowUpConversionDbResult { CREATED, NOT_FOUND, ALREADY_CONVERTED, VEHICLE_NOT_FOUND }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/sync/Sync.kt" <<'KT'
package com.optimal.fleet.core.database.sync
class PendingSyncOperationEntity
enum class SyncOperationType { CREATE, UPDATE, COMPLETE, CONVERT }
object LocalWriteVersion { fun next(clockMillis: Long, previousVersion: Long?): Long = maxOf(clockMillis, (previousVersion ?: -1L) + 1L) }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/dao/Daos.kt" <<'KT'
package com.optimal.fleet.core.database.dao
import com.optimal.fleet.core.database.entity.*
import com.optimal.fleet.core.database.model.*
import kotlinx.coroutines.flow.Flow
interface MaintenanceReadDao {
    fun observeVehicleOptions(companyId: String): Flow<List<MaintenanceVehicleOptionRow>>
    fun observeOperations(companyId: String): Flow<List<MaintenanceOperationListRow>>
    fun observeCompletedHistory(companyId: String): Flow<List<MaintenanceOperationListRow>>
    suspend fun loadOperationsPage(companyId: String, status: String, source: String?, type: String?, startedAtEpochMillis: Long?, query: String, limitWithLookahead: Int, offset: Int): List<MaintenanceOperationListRow>
    suspend fun loadCompletedHistoryPage(companyId: String, vehicleId: String?, query: String, limitWithLookahead: Int, offset: Int): List<MaintenanceOperationListRow>
    fun observeDetails(companyId: String, operationId: String): Flow<MaintenanceOperationDetailsRow?>
    suspend fun findById(companyId: String, operationId: String): MaintenanceOperationEntity?
}
interface MaintenanceAuditDao { fun observeForOperation(companyId: String, operationId: String): Flow<List<MaintenanceAuditRow>> }
interface InvoiceProjectionDao { fun observeByVertoInvoiceId(companyId: String, vertoInvoiceId: String): Flow<InvoiceProjectionEntity?> }
interface MaintenanceFollowUpDao {
    fun observeActive(companyId: String): Flow<List<MaintenanceFollowUpRow>>
    suspend fun findById(companyId: String, followUpId: String): MaintenanceFollowUpEntity?
}
interface VehicleDao { suspend fun findById(companyId: String, vehicleId: String): VehicleEntity? }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/verto/VertoEntities.kt" <<'KT'
package com.optimal.fleet.core.database.entity.verto

data class VertoMaintenanceProjectionEntity(
    val id: String,
    val sourceMaintenanceId: String,
    val sourceInvoiceId: String,
    val vehicleNameSnapshot: String?,
    val plateNumberSnapshot: String?,
    val driverNameSnapshot: String?,
    val description: String?,
    val odometerKm: Long?,
    val sourceStatus: String,
    val voided: Boolean,
    val completedAtEpochMillis: Long?,
)
data class VertoMaintenanceMediaEntity(
    val sourceMediaId: String,
    val attachmentId: String,
    val mimeType: String?,
    val sizeBytes: Long?,
    val position: Int,
)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/dao/verto/VertoDaos.kt" <<'KT'
package com.optimal.fleet.core.database.dao.verto
import com.optimal.fleet.core.database.entity.verto.*
import kotlinx.coroutines.flow.Flow
interface VertoMaintenanceProjectionDao {
    fun observeBySourceInvoiceId(companyId: String, sourceInvoiceId: String): Flow<VertoMaintenanceProjectionEntity?>
}
interface VertoMaintenanceMediaDao {
    fun observeForMaintenance(companyId: String, maintenanceProjectionId: String): Flow<List<VertoMaintenanceMediaEntity>>
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/maintenance/Transactions.kt" <<'KT'
package com.optimal.fleet.core.database.maintenance
import com.optimal.fleet.core.database.entity.*
import com.optimal.fleet.core.database.model.*
import com.optimal.fleet.core.database.sync.PendingSyncOperationEntity
class MaintenanceOperationTransactions {
    suspend fun insertWithSync(operation: MaintenanceOperationEntity, syncOperation: PendingSyncOperationEntity) = Unit
    suspend fun updateInProgressWithAudit(
        companyId: String, operationId: String, type: String, description: String, odometerKm: Long?,
        partsCostMinor: Long, serviceCostMinor: Long, updatedByUserId: String, updatedAtEpochMillis: Long,
        syncState: String, audit: MaintenanceAuditEntity, syncOperation: PendingSyncOperationEntity? = null,
    ): MaintenanceUpdateDbResult = MaintenanceUpdateDbResult.UPDATED
    suspend fun completeWithFollowUpAndAudit(
        companyId: String, operationId: String, description: String, completedAtEpochMillis: Long,
        odometerKm: Long?, partsCostMinor: Long, serviceCostMinor: Long, updatedByUserId: String,
        updatedAtEpochMillis: Long, syncState: String, audit: MaintenanceAuditEntity,
        followUp: MaintenanceFollowUpEntity?, syncOperations: List<PendingSyncOperationEntity> = emptyList(),
    ): MaintenanceCompletionDbResult = MaintenanceCompletionDbResult.COMPLETED
}
class MaintenanceFollowUpTransactions {
    suspend fun convertToOperation(
        companyId: String, followUpId: String, newOperation: MaintenanceOperationEntity,
        audit: MaintenanceAuditEntity, updatedAtEpochMillis: Long, syncState: String,
        syncOperations: List<PendingSyncOperationEntity> = emptyList(),
    ): FollowUpConversionDbResult = FollowUpConversionDbResult.CREATED
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/data/Adapters.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.data
import com.optimal.fleet.core.database.entity.*
import com.optimal.fleet.core.database.model.*
import com.optimal.fleet.core.database.sync.*
import com.optimal.fleet.feature.maintenance.domain.followup.MaintenanceFollowUp
import com.optimal.fleet.feature.maintenance.domain.model.*
object MaintenanceSyncOperationFactory {
    fun operation(entity: MaintenanceOperationEntity, operationType: SyncOperationType = SyncOperationType.CREATE) = PendingSyncOperationEntity()
    fun followUp(entity: MaintenanceFollowUpEntity, operationType: SyncOperationType = SyncOperationType.CREATE) = PendingSyncOperationEntity()
}
fun MaintenanceOperationEntity.toDomain(): MaintenanceOperation = error("compile stub")
fun MaintenanceVehicleOptionRow.toDomain(): OperationVehicleOption = error("compile stub")
fun MaintenanceOperationListRow.toDomain(): MaintenanceOperationSummary = error("compile stub")
fun MaintenanceOperationDetailsRow.toDomain(
    auditEvents: List<MaintenanceAuditEvent>,
    invoiceNumber: String? = null,
    officialRecord: com.optimal.fleet.feature.maintenance.domain.source.VertoOfficialMaintenanceRecord? = null,
): MaintenanceOperationDetails = error("compile stub")
fun MaintenanceAuditRow.toDomain(): MaintenanceAuditEvent = error("compile stub")
fun MaintenanceFollowUpRow.toDomain(): MaintenanceFollowUp = error("compile stub")
KT
mapfile -t DOMAIN_FILES < <(find "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain" -type f -name '*.kt' | sort)
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  $(find "$TMP_DIR/stubs" -type f -name '*.kt' | sort) \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditContracts.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/transaction/AtomicWriteTransactionRunner.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionIdentity.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "${DOMAIN_FILES[@]}" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceIdentityFactory.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceWriteAuditFactory.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceQueryRepository.kt" \
  -d "$TMP_DIR/v34-maintenance-data.jar"
echo "PASS: split maintenance repositories compile against their contracts"
echo "V34 maintenance data compilation: 1/1"
