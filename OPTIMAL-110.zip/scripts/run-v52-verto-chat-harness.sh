#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
OUT="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessage.kt \
  scripts/v52-verto-chat-harness.kt \
  -include-runtime -d "$OUT"
java -jar "$OUT"
