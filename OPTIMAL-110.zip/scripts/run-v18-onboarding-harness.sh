#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$(mktemp -d)"
trap 'rm -rf "$OUT_DIR"' EXIT
kotlinc \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt" \
  "$ROOT_DIR/scripts/v18-onboarding-harness.kt" \
  -include-runtime \
  -d "$OUT_DIR/v18-onboarding-harness.jar"
java -jar "$OUT_DIR/v18-onboarding-harness.jar"
