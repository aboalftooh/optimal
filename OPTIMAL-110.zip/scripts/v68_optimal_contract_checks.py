#!/usr/bin/env python3
"""Offline checks for the v68 BRQ/Optimal delivery.

This is intentionally a source-level gate. It does not connect to Supabase,
send SMS, create auth users, or execute SQL against any environment.
"""

from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    send = read("supabase/functions/optimal-send-phone-otp/index.ts")
    verify = read("supabase/functions/optimal-verify-phone-otp/index.ts")
    shared = read("supabase/functions/_shared/brq.ts")
    config = read("supabase/config.toml")
    migration = read("supabase/migrations/20260801090000_optimal_v68_brq_link_hardening.sql")
    readiness = read("supabase/migrations/20260728002100_optimal_backend_readiness.sql")
    auth_api = read(
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthApi.kt"
    )
    auth_remote = read(
        "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthRemoteDataSource.kt"
    )

    require("verify_jwt = false" in config, "Optimal OTP functions must not require a JWT")
    require("optimal-send-phone-otp" in config and "optimal-verify-phone-otp" in config, "function config missing")
    require("secureNumericOtp" in shared and "crypto.getRandomValues" in shared, "OTP generator is not cryptographically random")
    require("BRQSMS_API_KEY" in shared and "BRQSMS_SENDER" in shared, "BRQ secret names changed")
    require("ANDROID_SMS_RETRIEVER_HASH" in shared, "BRQ Android hash secret name changed")
    require("optimal_phone_otps" in send and "otp_hash" in send, "send function does not store the isolated OTP hash")
    require("sendBrqSms" in send and "success: true" in send, "send function is not wired to BRQ")
    require("otp_expired" in verify and "otp_attempts_exceeded" in verify, "verify expiry/attempt handling missing")
    require("eq('used', false)" in verify and "update({ used: true" in verify, "OTP is not single-use")
    require("optimal_members" in verify and "phone.optimal" in verify, "Optimal identity lookup/domain missing")
    require("autodrive" not in verify.lower(), "Optimal verify function references AutoDrive")
    require("autodrive" not in send.lower(), "Optimal send function references AutoDrive")
    require("autodrive" not in shared.lower(), "shared Optimal BRQ helper references AutoDrive")

    for endpoint in (
        'functions/v1/optimal-send-phone-otp',
        'functions/v1/optimal-verify-phone-otp',
    ):
        require(endpoint in auth_api, f"Optimal app endpoint missing: {endpoint}")
    require("auth/v1/otp" not in auth_api, "native Supabase Phone Auth OTP endpoint still present")
    require('type: String = "sms"' not in auth_api, "native SMS verify payload still present")
    require("sendOptimalOtp" in auth_remote and "verifyOptimalOtp" in auth_remote, "Optimal app does not call custom functions")

    for table in (
        "optimal_phone_otps",
        "optimal_phone_otp_attempt_log",
        "optimal_companies",
        "optimal_members",
        "optimal_verto_links",
        "optimal_verto_registration_codes",
        "optimal_backend_contracts",
    ):
        require(table in migration, f"migration does not cover {table}")
    for rpc in (
        "verto_issue_optimal_registration_code",
        "optimal_validate_verto_company_code",
        "optimal_complete_company_registration",
        "optimal_complete_onboarding",
        "optimal_current_member_profile",
        "optimal_backend_contract",
    ):
        require(rpc in migration or rpc in read("supabase/migrations/20260731004600_optimal_verto_backend_contract_gate.sql"), f"RPC missing: {rpc}")
    require("clients_organization_id_id_key" in migration, "tenant composite key missing")
    require("optimal_verto_links_verto_client_org_fkey" in migration, "cross-tenant client/org FK missing")
    require("optimal_members_one_active_phone_idx" in migration, "Optimal phone uniqueness missing")
    require("revoke all on table public.optimal_verto_registration_codes" in migration, "registration table is directly readable")
    require("security definer" in migration and "set search_path = pg_catalog, public, auth, extensions" in migration, "unsafe RPC search_path")
    require("organization_id uuid" in migration and "client_id uuid" in migration and "company_name text" in migration, "issuer response fields missing")
    require("auth_ready = false" in migration and "sync_ready = false" in migration and "verto_registration_ready = false" in migration, "readiness is not fail-closed")
    require("false," in readiness, "base backend readiness migration still promotes capabilities")

    # Verify the canonical Sudanese examples used by the BRQ contract without
    # printing any supplied phone value.
    def normalize(raw: str) -> str | None:
        digits = re.sub(r"\D", "", raw)
        if digits.startswith("00249"):
            digits = digits[2:]
        elif digits.startswith("0"):
            digits = "249" + digits[1:]
        elif len(digits) == 9:
            digits = "249" + digits
        return digits if re.fullmatch(r"249[0-9]{9}", digits) else None

    require(normalize("0912345678") == "249912345678", "local phone normalization failed")
    require(normalize("00249912345678") == "249912345678", "international phone normalization failed")
    require(normalize("123") is None, "invalid phone was accepted")

    print("PASS: v68 offline BRQ/Optimal source contract checks")
    print("PASS: custom endpoints, AutoDrive isolation, fail-closed readiness, RPC/FK/RLS declarations")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        raise SystemExit(1)
