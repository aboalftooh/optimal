#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v56-verto-audio-contract.py
python3 scripts/v56-verto-audio-harness.py
./scripts/run-v56-verto-audio-syntax-check.sh
./scripts/run-v56-verto-audio-compile-smoke.sh
./scripts/run-v36-test-syntax-check.sh

python3 scripts/v55-verto-attachment-contract.py
python3 scripts/v55-verto-attachment-harness.py
./scripts/run-v55-verto-importer-compile-smoke.sh
python3 scripts/v54-verto-text-outbox-contract.py
python3 scripts/v54-verto-text-outbox-harness.py
python3 scripts/v53-verto-message-sync-contract.py
./scripts/run-v53-verto-message-sync-harness.sh
python3 scripts/v52-verto-chat-read-model-contract.py
./scripts/run-v52-verto-chat-harness.sh
python3 scripts/v51-verto-home-entry-contract.py
python3 scripts/v49-verto-chat-permissions-contract.py
python3 scripts/v48-room-v2-contract.py
