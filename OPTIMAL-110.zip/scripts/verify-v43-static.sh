#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v43-attachment-contract.py
python3 scripts/v42-message-rpc-contract.py
python3 scripts/v41-conversation-schema-contract.py
python3 scripts/v40-registration-contract.py
python3 scripts/v39-contract-consistency.py
python3 scripts/static-architecture-check.py
python3 scripts/security-release-check.py
python3 scripts/static-v37-check.py
python3 scripts/v21-backend-contract-harness.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
