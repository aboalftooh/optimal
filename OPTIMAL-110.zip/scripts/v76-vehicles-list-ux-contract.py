#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
screen_path = root / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesScreen.kt"
components_path = root / "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesComponents.kt"
test_path = root / "feature/vehicles/src/androidTest/java/com/optimal/fleet/feature/vehicles/presentation/VehicleScreensTest.kt"
screen = screen_path.read_text()
components = components_path.read_text()
tests = test_path.read_text()
ui = screen + "\n" + components
checks = []


def check(label: str, condition: bool):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + ": " + label)


def sha256(path: str) -> str:
    return hashlib.sha256((root / path).read_bytes()).hexdigest()


protected = {
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesContract.kt": "79cc6e0c41121497fad8cf486a76132c2a62c5e033b7910ed1ef2e7efe11687e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt": "1fb69e68ec9d9a4fb19ba9950ff5b1645459033c53d0b7c1de307be8a80ea1c8",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt": "c342c80ee0231f1f6d5e2168cb8dd8a066170ca4093b00b408515a56fc9bfaad",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/navigation/VehiclesNavigation.kt": "1d40ab4412c0251852c8714db9b2f898517ee2ebf11089c2ee290ecd8056e893",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleFilter.kt": "e9e8a0b738789f60eca8efa72026fe177f2c42b02d6f68f3f03a0ef37638a629",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/LoadVehiclesPage.kt": "25c0b1138d5bf17482c8b3fb8d7f3a77ebe0ba5e0b645fa6b35648f419a76b24",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt": "55ccef40d2b60f0e974d9350d063cec27b4690939447df3308b91b9141178393",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailComponents.kt": "a480af46938b7585aa4928aaf160f2f5bbb1255ce82c5a269f124557b3df9dfa",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt": "22a79f67f294eea5ababf7adad925af00f3c40189c83b0a99e975c4e9926a87e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailDialogs.kt": "05695ff027badcd146136cb8d50f1361a3d26c1d03a0d6c06f5748633c119b90",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt": "762dbb7a8e41be672b091e2298a0997c5226929781d87ecd7cef5da616608e18",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailScreen.kt": "6d8ebaf3b0cc02186f82265881cfce3cd90484f05d186e38b4805bf260f65c8f",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailViewModel.kt": "f8fcd64282d0c8ce414a61130e7207c84fa71e5dd8ed3e056b5b43605604c589",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorComponents.kt": "8c4457268bcf292a4a0bef66d09185ad9a8232d165835f80fd9241a5767d4a69",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorContract.kt": "0d8f7e2ac8fcae26cd0a9fe2ef62cadf314b782fae66e0a1a3be29cc85c806a8",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorDialogs.kt": "40fa0cdfb8d3c1429927e51b22b0a9529bf1b6b6e4c46bf5b22134a189896e1f",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorRoute.kt": "2d0ce5841a8d421e9b58673a79ba86f42f267fd93f978fbec61567e19baa41e7",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorScreen.kt": "c28814b4cf1a921f7ffc76aff1515ecdd016afab90e10b09bb60170eb287c5b7",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorViewModel.kt": "4fb687f8dcdf6cad2dfce840b3696d69b29963e5fd6e4eca37b9732a00aeb492",
}

check("Vehicles screen exists", screen_path.is_file())
check("Vehicles components exist", components_path.is_file())
check("Vehicles UI test exists", test_path.is_file())
check("screen imports v2 search", "component.v2.OptimalSearchField" in screen)
check("screen imports v2 filter", "component.v2.OptimalFilterChip" in screen)
check("screen imports v2 loading state", "component.v2.OptimalLoadingState" in screen)
check("screen imports v2 error state", "component.v2.OptimalErrorState" in screen)
check("screen imports v2 empty state", "component.v2.OptimalEmptyState" in screen)
check("screen imports v2 primary button", "component.v2.OptimalPrimaryButton" in screen)
check("screen imports v2 secondary button", "component.v2.OptimalSecondaryButton" in screen)
check("components use v2 list row", "component.v2.OptimalListRow" in components)
check("components use v2 status badge", "component.v2.OptimalStatusBadge" in components)
check("legacy AppCard removed", "AppCard" not in ui)
check("legacy Switch filter removed", "Switch(" not in ui)
check("legacy component imports removed", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", ui) is None)
check("no direct dp literals in Vehicles List presentation", re.search(r"\b\d+(?:\.\d+)?\.dp\b", ui) is None)
check("no raw hexadecimal colors", "0xFF" not in ui)
check("content inset token used", "OptimalContentInsets.horizontal" in screen)
check("vertical inset token used", "OptimalContentInsets.vertical" in screen)
check("bottom safe token used", "OptimalContentInsets.bottomSafeContent" in screen)
check("spacing tokens used", "OptimalSpacing.medium" in screen)
check("icon size token used", "OptimalIconSize.standard" in components)
check("touch target token used", "OptimalTouchTarget.minimum" in components)
check("search event preserved", "VehiclesUiEvent.SearchChanged(it)" in screen)
check("clear search event preserved", "VehiclesUiEvent.ClearSearch" in screen)
check("search test tag preserved", 'testTag = "vehicle-search"' in screen)
check("archived filter is explicit", 'testTag("vehicles-archived-filter")' in screen)
check("archived filter reflects state", "selected = state.includeArchived" in screen)
check("archived filter toggles existing boolean", "IncludeArchivedChanged(!state.includeArchived)" in screen)
check("archived state has textual filter label", '"تشمل المؤرشفة"' in screen and '"إظهار المؤرشفة"' in screen)
check("loading state is explicit", 'testTag("vehicles-loading")' in screen)
check("error state tag preserved", 'testTag("vehicles-error")' in screen)
check("retry event preserved", "VehiclesUiEvent.Retry" in screen)
check("empty state distinguishes no vehicles", '"لا توجد سيارات"' in screen)
check("empty state distinguishes no results", '"لا توجد نتائج"' in screen)
check("empty search can be cleared", 'actionLabel = if (state.query.isBlank()) null else "مسح البحث"' in screen)
check("empty state uses vehicle icon", "Icons.Outlined.DirectionsCar" in screen)
check("decorative empty image removed", "painterResource" not in ui and "optimal_vehicle_empty" not in ui)
check("obsolete empty drawable removed", not (root / "core/designsystem/src/main/res/drawable-nodpi/optimal_vehicle_empty.png").exists())
check("vehicle list is keyed", "itemsIndexed(" in screen and "vehicle.id" in screen)
check("vehicle selection event preserved", "VehiclesUiEvent.VehicleSelected(vehicle.id)" in screen)
check("ordinary vehicle records use flat rows", "OptimalListRow(" in components)
check("vehicle row test tag preserved", 'testTag("vehicle-${vehicle.id}")' in components)
check("plate remains visible", "subtitle = vehicle.plateNumber" in components)
check("vehicle metadata remains visible", "vehicle.subtitle.takeIf" in components)
check("odometer remains visible", "vehicle.odometerLabel" in components)
check("archived status remains textual", 'text = "مؤرشفة"' in components)
check("archived status uses semantic badge", "OptimalStatusTone.Neutral" in components)
check("archived status not color-only", 'text = "مؤرشفة"' in components and "isArchived" in components)
check("load more event preserved", "VehiclesUiEvent.LoadMore" in screen)
check("load more test tag preserved", 'testTag("vehicles-load-more")' in screen)
check("load more disabled while loading", "enabled = !state.isLoadingMore" in screen)
check("add vehicle action preserved", "VehiclesUiEvent.AddVehicle" in screen)
check("add vehicle tag preserved", 'testTag("add-vehicle")' in screen)
check("add vehicle is full-width primary action", 'text = "إضافة سيارة"' in screen and ".fillMaxWidth()" in screen)
check("no DAO reach from list presentation", ".dao." not in ui and "Dao" not in ui)
check("no data implementation imports from list presentation", ".data." not in ui)
check("UI test covers archived filter", "archivedFilterDispatchesEnabledState" in tests)
check("UI test covers row selection", "vehicleRowPreservesSelectionEvent" in tests)
check("existing empty-list add test remains", "emptyListOffersAddVehicle" in tests)
check("existing detail test remains", "detailArchiveRequiresConfirmation" in tests)
check("existing editor tests remain", "editorShowsOnlyNameAndPlateAsRequired" in tests and "lowerOdometerDialogRequestsReason" in tests)

for path, expected in protected.items():
    check(f"out-of-scope/source contract unchanged: {Path(path).name}", sha256(path) == expected)

passed = sum(ok for _, ok in checks)
print(f"\nSESSION-76 static contract: {passed}/{len(checks)}")
raise SystemExit(0 if passed == len(checks) else 1)
