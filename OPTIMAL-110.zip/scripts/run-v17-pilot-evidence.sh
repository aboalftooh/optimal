#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

run() {
  local name="$1"
  shift
  echo "===== $name ====="
  "$@"
}

run "Architecture" python3 scripts/static-architecture-check.py
run "V07 completion/history/follow-up" timeout 180 ./scripts/run-v07-domain-harness.sh
run "V08 offline sync/idempotency" timeout 180 ./scripts/run-v08-sync-harness.sh
run "V09 invoice projection" timeout 180 ./scripts/run-v09-invoice-harness.sh
run "V10 invoice-maintenance linking" timeout 180 ./scripts/run-v10-linking-harness.sh
run "V11 finance" timeout 180 ./scripts/run-v11-finance-harness.sh
run "V12 audit" timeout 180 ./scripts/run-v12-audit-harness.sh
run "V13 members" timeout 180 ./scripts/run-v13-member-harness.sh
run "V14 notifications" timeout 180 ./scripts/run-v14-notification-harness.sh
run "V15 domain" timeout 180 ./scripts/run-v15-domain-harness.sh
run "V16 hardening" python3 scripts/static-v16-check.py
run "Published migrations" python3 scripts/sqlite-v16-all-published-migrations.py
run "V17 final documentation" python3 scripts/static-v17-check.py

echo "V17 pilot evidence suite: PASS"
echo "NOTE: This suite does not replace Gradle, connected Android tests, Verto transport, or manual usability pilot."
