#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v53-verto-message-sync-contract.py
./scripts/run-v53-verto-message-sync-harness.sh
./scripts/run-v53-verto-sync-syntax-check.sh
./scripts/run-v36-test-syntax-check.sh
python3 scripts/v52-verto-chat-read-model-contract.py
./scripts/run-v52-verto-chat-harness.sh
python3 scripts/v51-verto-home-entry-contract.py
./scripts/run-v51-verto-entry-harness.sh
python3 scripts/v48-room-v2-contract.py
python3 scripts/v49-verto-chat-permissions-contract.py
python3 scripts/v50-verto-permission-management-contract.py
