#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, bool(ok), detail))

build = read("app/build.gradle.kts")
check("versionCode 31", bool(re.search(r"\bversionCode\s*=\s*31\b", build)))
check("versionName v36", 'versionName = "0.36.0-v36"' in build)

shared_tools = {
    "main dispatcher rule": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/coroutine/MainDispatcherRule.kt",
    "mutable test clock": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/time/MutableTestClock.kt",
    "core fixtures": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fixture/CoreFixtures.kt",
    "sequence values": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fixture/SequenceValues.kt",
    "mutable session reader": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fake/MutableSessionReader.kt",
    "recording ports": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/fake/RecordingPorts.kt",
    "tenant repository contract": "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/contract/TenantRepositoryContract.kt",
}
for name, path in shared_tools.items():
    check(name, (ROOT / path).is_file())

core_testing_gradle = read("core/testing/build.gradle.kts")
for dependency in [":core:model", ":core:session", "junit4", "kotlinx.coroutines.test", "turbine"]:
    check(f"core testing dependency {dependency}", dependency in core_testing_gradle)

consumer_gradles = [
    "app/build.gradle.kts",
    "core/database/build.gradle.kts",
    "core/designsystem/build.gradle.kts",
    "core/network/build.gradle.kts",
    *[f"feature/{name}/build.gradle.kts" for name in ["auth", "finance", "home", "maintenance", "notifications", "settings", "vehicles"]],
]
for path in consumer_gradles:
    check(f"core testing consumed by {path.split('/')[0:2]}", 'testImplementation(project(":core:testing"))' in read(path), path)

viewmodel_tests = list((ROOT / "app/src/test").rglob("*ViewModelTest.kt"))
for feature in (ROOT / "feature").iterdir():
    test_dir = feature / "src/test"
    if test_dir.exists():
        viewmodel_tests.extend(test_dir.rglob("*ViewModelTest.kt"))
shared_rule_users = [p for p in viewmodel_tests if "MainDispatcherRule" in p.read_text(encoding="utf-8")]
check("shared dispatcher used broadly", len(shared_rule_users) >= 11, str(len(shared_rule_users)))
manual_main = []
for path in viewmodel_tests:
    text = path.read_text(encoding="utf-8")
    if "Dispatchers.setMain" in text or "Dispatchers.resetMain" in text:
        manual_main.append(str(path.relative_to(ROOT)))
check("manual Main dispatcher setup removed", not manual_main, ", ".join(manual_main))

check("vehicle repository contract", (ROOT / "feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryContractTest.kt").is_file())
vehicle_fake = read("feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryTest.kt")
check("vehicle fake matches current DAO", "override suspend fun markRemoteSyncSucceeded" in vehicle_fake)
check("auth process death contract", (ROOT / "feature/auth/src/test/java/com/optimal/fleet/feature/auth/data/ProcessDeathRepositoryContractTest.kt").is_file())
auth_contract = read("feature/auth/src/test/java/com/optimal/fleet/feature/auth/data/ProcessDeathRepositoryContractTest.kt")
for token in ["otpPendingFlowSurvivesRepositoryRecreationWithoutOtpValue", "expiredFlowIsDiscardedAfterProcessRecreation", "malformedOtpPendingFlowIsDiscarded", "verifiedFlowRequiresPersistedAuthSession"]:
    check(f"auth edge {token}", token in auth_contract)

risk_tests = {
    "atomic write rollback": "core/database/src/androidTest/java/com/optimal/fleet/core/database/AtomicWriteRollbackV28Test.kt",
    "sync lease ownership": "core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncLeaseOwnershipV29Test.kt",
    "company isolation matrix": "core/database/src/androidTest/java/com/optimal/fleet/core/database/CompanyIsolationMatrixTest.kt",
}
for name, path in risk_tests.items():
    check(name, (ROOT / path).is_file())

backend_harness = read("scripts/v21-backend-contract-harness.py")
check("backend harness reads migrations", 'MIGRATIONS = ROOT / "supabase" / "migrations"' in backend_harness)
check("backend harness no in-memory ingestion model", "class IngestionModel" not in backend_harness)
for token in ["enable row level security", "optimal_member_has_capability", "source_updated_at", "set search_path", "revoke all"]:
    check(f"backend SQL contract {token}", token in backend_harness)

v19_runner = read("scripts/run-v19-domain-harness.sh")
for use_case in ["RestoreSessionUseCase.kt", "RestorePendingOnboardingUseCase.kt", "DiscardPendingOnboardingUseCase.kt", "SignOutUseCase.kt"]:
    check(f"v19 harness current {use_case}", use_case in v19_runner)

check("shared app smoke robot", (ROOT / "app/src/androidTest/java/com/optimal/fleet/AppTestRobot.kt").is_file())
for path in ["app/src/androidTest/java/com/optimal/fleet/ComposeSmokeTest.kt", "app/src/androidTest/java/com/optimal/fleet/NavigationGraphTest.kt"]:
    text = read(path)
    check(f"smoke uses robot {Path(path).name}", "AppTestRobot(composeRule).ensureSignedIn()" in text)
    check(f"smoke duplicate helper removed {Path(path).name}", "private fun ensureSignedIn" not in text)

catalog = read("gradle/libs.versions.toml")
root_gradle = read("build.gradle.kts")
check("Kover catalog plugin", 'kover = { id = "org.jetbrains.kotlinx.kover"' in catalog)
check("Kover root aggregation", 'alias(libs.plugins.kover)' in root_gradle and 'kover(project(":app"))' in root_gradle)
for threshold in ["minBound(75)", "minBound(90)", "minBound(80)"]:
    check(f"Kover threshold {threshold}", threshold in root_gradle)
for exclusion in ["*.BuildConfig", "*.*_Factory", "*.ComposableSingletons$*", "*.presentation.*ScreenKt"]:
    check(f"Kover exclusion {exclusion}", exclusion in root_gradle)

for script in [
    "run-v36-testing-harness.sh", "run-v36-auth-process-death-harness.sh", "run-v36-vehicle-contract-harness.sh", "run-v36-test-syntax-check.sh",
    "verify-v36-static.sh", "verify-v36-regressions.sh",
]:
    check(f"v36 gate {script}", (ROOT / "scripts" / script).is_file())

for path in [
    "README.md", "AGENTS.md", "docs/sessions/v36.md", "docs/verifications/verification-v36.md",
    "verification-v36.md", "PATCH_MANIFEST-v36.md", "CHANGED_FILES-v36.txt", "DELETED_FILES-v36.txt",
]:
    check(f"delivery {path}", (ROOT / path).is_file())

failed = [(name, detail) for name, ok, detail in checks if not ok]
for name, ok, detail in checks:
    suffix = f" ({detail})" if detail and not ok else ""
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)}")
if failed:
    print("FAILED: " + ", ".join(name for name, _ in failed), file=sys.stderr)
    sys.exit(1)
