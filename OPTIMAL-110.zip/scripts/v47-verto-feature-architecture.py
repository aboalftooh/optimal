#!/usr/bin/env python3
"""Static architecture gate for the OPTIMAL v47 Verto feature module."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "feature/verto"
PACKAGE = MODULE / "src/main/java/com/optimal/fleet/feature/verto"

checks: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.is_file() else ""


required_files = [
    MODULE / "build.gradle.kts",
    MODULE / "consumer-rules.pro",
    MODULE / "src/main/AndroidManifest.xml",
    MODULE / "README.md",
    PACKAGE / "domain/model/VertoLinkState.kt",
    PACKAGE / "domain/model/VertoMessage.kt",
    PACKAGE / "domain/repository/VertoConversationRepository.kt",
    PACKAGE / "presentation/VertoEntryContract.kt",
    PACKAGE / "navigation/VertoNavigationContract.kt",
    PACKAGE / "data/README.md",
    PACKAGE / "di/README.md",
    MODULE / "src/test/java/com/optimal/fleet/feature/verto/VertoFeatureArchitectureTest.kt",
]
for path in required_files:
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())

for layer in ("domain", "data", "presentation", "navigation", "di"):
    check(f"layer:{layer}", (PACKAGE / layer).is_dir())

settings = read(ROOT / "settings.gradle.kts")
app_build = read(ROOT / "app/build.gradle.kts")
root_build = read(ROOT / "build.gradle.kts")
module_build = read(MODULE / "build.gradle.kts")
static_arch = read(ROOT / "scripts/static-architecture-check.py")

check("settings:module-declared-once", settings.count('include(":feature:verto")') == 1)
check("app:composition-root-depends-on-verto", 'project(":feature:verto")' in app_build)
check("kover:includes-verto", '":feature:verto"' in root_build)
check("static-architecture:expects-verto", '":feature:verto"' in static_arch)
check("gradle:android-library", 'id("optimal.android.library")' in module_build)
check("gradle:namespace", 'namespace = "com.optimal.fleet.feature.verto"' in module_build)

project_dependencies = set(re.findall(r'project\("(:[^"]+)"\)', module_build))
allowed_dependencies = {
    ":core:model",
    ":core:common",
    ":core:session",
    ":core:designsystem",
    ":core:database",
    ":core:network",
    ":core:testing",
}
check(
    "gradle:no-feature-dependency",
    not any(dependency.startswith(":feature:") for dependency in project_dependencies),
    ", ".join(sorted(project_dependencies)),
)
check(
    "gradle:only-approved-project-dependencies",
    project_dependencies <= allowed_dependencies,
    ", ".join(sorted(project_dependencies - allowed_dependencies)),
)
check("gradle:no-room", "libs.room" not in module_build)
check("gradle:no-retrofit", "libs.retrofit" not in module_build)
check("gradle:no-supabase", "supabase" not in module_build.lower())
check(
    "gradle:hilt-only-with-runtime-adapter",
    ("libs.plugins.hilt" not in module_build)
    or (PACKAGE / "data/access/RoomVertoChatAuthorization.kt").is_file(),
)

production_files = sorted(
    path
    for path in MODULE.rglob("*.kt")
    if "/src/main/" in path.as_posix()
)
check("source:production-kotlin-present", bool(production_files))

cross_feature_imports: list[str] = []
domain_banned_imports: list[str] = []
presentation_banned_imports: list[str] = []
navigation_banned_imports: list[str] = []
for path in production_files:
    content = read(path)
    imports = re.findall(r"^import\s+([^\s]+)", content, re.M)
    relative = str(path.relative_to(ROOT))
    for imported in imports:
        if imported.startswith("com.optimal.fleet.feature.") and not imported.startswith(
            "com.optimal.fleet.feature.verto.",
        ):
            cross_feature_imports.append(f"{relative} -> {imported}")
        if "/domain/" in path.as_posix() and imported.startswith(
            (
                "android.",
                "androidx.",
                "retrofit2.",
                "okhttp3.",
                "kotlinx.serialization.",
                "com.optimal.fleet.core.database.",
                "com.optimal.fleet.core.network.",
                "io.github.jan.supabase.",
            ),
        ):
            domain_banned_imports.append(f"{relative} -> {imported}")
        if "/presentation/" in path.as_posix() and (
            imported.startswith(
                (
                    "androidx.room.",
                    "retrofit2.",
                    "okhttp3.",
                    "com.optimal.fleet.core.database.",
                    "com.optimal.fleet.core.network.",
                    "io.github.jan.supabase.",
                ),
            )
            or ".data." in imported
        ):
            presentation_banned_imports.append(f"{relative} -> {imported}")
        if "/navigation/" in path.as_posix() and imported.startswith(
            ("com.optimal.fleet.", "android.", "androidx.room.", "io.github.jan.supabase."),
        ) and not imported.startswith("com.optimal.fleet.feature.verto."):
            navigation_banned_imports.append(f"{relative} -> {imported}")

check("source:no-cross-feature-imports", not cross_feature_imports, "; ".join(cross_feature_imports))
check("domain:pure", not domain_banned_imports, "; ".join(domain_banned_imports))
check("presentation:no-data-or-infrastructure", not presentation_banned_imports, "; ".join(presentation_banned_imports))
check("navigation:contract-is-independent", not navigation_banned_imports, "; ".join(navigation_banned_imports))

production_text = "\n".join(read(path) for path in production_files)
check("domain:owns-link-state", "data class VertoLinkState" in production_text)
check("domain:owns-message-model", "data class VertoMessage" in production_text)
check("domain:owns-conversation-contract", "interface VertoConversationRepository" in production_text)
check("presentation:owns-entry-contract", "VertoEntryUiState" in production_text and "VertoEntryUiEvent" in production_text)
check("navigation:owns-destination", "object VertoDestination" in production_text and "interface VertoNavigator" in production_text)
check(
    "source:no-placeholder-code",
    not re.search(r"\b(TODO|FIXME|NotImplementedError)\b|TODO\(", production_text),
)

# Ownership checks protect the decisions fixed in v39 and the v47 plan.
auth_api = read(
    ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OptimalOnboardingApi.kt",
)
check("ownership:registration-remains-auth", "optimal_validate_verto_company_code" in auth_api)
check(
    "ownership:finance-remains-finance",
    (
        ROOT
        / "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/VertoInvoiceSource.kt"
    ).is_file(),
)
check(
    "ownership:maintenance-remains-maintenance",
    (
        ROOT
        / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/importing/MaintenanceImportPort.kt"
    ).is_file(),
)
coordinator_path = (
    ROOT
    / "app/src/main/java/com/optimal/fleet/coordinator/verto/VertoInvoiceMaintenanceCoordinator.kt"
)
coordinator = read(coordinator_path)
auto_import_coordinator_path = (
    ROOT
    / "app/src/main/java/com/optimal/fleet/coordinator/verto/VertoMaintenanceAutoImportCoordinator.kt"
)
auto_import_coordinator = read(auto_import_coordinator_path)
check("ownership:cross-domain-coordinator-remains-app", coordinator_path.is_file() and auto_import_coordinator_path.is_file())
check(
    "ownership:coordinator-uses-domain-ports",
    "FinanceProjectionPort" in coordinator
    and all(
        token in auto_import_coordinator
        for token in ("FinanceProjectionPort", "MaintenanceImportPort", "VehicleMatcherPort")
    ),
)
check(
    "ownership:coordinator-has-no-data-access",
    all(
        ".data." not in source and "Dao" not in source and "OptimalDatabase" not in source
        for source in (coordinator, auto_import_coordinator)
    ),
)

# Full project graph checks: no feature-to-feature Gradle edge and no cycle.
module_names = re.findall(r'include\("(:[^"]+)"\)', settings)
graph: dict[str, set[str]] = {module: set() for module in module_names}
for module in module_names:
    build = ROOT / module.strip(":").replace(":", "/") / "build.gradle.kts"
    if build.is_file():
        graph[module] = set(re.findall(r'project\("(:[^"]+)"\)', read(build)))
feature_edges = [
    f"{module}->{dependency}"
    for module, dependencies in graph.items()
    if module.startswith(":feature:")
    for dependency in sorted(dependencies)
    if dependency.startswith(":feature:")
]
check("graph:no-feature-to-feature-edge", not feature_edges, ", ".join(feature_edges))


def has_cycle() -> bool:
    visiting: set[str] = set()
    complete: set[str] = set()

    def visit(node: str) -> bool:
        if node in visiting:
            return True
        if node in complete:
            return False
        visiting.add(node)
        for dependency in graph.get(node, set()):
            if dependency in graph and visit(dependency):
                return True
        visiting.remove(node)
        complete.add(node)
        return False

    return any(visit(node) for node in graph)


check("graph:acyclic", not has_cycle())

for name, passed, detail in checks:
    status = "PASS" if passed else "FAIL"
    print(f"{status}: {name}" + (f" — {detail}" if detail and not passed else ""))

passed_count = sum(1 for _, passed, _ in checks if passed)
print(f"\nV47 architecture checks: {passed_count}/{len(checks)}")
sys.exit(0 if passed_count == len(checks) else 1)
