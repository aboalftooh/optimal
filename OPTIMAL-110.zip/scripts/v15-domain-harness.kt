import com.optimal.fleet.core.common.analytics.*
import com.optimal.fleet.feature.finance.domain.invoice.model.InvoiceProjection
import com.optimal.fleet.feature.finance.domain.invoice.query.InvoiceListFilter
import com.optimal.fleet.feature.finance.domain.invoice.query.filterInvoices

private var passed = 0
private fun check(name: String, condition: Boolean) {
    if (!condition) error("FAIL: $name")
    passed += 1
    println("PASS: $name")
}

fun main() {
    val invoices = listOf(
        invoice("a", "100", remaining = 0, needsLink = false),
        invoice("b", "200", remaining = 500, needsLink = true),
        invoice("c", "300", remaining = 100, needsLink = false, voided = true),
    )
    check("search by number", filterInvoices(invoices, "200", InvoiceListFilter.ALL).map { it.id } == listOf("b"))
    check("needs link", filterInvoices(invoices, "", InvoiceListFilter.NEEDS_LINK).map { it.id } == listOf("b"))
    check("paid", filterInvoices(invoices, "", InvoiceListFilter.PAID).map { it.id } == listOf("a"))
    check("outstanding excludes voided", filterInvoices(invoices, "", InvoiceListFilter.OUTSTANDING).map { it.id } == listOf("b"))
    check("voided", filterInvoices(invoices, "", InvoiceListFilter.VOIDED).map { it.id } == listOf("c"))
    check("stable order", filterInvoices(invoices, "", InvoiceListFilter.ALL).map { it.id } == listOf("a", "b", "c"))
    check("analytics screen enum", AnalyticsEvent.ScreenViewed(AnalyticsScreen.HOME).screen == AnalyticsScreen.HOME)
    check("analytics search contains boolean only", AnalyticsEvent.SearchStateChanged(AnalyticsScreen.VEHICLES, true).hasQuery)
    check("analytics action typed", AnalyticsEvent.PrimaryAction(AnalyticsScreen.HOME, AnalyticsAction.ADD_OPERATION).action == AnalyticsAction.ADD_OPERATION)
    check("analytics item typed", AnalyticsEvent.ItemOpened(AnalyticsScreen.HOME, AnalyticsItemType.INVOICE).itemType == AnalyticsItemType.INVOICE)
    println("RESULT: $passed/10 passed")
}

private fun invoice(id: String, number: String, remaining: Long, needsLink: Boolean, voided: Boolean = false) =
    InvoiceProjection(
        id, id, "org", "client", number, "SALE", null, "قطع", 1_000, 0,
        remaining, null, null, "OPEN", voided, 1, 1, 1, needsLink,
    )
