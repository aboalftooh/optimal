#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/.tmp-v15-harness"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/core/common/src/main/kotlin/com/optimal/fleet/core/common/analytics/AnalyticsEvent.kt" \
  "$ROOT/core/common/src/main/kotlin/com/optimal/fleet/core/common/analytics/AnalyticsTracker.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjection.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/query/InvoiceSearch.kt" \
  "$ROOT/scripts/v15-domain-harness.kt" \
  -include-runtime -d "$OUT/v15-harness.jar"
java -jar "$OUT/v15-harness.jar"
rm -rf "$OUT"
