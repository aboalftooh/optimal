#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v39 documentation-only session."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ADR = ROOT / "docs/adr/ADR-verto-integration-v23.md"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
MATRIX = ROOT / "docs/integrations/verto-contract-matrix-v23.md"
SETTINGS = ROOT / "settings.gradle.kts"
APP_GRADLE = ROOT / "app/build.gradle.kts"
MIGRATIONS = ROOT / "supabase/migrations"

checks: list[tuple[str, bool]] = []

def check(name: str, condition: bool) -> None:
    checks.append((name, condition))


def contains_all(text: str, values: list[str]) -> bool:
    return all(value in text for value in values)

for file in (ADR, CONTRACT, MATRIX):
    check(f"exists:{file.relative_to(ROOT)}", file.is_file())

if not all(file.is_file() for file in (ADR, CONTRACT, MATRIX)):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

adr = ADR.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
matrix = MATRIX.read_text(encoding="utf-8")
settings = SETTINGS.read_text(encoding="utf-8")
app_gradle = APP_GRADLE.read_text(encoding="utf-8")
all_docs = "\n".join((adr, contract, matrix))

check("adr:accepted", "**الحالة:** Accepted" in adr)
check("adr:financial-source", "Verto هو مصدر الحقيقة" in adr)
check("adr:single-conversation", "محادثة واحدة" in adr and "link_id" in adr)
check("adr:auth-derived", "auth.uid()" in adr)
check("adr:no-service-role-android", "service_role" in adr and "Android" in adr)
check("adr:owner-manager-default", contains_all(adr, ["OWNER", "MANAGER", "VIEW_VERTO_CHAT", "SEND_VERTO_CHAT"]))
check("adr:home-entry", "بطاقة في الشاشة الرئيسية" in adr and "Bottom Navigation" in adr)
check("adr:legacy-read-only", "الروابط اليدوية القديمة" in adr and "قابلة للقراءة" in adr)
check("adr:no-manual-vehicle", "لا ينشئ سيارة" in adr and "مكتوبة يدويًا" in adr)
check("adr:feature-boundaries", contains_all(adr, [":feature:verto", ":feature:finance", ":feature:maintenance", "Coordinator"]))

cursor_tokens = [
    "(server_created_at, message_id)",
    "(source_updated_at, invoice_id)",
    "(source_updated_at, maintenance_id)",
    "CURSOR_INVALID",
]
check("contract:cursors-complete", contains_all(all_docs, cursor_tokens))

message_states = ["PENDING", "SENDING", "SENT", "FAILED_RETRYABLE", "FAILED_TERMINAL"]
attachment_states = [
    "LOCAL_READY", "UPLOADING", "UPLOADED", "FINALIZING", "READY",
    "LOCAL_MISSING", "PENDING_UPLOAD", "REJECTED", "ABANDONED",
]
check("contract:message-states", contains_all(adr, message_states))
check("contract:attachment-states", contains_all(adr, attachment_states))
check("contract:message-types", contains_all(all_docs, ["TEXT", "IMAGE", "VIDEO", "AUDIO", "DOCUMENT"]))
check("contract:sender-sides", contains_all(all_docs, ["OPTIMAL", "VERTO"]))
check("contract:idempotency", contains_all(all_docs, ["client_message_id", "idempotency_key", "IDEMPOTENCY_CONFLICT"]))
check("contract:per-user-state", contains_all(all_docs, ["optimal_verto_message_receipts", "optimal_verto_conversation_states", "user_id"]))
check("contract:private-storage", contains_all(all_docs, ["Bucket خاص", "object_path", "signed_url", "expires_at"]))
check("contract:v22-compat", contains_all(contract, ["optimal_verto_invoice_feed", "v22", "v23 RPCs بأسماء جديدة"]))
check("contract:v23-not-yet-published", "العقد المنشور حاليًا في المصدر:** `22`" in contract)
check("contract:financial-read-only", "لا توجد كتابة مالية" in adr)
check("contract:currency", contains_all(contract, ["currency_code", "SDG", "Decimal string", "HALF_UP"]))
check("contract:v23-no-manual-link", contains_all(contract, ["contract_version", "requires_vehicle_link", "false"]))
check("contract:official-maintenance-only", "لا يعاد أي سجل بلا `optimal_vehicle_remote_id`" in contract)
check("contract:no-hardcoded-unpublished-limits", "الحدود المنشورة" in contract and "لا يثبت Android رقمًا" in adr)

rpcs = [
    "optimal_verto_link_state",
    "optimal_verto_message_feed",
    "optimal_verto_send_message",
    "optimal_verto_mark_messages_read",
    "optimal_verto_set_conversation_archived",
    "optimal_verto_begin_attachment",
    "optimal_verto_finalize_attachment",
    "optimal_verto_attachment_access",
    "optimal_verto_invoice_feed_v23",
    "optimal_verto_maintenance_feed_v23",
]
for rpc in rpcs:
    check(f"rpc:{rpc}", rpc in contract and rpc in matrix)

dtos = [
    "VertoLinkStateDto", "VertoMessageDto", "VertoAttachmentDto",
    "VertoAttachmentUploadDto", "VertoInvoiceEnvelopeDto", "VertoInvoiceItemDto",
    "VertoMaintenanceDto", "VertoMaintenanceMediaDto",
]
for dto in dtos:
    check(f"dto:{dto}", dto in contract and dto in matrix)

room_entities = [
    "VertoConversationEntity", "VertoMessageEntity", "VertoAttachmentEntity",
    "VertoConversationUserStateEntity", "VertoRemoteCursorEntity",
    "InvoiceProjectionEntity", "VertoInvoiceItemEntity",
    "VertoMaintenanceProjectionEntity", "VertoMaintenanceMediaEntity",
]
for entity in room_entities:
    check(f"room:{entity}", entity in matrix)

# Session v39 was documentation-only; later sessions may add the module.
SESSION_V39 = ROOT / "docs/sessions/v39.md"
session_v39 = SESSION_V39.read_text(encoding="utf-8") if SESSION_V39.is_file() else ""
check("scope:v39-documented-no-feature-change", "لم يضف" in session_v39 and "feature:verto" in session_v39)
check("scope:app-version-unchanged", 'versionCode = 32' in app_gradle and 'versionName = "0.37.0-v37"' in app_gradle)
new_v23_migrations = [p for p in MIGRATIONS.glob("*.sql") if "v23" in p.name.lower() or "verto_chat" in p.name.lower()]
approved_later_v23_migrations = {
    "20260731004400_optimal_verto_invoice_feed_v23.sql",
    "20260731004500_optimal_verto_maintenance_feed_v23.sql",
    "20260731004900_optimal_verto_chat_permissions.sql",
}
check("scope:no-v23-migration", all(p.name in approved_later_v23_migrations for p in new_v23_migrations))

# Existing feature modules must not depend directly on another feature module.
feature_gradles = list((ROOT / "feature").glob("*/build.gradle.kts"))
violations: list[str] = []
for gradle in feature_gradles:
    content = gradle.read_text(encoding="utf-8")
    for target in re.findall(r'project\("(:feature:[^"]+)"\)', content):
        violations.append(f"{gradle.parent.name}->{target}")
check("architecture:no-feature-to-feature-dependency", not violations)

passed = sum(ok for _, ok in checks)
failed = [(name, ok) for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
print(f"RESULT {passed}/{len(checks)}")
if violations:
    print("VIOLATIONS", ", ".join(violations))
if failed:
    sys.exit(1)
