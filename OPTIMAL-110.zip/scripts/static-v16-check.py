#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


manifest = read("app/src/main/AndroidManifest.xml")
network = read("app/src/main/res/xml/network_security_config.xml")
backup = read("app/src/main/res/xml/backup_rules.xml")
extraction = read("app/src/main/res/xml/data_extraction_rules.xml")
app_build = read("app/build.gradle.kts")
proguard = read("app/proguard-rules.pro")
application = read("app/src/main/java/com/optimal/fleet/OptimalApplication.kt")
strict_mode = read("app/src/main/java/com/optimal/fleet/security/AppStrictMode.kt")
sync_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt")
sync_monitor = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncQueueMonitor.kt")
sync_status = read("app/src/main/java/com/optimal/fleet/sync/SyncStatusViewModel.kt")
member_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/MemberDao.kt")
invoice_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
migrations = read("core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt")

check("backup disabled", 'android:allowBackup="false"' in manifest)
check("cleartext disabled in manifest", 'android:usesCleartextTraffic="false"' in manifest)
check("network security config wired", 'android:networkSecurityConfig="@xml/network_security_config"' in manifest)
check("data extraction rules wired", 'android:dataExtractionRules="@xml/data_extraction_rules"' in manifest)
check("full backup rules wired", 'android:fullBackupContent="@xml/backup_rules"' in manifest)
check("network config rejects cleartext", 'cleartextTrafficPermitted="false"' in network)
check("network config trusts system CA", '<certificates src="system"' in network)
check("network config rejects user CA", 'src="user"' not in network)
check("database excluded from legacy backup", 'domain="database" path="."' in backup)
check("database excluded from device transfer", 'domain="database" path="."' in extraction)

check("release not debuggable", "isDebuggable = false" in app_build)
check("release minification enabled", "isMinifyEnabled = true" in app_build)
check("release resource shrinking enabled", "isShrinkResources = true" in app_build)
check("release version v16 or later", bool(re.search(r'versionName\s*=\s*\"0\.(?:1[6-9]|[2-9]\d)\.[^\"]+\"', app_build)))
version_code = int(re.search(r'versionCode\s*=\s*(\d+)', app_build).group(1))
check("release version code 12 or later", version_code >= 12)
check("R8 has no broad dontwarn", "-dontwarn **" not in proguard and "-ignorewarnings" not in proguard)
check("R8 strips source metadata", "!SourceFile" in proguard and "!LineNumberTable" in proguard)

check("strict mode installed from application", "AppStrictMode.install(BuildConfig.DEBUG)" in application)
check("strict mode guarded by debuggable", "if (!debuggable) return" in strict_mode)
check("strict mode detects thread violations", "detectAll()" in strict_mode)
check("strict mode logs VM leaks", "detectLeakedClosableObjects()" in strict_mode)

for method in ("claim", "markSucceeded", "markRetry", "markPermanentFailure"):
    signature = re.search(rf"suspend fun {method}\([\s\S]*?\):", sync_dao)
    check(f"sync {method} receives companyId", signature is not None and "companyId: String" in signature.group(0))
check("sync mutation SQL scopes company", sync_dao.count("AND companyId = :companyId") >= 4)
check("sync UI summary requires company", "observeSummary(companyId: String)" in sync_monitor)
check("sync UI uses active company", "queueMonitor.observeSummary(it.companyId)" in sync_status)
check("sync backend stays disabled", 'buildConfigField("boolean", "SYNC_ENABLED", "false")' in app_build)

check("invite use mutation scoped", "markInviteUsed(companyId: String" in member_dao)
check("invite expiry mutation scoped", "markInviteExpired(companyId: String" in member_dao)
check("invite SQL company predicate", member_dao.count("companyId = :companyId") >= 10)
check("invoice raw Update removed", "@Update" not in invoice_dao)
check("invoice update explicitly scoped", "WHERE id = :invoice.id AND companyId = :invoice.companyId" in invoice_dao)

check("Room version remains 12", "version = 12" in database)
for version in range(1, 12):
    check(f"migration {version}->{version + 1} declared", f"MIGRATION_{version}_{version + 1}" in migrations)
check("migration suite added", (ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/AllPublishedMigrationsTest.kt").is_file())
check("company isolation integration test added", (ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/CompanyIsolationIntegrationTest.kt").is_file())
check("published migration executable added", (ROOT / "scripts/sqlite-v16-all-published-migrations.py").is_file())

production_roots = [ROOT / "app/src/main", ROOT / "core", ROOT / "feature"]
markers: list[str] = []
secret_hits: list[str] = []
secret_patterns = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"(?i)(?:api[_-]?key|secret|password|access[_-]?token)\s*[=:]\s*[\"'][^\"']{8,}"),
    re.compile(r"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
]
for root in production_roots:
    if not root.exists():
        continue
    for path in root.rglob("*"):
        if not path.is_file() or any(part in {"build", ".gradle"} for part in path.parts):
            continue
        if path.suffix.lower() not in {".kt", ".xml", ".kts", ".properties", ".json"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"\b(?:TODO|FIXME|HACK)\b", text):
            markers.append(str(path.relative_to(ROOT)))
        if any(pattern.search(text) for pattern in secret_patterns):
            secret_hits.append(str(path.relative_to(ROOT)))
check("no production TODO markers", not markers, ", ".join(markers))
check("no embedded secrets", not secret_hits, ", ".join(secret_hits))

for relative in (
    "app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt",
    "app/src/main/java/com/optimal/fleet/work/FollowUpNotificationWorker.kt",
):
    worker = read(relative)
    check(f"{Path(relative).name} preserves cancellation", "catch (cancelled: CancellationException)" in worker and "throw cancelled" in worker)
    check(f"{Path(relative).name} retries ordinary failures", "catch (_: Exception)" in worker and "Result.retry()" in worker)

for name, passed, detail in checks:
    suffix = f" — {detail}" if detail and not passed else ""
    print(f"{'PASS' if passed else 'FAIL'}: {name}{suffix}")
passed = sum(1 for _, ok, _ in checks if ok)
print(f"RESULT: {passed}/{len(checks)} passed")
sys.exit(0 if passed == len(checks) else 1)
