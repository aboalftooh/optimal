import com.optimal.fleet.feature.notifications.domain.NotificationEventPolicy
import com.optimal.fleet.feature.notifications.domain.NotificationType

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

fun main() {
    val start = 1_000_000L
    val end = start + 86_400_000L
    verify("future follow-up ignored", NotificationEventPolicy.followUpType(end + 1, null, null, start, end) == null)
    verify("today follow-up due", NotificationEventPolicy.followUpType(start + 100, null, null, start, end) == NotificationType.FOLLOW_UP_DUE)
    verify("past date overdue", NotificationEventPolicy.followUpType(start - 1, null, null, start, end) == NotificationType.FOLLOW_UP_OVERDUE)
    verify("odometer equality due", NotificationEventPolicy.followUpType(null, 5000, 5000, start, end) == NotificationType.FOLLOW_UP_DUE)
    verify("odometer exceeded overdue", NotificationEventPolicy.followUpType(null, 5000, 5001, start, end) == NotificationType.FOLLOW_UP_OVERDUE)
    verify("odometer before target ignored", NotificationEventPolicy.followUpType(null, 5000, 4999, start, end) == null)
    verify("overdue wins over due", NotificationEventPolicy.followUpType(start + 100, 5000, 5001, start, end) == NotificationType.FOLLOW_UP_OVERDUE)
    verify("due key stable", NotificationEventPolicy.followUpKey("f1", NotificationType.FOLLOW_UP_DUE) == "follow-up:f1:due")
    verify("overdue key stable", NotificationEventPolicy.followUpKey("f1", NotificationType.FOLLOW_UP_OVERDUE) == "follow-up:f1:overdue")
    verify("due and overdue keys differ", NotificationEventPolicy.followUpKey("f1", NotificationType.FOLLOW_UP_DUE) != NotificationEventPolicy.followUpKey("f1", NotificationType.FOLLOW_UP_OVERDUE))
    verify("invoice new key", NotificationEventPolicy.invoiceNewKey("i1") == "invoice:i1:new")
    verify("invoice link key", NotificationEventPolicy.invoiceRequiresLinkKey("i1") == "invoice:i1:requires-link")
    verify("invoice event keys differ", NotificationEventPolicy.invoiceNewKey("i1") != NotificationEventPolicy.invoiceRequiresLinkKey("i1"))
    verify("sync failure key", NotificationEventPolicy.syncFailedKey("s1") == "sync:s1:failed")
    verify("different follow-ups differ", NotificationEventPolicy.followUpKey("f1", NotificationType.FOLLOW_UP_DUE) != NotificationEventPolicy.followUpKey("f2", NotificationType.FOLLOW_UP_DUE))
    verify("different invoices differ", NotificationEventPolicy.invoiceNewKey("i1") != NotificationEventPolicy.invoiceNewKey("i2"))
    verify("boundary before end is due", NotificationEventPolicy.followUpType(end - 1, null, null, start, end) == NotificationType.FOLLOW_UP_DUE)
    verify("end boundary excluded", NotificationEventPolicy.followUpType(end, null, null, start, end) == null)
    verify("start boundary is due", NotificationEventPolicy.followUpType(start, null, null, start, end) == NotificationType.FOLLOW_UP_DUE)
    verify("one millisecond before start overdue", NotificationEventPolicy.followUpType(start - 1, null, null, start, end) == NotificationType.FOLLOW_UP_OVERDUE)
    println("RESULT: $checks/$checks passed")
}
