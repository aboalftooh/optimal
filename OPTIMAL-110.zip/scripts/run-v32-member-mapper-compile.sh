#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p \
  "$TMP_DIR/stubs/com/optimal/fleet/core/common/error" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/session" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/remote" \
  "$TMP_DIR/stubs/kotlinx/serialization/json"
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/common/error/DomainError.kt" <<'KT'
package com.optimal.fleet.core.common.error
open class DomainError
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/session/ActiveSession.kt" <<'KT'
package com.optimal.fleet.core.session
data class ActiveSession(val userId: String = "", val companyId: String = "")
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/Entities.kt" <<'KT'
package com.optimal.fleet.core.database.entity
data class LocalUserEntity(
    val id: String,
    val companyId: String,
    val remoteId: String?,
    val displayName: String,
    val phone: String?,
    val isActive: Boolean,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val syncStatus: String,
    val normalizedPhone: String? = null,
    val lastActiveAtEpochMillis: Long = 0L,
    val role: String = "MEMBER",
    val permissionsJson: String = "{}",
)
data class MemberInviteEntity(
    val id: String,
    val companyId: String,
    val displayName: String,
    val phone: String,
    val normalizedPhone: String,
    val codeHash: String,
    val state: String,
    val expiresAtEpochMillis: Long,
    val usedAtEpochMillis: Long?,
    val usedByUserId: String?,
    val createdByUserId: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val role: String = "MEMBER",
    val permissionsJson: String = "{}",
)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/remote/RemoteDtos.kt" <<'KT'
package com.optimal.fleet.feature.settings.data.members.remote
import kotlinx.serialization.json.JsonObject
data class RemoteMemberDto(
    val id: String,
    val companyId: String,
    val displayName: String,
    val phone: String?,
    val normalizedPhone: String?,
    val isActive: Boolean,
    val role: String,
    val permissions: JsonObject,
    val lastActiveAtEpochMillis: Long,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
data class RemoteInviteDto(
    val id: String,
    val companyId: String,
    val displayName: String,
    val phone: String,
    val normalizedPhone: String,
    val role: String,
    val permissions: JsonObject,
    val state: String,
    val expiresAtEpochMillis: Long,
    val createdAtEpochMillis: Long,
)
KT
cat > "$TMP_DIR/stubs/kotlinx/serialization/json/Json.kt" <<'KT'
package kotlinx.serialization.json
open class JsonElement
class JsonPrimitive(val value: Boolean? = null) : JsonElement()
class JsonObject(
    private val backing: Map<String, JsonElement> = emptyMap(),
) : JsonElement(), Map<String, JsonElement> by backing
class Json(configure: Builder.() -> Unit = {}) {
    class Builder { var ignoreUnknownKeys: Boolean = false }
    init { Builder().configure() }
    fun parseToJsonElement(value: String): JsonElement = JsonObject()
}
val JsonElement.jsonObject: JsonObject get() = this as JsonObject
val JsonElement.jsonPrimitive: JsonPrimitive get() = this as JsonPrimitive
val JsonPrimitive.booleanOrNull: Boolean? get() = value
KT
kotlinc -nowarn \
  "$TMP_DIR/stubs/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/Entities.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/remote/RemoteDtos.kt" \
  "$TMP_DIR/stubs/kotlinx/serialization/json/Json.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/mapper/MemberMapper.kt" \
  -d "$TMP_DIR/member-mapper.jar"
echo "V32 member mapper focused compilation: 1/1"
