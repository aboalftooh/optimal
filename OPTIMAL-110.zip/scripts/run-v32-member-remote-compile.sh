#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p \
  "$TMP_DIR/stubs/javax/inject" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/network/supabase" \
  "$TMP_DIR/stubs/retrofit2/http" \
  "$TMP_DIR/stubs/retrofit2" \
  "$TMP_DIR/stubs/kotlinx/serialization/json" \
  "$TMP_DIR/stubs/kotlinx/serialization"
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
@Target(AnnotationTarget.CLASS)
annotation class Singleton
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/network/supabase/Supabase.kt" <<'KT'
package com.optimal.fleet.core.network.supabase
@Target(AnnotationTarget.VALUE_PARAMETER, AnnotationTarget.FIELD)
annotation class SupabaseRetrofit
interface SupabaseConfig { val isConfigured: Boolean }
interface AuthSessionStore { fun current(): Any? }
KT
cat > "$TMP_DIR/stubs/retrofit2/Retrofit.kt" <<'KT'
package retrofit2
class ResponseBody { fun string(): String = "" }
class Response<T>(
    val isSuccessful: Boolean = true,
    private val value: T? = null,
    private val status: Int = 200,
) {
    fun code(): Int = status
    fun errorBody(): ResponseBody? = null
    fun body(): T? = value
}
class Retrofit { fun <T> create(type: Class<T>): T = error(type.name) }
KT
cat > "$TMP_DIR/stubs/retrofit2/http/Annotations.kt" <<'KT'
package retrofit2.http
@Target(AnnotationTarget.FUNCTION)
annotation class POST(val value: String)
@Target(AnnotationTarget.VALUE_PARAMETER)
annotation class Body
KT
cat > "$TMP_DIR/stubs/kotlinx/serialization/Annotations.kt" <<'KT'
package kotlinx.serialization
@Target(AnnotationTarget.CLASS)
annotation class Serializable
@Target(AnnotationTarget.PROPERTY)
annotation class SerialName(val value: String)
KT
cat > "$TMP_DIR/stubs/kotlinx/serialization/json/Json.kt" <<'KT'
package kotlinx.serialization.json
class JsonObject
class JsonObjectBuilder
fun buildJsonObject(builder: JsonObjectBuilder.() -> Unit): JsonObject {
    JsonObjectBuilder().builder()
    return JsonObject()
}
KT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
kotlinc -cp "$COROUTINES_JAR" \
  "$TMP_DIR/stubs/javax/inject/Inject.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/network/supabase/Supabase.kt" \
  "$TMP_DIR/stubs/retrofit2/Retrofit.kt" \
  "$TMP_DIR/stubs/retrofit2/http/Annotations.kt" \
  "$TMP_DIR/stubs/kotlinx/serialization/Annotations.kt" \
  "$TMP_DIR/stubs/kotlinx/serialization/json/Json.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/OptimalMembersApi.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/MemberRemoteDataSource.kt" \
  -d "$TMP_DIR/member-remote.jar"
echo "V32 member remote focused compilation: 2/2"
