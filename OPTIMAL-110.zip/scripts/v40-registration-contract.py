#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v40 Verto registration compatibility."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
V19 = ROOT / "supabase/migrations/20260728001900_optimal_auth_membership_rls.sql"
V22 = ROOT / "supabase/migrations/20260728002200_optimal_verto_direct_link.sql"
V32 = ROOT / "supabase/migrations/20260730003200_optimal_member_permissions_rls.sql"
V40 = ROOT / "supabase/migrations/20260731004000_optimal_verto_registration_compatibility.sql"
PREFLIGHT = ROOT / "supabase/tests/v40_verto_registration_preflight.sql"
PROMOTE = ROOT / "supabase/post_deploy/v40_promote_verto_registration_ready.sql"
MAPPER = ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/mapper/OnboardingMapper.kt"
API = ROOT / "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OptimalOnboardingApi.kt"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
APP_GRADLE = ROOT / "app/build.gradle.kts"

checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, condition))


def contains_all(text: str, values: list[str]) -> bool:
    return all(value in text for value in values)


def function_body(sql: str, name: str) -> str:
    marker = f"function public.{name}"
    start = sql.find(marker)
    if start < 0:
        return ""
    next_start = sql.find("function public.", start + len(marker))
    return sql[start:] if next_start < 0 else sql[start:next_start]


for path in (V19, V22, V32, V40, PREFLIGHT, PROMOTE, MAPPER, API, CONTRACT, APP_GRADLE):
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())

if not all(path.is_file() for path in (V19, V22, V32, V40, PREFLIGHT, PROMOTE, MAPPER, API, CONTRACT, APP_GRADLE)):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

v19 = V19.read_text(encoding="utf-8")
v22 = V22.read_text(encoding="utf-8")
v32 = V32.read_text(encoding="utf-8")
v40 = V40.read_text(encoding="utf-8")
preflight = PREFLIGHT.read_text(encoding="utf-8")
promote = PROMOTE.read_text(encoding="utf-8")
mapper = MAPPER.read_text(encoding="utf-8")
api = API.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
app_gradle = APP_GRADLE.read_text(encoding="utf-8")
all_sql = "\n".join((v19, v22, v32, v40))

issue = function_body(v40, "verto_issue_optimal_registration_code")
validate = function_body(v40, "optimal_validate_verto_company_code")
consume = function_body(v40, "optimal_complete_company_registration")
backend_contract = function_body(v40, "optimal_backend_contract")

# Migration order and scope.
migrations = sorted(p.name for p in (ROOT / "supabase/migrations").glob("*.sql"))
check("order:v40-after-v32", migrations.index(V40.name) > migrations.index(V32.name))
check("scope:no-room-change", "OptimalDatabase" not in v40 and "Room" not in v40)
check("scope:no-android-version-bump", 'versionCode = 32' in app_gradle and 'versionName = "0.37.0-v37"' in app_gradle)
check("scope:contract-version-stays-22", "set contract_version = 23" not in v40 and "contract_version = 23" not in v40)
check("scope:no-minimum-client-raise", "minimum_android_version_code =" not in v40)

# Issuance remains Verto-owned and exactly 24 hours.
check("issuer:rpc-present", bool(issue))
check("issuer:authenticated-only", "revoke all on function public.verto_issue_optimal_registration_code(uuid, integer)" in v40 and "from public, anon" in v40 and "grant execute on function public.verto_issue_optimal_registration_code(uuid, integer)" in v40 and "to authenticated" in v40)
check("issuer:fixed-1440-wire-compatible", "p_expires_in_minutes integer default 1440" in issue)
check("issuer:rejects-non-24h", "p_expires_in_minutes is distinct from 1440" in issue)
check("issuer:exact-24h", "interval '24 hours'" in issue)
check("issuer:company-client-only", contains_all(issue, ["client_must_be_company", "'COMPANY' = any"]))
check("issuer:verto-permission", contains_all(issue, ["get_my_org_id()", "has_perm('clients_edit')"]))
check("issuer:client-lock", "optimal-verto-client:" in issue and "pg_advisory_xact_lock" in issue)
check("issuer:revokes-old-pending", contains_all(issue, ["state = case when expires_at <= now() then 'EXPIRED' else 'REVOKED' end", "state = 'PENDING'"]))
check("issuer:hash-only", "extensions.digest(v_code, 'sha256')" in issue)
check("issuer:no-plaintext-column", not re.search(r"\bplain_code\b", v40, re.IGNORECASE))

# Direct code-table exposure remains forbidden.
check("security:code-table-rls", "alter table public.optimal_verto_registration_codes enable row level security" in v22)
check("security:code-table-revoked", "revoke all on table public.optimal_verto_registration_codes from public, anon, authenticated" in v22)
check("security:service-role-only", "grant all on table public.optimal_verto_registration_codes to service_role" in v22)
check("security:no-android-issuer", "verto_issue_optimal_registration_code" not in "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for p in ROOT.glob("**/*.kt")
))
check("security:validation-minimal-shape", contains_all(validate, ["verto_client_id uuid", "company_name text", "status text"]))
check("security:validation-no-code-return", "returns table (\n    code text" not in validate)

# One client, one active company; one user, one company; one pending code.
check("identity:active-link-unique", contains_all(all_sql, ["optimal_verto_links_one_active_client_idx", "where is_active = true"]))
check("identity:pending-code-unique", contains_all(all_sql, ["optimal_verto_one_pending_code_per_client_idx", "where state = 'PENDING'"]))
check("identity:user-membership-unique", bool(re.search(r"auth_user_id\s+uuid\s+unique", v19)))
check("identity:code-hash-unique", "code_hash bytea not null unique" in v22)
check("identity:code-states", contains_all(v22, ["'PENDING'", "'USED'", "'REVOKED'", "'EXPIRED'"]))

# Atomic consume and concurrency controls.
check("consume:rpc-present", bool(consume))
check("consume:auth-required", "auth_session_required" in consume)
check("consume:verified-phone", "verified_phone_required" in consume)
check("consume:code-row-lock", "for update" in consume and "optimal_verto_registration_codes" in consume)
check("consume:user-advisory-lock", "optimal-auth-user:" in consume)
check("consume:client-advisory-lock", "optimal-verto-client:" in consume)
check("consume:membership-recheck-after-lock", consume.find("optimal-auth-user:") < consume.find("user_already_has_company"))
check("consume:link-recheck-after-lock", consume.find("optimal-verto-client:") < consume.find("company_already_linked"))
check("consume:creates-company", "insert into public.optimal_companies" in consume)
check("consume:creates-owner", contains_all(consume, ["insert into public.optimal_members", "'OWNER'", "'{\"*\":true}'::jsonb"]))
check("consume:creates-link", "insert into public.optimal_verto_links" in consume)
check("consume:marks-used", contains_all(consume, ["set state = 'USED'", "used_by_user_id = v_auth_user", "used_at = now()"]))
check("consume:conditional-state-transition", contains_all(consume, ["where id = v_code.id", "and state = 'PENDING'", "registration_code_concurrently_consumed"]))
check("consume:same-user-retry-idempotent", contains_all(consume, ["v_code.state = 'USED'", "v_code.used_by_user_id = v_auth_user", "registration_replay_inconsistent"]))
check("consume:different-user-used-rejected", "registration_code_' || pg_catalog.lower(v_code.state)" in consume)

# Existing Android API and UI-recognized statuses remain unchanged.
check("android:validate-rpc-name", 'rpc/optimal_validate_verto_company_code' in api)
check("android:consume-rpc-name", 'rpc/optimal_complete_company_registration' in api)
check("android:valid-status", 'STATUS_VALID = "VALID"' in mapper)
check("android:expired-status", 'STATUS_EXPIRED = "EXPIRED"' in mapper)
check("android:used-status", 'STATUS_USED = "USED"' in mapper)
check("android:revoked-status", 'STATUS_REVOKED = "REVOKED"' in mapper)
check("errors:validation-emits-known-states", contains_all(validate, ["'VALID'", "'EXPIRED'", "'REVOKED'"]))
check("errors:completion-code-token", contains_all(consume, ["invalid_registration_code", "registration_code_expired", "registration_code_"]))
check("errors:conflicts-distinct", contains_all(consume, ["user_already_has_company", "company_already_linked"]))

# Readiness is staged and the v23 envelope is stable without premature promotion.
readiness_fields = [
    "verto_registration_ready",
    "verto_chat_ready",
    "verto_attachments_ready",
    "verto_finance_v23_ready",
    "verto_maintenance_ready",
    "verto_limits",
]
for field in readiness_fields:
    check(f"readiness:{field}", field in v40 and field in backend_contract)
check("readiness:registration-default-false", "verto_registration_ready boolean not null default false" in v40)
check("readiness:not-promoted-in-migration", "set verto_registration_ready = true" not in v40)
check("readiness:preflight-requires-false", "v40_readiness_must_remain_false_before_live_tests" in preflight)
check("readiness:promotion-is-post-deploy", "set verto_registration_ready = true" in promote)
check("readiness:promotion-checks-indexes", contains_all(promote, ["optimal_verto_links_one_active_client_idx", "optimal_verto_one_pending_code_per_client_idx"]))
check("readiness:promotion-checks-table-privacy", "v40_registration_codes_exposed" in promote)
check("readiness:contract-doc-field", "verto_registration_ready" in contract)

# Basic delimiter/syntax sanity for files that cannot be executed without PostgreSQL.
check("syntax:v40-dollar-quotes-balanced", v40.count("$$") % 2 == 0)
check("syntax:preflight-dollar-quotes-balanced", preflight.count("$$") % 2 == 0)
check("syntax:promotion-dollar-quotes-balanced", promote.count("$$") % 2 == 0)
check("syntax:no-merge-markers", not any(token in v40 for token in ("<<<<<<<", "=======", ">>>>>>>")))

passed = sum(ok for _, ok in checks)
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
print(f"RESULT {passed}/{len(checks)}")

if passed != len(checks):
    sys.exit(1)
