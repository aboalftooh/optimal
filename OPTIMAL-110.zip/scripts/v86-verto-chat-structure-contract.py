#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]
PRESENTATION = ROOT / 'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation'
FILES = {
    'screen': PRESENTATION / 'VertoChatScreen.kt',
    'chrome': PRESENTATION / 'VertoChatChrome.kt',
    'messages': PRESENTATION / 'VertoChatMessages.kt',
    'attachments': PRESENTATION / 'VertoChatAttachments.kt',
    'composer': PRESENTATION / 'VertoChatComposer.kt',
    'formatting': PRESENTATION / 'VertoChatFormatting.kt',
    'test': ROOT / 'feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoChatPresentationV86Test.kt',
}
checks = []

def check(label, cond):
    checks.append((label, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + label)

def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

def tree(rel):
    h = hashlib.sha256()
    for f in sorted((ROOT / rel).rglob('*')):
        if f.is_file():
            h.update(str(f.relative_to(ROOT)).encode())
            h.update(b'\0')
            h.update(f.read_bytes())
            h.update(b'\0')
    return h.hexdigest()

for name, path in FILES.items():
    check(f'exists {name}', path.is_file())
text = {name: path.read_text() for name, path in FILES.items()}
all_ui = '\n'.join(text[n] for n in ['screen','chrome','messages','attachments','composer','formatting'])

# Structural split and testability.
check('screen reduced below 200 lines', len(text['screen'].splitlines()) < 200)
for name, fn in [
    ('chrome','VertoChatHeader'), ('chrome','CachedMessagesErrorBanner'), ('chrome','VertoChatGate'),
    ('messages','VertoMessageList'), ('messages','VertoMessageBubble'), ('messages','MessageFooter'),
    ('attachments','AttachmentPreview'), ('attachments','VertoAudioAttachmentPreview'),
    ('composer','VertoTextComposer'), ('composer','VertoAudioRecordingComposer'), ('composer','VertoAudioDraftComposer'),
    ('formatting','formatDuration'), ('formatting','formatBytes'), ('formatting','formatMessageTime'),
]:
    check(f'{fn} extracted to {name}', re.search(rf'\binternal fun {fn}\b', text[name]) is not None)
for token in ['VertoChatHeader(', 'VertoMessageList(', 'VertoTextComposer(', 'VertoChatGate(']:
    check(f'screen composes {token[:-1]}', token in text['screen'])
check('only screen entry remains public', 'fun VertoChatScreen(' in text['screen'] and 'internal fun VertoChatScreen' not in text['screen'])

# Existing state gates and cached error behavior.
for token in ['state.loading && state.messages.isEmpty()', 'state.accessDenied', '!state.linkState.linked', 'state.errorMessage?.let']:
    check(f'gate preserved {token}', token in text['screen'])
for phrase in ['جارٍ تحميل الرسائل', 'لا توجد صلاحية', 'غير مرتبط بـ Verto', 'لا توجد رسائل', 'إعادة المحاولة']:
    check(f'copy preserved {phrase}', phrase in all_ui)

# Message semantics/read model.
for token in ['key = VertoMessage::stableIdentity', 'snapshotFlow', 'VertoMessageCursor(createdAt, remoteId)', 'onMessagesVisible', 'FAILED_RETRYABLE', 'FAILED_TERMINAL']:
    check(f'message semantics {token}', token in text['messages'])
for token in ['senderDisplayName', 'senderRole', 'remoteStatus == VertoMessageStatus.REDACTED', 'bodyText', 'attachments.isNotEmpty()']:
    check(f'message rendering {token}', token in text['messages'])
for phrase in ['تم حجب محتوى هذه الرسالة', 'إعادة', 'قيد الانتظار', 'جارٍ الإرسال', 'تم الإرسال', 'فشل الإرسال']:
    check(f'message label preserved {phrase}', phrase in text['messages'])

# Attachment protocol/open semantics.
for token in [
    'attachment.kind == VertoAttachmentKind.AUDIO',
    'attachment.localPrivatePath != null',
    'attachment.transferState == VertoAttachmentTransferState.READY',
    'VertoAttachmentOpenContract.open(context, attachment)',
    'onOpenRemoteAttachment(remoteAttachmentId)',
]:
    check(f'attachment behavior {token}', token in text['attachments'])
for state in ['LOCAL_READY','UPLOADING','UPLOADED','FINALIZING','READY','FAILED_RETRYABLE','FAILED_TERMINAL','LOCAL_MISSING']:
    check(f'attachment transfer state {state}', state in text['attachments'])
for phrase in ['بانتظار الرفع','جارٍ الرفع','جارٍ التحقق','جاهز','تعذر الرفع مؤقتًا','تعذر الرفع']:
    check(f'attachment label preserved {phrase}', phrase in text['attachments'])
for kind in ['IMAGE','VIDEO','AUDIO','DOCUMENT']:
    check(f'attachment kind {kind}', f'VertoAttachmentKind.{kind}' in text['attachments'] or f'VertoMessageKind.{kind}' in text['attachments'])

# Composer/audio semantics.
for token in ['state.recordingAudio', 'state.audioDraft != null', 'state.audioOperationInProgress', 'state.attachmentEnabled', 'state.audioRecordEnabled', 'state.sendEnabled']:
    check(f'composer state {token}', token in text['composer'])
for callback in ['onTakePhoto','onPickImage','onPickVideo','onPickDocument','onRecordAudio','onStopAudio','onCancelAudio','onSendAudio','onDiscardAudio']:
    check(f'composer callback {callback}', callback in text['composer'])
for tag in ['COMPOSER_TAG','SEND_TAG','ATTACHMENT_MENU_TAG','AUDIO_RECORD_TAG','AUDIO_RECORDING_TAG','AUDIO_STOP_TAG','AUDIO_DRAFT_TAG','AUDIO_PREVIEW_TAG','AUDIO_DISCARD_TAG','AUDIO_SEND_TAG']:
    check(f'composer tag {tag}', tag in text['composer'] or tag in text['formatting'])
check('audio draft keeps private playback', 'rememberVertoAudioPlaybackState' in text['composer'])
check('audio attachment keeps private playback', 'rememberVertoAudioPlaybackState' in text['attachments'])

# Stable public test tags preserved after extraction.
for literal in ['destination-verto','verto-message-list','verto-load-older','verto-text-composer','verto-send-text','verto-attachment-menu','verto-audio-record']:
    check(f'stable tag literal {literal}', f'"{literal}"' in text['formatting'])

# Presentation-only boundary.
for name in ['screen','chrome','messages','attachments','composer','formatting']:
    src = text[name]
    check(f'{name} has no data import', '.data.' not in src)
    check(f'{name} has no database import', 'core.database' not in src)
    check(f'{name} has no network import', 'core.network' not in src and 'Retrofit' not in src and 'Supabase' not in src and 'HttpClient' not in src)

# Behavior/protocol locks from v85.
protected_trees = {
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain': '4525f4fc8f5dd55a4abf5e2146443de629d052f67c1721405adb133594598540',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/data': 'ba98e90d619d4e2d757c477bb0fd97b1250eeedbe97e127d26407459a9839bd0',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/di': '7267f438a631d304d66e5b1890d152169b7083433bb8292ad9743c90874fc301',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/navigation': '2649832acfeb55e356f70abed9df0ac5955537aff808feb581824b17d0e84352',
}
protected_files = {
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt': '65e99bad21d55f9cfb080212abe8d053b5e56d0d79ecd8009316d879259df6d0',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt': 'd160312ae48c1ced85dc0e102f3f9bc87c2f5d9a6c5a468359fa0c768f1469cb',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt': '21c428519492d38413fb5a6b38cbaa1b5cc4ba16c20f3282300df9499db3301c',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentPickerCoordinator.kt': '74aa740467eeb0d9a0b670bbabe70ff286aaef05c4216656845c8489794464c0',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentOpenContract.kt': 'acd9b82ff9166111dd60b3362c6106a5d53dfe1792c91122e820cc22da93e642',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAudioPlayback.kt': 'a07ef2c8ebf97dfe6755bdc243ac5b0ae49bd0ce67ceb1499d9996fa90319383',
    'app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncParticipant.kt': '3635ed5aca8688836d029948fd2182e0f2c7a8013eaa29d4143a2d09adcd7cb4',
    'app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncSchedulerAdapter.kt': '059c6e208a0bb1e4d733e7b673cfd68dc3195feb4b7084e2825c3f58a4b554b4',
}
for rel, digest in protected_trees.items(): check('protected tree unchanged ' + rel, tree(rel) == digest)
for rel, digest in protected_files.items(): check('protected file unchanged ' + rel, sha(rel) == digest)

# Regression scripts were taught to read the extracted presentation aggregate, not weakened.
for version in range(53, 58):
    matches = list((ROOT / 'scripts').glob(f'v{version}-verto-*-contract.py'))
    if not matches:
        matches = list((ROOT / 'scripts').glob(f'v{version}-*-contract.py'))
    check(f'legacy v{version} contract present', bool(matches))
    if matches:
        src = matches[0].read_text()
        check(f'legacy v{version} reads split presentation', 'CHAT_PRESENTATION_FILES' in src and 'chat_presentation_text()' in src)

# Focused unit source coverage.
for test_name in ['extractedFormattingPreservesDurationSemantics','extractedFormattingPreservesByteSemantics','extractedComponentsKeepStableUiTags']:
    check(f'v86 unit test {test_name}', test_name in text['test'])

failed = [x for x in checks if not x[1]]
print(f'v86 Verto Chat structural contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
