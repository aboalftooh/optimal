#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
paths = {
    'auth_components': 'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt',
    'auth_steps': 'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt',
    'auth_account': 'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthAccountContent.kt',
    'auth_route': 'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt',
    'join': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRoute.kt',
    'notifications_screen': 'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreen.kt',
    'notifications_components': 'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsComponents.kt',
    'auth_test': 'feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AuthRouteV85Test.kt',
    'join_test': 'feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRouteV85Test.kt',
    'notifications_test': 'feature/notifications/src/androidTest/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreenV85Test.kt',
}
text = {name: (root / rel).read_text() for name, rel in paths.items()}
checks = []

def check(label, cond):
    checks.append((label, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + label)

def sha(rel):
    return hashlib.sha256((root / rel).read_bytes()).hexdigest()

def tree(rel):
    h = hashlib.sha256()
    for f in sorted((root / rel).rglob('*.kt')):
        h.update(str(f.relative_to(root)).encode())
        h.update(b'\0')
        h.update(f.read_bytes())
        h.update(b'\0')
    return h.hexdigest()

# Design-system migration invariants for owned presentation files.
for name in ['auth_components', 'auth_steps', 'auth_account', 'auth_route', 'join', 'notifications_screen', 'notifications_components']:
    source = text[name]
    check(f'{name} has no legacy DS import', re.search(r'import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', source) is None)
    check(f'{name} has no AppCard', 'AppCard' not in source)
    check(f'{name} has no AppTextField', 'AppTextField' not in source)
    check(f'{name} has no direct dp literal', re.search(r'\b\d+(?:\.\d+)?\.dp\b', source) is None)
    check(f'{name} has no raw hex colors', '0xFF' not in source)

# Auth hierarchy + validation + event contracts.
for token in ['OptimalSectionHeader', 'AuthStepIndicator', 'AuthMessageBanner', 'OptimalContentInsets']:
    check(f'auth route uses {token}', token in text['auth_route'])
for tag in ['destination-auth-onboarding']:
    check(f'auth route preserves tag {tag}', f'"{tag}"' in text['auth_route'])
for token in ['OptimalStatusBadge', 'OptimalStatusTone.Info', 'OptimalStatusTone.Success', 'OptimalStatusTone.Warning', 'OptimalStatusTone.Danger', 'OptimalTertiaryButton']:
    check(f'auth components use {token}', token in text['auth_components'])
for token in ['OptimalFormSection', 'OptimalTextField', 'OptimalPrimaryButton', 'OptimalSecondaryButton', 'OptimalListRow']:
    check(f'auth onboarding uses {token}', token in text['auth_steps'])
for tag in ['auth-phone', 'request-otp', 'auth-otp', 'verify-otp', 'resend-otp', 'join-code', 'join-code-next', 'company-registration-form', 'company-name', 'user-name', 'complete-onboarding', 'onboarding-result', 'continue-to-app', 'restart-onboarding']:
    corpus = text['auth_steps'] + text['auth_components']
    check(f'auth preserves tag {tag}', f'"{tag}"' in corpus)
for event in ['PhoneChanged', 'RequestOtp', 'OtpChanged', 'VerifyOtp', 'ResendOtp', 'JoinCodeChanged', 'SubmitJoinCode', 'UserDisplayNameChanged', 'CompleteOnboarding', 'Back', 'Continue', 'Restart']:
    check(f'auth preserves event {event}', f'AuthUiEvent.{event}' in text['auth_steps'])
for error in ['Phone', 'Otp', 'JoinCode', 'CompanyName', 'UserDisplayName', 'VehicleCount', 'EmployeeCount', 'WorkshopName']:
    check(f'auth presents field error {error}', f'AuthFieldError.{error}' in text['auth_steps'])
check('auth message includes transport/domain errors', 'state.errorKind != null' in text['auth_route'])
check('auth account summary uses v2 structure', all(token in text['auth_account'] for token in ['OptimalSectionHeader', 'OptimalFormSection', 'OptimalListRow', 'OptimalPrimaryButton', 'OptimalDestructiveButton']))
check('auth account sign out is destructive', 'text = "تسجيل الخروج"' in text['auth_account'] and 'OptimalDestructiveButton' in text['auth_account'])
for tag in ['account-continue', 'account-sign-out']:
    check(f'auth account preserves tag {tag}', f'"{tag}"' in text['auth_account'])

# Join Company presentation-only migration.
for token in ['OptimalSectionHeader', 'OptimalStatusBadge', 'OptimalFormSection', 'OptimalTextField', 'OptimalPrimaryButton']:
    check(f'join uses {token}', token in text['join'])
for tag in ['destination-join-company', 'join-code', 'join-submit', 'join-message']:
    check(f'join preserves/adds tag {tag}', f'"{tag}"' in text['join'])
for event in ['CodeChanged', 'Submit']:
    check(f'join preserves event {event}', f'JoinCompanyUiEvent.{event}' in text['join'])
check('join validation is field adjacent', 'UiErrorKind.VALIDATION' in text['join'] and 'isError = hasValidationError' in text['join'])
check('join loading disables submit', 'enabled = !state.isLoading' in text['join'])
check('join preserves error reference presentation', 'state.errorReference' in text['join'])

# Notifications flat-list migration and stable targets.
for token in ['OptimalLoadingState', 'OptimalErrorState', 'NotificationsEmpty', 'NotificationRow', 'OptimalSecondaryButton']:
    check(f'notifications screen uses {token}', token in text['notifications_screen'])
for tag in ['destination-notifications', 'notifications-error', 'notifications-empty', 'notifications-load-more']:
    check(f'notifications screen preserves/adds tag {tag}', f'"{tag}"' in text['notifications_screen'])
for event in ['Refresh', 'LoadMore', 'OpenNotification']:
    check(f'notifications screen preserves event {event}', f'NotificationsUiEvent.{event}' in text['notifications_screen'])
for token in ['OptimalSectionHeader', 'OptimalListRow', 'OptimalStatusBadge', 'OptimalStatusTone.Info', 'OptimalStatusTone.Neutral', 'OptimalTertiaryButton', 'OptimalSecondaryButton']:
    check(f'notifications components use {token}', token in text['notifications_components'])
for tag in ['notification-unread-count', 'refresh-notifications', 'mark-all-notifications-read', 'notifications-message', 'notification-${item.id}', 'notification-action-${item.id}']:
    check(f'notifications preserve/add tag {tag}', f'"{tag}"' in text['notifications_components'])
for event in ['Refresh', 'MarkAllRead']:
    check(f'notifications header preserves event {event}', f'NotificationsUiEvent.{event}' in text['notifications_components'])
check('notification row open remains stable item id event path', 'OpenNotification(item.id)' in text['notifications_screen'])
check('notification rows are flat v2 rows', 'OptimalListRow' in text['notifications_components'])
check('unread emphasis is semantic state not decorative badge', 'if (item.isRead)' in text['notifications_components'] and 'OptimalStatusTone.Info' in text['notifications_components'])
check('refresh is disabled while refreshing', 'enabled = !state.isRefreshing' in text['notifications_components'])
check('mark all disabled when nothing unread', 'enabled = state.unreadCount > 0' in text['notifications_components'])

# New focused source UI coverage.
for test_name in ['phoneValidationIsFieldAdjacentAndKeepsRequestEvent', 'joinCodeStepKeepsSubmitAndBackEvents']:
    check(f'auth v85 UI test {test_name}', test_name in text['auth_test'])
for test_name in ['submitKeepsExistingJoinEvent', 'validationErrorIsPresentedBesideCode']:
    check(f'join v85 UI test {test_name}', test_name in text['join_test'])
for test_name in ['markAllReadKeepsExistingEvent', 'errorStateRetriesThroughRefreshEvent']:
    check(f'notifications v85 UI test {test_name}', test_name in text['notifications_test'])

# Behavior/data/navigation locks from v84.
protected_files = {
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt': 'a27802b41a0929864d97c8d09de6f6c4e5458d222a65fd5fbe060d196b38abb2',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt': 'a2da9e11fc258a20e84142ad3d8aaf54b97ccb079a91f1b321d37f08fe108015',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthScreenContent.kt': '7807a4326f7ed6e79a71251fef98adbeb6326c38f2ff003cb3f8bbdf0e2d7e6e',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/navigation/AuthNavigation.kt': '44620ce00b652d9bf83dcc22aca1dcefa3a6c61eaa759893a2500e3ce9845bcf',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyContract.kt': '615e08139a2096981f437241a7b20a69d6910757e75f7cec23665c675d6889f3',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyViewModel.kt': '6ff8ddf7eb20494ca9988a77bbbfb54c8f00fbadee590932b9817da4ed8fc049',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation/SettingsNavigation.kt': '8861804dfeae111e35eafde1f5ed32df6f4cddb9b1557c009950986f4a479df8',
    'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsContract.kt': '7e2babf6796e43995cd085f0d81bb0113c3ea5990d7cfee9b867615c63afd3a7',
    'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsViewModel.kt': '560e7686686e90bbe69028cfa70649f9202731ddd4d28b2bf8d146beacf05510',
    'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsRoute.kt': 'd7a934428a7707a242069f4d536c3cccc791ea24e588f5742f3d3529491131c5',
    'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/navigation/NotificationsNavigation.kt': '3c2c6801cd0f864712fce9c4872843ce94df820e5d57e36473ffd82e3e077d08',
    'app/src/main/java/com/optimal/fleet/navigation/deeplink/NotificationDeepLink.kt': '37d19faf719805e6b6407df28108f51188fb76e0635030f6ff5e7aabdb91c8ba',
    'app/src/main/java/com/optimal/fleet/navigation/deeplink/NotificationTapViewModel.kt': 'b44623b22fdfc547df013419380a3d879c66cfc9df4094ebc1baefc4f01fa64d',
}
protected_trees = {
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain': '8b16d181b8b0231d0c4f6c0b703c91b056a5212102924bfad538c871b61efafa',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/data': '39f039d3a2dbf514e678066efdddce297b25dacd5dc92f066f5e0d2616765449',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain': 'bcf34c3f18d22ed6a1d7209347397f9e427c51a528d19a670c73dcc2141ec647',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/data': 'ca09349c43da216f8580d30e7da538cc65e94d3ecfaa26f49669e5a7da198e79',
    'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/domain': '11825cf2379fb63573f0cc1c882bd756f6bc384901b177ef418b20f168b2d526',
    'feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data': 'de4b816d6bca128df4e2b9c2f78d61849f75e8193a1068e26d7c2b26670e231b',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance': 'b04e0943df0a1528d62d3b4f51270774cd3f8222120624a81c39c86aa039ae13',
}
for rel, digest in protected_files.items():
    check('protected file unchanged ' + rel, sha(rel) == digest)
for rel, digest in protected_trees.items():
    check('protected tree unchanged ' + rel, tree(rel) == digest)

failed = [item for item in checks if not item[1]]
print(f'v85 Auth + Join Company + Notifications UX contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
