#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
FILES=(
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalButtons.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalCards.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalDialogs.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalEmptyCards.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalFields.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalHeader.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalNavigation.kt
  core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/OptimalSegments.kt
  feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AuthScreenTest.kt
  feature/home/src/androidTest/java/com/optimal/fleet/feature/home/HomeUiTest.kt
  feature/vehicles/src/androidTest/java/com/optimal/fleet/feature/vehicles/presentation/VehicleScreensTest.kt
  feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/SettingsScreenTest.kt
  feature/notifications/src/androidTest/java/com/optimal/fleet/feature/notifications/presentation/NotificationsScreenTest.kt
  feature/finance/src/androidTest/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreenTest.kt
)
while IFS= read -r file; do FILES+=("$file"); done < <(
  find feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation \
       feature/home/src/main/java/com/optimal/fleet/feature/home/presentation \
       feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation \
       feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation \
       feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation \
       feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation \
       -type f -name '*.kt' | sort
)
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180 kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
set -e
if grep -Eiq 'expecting|unexpected tokens|syntax error' "$OUT"; then
  grep -Ein 'expecting|unexpected tokens|syntax error' "$OUT"
  echo "FAIL: Kotlin parser diagnostics found" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} UI/contract files; unresolved Android symbols were intentionally ignored without classpath."
