#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_MAIN="$ROOT_DIR/app/src/main/java/com/optimal/fleet"
APP_TEST="$ROOT_DIR/app/src/test/java/com/optimal/fleet"
FINANCE="$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance"
MAINTENANCE="$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance"
FILES=(
  "$APP_MAIN/coordinator/verto/VertoMaintenanceAutoImportCoordinator.kt"
  "$APP_MAIN/work/OptimalSyncWorker.kt"
  "$APP_MAIN/work/SyncWorkerEntryPoint.kt"
  "$APP_TEST/CrossFeatureArchitectureTest.kt"
  "$APP_TEST/coordinator/verto/VertoCoordinatorTestFixtures.kt"
  "$APP_TEST/coordinator/verto/VertoMaintenanceAutoImportCoordinatorTest.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceProjectionDao.kt"
  "$FINANCE/data/RoomFinanceProjectionPort.kt"
  "$FINANCE/domain/ports/FinanceProjectionPort.kt"
  "$MAINTENANCE/data/RoomVertoMaintenanceProjectionRepository.kt"
  "$MAINTENANCE/domain/source/VertoMaintenanceProjectionRepository.kt"
  "$ROOT_DIR/scripts/v10-linking-harness.kt"
)
for file in "${FILES[@]}"; do
  [[ -f "$file" ]] || {
    echo "FAIL: missing v61 Kotlin source: $file" >&2
    exit 1
  }
done
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
PARSER_PATTERN='error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected'
PARSER_PATTERN+='|type expected|name expected|property getter or setter expected)'
if grep -Eiq "$PARSER_PATTERN" "$OUT"; then
  grep -Ein "$PARSER_PATTERN" "$OUT"
  echo "FAIL: v61 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v61 Kotlin parser timed out" >&2
  exit 1
fi
printf 'PASS: Kotlin parser accepted %s v61 files; unresolved external symbols were ignored.\n' \
  "${#FILES[@]}"
