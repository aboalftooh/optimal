#!/usr/bin/env python3
"""Non-destructive v32 contract checks for member roles, RPCs, RLS, and invite lifecycle."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SQL = (ROOT / "supabase/migrations/20260730003200_optimal_member_permissions_rls.sql").read_text(encoding="utf-8")
MODELS = (ROOT / "core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt").read_text(encoding="utf-8")
POLICY = MODELS
API = (ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/OptimalMembersApi.kt").read_text(encoding="utf-8")

checks: list[tuple[str, bool]] = []
def check(name: str, condition: bool) -> None:
    checks.append((name, condition))

roles = {"OWNER", "MANAGER", "ENGINEER", "ACCOUNTANT", "DRIVER", "MEMBER"}
capabilities = {
    "VIEW_MEMBER_DIRECTORY",
    "CREATE_MEMBER_INVITE",
    "RESEND_MEMBER_INVITE",
    "REVOKE_MEMBER_INVITE",
    "CHANGE_MEMBER_STATUS",
}

for role in roles:
    check(f"Android role {role}", f'{role}("{role}")' in MODELS)
    check(f"SQL role {role}", f"'{role}'" in SQL)
for capability in capabilities:
    check(f"Android capability {capability}", f'{capability}("{capability}")' in MODELS)
    check(f"SQL capability {capability}", f"'{capability}'" in SQL)

check("single Android policy", "object MemberAccessPolicy" in POLICY and "defaultsByRole" in POLICY)
check("unknown role fails closed", "MemberRole.UNKNOWN to emptySet()" in POLICY)
check("inactive member fails closed", "if (!isActive || role == MemberRole.UNKNOWN) return emptySet()" in POLICY)
check("false overrides supported", "permissionOverrides[capability]" in POLICY)

sensitive = {
    "optimal_member_directory": "VIEW_MEMBER_DIRECTORY",
    "optimal_create_member_invite": "CREATE_MEMBER_INVITE",
    "optimal_resend_member_invite": "RESEND_MEMBER_INVITE",
    "optimal_revoke_member_invite": "REVOKE_MEMBER_INVITE",
    "optimal_set_member_active": "CHANGE_MEMBER_STATUS",
}
for function, capability in sensitive.items():
    start = SQL.find(f"function public.{function}")
    check(f"{function} exists", start >= 0)
    if start >= 0:
        next_start = SQL.find("create ", start + 20)
        block = SQL[start: next_start if next_start >= 0 else len(SQL)]
        check(f"{function} checks capability", f"'{capability}'" in block and "optimal_member_has_capability" in block)
        check(f"{function} security definer", "security definer" in block)
        check(f"{function} fixed search_path", "set search_path =" in block)
    signature = {
        "optimal_member_directory": "()",
        "optimal_create_member_invite": "(text, text)",
        "optimal_resend_member_invite": "(uuid)",
        "optimal_revoke_member_invite": "(uuid)",
        "optimal_set_member_active": "(uuid, boolean)",
    }[function]
    normalized_sql = re.sub(r"\s+", " ", SQL)
    check(
        f"{function} revoked broadly",
        f"revoke all on function public.{function}{signature} from public, anon, authenticated;" in normalized_sql,
    )
    check(
        f"{function} authenticated grant",
        f"grant execute on function public.{function}{signature} to authenticated;" in normalized_sql,
    )

# Cross-company protection: public mutations do not accept company_id and target rows are actor-scoped.
check("create company derived from actor", "v_actor.company_id" in SQL and "p_company_id" not in SQL[SQL.find("optimal_create_member_invite"):SQL.find("optimal_resend_member_invite")])
check("resend target actor company scoped", "i.id = p_invite_id\n      and i.company_id = v_actor.company_id" in SQL)
check("revoke target actor company scoped", SQL.count("i.company_id = v_actor.company_id") >= 2)
check("status target actor company scoped", "m.id = p_member_id\n      and m.company_id = v_actor.company_id" in SQL)
check("directory RLS uses capability", "optimal_member_has_capability(company_id, 'VIEW_MEMBER_DIRECTORY')" in SQL)
check("direct member writes revoked", "revoke insert, update, delete on table public.optimal_members" in SQL)
check("direct invite writes revoked", "revoke insert, update, delete on table public.optimal_member_invites" in SQL)

# Invitation contract: pending-only uniqueness, expiry, cancellation, and one-time consumption propagation.
v19 = (ROOT / "supabase/migrations/20260728001900_optimal_auth_membership_rls.sql").read_text(encoding="utf-8")
check("one pending invite per company phone", "optimal_invites_one_pending_per_phone_idx" in v19 and "where state = 'PENDING'" in v19)
check("invite validity checks pending and expiry", "i.state = 'PENDING'" in v19 and "i.expires_at > now()" in v19)
check("onboarding consumes pending exactly once", "where id = v_invite.id and state = 'PENDING'" in v19 and "invite_concurrently_consumed" in v19)
check("v32 revoke is pending-only", "v_invite.state <> 'PENDING'" in SQL and "state = 'REVOKED'" in SQL)
check("consumed invite propagates role permissions", "optimal_apply_consumed_invite_permissions" in SQL and "permissions = new.permissions" in SQL)

check("Android directory decodes role", "val role: String" in API)
check("Android directory decodes permissions", "val permissions: JsonObject" in API)
check("Android has revoke RPC", "optimal_revoke_member_invite" in API)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)}")
if failed:
    print("FAILED: " + ", ".join(failed), file=sys.stderr)
    raise SystemExit(1)
