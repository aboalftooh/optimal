#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "docs/sessions/v26.md",
    "docs/database-testing-v26.md",
    "docs/verification-scripts-v26.md",
    "docs/source-archive-v26.sha256",
    "scripts/room-schema-drift-contract.py",
    "scripts/static-v26-check.py",
    "scripts/verify-v26-static.sh",
    "scripts/verify-v26-regressions.sh",
    "PATCH_MANIFEST-v26.md",
    "CHANGED_FILES-v26.txt",
    "DELETED_FILES-v26.txt",
    "verification-v26.md",
    "docs/verifications/verification-v26.md",
    "core/testing/src/main/kotlin/com/optimal/fleet/core/testing/database/DatabaseFixture.kt",
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/RoomTestData.kt",
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/PublishedSchemaContractTest.kt",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 21", bool(re.search(r"\bversionCode\s*=\s*21\b", build)))
check("versionName is v26", 'versionName = "0.26.0-v26"' in build)

database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
database_build = read("core/database/build.gradle.kts")
testing_build = read("core/testing/build.gradle.kts")
fixture = read("core/testing/src/main/kotlin/com/optimal/fleet/core/testing/database/DatabaseFixture.kt")
check("Room remains clean version 1", "version = 1" in database)
check("all 18 entities remain registered", len(re.findall(r"\w+Entity::class", database)) == 18)
check("database android tests consume core:testing", 'androidTestImplementation(project(":core:testing"))' in database_build)
check("database android tests use Room testing", "androidTestImplementation(libs.room.testing)" in database_build)
check("core:testing remains a JVM utility module", 'id("optimal.kotlin.library")' in testing_build)
check("core:testing does not depend on database", 'project(":core:database")' not in testing_build)
check("shared fixture defines two deterministic tenants", all(token in fixture for token in ["data class TenantFixture", "COMPANY_A", "COMPANY_B", "NOW"]))

schema_dir = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
schema_files = sorted(path.name for path in schema_dir.glob("*.json"))
check("schemas directory still contains only 1.json", schema_files == ["1.json"], ", ".join(schema_files))
try:
    schema = json.loads((schema_dir / "1.json").read_text(encoding="utf-8"))
except Exception as error:
    schema = {}
    check("1.json is valid JSON", False, str(error))
else:
    check("1.json is valid JSON", True)
db = schema.get("database", {})
entities = db.get("entities", [])
check("published schema version is 1", db.get("version") == 1, str(db.get("version")))
check("published schema has 18 tables", len(entities) == 18, str(len(entities)))
check("published schema has 219 columns", sum(len(entity.get("fields", [])) for entity in entities) == 219)
check("published schema has 91 indices", sum(len(entity.get("indices", [])) for entity in entities) == 91)
check("published schema has 35 foreign keys", sum(len(entity.get("foreignKeys", [])) for entity in entities) == 35)

android_test_root = ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database"
test_paths = sorted(android_test_root.glob("*.kt"))
test_source = "\n".join(path.read_text(encoding="utf-8") for path in test_paths)
new_contract_tests = [
    "CompanyUserSessionDaoContractTest.kt",
    "MemberAuditNotificationDaoContractTest.kt",
    "FinanceDashboardDaoContractTest.kt",
    "InvoiceDaoContractV26Test.kt",
    "VehicleMaintenanceSyncDaoContractV26Test.kt",
    "DatabaseConstraintContractTest.kt",
    "CompanyIsolationMatrixTest.kt",
    "PublishedSchemaContractTest.kt",
]
for name in new_contract_tests:
    check(f"v26 contract test exists: {name}", (android_test_root / name).is_file())

check("instrumentation suite has at least 30 test cases", len(re.findall(r"@Test\b", test_source)) >= 30, str(len(re.findall(r"@Test\b", test_source))))
check("published schema test uses MigrationTestHelper", "MigrationTestHelper" in read("core/database/src/androidTest/java/com/optimal/fleet/core/database/PublishedSchemaContractTest.kt"))
check("published schema test asserts all 18 tables", read("core/database/src/androidTest/java/com/optimal/fleet/core/database/PublishedSchemaContractTest.kt").count('            "') >= 18)
check("company isolation matrix covers every sensitive area", all(token in read("core/database/src/androidTest/java/com/optimal/fleet/core/database/CompanyIsolationMatrixTest.kt") for token in [
    "localUserDao()",
    "memberDao()",
    "vehicleDao()",
    "maintenanceDao()",
    "invoiceProjectionDao()",
    "invoiceLinkDao()",
    "financeDao()",
    "homeDashboardDao()",
    "auditEventDao()",
    "notificationDao()",
    "syncQueueDao()",
]))
check("constraint contract covers unique, foreign key, delete, and append-only rules", all(token in read("core/database/src/androidTest/java/com/optimal/fleet/core/database/DatabaseConstraintContractTest.kt") for token in [
    "foreignKeysReject",
    "uniqueConstraintsPrevent",
    "deletePoliciesCascade",
    "genericAuditLogIsAppendOnly",
]))

dao_getters = {
    "CompanyDao": "companyDao()",
    "LocalUserDao": "localUserDao()",
    "SessionDao": "sessionDao()",
    "VehicleDao": "vehicleDao()",
    "MaintenanceDao": "maintenanceDao()",
    "SyncQueueDao": "syncQueueDao()",
    "InvoiceProjectionDao": "invoiceProjectionDao()",
    "InvoiceLinkDao": "invoiceLinkDao()",
    "FinanceDao": "financeDao()",
    "HomeDashboardDao": "homeDashboardDao()",
    "AuditEventDao": "auditEventDao()",
    "MemberDao": "memberDao()",
    "NotificationDao": "notificationDao()",
}
for dao, getter in dao_getters.items():
    check(f"{dao} is exercised by instrumentation tests", getter in test_source)

schema_check = subprocess.run(
    [sys.executable, str(ROOT / "scripts/generate-room-baseline.py"), "--check"],
    cwd=ROOT,
    capture_output=True,
    text=True,
)
check("source-derived Room schema check passes", schema_check.returncode == 0, (schema_check.stdout + schema_check.stderr).strip())

drift_check = subprocess.run(
    [sys.executable, str(ROOT / "scripts/room-schema-drift-contract.py")],
    cwd=ROOT,
    capture_output=True,
    text=True,
)
check("schema drift contract accepts current and rejects unpublished changes", drift_check.returncode == 0, (drift_check.stdout + drift_check.stderr).strip())

verify_project = read("scripts/verify-project.sh")
verify_static = read("scripts/verify-v26-static.sh")
verify_regressions = read("scripts/verify-v26-regressions.sh")
check("verify-project invokes v26 static gate", "verify-v26-static.sh" in verify_project)
check("verify-project invokes v26 regression gate", "verify-v26-regressions.sh" in verify_project)
check("verify-project retains required Gradle commands", all(command in verify_project for command in [
    "./gradlew clean",
    "./gradlew testDebugUnitTest",
    "./gradlew lintDebug",
    "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))
check("v26 static gate includes architecture, schema, drift, and database contracts", all(token in verify_static for token in [
    "static-architecture-check.py",
    "static-v26-check.py",
    "generate-room-baseline.py --check",
    "room-schema-drift-contract.py",
]))
check("v26 regression gate retains the full historical harness suite", "verify-v25-regressions.sh" in verify_regressions)

for script in [
    "scripts/verify-project.sh",
    "scripts/generate-room-baseline.py",
    "scripts/room-schema-drift-contract.py",
    "scripts/static-v26-check.py",
    "scripts/verify-v26-static.sh",
    "scripts/verify-v26-regressions.sh",
]:
    path = ROOT / script
    check(f"active script is executable: {script}", path.is_file() and bool(path.stat().st_mode & 0o111))

for script in [
    "scripts/generate-room-baseline.py",
    "scripts/room-schema-drift-contract.py",
    "scripts/static-v26-check.py",
    "scripts/static-architecture-check.py",
]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid = True
        detail = ""
    except py_compile.PyCompileError as error:
        valid = False
        detail = str(error)
    check(f"Python syntax valid: {script}", valid, detail)

for script in [
    "scripts/verify-project.sh",
    "scripts/verify-v26-static.sh",
    "scripts/verify-v26-regressions.sh",
]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result.returncode == 0, result.stderr.strip())

source_hash = read("docs/source-archive-v26.sha256").strip()
check(
    "v25 source archive SHA-256 is recorded",
    bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-full-v25\.zip", source_hash)),
    source_hash,
)

for document in [
    "README.md",
    "AGENTS.md",
    "docs/release-notes.md",
    "docs/implementation-plan.md",
    "docs/implementation-changelog.md",
    "docs/sessions/v26.md",
    "docs/database-testing-v26.md",
]:
    text = read(document)
    check(f"{document} documents v26", "v26" in text or "0.26.0-v26" in text)

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV26 database contract checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
