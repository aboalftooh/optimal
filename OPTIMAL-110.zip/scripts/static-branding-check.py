#!/usr/bin/env python3
from pathlib import Path
import re
import struct
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []

def check(name: str, value: bool) -> None:
    checks.append((name, value))

manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
manifest_text = manifest_path.read_text(encoding="utf-8")
ET.parse(manifest_path)
check("manifest XML valid", True)
check("application icon declared", 'android:icon="@mipmap/ic_launcher"' in manifest_text)
check("round icon declared", 'android:roundIcon="@mipmap/ic_launcher_round"' in manifest_text)
check("application label declared", 'android:label="@string/app_name"' in manifest_text)
check("launcher activity label declared", manifest_text.count('android:label="@string/app_name"') >= 2)

strings = (ROOT / "app/src/main/res/values/strings.xml").read_text(encoding="utf-8")
check("launcher name OPTIMAL", '<string name="app_name">OPTIMAL</string>' in strings)

theme = (ROOT / "app/src/main/res/values/themes.xml").read_text(encoding="utf-8")
check("XML theme uses Tajawal", '@font/tajawal_regular' in theme)

typography = (ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTypography.kt").read_text(encoding="utf-8")
check("Compose family declared", 'val TajawalFontFamily = FontFamily(' in typography)
check("Compose typography uses family", typography.count('fontFamily = TajawalFontFamily') >= 10)

fonts = [
    "tajawal_light.ttf",
    "tajawal_regular.ttf",
    "tajawal_medium.ttf",
    "tajawal_bold.ttf",
    "tajawal_extra_bold.ttf",
]
font_root = ROOT / "core/designsystem/src/main/res/font"
check("all Tajawal weights exist", all((font_root / name).is_file() for name in fonts))
check("font license included", (ROOT / "docs/licenses/Tajawal-OFL.txt").is_file())

for name in ("ic_launcher.xml", "ic_launcher_round.xml"):
    path = ROOT / "app/src/main/res/mipmap-anydpi-v26" / name
    ET.parse(path)
check("adaptive icon XML valid", True)
check("adaptive foreground exists", (ROOT / "app/src/main/res/drawable-nodpi/ic_launcher_foreground.png").is_file())

def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as f:
        if f.read(8) != b"\x89PNG\r\n\x1a\n":
            return (0, 0)
        length = struct.unpack(">I", f.read(4))[0]
        if f.read(4) != b"IHDR" or length < 8:
            return (0, 0)
        return struct.unpack(">II", f.read(8))

expected = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}
legacy_ok = True
round_ok = True
for folder, size in expected.items():
    legacy_ok &= png_size(ROOT / "app/src/main/res" / folder / "ic_launcher.png") == (size, size)
    round_ok &= png_size(ROOT / "app/src/main/res" / folder / "ic_launcher_round.png") == (size, size)
check("legacy density icons valid", legacy_ok)
check("round density icons valid", round_ok)

build = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
check("branding version code preserved or advanced", any(f"versionCode = {v}" in build for v in range(2, 100)))
version_match = re.search(r'versionName\s*=\s*"0\.(\d+)\.0-v(\d+)"', build)
check("branding version name preserved or advanced", bool(version_match and int(version_match.group(1)) >= 6 and int(version_match.group(2)) >= 6))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + ": " + name)
print(f"\nBranding checks: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
