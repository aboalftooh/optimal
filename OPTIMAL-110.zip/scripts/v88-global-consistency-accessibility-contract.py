#!/usr/bin/env python3
"""SESSION-88 global Design System, accessibility, RTL, and legacy-cleanup gate."""
from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []

def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))
    if not condition:
        print(f"FAIL: {label}")

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

production_roots = [ROOT / "app/src/main", ROOT / "feature"]
production_files: list[Path] = []
for base in production_roots:
    if not base.exists():
        continue
    for path in base.rglob("*.kt"):
        posix = path.as_posix()
        if base.name == "feature" and "/src/main/" not in posix:
            continue
        if "/build/" in posix:
            continue
        production_files.append(path)
production_files = sorted(set(production_files))
check("production Kotlin inventory is non-empty", len(production_files) >= 100)

legacy_import = re.compile(r"^import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", re.M)
dp_literal = re.compile(r"\b\d+(?:\.\d+)?\.dp\b")
sp_literal = re.compile(r"\b\d+(?:\.\d+)?\.sp\b")
raw_hex = re.compile(r"Color\s*\(\s*0x[0-9A-Fa-f]+|#[0-9A-Fa-f]{6,8}")
legacy_palette = re.compile(
    r"\b(?:OptimalBlue|OptimalBlueBright|OptimalBlueDark|OptimalBlueSoft|OptimalBlueMist|"
    r"OptimalNavy|OptimalBackground|OptimalSurface|OptimalSurfaceVariant|OptimalOutline|"
    r"OptimalOutlineStrong|OptimalTextPrimary|OptimalTextSecondary|OptimalTextMuted|"
    r"OptimalSuccess|OptimalSuccessSoft|OptimalWarning|OptimalInfo|OptimalError|OptimalTeal|"
    r"OptimalTealDark|OptimalTealContainer|OptimalOnTealContainer)\b"
)

violations = {"legacy": [], "dp": [], "sp": [], "hex": [], "palette": []}
for path in production_files:
    source = path.read_text(encoding="utf-8")
    rel = str(path.relative_to(ROOT))
    if legacy_import.search(source): violations["legacy"].append(rel)
    if dp_literal.search(source): violations["dp"].append(rel)
    if sp_literal.search(source): violations["sp"].append(rel)
    if raw_hex.search(source): violations["hex"].append(rel)
    if legacy_palette.search(source): violations["palette"].append(rel)

check("no production legacy component imports", not violations["legacy"])
check("no production direct visual dp literals", not violations["dp"])
check("no production direct typography sp literals", not violations["sp"])
check("no production raw visual colors", not violations["hex"])
check("no production palette-oriented aliases", not violations["palette"])

legacy_dir = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component"
legacy_files = [p for p in legacy_dir.glob("*.kt") if p.is_file()]
check("retired legacy component source set removed", not legacy_files)

colors = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalColors.kt")
check("semantic colors remain canonical", "object OptimalSemanticColors" in colors)
check("palette compatibility declarations removed", not legacy_palette.search(colors))
spacing = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalSpacing.kt")
for token in ["touchTarget", "buttonHeight", "fieldHeight"]:
    check(f"legacy spacing alias removed:{token}", f"val {token}" not in spacing)

v2_dir = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2"
for filename in [
    "OptimalAppShell.kt", "OptimalBottomActions.kt", "OptimalButtons.kt", "OptimalCards.kt",
    "OptimalComponentDefaults.kt", "OptimalDialogs.kt", "OptimalFields.kt", "OptimalRows.kt",
    "OptimalScreenStates.kt", "OptimalSearchAndChips.kt", "OptimalSegments.kt", "OptimalStatus.kt",
]:
    check(f"v2 component exists:{filename}", (v2_dir / filename).is_file())

defaults = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalComponentDefaults.kt")
for token, expected in {
    "buttonMinHeight": "OptimalTouchTarget.comfortable",
    "iconButtonMinSize": "OptimalTouchTarget.minimum",
    "fieldMinHeight": "OptimalTouchTarget.comfortable",
    "listRowMinHeight": "OptimalTouchTarget.comfortable",
    "chipMinHeight": "OptimalTouchTarget.minimum",
}.items():
    check(f"48dp-class component default:{token}", f"val {token} = {expected}" in defaults)

buttons = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalButtons.kt")
check("icon buttons require readable content description", "contentDescription: String" in buttons)
check("icon buttons enforce minimum width", "minWidth = OptimalComponentDefaults.iconButtonMinSize" in buttons)
check("icon buttons enforce minimum height", "minHeight = OptimalComponentDefaults.iconButtonMinSize" in buttons)

rows = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalRows.kt")
check("list rows expose optional click label", "onClickLabel: String? = null" in rows)
check("clickable list rows expose Button role", "role = Role.Button" in rows)
check("clickable list rows keep comfortable minimum", "OptimalComponentDefaults.listRowMinHeight" in rows)

fields = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt")
check("selection fields expose labeled action", 'onClickLabel = "فتح خيارات $label"' in fields)
check("selection fields expose Button role", "role = Role.Button" in fields)

segments = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalSegments.kt")
check("segments use selectable semantics", ".selectable(" in segments and ".clickable" not in segments)
check("segments expose selected state", "selected = active" in segments)
check("segments expose Tab role", "role = Role.Tab" in segments)

app = read("app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt")
check("app enforces RTL composition", "LocalLayoutDirection provides LayoutDirection.Rtl" in app)
check("app loading state uses v2", "component.v2.OptimalLoadingState" in app)

all_production = "\n".join(p.read_text(encoding="utf-8") for p in production_files)
check("no forced LTR in production", "LayoutDirection.Ltr" not in all_production)
for token in [
    "Icons.Outlined.ArrowBack", "Icons.Outlined.ArrowForward", "Icons.Outlined.ChevronLeft",
    "Icons.Outlined.ChevronRight", "Icons.Outlined.KeyboardArrowLeft", "Icons.Outlined.KeyboardArrowRight",
    "Icons.Outlined.Send",
]:
    check(f"no fixed directional icon:{token}", token not in all_production)
check("RTL auto-mirrored directional icons are used", "Icons.AutoMirrored.Outlined.ArrowForward" in all_production)

verto_home = read("feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoHomeEntry.kt")
check("Verto Home migrated to v2 list row", "component.v2.OptimalListRow" in verto_home)
check("Verto Home has accessible click label", 'onClickLabel = "فتح التواصل مع Verto"' in verto_home)
check("Verto Home keeps entry tag", 'testTag("home-verto-entry")' in verto_home)
check("Verto Home keeps unread badge", 'testTag("verto-unread-badge")' in verto_home)

attachments = read("feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatAttachments.kt")
check("direct attachment surface has comfortable minimum target", "defaultMinSize(minHeight = OptimalTouchTarget.comfortable)" in attachments)
check("direct attachment surface has action label", 'onClickLabel = "فتح المرفق"' in attachments)
check("direct attachment surface has Button role", "role = Role.Button" in attachments)

# Direct interaction primitives are centralized in v2, with one documented feature-owned attachment surface.
direct_clickable = []
material_controls = []
for path in production_files:
    source = path.read_text(encoding="utf-8")
    rel = str(path.relative_to(ROOT))
    if ".clickable(" in source:
        direct_clickable.append(rel)
    if re.search(r"^import androidx\.compose\.material3\.(?:AlertDialog|Button|OutlinedButton|TextButton|ModalBottomSheet)", source, re.M):
        material_controls.append(rel)
check("only documented feature direct clickable remains", direct_clickable == ["feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatAttachments.kt"])
check("feature/app buttons dialogs sheets route through v2", not material_controls)

# Specialized Verto chat editor is the sole direct OutlinedTextField exception; behavior contract stays local to chat.
direct_fields = []
for path in production_files:
    source = path.read_text(encoding="utf-8")
    if re.search(r"^import androidx\.compose\.material3\.OutlinedTextField$", source, re.M):
        direct_fields.append(str(path.relative_to(ROOT)))
check("only specialized Verto composer owns direct text field", direct_fields == ["feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatComposer.kt"])

# Text scaling: rigid heights are allowed only for spacers/intrinsic layout, never content controls.
rigid_height_violations = []
for path in production_files:
    source = path.read_text(encoding="utf-8")
    lines = source.splitlines()
    for i, line in enumerate(lines):
        if ".height(" not in line:
            continue
        window = " ".join(lines[max(0, i-1):i+1])
        if "Spacer(" not in window and "IntrinsicSize.Min" not in line:
            rigid_height_violations.append(f"{path.relative_to(ROOT)}:{i+1}")
check("no rigid content-control heights in production", not rigid_height_violations)

auth_components = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt")
check("Auth loading control uses minimum not fixed height", "defaultMinSize(minHeight = OptimalTouchTarget.comfortable)" in auth_components and ".height(" not in auth_components)

foundation_test = read("core/designsystem/src/test/java/com/optimal/fleet/designsystem/FoundationContractTest.kt")
check("foundation test enforces 48dp minimum", "minimum.value >= 48f" in foundation_test)
check("foundation test no longer protects palette aliases", "LegacyAliases" not in foundation_test and not legacy_palette.search(foundation_test))
ui_test = read("core/designsystem/src/androidTest/java/com/optimal/fleet/designsystem/DesignSystemComponentTest.kt")
check("Design System UI test uses v2 primary button", "component.v2.OptimalPrimaryButton" in ui_test)
check("Design System UI test uses v2 sync status", "component.v2.OptimalSyncStatus" in ui_test)
check("Design System UI test has no legacy imports", not legacy_import.search(ui_test))

ledger = read("docs/design-system/MIGRATION-LEDGER.md")
check("migration ledger closes SESSION-88", "| Global Consistency + Accessibility | Migrated | v88 | No |" in ledger)
debt = read("docs/design-system/DESIGN-DEBT.md")
check("design debt records no known production legacy", "No known production Design Language legacy remains after SESSION-88" in debt)
state = read("docs/design-system/CURRENT-DESIGN-STATE.md")
check("current state advances to v88", "# CURRENT DESIGN STATE — v88" in state and "SESSION-89" in state)


# SESSION-88 is presentation/design-system only: lock touched feature behavior layers to v87.
def tree_hash(rel: str) -> str:
    digest = hashlib.sha256()
    base = ROOT / rel
    for path in sorted(base.rglob("*")):
        if path.is_file():
            digest.update(str(path.relative_to(ROOT)).encode())
            digest.update(b"\0")
            digest.update(path.read_bytes())
            digest.update(b"\0")
    return digest.hexdigest()

def file_hash(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

protected_trees = {
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain": "8b16d181b8b0231d0c4f6c0b703c91b056a5212102924bfad538c871b61efafa",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data": "39f039d3a2dbf514e678066efdddce297b25dacd5dc92f066f5e0d2616765449",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/navigation": "d234e774a636b3a6762a7225aa9e2cc261c1f88b31f07d30e607c24d081c5b97",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain": "ba53ad829ba0bcb7750cf5221aaf7c3883522bb76ed4c837f8ae840592692450",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data": "338fa7a4a621df6128867db30ab76d8a6b5b8d54d183e07a06ff7538e8d2a699",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/navigation": "616543fbfa86cd56d91a94b87cc2df3ffd199eab27984ee663e01d77c12aac2d",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain": "fc1435c6e223816aee066b433aa917678877e8c84a44466d542e45489904a127",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data": "b98dc8bf1d693c0336b4f647af61e000a6fa46323770ff14842438937087c931",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation": "1582beec6a295251327f16825721427267dee6edbd6729fb8aefe9a6f2137f77",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain": "bcf34c3f18d22ed6a1d7209347397f9e427c51a528d19a670c73dcc2141ec647",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data": "ca09349c43da216f8580d30e7da538cc65e94d3ecfaa26f49669e5a7da198e79",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation": "901eab0ca89b95011d23319321b2ce6dfa4ddaa9dbb52f871bc9f913ca1b2f8a",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain": "4525f4fc8f5dd55a4abf5e2146443de629d052f67c1721405adb133594598540",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data": "ba98e90d619d4e2d757c477bb0fd97b1250eeedbe97e127d26407459a9839bd0",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/di": "7267f438a631d304d66e5b1890d152169b7083433bb8292ad9743c90874fc301",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/navigation": "2649832acfeb55e356f70abed9df0ac5955537aff808feb581824b17d0e84352",
}
protected_files = {
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt": "a27802b41a0929864d97c8d09de6f6c4e5458d222a65fd5fbe060d196b38abb2",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt": "a2da9e11fc258a20e84142ad3d8aaf54b97ccb079a91f1b321d37f08fe108015",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountProfileContract.kt": "795dae883e2f7a8cde0d52e4f10de5edfd5635eca4388c5432498e3c03dd559a",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountProfileViewModel.kt": "12e8fb123d924f25aeb61bfa20353bb9332d2b329c4f90e36de819c02084add5",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt": "22a79f67f294eea5ababf7adad925af00f3c40189c83b0a99e975c4e9926a87e",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailViewModel.kt": "f8fcd64282d0c8ce414a61130e7207c84fa71e5dd8ed3e056b5b43605604c589",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt": "c5b3abf17663444b636e7fa9c46d58b9f07bb17124429d6d2ef05ef3ad05c178",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt": "857dc3a32745af87bd922bcb8e55c31448c5d89ee8aa97aa3d0e64d3952d7c37",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersContract.kt": "683dbf6f76031e07e3797a31c3f986c83047cc23df1d07a515a0324ed8a5b34f",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt": "f1422597725aedcdab569438448cb37908a850f959c6f58737f3b5671b89fe98",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt": "65e99bad21d55f9cfb080212abe8d053b5e56d0d79ecd8009316d879259df6d0",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt": "d160312ae48c1ced85dc0e102f3f9bc87c2f5d9a6c5a468359fa0c768f1469cb",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoEntryContract.kt": "f7ad803624e9c13f42ad26643fc4a2c0c77ce89034b92cf172cc756506a06daf",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoEntryViewModel.kt": "3e5e4c28d52d7c5930a0ada20cd10301e74d96936170adf1e0a6a7ca4365d854",
}
for rel, expected in protected_trees.items():
    check(f"behavior tree unchanged:{rel}", tree_hash(rel) == expected)
for rel, expected in protected_files.items():
    check(f"behavior file unchanged:{rel}", file_hash(rel) == expected)

failed = [label for label, ok in checks if not ok]
print(f"v88 global consistency/accessibility contract: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    for label in failed:
        print(" -", label)
    raise SystemExit(1)
