#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
create = (root / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create/CreateOperationRoute.kt').read_text()
follow = (root / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpRoute.kt').read_text()
fields = (root / 'core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt').read_text()
tests = (root / 'feature/maintenance/src/androidTest/java/com/optimal/fleet/feature/maintenance/presentation/MaintenanceUiTest.kt').read_text()
checks=[]
def check(label, cond):
    checks.append((label,bool(cond))); print(('PASS' if cond else 'FAIL')+': '+label)
def sha(rel): return hashlib.sha256((root/rel).read_bytes()).hexdigest()
def tree(rel):
    h=hashlib.sha256()
    for f in sorted((root/rel).rglob('*.kt')):
        h.update(str(f.relative_to(root)).encode()); h.update(b'\0'); h.update(f.read_bytes()); h.update(b'\0')
    return h.hexdigest()

for name,text in [('create',create),('followup',follow)]:
    check(f'{name} has no legacy DS import', re.search(r'import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', text) is None)
    check(f'{name} has no AppCard', 'AppCard' not in text)
    check(f'{name} has no direct dp literal', re.search(r'\b\d+(?:\.\d+)?\.dp\b', text) is None)
    check(f'{name} has no raw hex colors', '0xFF' not in text)

for token in ['OptimalFormSection','OptimalSelectionField','OptimalSegmentedControl','OptimalTextField','OptimalMoneyField','OptimalBottomActionBar']:
    check(f'create uses {token}', token in create)
for title in ['العملية','وصف الصيانة','العداد والتكلفة']:
    check(f'create section {title}', f'title = "{title}"' in create)
for tag in ['create-operation-identity-section','create-operation-description-section','create-operation-cost-section','create-operation-progress-status','save-operation']:
    check(f'create tag {tag}', f'"{tag}"' in create)
for event in ['VehicleSelected','TypeSelected','DescriptionChanged','OdometerChanged','PartsCostChanged','ServiceCostChanged','Save']:
    check(f'create event preserved {event}', f'CreateOperationUiEvent.{event}' in create)
for field in ['Vehicle','Type','Description','Odometer','PartsCost','ServiceCost']:
    check(f'create field validation {field}', f'CreateOperationField.{field}' in create)
check('create inline field errors', 'errorFor(' in create and 'supportingText' in create)
check('create error focus requesters', 'LaunchedEffect(state.fieldError)' in create and '.requestFocus()' in create)
check('create IME next/done', 'ImeAction.Next' in create and 'ImeAction.Done' in create and 'KeyboardActions(' in create)
check('create status cue is info', 'OptimalStatusTone.Info' in create)
check('create loading retained', 'create-operation-loading' in create)
check('create no vehicles retained', 'create-operation-no-vehicles' in create)
check('create saving label retained', 'جارٍ الحفظ…' in create)
check('create in-progress save label retained', 'حفظ كجاري المعالجة' in create)

for token in ['OptimalFilterChip','OptimalListRow','OptimalStatusBadge','OptimalPrimaryButton','OptimalEmptyState','OptimalLoadingState']:
    check(f'followup uses {token}', token in follow)
for status,tone in [('UPCOMING','Info'),('DUE','Warning'),('OVERDUE','Danger')]:
    check(f'followup {status} tone {tone}', f'FollowUpStatus.{status} -> OptimalStatusTone.{tone}' in follow)
for label in ['الكل','متأخرة','مستحقة','قادمة']:
    check(f'followup filter {label}', f'label = "{label}"' in follow)
for event in ['StatusChanged','CreateOperation','DismissMessage']:
    check(f'followup event preserved {event}', f'MaintenanceFollowUpUiEvent.{event}' in follow)
for token in ['item.vehicleName','item.plateNumber','item.reason','item.dueDateLabel','item.dueOdometerLabel','item.currentOdometerLabel','item.statusLabel']:
    check(f'followup data retained {token}', token in follow)
check('followup focused item scroll retained', 'focusFollowUpId' in follow and 'animateScrollToItem(index)' in follow)
check('followup create saving state retained', 'isCreatingOperation' in follow and 'جارٍ إنشاء العملية…' in follow)
check('followup error message dismissible', 'followup-message' in follow and 'DismissMessage' in follow)

check('v2 text field accepts keyboard actions', 'keyboardActions: KeyboardActions = KeyboardActions.Default' in fields and 'keyboardActions = keyboardActions' in fields)
check('v2 money field accepts keyboard actions', fields.count('keyboardActions: KeyboardActions = KeyboardActions.Default') >= 2)
check('UI test create flow added', 'createOperationUsesSectionedFormAndPreservesSaveEvent' in tests)
check('UI test create validation added', 'createOperationValidationMessageIsRenderedAtAffectedField' in tests)
check('UI test followup row added', 'followUpRowShowsSemanticStatusAndPreservesCreateEvent' in tests)
check('UI test followup filter added', 'followUpFilterPreservesStatusChangeEvent' in tests)

protected_files={
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create/CreateOperationContract.kt':'a20dfe4641c6aaec171941e83e07608d795f4e28e12883d83371bfba89399cb4',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create/CreateOperationViewModel.kt':'bcce7197126798562f2592fa38eba775bd99369669bab1eb129997f89923fe4f',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpContract.kt':'15c454596866335ff6daad81798221360d8d2c7ac3c5bcdcf21e048a86d304ee',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpViewModel.kt':'33295b4621c105d1efcbbfdfdecad3512566dbdea53dd20e2c4c1979516add4d',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt':'c0da7f24661b7154379589b0295fa27eb90b1e37b93d051c51a6704f744e373c',
}
protected_trees={
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain':'fc1435c6e223816aee066b433aa917678877e8c84a44466d542e45489904a127',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data':'b98dc8bf1d693c0336b4f647af61e000a6fa46323770ff14842438937087c931',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list':'9ab2d6c6d4c2a0690af36e24a2f33e195c3b04fc45f2371a5b0e7350abe64d1e',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history':'39e542db263960ba05ebad210af70fe44b68a3323babc44ae43e34269a8304a9',
'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details':'3257eb7167377897084d53fadf4ce6cf6c58aed67eeb99c667fa2db5a58bd6e9',
}
for rel,digest in protected_files.items(): check('protected file unchanged '+rel, sha(rel)==digest)
for rel,digest in protected_trees.items(): check('protected tree unchanged '+rel, tree(rel)==digest)

failed=[x for x in checks if not x[1]]
print(f'v81 Maintenance Create + Follow-up UX contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: raise SystemExit(1)
