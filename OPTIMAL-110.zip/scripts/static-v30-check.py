#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt",
    "core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorMapper.kt",
    "core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorPresentation.kt",
    "core/common/src/main/kotlin/com/optimal/fleet/core/common/error/SafeErrorReporter.kt",
    "core/common/src/test/kotlin/com/optimal/fleet/core/common/error/DomainErrorMapperTest.kt",
    "core/common/src/test/kotlin/com/optimal/fleet/core/common/error/SensitiveDataRedactorTest.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/error/AndroidSafeErrorReporter.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/error/ErrorReportingModule.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncErrorMapping.kt",
    "scripts/v30-error-harness.kt",
    "scripts/run-v30-error-harness.sh",
    "scripts/run-v30-presentation-compile.sh",
    "scripts/static-v30-check.py",
    "scripts/verify-v30-static.sh",
    "scripts/verify-v30-regressions.sh",
    "docs/error-model-v30.md",
    "docs/sessions/v30.md",
    "docs/verification-scripts-v30.md",
    "docs/source-archive-v30.sha256",
    "verification-v30.md",
    "docs/verifications/verification-v30.md",
    "PATCH_MANIFEST-v30.md",
    "CHANGED_FILES-v30.txt",
    "DELETED_FILES-v30.txt",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 25", bool(re.search(r"\bversionCode\s*=\s*25\b", build)))
check("versionName is v30", 'versionName = "0.30.0-v30"' in build)

model = read("core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt")
mapper = read("core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorMapper.kt")
presentation = read("core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorPresentation.kt")
redactor = read("core/common/src/main/kotlin/com/optimal/fleet/core/common/error/SafeErrorReporter.kt")
for category in ["Validation", "Authentication", "Permission", "Network", "Timeout", "Conflict", "Storage", "Unexpected"]:
    check(f"domain category exists: {category}", f"data class {category}(" in model)
    check(f"UI category exists: {category}", category.upper() in presentation)
check("technical cause remains infrastructure-only", "data class MappedFailure" in model and "technicalCause: Throwable?" in model)
check("domain error exception preserves cause", "class DomainErrorException" in model and "cause: Throwable?" in model)
check("correlation ID supports random generation", "UUID.randomUUID()" in model)
check("correlation ID supports deterministic operations", "UUID.nameUUIDFromBytes" in model)
check("reference code is safe and short", "take(8).uppercase()" in model)
check("domain error does not expose Throwable", "technicalCause" not in model.split("sealed interface DomainError", 1)[1].split("class DomainErrorException", 1)[0])

for status, category in [(400, "Validation"), (401, "Authentication"), (403, "Permission"), (408, "Timeout"), (409, "Conflict"), (429, "Network")]:
    check(f"HTTP {status} is mapped", f"statusCode == {status}" in mapper and f"DomainError.{category}" in mapper)
check("HTTP 5xx is retryable network", "statusCode >= 500" in mapper and "retryable = true" in mapper)
check("Supabase configuration is classified", "SupabaseNotConfiguredException" in mapper and "BACKEND_NOT_CONFIGURED" in mapper)
check("serialization is classified", "SerializationException" in mapper and "REMOTE_SERIALIZATION" in mapper)
check("Room and SQLite are classified", "SQLite" in mapper and "Room" in mapper and "ROOM_STORAGE" in mapper)
check("storage IO is distinct from network IO", "STORAGE_IO" in mapper and "NETWORK_IO" in mapper)
check("unknown exceptions remain unexpected", "UNEXPECTED_EXCEPTION" in mapper)

for secret in ["access[_-]?token", "refresh[_-]?token", "anon[_-]?key", "api[_-]?key", "password", "otp", "secret", "phone", "email"]:
    check(f"redactor covers {secret}", secret in redactor)
check("redacted logs are bounded", "MAX_SAFE_LOG_CHARS = 800" in redactor)

reporter = read("app/src/main/java/com/optimal/fleet/infrastructure/error/AndroidSafeErrorReporter.kt")
check("reporter uses redactor", "SensitiveDataRedactor.redact" in reporter)
check("reporter logs correlation ID", "correlationId=" in reporter)
check("reporter logs category and technical code", "category=" in reporter and " code=" in reporter)
check("reporter never logs Throwable object", not re.search(r"Log\.e\([^\n]*,\s*(cause|failure\.technicalCause|error)\s*\)", reporter))
check("reporter never logs cause message", ".message" not in reporter and "causeMessage" not in reporter)
check("Hilt binds the safe reporter", "bindSafeErrorReporter" in read("app/src/main/java/com/optimal/fleet/infrastructure/error/ErrorReportingModule.kt"))

# Broad catches are permitted only in data/infrastructure boundaries and tests.
generic_catches: list[tuple[str, int, str]] = []
for path in [*ROOT.glob("app/src/**/*.kt"), *ROOT.glob("core/src/**/*.kt"), *ROOT.glob("feature/src/**/*.kt")]:
    # The glob patterns above do not recurse module subdirectories; scan explicitly below instead.
    pass
for base in [ROOT / "app", ROOT / "core", ROOT / "feature"]:
    for path in base.rglob("*.kt"):
        rel = path.relative_to(ROOT).as_posix()
        if "/test/" in rel or "/androidTest/" in rel:
            continue
        lines = path.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            if re.search(r"catch\s*\([^)]*:\s*Exception\)", line):
                generic_catches.append((rel, index + 1, "\n".join(lines[index:index + 24])))

allowed_prefixes = (
    "app/src/main/java/com/optimal/fleet/work/",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/",
    "core/network/src/main/java/com/optimal/fleet/core/network/supabase/",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/",
)
for rel, line, window in generic_catches:
    check(f"generic catch is at infrastructure boundary: {rel}:{line}", rel.startswith(allowed_prefixes))
    check(
        f"generic catch maps before returning: {rel}:{line}",
        any(token in window for token in ["DomainErrorMapper", "mapFailure(", "reportAndWrap(", "failureMapper.fromThrowable", "wrap("]),
    )
    check(
        f"generic catch does not return legacy network result: {rel}:{line}",
        not re.search(r"return\s+[A-Za-z0-9_.]+NetworkError", window),
    )

presentation_catches = []
for path in (ROOT / "feature").rglob("*ViewModel.kt"):
    if re.search(r"catch\s*\([^)]*:\s*Exception\)", path.read_text(encoding="utf-8")):
        presentation_catches.append(path.relative_to(ROOT).as_posix())
for path in (ROOT / "app/src/main/java").rglob("*ViewModel.kt"):
    if re.search(r"catch\s*\([^)]*:\s*Exception\)", path.read_text(encoding="utf-8")):
        presentation_catches.append(path.relative_to(ROOT).as_posix())
check("ViewModels contain no broad exception catches", not presentation_catches, ", ".join(presentation_catches))

sync_transport = read("core/network/src/main/java/com/optimal/fleet/core/network/sync/SyncTransport.kt")
sync_impl = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SupabaseSyncTransport.kt")
dispatcher = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncOperationDispatcher.kt")
check("sync results carry correlation IDs", sync_transport.count("correlationId: String?") >= 3)
check("sync transport maps HTTP errors", "DomainErrorMapper.fromHttp" in sync_impl)
check("sync transport maps throwables", "DomainErrorMapper.fromThrowable" in sync_impl)
check("sync operations use deterministic correlation IDs", "CorrelationId.deterministic" in sync_impl and "CorrelationId.deterministic" in dispatcher)
check("sync dispatcher preserves cancellation", "throw cancellation" in dispatcher)
check("timeout is distinct from network", "DomainError.Timeout" in dispatcher and "OPERATION_TIMEOUT" in dispatcher)

worker = read("app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt")
notification_worker = read("app/src/main/java/com/optimal/fleet/work/FollowUpNotificationWorker.kt")
for name, content in [("sync worker", worker), ("notification worker", notification_worker)]:
    check(f"{name} maps uncaught infrastructure failures", "DomainErrorMapper.fromThrowable" in content)
    check(f"{name} retries only retryable failures", "failure.error.retryable" in content)
    check(f"{name} returns correlation reference", '"correlation_id"' in content)

keystore = read("core/network/src/main/java/com/optimal/fleet/core/network/supabase/AndroidKeystoreAuthSessionStore.kt")
check("keystore maps read, save and clear failures", all(token in keystore for token in ["auth_session.read", "auth_session.save", "auth_session.clear"]))
check("keystore wraps write failures safely", "DomainErrorException" in keystore and "reportAndWrap" in keystore)

models = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt")
auth_vm = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt")
auth_contract = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt")
check("auth results expose typed failures", models.count("data class Failure(val error: DomainError)") >= 5)
check("session restoration is typed", "sealed interface RestoreSessionResult" in models)
check("auth ViewModel handles every typed failure family", auth_vm.count("is ") >= 5 and auth_vm.count("Failure -> applyDomainFailure") >= 4)
check("auth UI state exposes category and reference", "errorKind: UiErrorKind?" in auth_contract and "errorReference: String?" in auth_contract)
check("auth ViewModel maps error category", "uiError.kind" in auth_vm and "uiError.referenceCode" in auth_vm)
check("OTP failure branch binds its result", "when (val result = verifyOtp" in auth_vm)

member_models = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt")
members_vm = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt")
members_contract = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersContract.kt")
check("member results expose typed failures", member_models.count("data class Failure(val error: DomainError)") >= 4)
check("members ViewModel handles typed failures", members_vm.count("is ") >= 4 and "applyDomainFailure" in members_vm)
check("members UI state exposes category and reference", "errorKind: UiErrorKind?" in members_contract and "errorReference: String?" in members_contract)

unit_mapper_test = read("core/common/src/test/kotlin/com/optimal/fleet/core/common/error/DomainErrorMapperTest.kt")
redactor_test = read("core/common/src/test/kotlin/com/optimal/fleet/core/common/error/SensitiveDataRedactorTest.kt")
check("mapper unit tests cover all eight categories", all(category in unit_mapper_test for category in ["Validation", "Authentication", "Permission", "Network", "Timeout", "Conflict", "Storage", "Unexpected"]))
check("redactor unit tests cover secrets", all(token in redactor_test.lower() for token in ["bearer", "token", "password", "otp", "phone", "email"]))
check("v30 harness has at least 30 assertions", len(re.findall(r"\bverify\(", read("scripts/v30-error-harness.kt"))) >= 30)

source_hash = read("docs/source-archive-v30.sha256").strip()
check("v29 source archive SHA-256 is recorded", bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-full-v29\.zip", source_hash)), source_hash)

for script in ["scripts/static-v30-check.py", "scripts/static-v29-check.py", "scripts/room-schema-drift-contract.py"]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid, detail = True, ""
    except py_compile.PyCompileError as error:
        valid, detail = False, str(error)
    check(f"Python syntax valid: {script}", valid, detail)

for script in ["scripts/run-v30-error-harness.sh", "scripts/run-v30-presentation-compile.sh", "scripts/verify-v30-static.sh", "scripts/verify-v30-regressions.sh", "scripts/verify-project.sh"]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result.returncode == 0, result.stderr.strip())

verify_project = read("scripts/verify-project.sh")
check("verify-project invokes v30 gates", "verify-v30-static.sh" in verify_project and "verify-v30-regressions.sh" in verify_project)
check("verify-project retains Gradle gates", all(command in verify_project for command in [
    "./gradlew clean", "./gradlew testDebugUnitTest", "./gradlew lintDebug", "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV30 unified-error checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
