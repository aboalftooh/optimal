#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cp "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" "$TMP/"
cp "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" "$TMP/"
cp "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionIdentity.kt" "$TMP/"
cp "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt" "$TMP/"
cp "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncStatusStore.kt" "$TMP/"
cat > "$TMP/InjectStubs.kt" <<'EOF'
package javax.inject
annotation class Inject
annotation class Singleton
EOF
cat > "$TMP/SyncStubs.kt" <<'EOF'
package com.optimal.fleet.coordinator.sync
import com.optimal.fleet.core.session.ActiveSession
class SyncManager { suspend fun runBatch(session: ActiveSession): SyncRunResult = SyncRunResult() }
data class SyncRunResult(val sessionChanged: Boolean = false, val shouldRetryWorker: Boolean = false)
EOF
cat > "$TMP/MaintenanceStubs.kt" <<'EOF'
package com.optimal.fleet.coordinator.verto
import com.optimal.fleet.core.session.ActiveSession
class VertoMaintenanceAutoImportCoordinator { suspend fun run(session: ActiveSession): VertoMaintenanceAutoImportResult = VertoMaintenanceAutoImportResult.Success }
sealed interface VertoMaintenanceAutoImportResult { data object Success : VertoMaintenanceAutoImportResult; data object SessionChanged : VertoMaintenanceAutoImportResult; data class Unavailable(val reason: String) : VertoMaintenanceAutoImportResult }
EOF
cat > "$TMP/FinanceStubs.kt" <<'EOF'
package com.optimal.fleet.feature.finance.domain.invoice.usecase
import com.optimal.fleet.core.session.ActiveSession
class DomainError(val retryable: Boolean)
class SyncVertoInvoices { suspend operator fun invoke(session: ActiveSession): SyncVertoInvoicesResult = SyncVertoInvoicesResult.Success }
sealed interface SyncVertoInvoicesResult { data object Success : SyncVertoInvoicesResult; data object SessionChanged : SyncVertoInvoicesResult; data class Unavailable(val reason: String, val error: DomainError? = null) : SyncVertoInvoicesResult }
EOF
cat > "$TMP/VertoRepositoryStubs.kt" <<'EOF'
package com.optimal.fleet.feature.verto.domain.repository
sealed interface VertoRefreshResult { data object Refreshed : VertoRefreshResult; data object SessionChanged : VertoRefreshResult; data class Unavailable(val reason: String) : VertoRefreshResult }
EOF
cat > "$TMP/VertoUseCaseStubs.kt" <<'EOF'
package com.optimal.fleet.feature.verto.domain.usecase
import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.feature.verto.domain.repository.VertoRefreshResult
class PullVertoMessagesUseCase { suspend operator fun invoke(session: ActiveSession): VertoRefreshResult = VertoRefreshResult.Refreshed }
EOF
KOTLIN_LIB="${KOTLIN_HOME:-/root/.sdkman/candidates/kotlin/current}/lib"
kotlinc "$TMP"/*.kt -cp "$KOTLIN_LIB/kotlinx-coroutines-core-jvm.jar" -d "$TMP/out.jar" >/dev/null
printf 'PASS: focused semantic compilation for v64 unified coordinator/status/session identity.\n'
