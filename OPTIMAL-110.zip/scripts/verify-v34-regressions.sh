#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
./scripts/run-v33-paging-harness.sh
python3 scripts/v33-paging-contract.py
python3 scripts/v33-room-query-contract.py
./scripts/run-v33-domain-compile.sh
./scripts/run-v33-presentation-compile.sh
./scripts/verify-v33-regressions.sh
