#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition):
    if not condition:
        raise SystemExit(f"FAIL: {name}")
    checks.append(name)
    print(f"PASS: {name}")

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

required = [
    "docs/pilot-checklist.md",
    "docs/release-notes-v17.md",
    "docs/final-architecture.md",
    "docs/install-and-verification.md",
    "docs/final-acceptance-matrix.md",
    "docs/manual-test-scenarios.md",
    "docs/verifications/verification-v17.md",
]
for item in required:
    check(f"exists {item}", (ROOT / item).is_file())

gradle = read("app/build.gradle.kts")
version_code_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
version_name_match = re.search(r'versionName\s*=\s*"0\.(\d+)\.0-v(\d+)"', gradle)
check("versionCode 13 or later", version_code_match is not None and int(version_code_match.group(1)) >= 13)
check(
    "versionName v17 or later",
    version_name_match is not None
    and int(version_name_match.group(1)) >= 17
    and int(version_name_match.group(2)) >= 17,
)

architecture = read("docs/final-architecture.md")
for module in [":app", ":core:session", ":core:database", ":feature:vehicles", ":feature:maintenance", ":feature:finance"]:
    check(f"architecture documents {module}", module in architecture)
check("Room is source of truth", "Room" in architecture and "مصادر الحقيقة" in architecture)
check("Verto ownership documented", "Verto" in architecture and "للقراءة فقط" in architecture)
check("company isolation documented", "companyId" in architecture)
check("sync disabled documented", "SYNC_ENABLED=false" in architecture)

acceptance = read("docs/final-acceptance-matrix.md")
rows = re.findall(r"^\|\s*(\d+)\s*\|", acceptance, flags=re.MULTILINE)
check("14 acceptance rows", rows == [str(i) for i in range(1, 15)])
check("release decision explicit", "NO-GO" in acceptance)
check("manual pilot unresolved", "NOT_RUN" in acceptance)

release = read("docs/release-notes-v17.md")
check("release candidate stated", "Release Candidate" in release)
check("transport limitation stated", "Transport" in release and "غير مفعّل" in release)
check("no production-ready claim", "NO-GO للإنتاج" in release)

pilot = read("docs/pilot-checklist.md")
for term in ["شركة غير مرتبطة", "Offline", "Verto", "العزل", "TalkBack", "قرار Pilot"]:
    check(f"pilot covers {term}", term in pilot)

install = read("docs/install-and-verification.md")
for command in ["compileDebugKotlin", "testDebugUnitTest", "lintDebug", "assembleDebug", "connectedDebugAndroidTest"]:
    check(f"install guide includes {command}", command in install)

session = read("docs/sessions/v17-pilot-e2e-final.md")
check("v17 session not falsely DONE", "`BLOCKED`" in session)
verification = read("docs/verifications/verification-v17.md")
check("verification records blocked Gradle", "UnknownHostException" in verification)
check("verification records no device tests", "NOT_RUN" in verification and "connectedDebugAndroidTest" in verification)

check("no backend SDK introduced in v17", not any((ROOT / p).exists() for p in ["app/google-services.json", "local.properties"]))

print(f"RESULT: {len(checks)}/{len(checks)} passed")
