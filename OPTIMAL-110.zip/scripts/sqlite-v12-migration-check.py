#!/usr/bin/env python3
import sqlite3

checks = 0

def verify(name: str, condition: bool):
    global checks
    if not condition:
        raise AssertionError(name)
    checks += 1
    print(f"PASS: {name}")

connection = sqlite3.connect(":memory:")
connection.execute("PRAGMA foreign_keys = ON")
connection.execute("CREATE TABLE companies(id TEXT NOT NULL PRIMARY KEY)")
connection.execute("INSERT INTO companies(id) VALUES ('company-1')")
connection.executescript(
    """
    CREATE TABLE audit_events (
        id TEXT NOT NULL PRIMARY KEY,
        companyId TEXT NOT NULL,
        actorUserId TEXT,
        actorDisplayName TEXT NOT NULL,
        actorSource TEXT NOT NULL,
        action TEXT NOT NULL,
        entityType TEXT NOT NULL,
        entityId TEXT NOT NULL,
        vehicleId TEXT,
        operationId TEXT,
        summary TEXT NOT NULL,
        encodedChanges TEXT NOT NULL,
        sourceReference TEXT,
        occurredAtEpochMillis INTEGER NOT NULL,
        FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE INDEX index_audit_events_companyId_occurredAtEpochMillis
        ON audit_events(companyId, occurredAtEpochMillis);
    CREATE INDEX index_audit_events_companyId_entityType_entityId_occurredAtEpochMillis
        ON audit_events(companyId, entityType, entityId, occurredAtEpochMillis);
    CREATE INDEX index_audit_events_companyId_vehicleId_occurredAtEpochMillis
        ON audit_events(companyId, vehicleId, occurredAtEpochMillis);
    CREATE INDEX index_audit_events_companyId_operationId_occurredAtEpochMillis
        ON audit_events(companyId, operationId, occurredAtEpochMillis);
    CREATE INDEX index_audit_events_actorUserId_companyId
        ON audit_events(actorUserId, companyId);
    CREATE TRIGGER audit_events_no_update
    BEFORE UPDATE ON audit_events
    BEGIN
        SELECT RAISE(ABORT, 'audit_events are append-only');
    END;
    CREATE TRIGGER audit_events_no_delete
    BEFORE DELETE ON audit_events
    BEGIN
        SELECT RAISE(ABORT, 'audit_events are append-only');
    END;
    """
)

columns = {row[1] for row in connection.execute("PRAGMA table_info(audit_events)")}
verify("table has id", "id" in columns)
verify("table has companyId", "companyId" in columns)
verify("table has actor source", "actorSource" in columns)
verify("table has action", "action" in columns)
verify("table has entity scope", {"entityType", "entityId"}.issubset(columns))
verify("table has vehicle scope", "vehicleId" in columns)
verify("table has operation scope", "operationId" in columns)
verify("table has before after payload", "encodedChanges" in columns)
verify("table has source reference", "sourceReference" in columns)
verify("table has timestamp", "occurredAtEpochMillis" in columns)

connection.execute(
    """
    INSERT INTO audit_events VALUES (
        'event-1', 'company-1', 'user-1', 'أحمد', 'USER', 'VEHICLE_UPDATED',
        'VEHICLE', 'vehicle-1', 'vehicle-1', NULL, 'تم تعديل السيارة',
        'encoded', NULL, 1000
    )
    """
)
verify("append succeeds", connection.execute("SELECT COUNT(*) FROM audit_events").fetchone()[0] == 1)

try:
    connection.execute("UPDATE audit_events SET summary = 'changed' WHERE id = 'event-1'")
    update_blocked = False
except sqlite3.DatabaseError:
    update_blocked = True
verify("update blocked", update_blocked)

try:
    connection.execute("DELETE FROM audit_events WHERE id = 'event-1'")
    delete_blocked = False
except sqlite3.DatabaseError:
    delete_blocked = True
verify("delete blocked", delete_blocked)
verify("event retained", connection.execute("SELECT COUNT(*) FROM audit_events").fetchone()[0] == 1)

indexes = {row[1] for row in connection.execute("PRAGMA index_list(audit_events)")}
verify("company timeline index", "index_audit_events_companyId_occurredAtEpochMillis" in indexes)
verify("entity timeline index", "index_audit_events_companyId_entityType_entityId_occurredAtEpochMillis" in indexes)
verify("vehicle timeline index", "index_audit_events_companyId_vehicleId_occurredAtEpochMillis" in indexes)
verify("operation timeline index", "index_audit_events_companyId_operationId_occurredAtEpochMillis" in indexes)
verify("actor index", "index_audit_events_actorUserId_companyId" in indexes)

rows = connection.execute(
    "SELECT summary FROM audit_events WHERE companyId = ? ORDER BY occurredAtEpochMillis DESC LIMIT ?",
    ("company-1", 100),
).fetchall()
verify("company-scoped query", rows == [("تم تعديل السيارة",)])

print(f"RESULT: {checks}/{checks} passed")
