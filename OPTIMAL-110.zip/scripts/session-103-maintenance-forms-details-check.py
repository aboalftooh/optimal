#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

base = "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation"
create = read(f"{base}/create/CreateOperationRoute.kt")
details_route = read(f"{base}/details/MaintenanceDetailsRoute.kt")
details = read(f"{base}/details/MaintenanceDetailsContent.kt")
components = read(f"{base}/details/MaintenanceDetailsComponents.kt")
completion = read(f"{base}/details/MaintenanceCompletionContent.kt")
edit = read(f"{base}/details/MaintenanceEditContent.kt")
fields = read("core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt")

# Generic DS menu support required by OVL-001.
check("canonical dropdown menu API exists", "fun OptimalDropdownMenu(" in fields)
check("canonical dropdown item API exists", "fun OptimalDropdownMenuItem(" in fields)
check("menu wrapper delegates to Material popup inside DS", "DropdownMenu(" in fields)
check("menu item uses canonical typography role", "style = OptimalTypographyRoles.body" in fields)

# SCR-013 / OVL-001 / STA-036..038.
check("create route exists", "fun CreateOperationRoute(" in create)
check("create loading canonical", "OptimalLoadingState(" in create)
check("create loading tag preserved", 'testTag("create-operation-loading")' in create)
check("create no-vehicles canonical", "OptimalEmptyState(" in create)
check("create no-vehicles tag preserved", 'testTag("create-operation-no-vehicles")' in create)
check("create form sections canonical", create.count("OptimalFormSection(") >= 3)
check("create text field canonical", "OptimalTextField(" in create)
check("create money fields canonical", "OptimalMoneyField(" in create)
check("create type segment canonical", "OptimalSegmentedControl(" in create)
check("create in-progress semantic status", '"جاري المعالجة بعد الحفظ"' in create and "OptimalStatusTone.Info" in create)
check("create field focus behavior retained", "LaunchedEffect(state.fieldError)" in create and ".requestFocus()" in create)
check("create non-field error semantic", "OptimalInlineStatus(" in create and 'title = "تعذر حفظ العملية"' in create and "OptimalStatusTone.Danger" in create)
check("create persistent action canonical", "OptimalBottomActionBar(" in create)
check("create save callback preserved", "CreateOperationUiEvent.Save" in create)
check("create saving disable preserved", "primaryEnabled = !state.isSaving" in create)
check("vehicle selector uses canonical selection field", "OptimalSelectionField(" in create)
check("vehicle selector overlay uses DS menu", "OptimalDropdownMenu(" in create and "OptimalDropdownMenuItem(" in create)
check("vehicle selector no direct Material menu", re.search(r"(?<!Optimal)\bDropdownMenu(?:Item)?\s*\(", create) is None)
check("vehicle select callback preserved", "CreateOperationUiEvent.VehicleSelected(it)" in create)
check("type select callback preserved", "CreateOperationUiEvent.TypeSelected(it)" in create)
for token in [
    "DescriptionChanged(it)", "OdometerChanged(it)", "PartsCostChanged(it)", "ServiceCostChanged(it)",
    'testTag = "operation-description"', 'testTag = "operation-odometer"',
    'tag = "operation-parts-cost"', 'tag = "operation-service-cost"',
]:
    check(f"create input preserved: {token}", token in create)

# SCR-016 / STA-039..041.
check("details route exists", "fun MaintenanceDetailsRoute(" in details_route)
check("details loading canonical", "state.isLoading -> OptimalLoadingState(" in details_route)
check("details loading tag preserved", 'testTag("maintenance-details-loading")' in details_route)
check("details error canonical", "state.errorMessage != null -> OptimalErrorState(" in details_route)
check("details error tag preserved", 'testTag("maintenance-details-error")' in details_route)
check("details not-found canonical", "state.details == null -> OptimalEmptyState(" in details_route)
check("details not-found copy preserved", '"العملية غير موجودة"' in details_route)
check("completion remains route mode", "state.isCompleting -> MaintenanceCompletionContent(state, onEvent)" in details_route)
check("edit remains route mode", "state.isEditing -> MaintenanceEditContent(state, onEvent)" in details_route)
check("no new details route introduced", details_route.count("fun MaintenanceDetailsRoute(") == 1)
check("details summary uses canonical hero", "OptimalHeroSurface(" in components)
check("details summary status semantic", "OptimalStatusBadge(" in components and "OptimalStatusTone.Info" in components and "OptimalStatusTone.Success" in components)
check("details grouped with section headers", details.count("OptimalSectionHeader(") >= 4)
check("details rows canonical", "OptimalListRow(" in details)
check("details financial metrics canonical", "OptimalMetricCard(" in details)
check("details Verto finance fallback preserved", '"تظهر في فاتورة Verto الأصلية فقط."' in details)
check("details invoice preserved", '"فاتورة Verto"' in details)
check("details attachments preserved", '"المرفقات"' in details)
check("official record preserved", "OfficialMaintenanceRecordSection(" in details)
check("activity callback preserved", "MaintenanceDetailsUiEvent.OpenActivity" in details)
check("complete callback preserved", "MaintenanceDetailsUiEvent.StartCompletion" in details)
check("edit callback preserved", "MaintenanceDetailsUiEvent.StartEdit" in details)
check("details action error semantic", "OptimalInlineStatus(" in details and "OptimalStatusTone.Danger" in details)
check("details error dismiss preserved", "MaintenanceDetailsUiEvent.DismissMessage" in details)

# SCR-017 / STA-042.
check("completion screen exists", "fun MaintenanceCompletionContent(" in completion)
check("completion form sections canonical", completion.count("OptimalFormSection(") >= 3)
check("completion persistent bottom action", "OptimalBottomActionBar(" in completion)
check("completion action sits outside scroll content", completion.index("OptimalBottomActionBar(") > completion.index(".verticalScroll("))
check("completion confirm callback preserved", "MaintenanceDetailsUiEvent.ConfirmCompletion" in completion)
check("completion cancel callback preserved", "MaintenanceDetailsUiEvent.CancelCompletion" in completion)
check("completion saving disable preserved", "primaryEnabled = !state.isSaving" in completion)
check("completion semantic non-field failure", "OptimalInlineStatus(" in completion and 'title = "تعذر إكمال العملية"' in completion)
for event in [
    "CompletionDescriptionChanged", "CompletionDateChanged", "CompletionOdometerChanged",
    "CompletionPartsCostChanged", "CompletionServiceCostChanged", "FollowUpReasonChanged",
    "FollowUpDateChanged", "FollowUpOdometerChanged",
]:
    check(f"completion callback preserved: {event}", f"MaintenanceDetailsUiEvent.{event}" in completion)
for field in [
    "Description", "CompletionDate", "Odometer", "PartsCost", "ServiceCost",
    "FollowUpReason", "FollowUpDate", "FollowUpOdometer",
]:
    check(f"completion validation field preserved: {field}", f"MaintenanceCompletionField.{field}" in completion)
check("completion Verto cost lock preserved", "details.source == OperationSource.MANUAL" in completion)

# SCR-018 / STA-043.
check("edit screen exists", "fun MaintenanceEditContent(" in edit)
check("edit form sections canonical", edit.count("OptimalFormSection(") >= 2)
check("edit persistent bottom action", "OptimalBottomActionBar(" in edit)
check("edit action sits outside scroll content", edit.index("OptimalBottomActionBar(") > edit.index(".verticalScroll("))
check("edit save callback preserved", "MaintenanceDetailsUiEvent.SaveEdit" in edit)
check("edit cancel callback preserved", "MaintenanceDetailsUiEvent.CancelEdit" in edit)
check("edit saving disable preserved", "primaryEnabled = !state.isSaving" in edit)
check("edit semantic non-field failure", "OptimalInlineStatus(" in edit and 'title = "تعذر حفظ التعديل"' in edit)
check("edit type segmented control preserved", "OptimalSegmentedControl(" in edit)
for event in ["TypeChanged", "DescriptionChanged", "OdometerChanged", "PartsCostChanged", "ServiceCostChanged"]:
    check(f"edit callback preserved: {event}", f"MaintenanceDetailsUiEvent.{event}" in edit)
for field in ["Type", "Description", "Odometer", "PartsCost", "ServiceCost"]:
    check(f"edit validation field preserved: {field}", f"MaintenanceEditField.{field}" in edit)

# Functional boundary: non-visual create/details implementation stays byte-identical to supplied v102.
expected_hashes = {
    f"{base}/create/CreateOperationContract.kt": "a20dfe4641c6aaec171941e83e07608d795f4e28e12883d83371bfba89399cb4",
    f"{base}/create/CreateOperationViewModel.kt": "bcce7197126798562f2592fa38eba775bd99369669bab1eb129997f89923fe4f",
    f"{base}/details/MaintenanceDetailsContract.kt": "c5b3abf17663444b636e7fa9c46d58b9f07bb17124429d6d2ef05ef3ad05c178",
    f"{base}/details/MaintenanceDetailsFormParser.kt": "4c40149311690cfb622169ab3c13e2a4d04f7a5592f45c8c951dcd214de32049",
    f"{base}/details/MaintenanceDetailsStateReducer.kt": "52f32e8197add31391ecfac2708f7125039343058db8fd3f409d451ff2565757",
    f"{base}/details/MaintenanceDetailsUiMapper.kt": "f5def88b9e2e7189d045b4bb0a7fac7fb0f6812fad9730fa506af7425c0bf3a0",
    f"{base}/details/MaintenanceDetailsViewModel.kt": "857dc3a32745af87bd922bcb8e55c31448c5d89ee8aa97aa3d0e64d3952d7c37",
}
for rel, expected in expected_hashes.items():
    actual = sha256(rel)
    check(f"v102 behavior unchanged: {Path(rel).name}", actual == expected, actual)

# All target UI must be free of local visual-language violations.
target_ui = [
    f"{base}/create/CreateOperationRoute.kt",
    f"{base}/details/MaintenanceCompletionContent.kt",
    f"{base}/details/MaintenanceDetailsComponents.kt",
    f"{base}/details/MaintenanceDetailsContent.kt",
    f"{base}/details/MaintenanceDetailsRoute.kt",
    f"{base}/details/MaintenanceEditContent.kt",
]
for rel in target_ui:
    text = read(rel)
    check(f"{Path(rel).name} no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", text) is None)
    check(f"{Path(rel).name} no raw hex color", "Color(0x" not in text)
    check(f"{Path(rel).name} no local font", "FontFamily(" not in text and "fontFamily =" not in text)
    check(f"{Path(rel).name} no direct Material field", re.search(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(", text) is None)
    check(f"{Path(rel).name} no direct Material button", re.search(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(", text) is None)
    check(f"{Path(rel).name} no direct AlertDialog", re.search(r"(?<![A-Za-z0-9_])AlertDialog\s*\(", text) is None)

# Ledger / allowlist acceptance.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_103 = {"SCR-013", "SCR-016", "SCR-017", "SCR-018", "OVL-001", *(f"STA-{i:03d}" for i in range(36, 44))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("all SESSION-103 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_103), str(sorted(i for i in expected_103 if statuses.get(i) != "MIGRATED")))
check("ledger migrated total is 69", sum(status == "MIGRATED" for _, status in rows) == 69)
check("ledger unmigrated total is 54", sum(status == "UNMIGRATED" for _, status in rows) == 54)
check("ledger has no blocked rows", all(status != "BLOCKED" for _, status in rows))

allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("entire Maintenance feature removed from allowlist", not any(path.startswith("feature/maintenance/") for path in allow))
check("remaining allowlist is 32 UI files", len(allow) == 32, str(len(allow)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-103 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
