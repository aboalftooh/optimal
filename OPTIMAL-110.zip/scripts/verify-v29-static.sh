#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/static-architecture-check.py
python3 scripts/static-v29-check.py
./scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
python3 scripts/v29-sync-contract.py
./scripts/run-v29-sync-harness.sh
python3 scripts/v21-backend-contract-harness.py
./scripts/run-v09-invoice-harness.sh
./scripts/run-v20-domain-harness.sh
