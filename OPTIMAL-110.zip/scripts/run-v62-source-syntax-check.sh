#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/verto/VertoInvoiceMaintenanceCoordinator.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/CrossFeatureArchitectureTest.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/coordinator/verto/LinkInvoiceToVehicleTest.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/coordinator/verto/ImportIdempotencyTest.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/notifications/NotificationArchitectureTest.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/NotificationDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/model/NotificationCandidateRows.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/linking/LinkVertoInvoice.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardContract.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardViewModel.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListComponents.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListContract.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt"
  "$ROOT_DIR/feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeComponents.kt"
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/data/RoomNotificationCandidateSource.kt"
)
for file in "${FILES[@]}"; do
  [[ -f "$file" ]] || { echo "FAIL: missing v62 Kotlin source: $file" >&2; exit 1; }
done
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
PARSER_PATTERN='error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)'
if grep -Eiq "$PARSER_PATTERN" "$OUT"; then
  grep -Ein "$PARSER_PATTERN" "$OUT"
  echo "FAIL: v62 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v62 Kotlin parser timed out" >&2
  exit 1
fi
printf 'PASS: Kotlin parser accepted %s v62 files; unresolved external symbols were ignored.\n' "${#FILES[@]}"
