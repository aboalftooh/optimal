#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def check(name: str, condition: bool) -> None:
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {name}")
    checks += 1
    print(f"PASS: {name}")


required = [
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/LocalOtpRepository.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RequestLocalOtpUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/VerifyLocalOtpUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/CompleteLocalOnboardingUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/InMemoryLocalOtpRepository.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountRoute.kt",
    "scripts/run-v18-domain-harness.sh",
    "scripts/v18-domain-harness.kt",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
models = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt")
contract = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt")
view_model = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt")
route = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt")
nav = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/navigation/AuthNavigation.kt")
app_nav = read("app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt")
app_shell = read("app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt")
repo = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomCompanyBootstrapRepository.kt")
otp_repo = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/InMemoryLocalOtpRepository.kt")
policy = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")

check("versionCode 14", "versionCode = 14" in build)
check("versionName v18", 'versionName = "0.18.0-v18"' in build)
check("Room schema unchanged at 12", "version = 12" in database)
check("join code step", "JoinCode" in models and "join-code" in route)
check("phone step", "Phone" in models and "auth-phone" in route)
check("OTP step", "Otp" in models and "auth-otp" in route)
check("company data step", "CompanyData" in models and "company-name" in route and "user-name" in route)
check("success step", "Success" in models and "onboarding-result" in route)
check("account screen", "Account" in models and "destination-account" in read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountRoute.kt"))
check("active account state", "AccountStatus.Active" in view_model and "الحساب نشط" in route)
check("pending account state", "AccountStatus.PendingActivation" in view_model and "بانتظار إكمال التفعيل" in route)
check("disabled account state", "AccountStatus.Disabled" in view_model and "الحساب معطل" in route)
check("join code length eight", "JOIN_CODE_LENGTH = 8" in policy)
check("OTP length six", "OTP_LENGTH = 6" in policy)
check("phone validation bounded", "digits.length in 9..15" in policy)
check("local OTP uses SecureRandom", "SecureRandom" in otp_repo)
check("local OTP expires", "OTP_TTL_MILLIS" in otp_repo and "expiresAtEpochMillis" in otp_repo)
check("local OTP limits attempts", "MAX_ATTEMPTS" in otp_repo and "AttemptsExceeded" in otp_repo)
check("local OTP constant-time compare", "constantTimeEquals" in otp_repo)
check("local OTP is explicitly temporary in UI", "اختبار محلي فقط" in route)
check("auth and account routes separated", 'AUTH_ROUTE = "auth/onboarding"' in nav and 'ACCOUNT_ROUTE = "account"' in nav)
check("settings account opens account route", "navigate(ACCOUNT_ROUTE)" in app_nav)
check("session gate does not skip success screen", "is SessionGateState.SignedIn -> Unit" in app_shell)
check("presentation has no data imports", not re.search(r"^import .*\.data\.", view_model, re.MULTILINE))
check("presentation has no Room or DAO", not re.search(r"\b(Room|Dao|WorkManager|Retrofit)\b", view_model + route))
check("create or restore contract", "createOrRestoreLocalAccount" in read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/CompanyBootstrapRepository.kt"))
check("existing user lookup by phone", "findByNormalizedPhone" in repo)
check("disabled user blocked", "LocalAccountDisabledException" in repo)
check("company mismatch blocked", "LocalCompanyMismatchException" in repo)
check("company user and session written transactionally", "database.withTransaction" in repo and "upsertSession" in repo)
check("companyId generated in data adapter", "UUID.randomUUID" in repo)
check("no password field", "PasswordVisualTransformation" not in route and not re.search(r"\bpassword\s*[:=]", contract + route + view_model, re.IGNORECASE))
check("no Supabase SDK in auth", "supabase" not in "\n".join(read(path) for path in required).lower())
check("no service role secret", "service_role" not in "\n".join(read(path) for path in required).lower())
check("view model full flow events", all(name in contract for name in ["SubmitJoinCode", "RequestOtp", "VerifyOtp", "CompleteOnboarding"]))
check("view model restore session", "restoreSession()" in view_model)
check("view model sign out", "signOut()" in view_model)
check("unit onboarding policy test", (ROOT / "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicyTest.kt").is_file())
check("unit completion test", (ROOT / "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/CompleteLocalOnboardingUseCaseTest.kt").is_file())
check("view model flow test", "fullLocalOnboardingCreatesSession" in read("feature/auth/src/test/java/com/optimal/fleet/feature/auth/presentation/AuthViewModelTest.kt"))
check("Compose onboarding test", "firstRunStartsWithJoinCode" in read("feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AuthScreenTest.kt"))
check("navigation test covers account", "destination-account" in read("app/src/androidTest/java/com/optimal/fleet/NavigationGraphTest.kt"))
check("domain harness runner executable", (ROOT / "scripts/run-v18-domain-harness.sh").stat().st_mode & 0o111 != 0)
check("domain harness wired", "run-v18-domain-harness.sh" in read("scripts/verify-project.sh"))

print(f"RESULT: {checks}/{checks} passed")
