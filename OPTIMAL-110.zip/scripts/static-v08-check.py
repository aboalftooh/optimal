#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
checks=[]
def read(rel): return (ROOT/rel).read_text(encoding='utf-8')
def check(name, ok):
    checks.append(bool(ok)); print(('PASS' if ok else 'FAIL')+': '+name)

required=[
'core/database/src/main/java/com/optimal/fleet/core/database/sync/PendingSyncOperationEntity.kt',
'core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncConflictAuditEntity.kt',
'core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueConstants.kt',
'core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt',
'core/network/src/main/java/com/optimal/fleet/core/network/sync/SyncTransport.kt',
'app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt',
'app/src/main/java/com/optimal/fleet/coordinator/sync/SyncParticipant.kt',
'app/src/main/java/com/optimal/fleet/coordinator/sync/VehicleSyncParticipant.kt',
'app/src/main/java/com/optimal/fleet/coordinator/sync/MaintenanceSyncParticipant.kt',
'app/src/main/java/com/optimal/fleet/coordinator/sync/SyncRetryPolicy.kt',
'app/src/main/java/com/optimal/fleet/coordinator/sync/DescriptionConflictResolver.kt',
'app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt',
'app/src/main/java/com/optimal/fleet/work/SyncScheduler.kt',
'app/src/main/java/com/optimal/fleet/sync/SyncStatusViewModel.kt',
]
for r in required: check('required '+r, (ROOT/r).is_file())
check('required SyncQueueMonitor', (ROOT/'app/src/main/java/com/optimal/fleet/coordinator/sync/SyncQueueMonitor.kt').is_file())

entity=read(required[0]); conflict=read(required[1]); dao=read(required[3]); db=read('core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt'); mig=read('core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt')
for f in ['companyId','aggregateType','aggregateId','operationType','payload','idempotencyKey','localVersion','state','attemptCount','nextAttemptAtEpochMillis','leaseUntilEpochMillis','lastErrorCode','remoteId','remoteVersion','createdAtEpochMillis','updatedAtEpochMillis']:
    check('queue field '+f, f'val {f}:' in entity)
check('idempotency unique', 'Index(value = ["idempotencyKey"], unique = true)' in entity)
check('queue company FK', 'childColumns = ["companyId"]' in entity)
check('queue company state due index', 'companyId", "state", "nextAttemptAtEpochMillis' in entity)
for f in ['losingPayload','winningPayload','resolution','localVersion','remoteVersion']:
    check('conflict audit '+f, f'val {f}:' in conflict)
check('db version at least six', any(f'version = {v}' in db for v in range(6, 20)))
check('queue entities registered', all(x in db for x in ['PendingSyncOperationEntity::class','SyncConflictAuditEntity::class']))
check('sync dao exposed', 'abstract fun syncQueueDao()' in db)
check('migration 5 to 6', 'MIGRATION_5_6' in mig and 'Migration(5, 6)' in mig)
check('migration creates queue', 'CREATE TABLE IF NOT EXISTS `pending_sync_operations`' in mig)
check('migration creates conflict audit', 'CREATE TABLE IF NOT EXISTS `sync_conflict_audit`' in mig)
check('schema six exported', (ROOT/'core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/6.json').is_file())

for token in ['findDue','claimDueBatch','markSucceeded','markRetry','markPermanentFailure','recoverExpiredLeases','observeSummary']:
    check('queue dao '+token, token in dao)
check('claim only pending retry', "state IN ('PENDING', 'RETRY')" in dao)
check('running lease', "state = 'RUNNING'" in dao and 'leaseUntilEpochMillis' in dao)
check('success retained for idempotency', "state = 'SUCCEEDED'" in dao)
check('process death recovery code', 'PROCESS_DEATH_RECOVERY' in dao)
check('queue insert ignores duplicate', 'OnConflictStrategy.IGNORE' in dao)

vehicle_dao=read('core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt'); maint_dao=read('core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceDao.kt')
check('vehicle writes queue atomically', 'insertVehicleWithAudit' in vehicle_dao and 'insertSyncOperation' in vehicle_dao and '@Transaction' in vehicle_dao)
check('maintenance create queues atomically', 'insertOperationWithSync' in maint_dao and '@Transaction' in maint_dao)
check('maintenance update queues atomically', 'updateInProgressWithAudit' in maint_dao and 'syncOperation' in maint_dao)
check('completion queues atomically', 'completeWithFollowUpAndAudit' in maint_dao and 'syncOperations' in maint_dao)
check('followup conversion queues atomically', 'convertFollowUpToOperation' in maint_dao and 'syncOperations' in maint_dao)

vf=read('feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleSyncOperationFactory.kt'); mf=read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceSyncOperationFactory.kt')
for src,name in [(vf,'vehicle'),(mf,'maintenance')]:
    check(name+' idempotency generated', 'idempotencyKey' in src and 'updatedAtEpochMillis' in src)
    check(name+' local version sent', 'localVersion' in src)
    check(name+' payload created in data layer', 'payload' in src and 'presentation' not in src)

manager=read(required[5]); worker=read(required[11]); scheduler=read(required[12]); retry=read(required[9]); resolver=read(required[10]); module=read('app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt')
check('manager has no DAO', 'Dao' not in manager)
check('manager has no Android', not re.search(r'^import android\.', manager, re.M))
check('manager orchestrates participants', 'participants' in manager and 'supports(operation)' in manager)
check('manager recovers leases first', manager.find('recoverExpiredLeases') < manager.find('claimDueBatch'))
check('manager handles all outcomes', all(x in manager for x in ['Success','RetryableFailure','PermanentFailure','Conflict']))
check('retry exponential', '2.0.pow' in retry and 'MAX_DELAY_MILLIS' in retry)
check('retry max attempts', 'MAX_ATTEMPTS' in retry and 'shouldStopAfter' in retry)
check('conflict newest wins', 'localVersion >= remoteVersion' in resolver)
check('conflict losing payload preserved', 'losingPayload' in resolver and 'recordConflict' in manager)
check('participants multibound', module.count('@IntoSet') == 2)
check('transport bound behind contract', 'SyncTransport' in module and 'DeferredSyncTransport' in module)
check('worker delegates only', 'runBatch' in worker and 'SyncPushResult' not in worker and 'Dao' not in worker)
check('worker maps retry', 'Result.retry()' in worker)
check('network constraint', 'NetworkType.CONNECTED' in scheduler)
check('workmanager exponential backoff', 'BackoffPolicy.EXPONENTIAL' in scheduler)
check('unique one-time work', 'enqueueUniqueWork' in scheduler and 'ExistingWorkPolicy.KEEP' in scheduler)
check('unique periodic work', 'enqueueUniquePeriodicWork' in scheduler and 'ExistingPeriodicWorkPolicy.KEEP' in scheduler)
check('backend deferred safely', 'BuildConfig.SYNC_ENABLED' in scheduler and 'if (!BuildConfig.SYNC_ENABLED) return' in scheduler)
check('sync disabled in build until backend', 'buildConfigField("boolean", "SYNC_ENABLED", "false")' in read('app/build.gradle.kts'))

status=read(required[13]); app=read('app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt'); scaffold=read('app/src/main/java/com/optimal/fleet/ui/OptimalAppScaffold.kt')
check('quiet status observes queue contract', 'SyncQueueMonitor' in status and 'observeSummary' in status)
check('pending local status', 'OfflineVisualState.SavedLocally' in status)
check('status wired to app', 'SyncStatusViewModel' in app and 'syncVisualState' in app)
check('status rendered in shell', 'OptimalOfflineStatus' in scaffold)

production='\n'.join(p.read_text(encoding='utf-8') for p in ROOT.rglob('*.kt') if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix())
for p in list((ROOT/'feature').rglob('domain/**/*.kt')):
    src=p.read_text(encoding='utf-8'); check('domain clean '+p.name, 'core.network' not in src and 'SyncQueueDao' not in src and 'androidx.room' not in src)
for p in list((ROOT/'feature').rglob('presentation/**/*.kt')):
    src=p.read_text(encoding='utf-8'); check('presentation clean '+p.name, 'core.network' not in src and 'SyncQueueDao' not in src)
check('no destructive migration', 'fallbackToDestructiveMigration' not in production)
check('version v08 or later', any(f'versionName = "0.{v}.0-v{v:02d}"' in read('app/build.gradle.kts') for v in range(8, 20)))

for r in [
'app/src/test/java/com/optimal/fleet/sync/RetryPolicyTest.kt',
'app/src/test/java/com/optimal/fleet/sync/ConflictResolutionTest.kt',
'app/src/test/java/com/optimal/fleet/sync/SyncManagerTest.kt',
'app/src/test/java/com/optimal/fleet/sync/ProcessDeathRecoveryTest.kt',
'app/src/test/java/com/optimal/fleet/sync/SyncWorkerTest.kt',
'app/src/test/java/com/optimal/fleet/sync/SyncArchitectureTest.kt',
'core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncQueueDaoTest.kt',
]: check('test '+r, (ROOT/r).is_file())

passed=sum(checks); total=len(checks)
print(f'\nV08 static checks: {passed}/{total}')
sys.exit(0 if passed==total else 1)
