#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "docs/sessions/v29.md",
    "docs/sync-engine-v29.md",
    "docs/verification-scripts-v29.md",
    "docs/source-archive-v29.sha256",
    "scripts/static-v29-check.py",
    "scripts/v29-sync-contract.py",
    "scripts/v29-sync-harness.kt",
    "scripts/run-v29-sync-harness.sh",
    "scripts/verify-v29-static.sh",
    "scripts/verify-v29-regressions.sh",
    "PATCH_MANIFEST-v29.md",
    "verification-v29.md",
    "docs/verifications/verification-v29.md",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchClaimer.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncLeaseRecoveryCoordinator.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncOperationDispatcher.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncConflictCoordinator.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchReporter.kt",
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncLeaseOwnershipV29Test.kt",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 24", bool(re.search(r"\bversionCode\s*=\s*24\b", build)))
check("versionName is v29", 'versionName = "0.29.0-v29"' in build)

entity = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/PendingSyncOperationEntity.kt")
queue = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt")
check("outbox row carries nullable lease token", "val leaseToken: String?" in entity)
check("lease token has an index", 'Index(value = ["leaseToken"])' in entity)
check("claim writes lease token", "leaseToken = :leaseToken" in queue and "suspend fun claim(" in queue)
for transition in ["markSucceeded", "markRetry", "markPermanentFailure"]:
    pattern = rf"suspend fun {transition}\([\s\S]*?leaseToken: String[\s\S]*?\): Int"
    check(f"{transition} requires lease owner", bool(re.search(pattern, queue)))
check("normal transitions reject expired leases", queue.count("leaseUntilEpochMillis > :nowEpochMillis") >= 4)
check("expired leases are queried explicitly", "findExpiredLeasesForSystem" in queue and "leaseUntilEpochMillis <= :nowEpochMillis" in queue)
check("expired lease recovery clears ownership", queue.count("leaseToken = NULL") >= 5)
check("process death recovery increments attempts", queue.count("attemptCount = attemptCount + 1") >= 4)
check("conflict audit insert is idempotent", "insertConflictAudit" in queue and "OnConflictStrategy.IGNORE" in queue)
check("conflict audit requires current lease", "insertConflictAuditIfLeaseOwned" in queue and "countActiveLease" in queue)
check("old global lease recovery query is removed", "recoverExpiredLeasesForSystem" not in queue)

manager = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt")
claimer = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchClaimer.kt")
recovery = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncLeaseRecoveryCoordinator.kt")
dispatcher = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncOperationDispatcher.kt")
conflict = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncConflictCoordinator.kt")
reporter = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchReporter.kt")
result = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncRunResult.kt")
check("batch claiming is isolated", "class SyncBatchClaimer" in claimer and "claimDueBatch" in claimer)
check("lease recovery is isolated", "class SyncLeaseRecoveryCoordinator" in recovery and "recoverExpiredLeases" in recovery)
check("transport dispatch is isolated", "class SyncOperationDispatcher" in dispatcher and "participant.push" in dispatcher)
check("conflict handling is isolated", "class SyncConflictCoordinator" in conflict and "resolver.resolve" in conflict)
check("batch reporting is isolated", "class SyncBatchReporter" in reporter and "CompanySyncRunResult" in reporter)
check("manager composes focused components", all(token in manager for token in ["SyncBatchClaimer", "SyncLeaseRecoveryCoordinator", "SyncOperationDispatcher", "SyncConflictCoordinator", "SyncBatchReporter"]))
check("manager prevents in-process concurrent runs", "Mutex()" in manager and "runMutex.tryLock()" in manager)
check("manager records lost leases separately", "leaseLost" in manager and "changed == 1" in manager)
check("result contains per-company map", "Map<String, CompanySyncRunResult>" in result)
check("aggregates derive from company results", "companies.values.sumOf" in result)
check("company reporter uses company-local numbers", all(f'result.{field}' in reporter for field in ["claimed", "succeeded", "retryScheduled", "permanentFailures", "leaseLost"]))
check("reporter does not use global run totals", not re.search(r"\bSyncRunResult\b", reporter))

retry = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncRetryPolicy.kt")
scheduler = read("app/src/main/java/com/optimal/fleet/work/SyncScheduler.kt")
worker = read("app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt")
check("retry policy defines attempt ceiling", "MAX_ATTEMPTS = 8" in retry)
check("retry policy defines exponential cap", "BASE_DELAY_MILLIS" in retry and "MAX_DELAY_MILLIS" in retry and "2.0.pow" in retry)
check("WorkManager uses retry policy base", "SyncRetryPolicy.WORKER_BACKOFF_SECONDS" in scheduler)
check("WorkManager requires connectivity", "NetworkType.CONNECTED" in scheduler)
check("unique work uses KEEP", "ExistingWorkPolicy.KEEP" in scheduler and "ExistingPeriodicWorkPolicy.KEEP" in scheduler)
check("worker delegates queue work to manager", "syncManager().runBatch()" in worker)
check("operation timeout is bounded below lease duration", "OPERATION_TIMEOUT_MILLIS = 60_000L" in dispatcher and "LEASE_DURATION_MILLIS = 10 * 60 * 1000L" in claimer)
check("operation exceptions become retryable per item", "PARTICIPANT_FAILURE" in dispatcher and "RetryableFailure" in dispatcher)
check("structured cancellation is preserved", "throw cancellation" in dispatcher and "TimeoutCancellationException" in dispatcher)

resolver = read("app/src/main/java/com/optimal/fleet/coordinator/sync/DescriptionConflictResolver.kt")
transport = read("core/network/src/main/java/com/optimal/fleet/core/network/sync/SyncTransport.kt")
api = read("app/src/main/java/com/optimal/fleet/coordinator/sync/remote/OptimalSyncApi.kt")
check("idempotent replay avoids remote rewrite", "IDEMPOTENT_REPLAY" in resolver and "requiresRemoteWrite = false" in resolver)
check("conflict compares version then timestamp", "localVersion != remoteVersion" in resolver and "localUpdatedAtEpochMillis" in resolver)
check("equal conflicts use deterministic SHA-256", "MessageDigest" in resolver and 'getInstance("SHA-256")' in resolver)
check("remote conflict carries timing and idempotency", all(token in transport for token in ["remoteUpdatedAtEpochMillis", "remoteIdempotencyKey", "remoteId"]))
check("RPC DTO accepts optional conflict metadata", all(token in api for token in ["remote_updated_at_epoch_millis", "remote_idempotency_key"]))
check("conflict audit id is deterministic", "UUID.nameUUIDFromBytes" in conflict)
check("duplicate conflict can complete without resolve call", "resolution.requiresRemoteWrite" in conflict and "SyncPushResult.Success(conflict.remoteId" in conflict)

manager_test = read("app/src/test/java/com/optimal/fleet/sync/SyncManagerTest.kt")
recovery_test = read("app/src/test/java/com/optimal/fleet/sync/ProcessDeathRecoveryTest.kt")
room_test = read("core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncLeaseOwnershipV29Test.kt")
for scenario, token in [
    ("two companies", "twoCompaniesReceiveIndependentBatchResults"),
    ("partial success", "partialSuccessLeavesFailedOperationRetryable"),
    ("duplicate response", "idempotentConflictDoesNotWriteRemoteTwice"),
    ("stale lease", "staleWorkerCannotFinalizeNewOwnersLease"),
    ("retry exhaustion", "retryLimitMovesOperationToPermanentFailure"),
    ("concurrent runner", "concurrentRunnerIsSkippedInsideProcess"),
]:
    check(f"JVM test covers {scenario}", token in manager_test)
check("process death tests retry and exhaustion", "expiredLeaseReturnsToRetryWithBackoff" in recovery_test and "repeatedProcessDeathEventuallyBecomesPermanentFailure" in recovery_test)
check("Room tests cover lease owner and duplicate audit", "staleLeaseOwnerCannotFinalizeAfterRecoveryAndReclaim" in room_test and "duplicateConflictResponseIsAuditedOnce" in room_test)
check("Room v29 suite has four tests", len(re.findall(r"@Test\b", room_test)) == 4)

schema_path = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/1.json"
schema = json.loads(schema_path.read_text(encoding="utf-8"))
entities = schema["database"]["entities"]
pending = next(entity for entity in entities if entity["tableName"] == "pending_sync_operations")
check("Room remains version 1", schema["database"]["version"] == 1)
check("Room remains 18 tables", len(entities) == 18)
check("Room now has 220 columns", sum(len(entity["fields"]) for entity in entities) == 220)
check("Room now has 92 indices", sum(len(entity["indices"]) for entity in entities) == 92)
check("Room keeps 35 foreign keys", sum(len(entity["foreignKeys"]) for entity in entities) == 35)
check("published pending table includes leaseToken", any(field["columnName"] == "leaseToken" for field in pending["fields"]))
check("published pending table indexes leaseToken", any(index["columnNames"] == ["leaseToken"] for index in pending["indices"]))

source_hash = read("docs/source-archive-v29.sha256").strip()
check("v28 source archive SHA-256 is recorded", bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-full-v28\.zip", source_hash)), source_hash)

for script in ["scripts/static-v29-check.py", "scripts/v29-sync-contract.py", "scripts/room-schema-drift-contract.py"]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid, detail = True, ""
    except py_compile.PyCompileError as error:
        valid, detail = False, str(error)
    check(f"Python syntax valid: {script}", valid, detail)

for script in ["scripts/run-v29-sync-harness.sh", "scripts/verify-v29-static.sh", "scripts/verify-v29-regressions.sh", "scripts/verify-project.sh"]:
    result_shell = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result_shell.returncode == 0, result_shell.stderr.strip())

verify_project = read("scripts/verify-project.sh")
check("verify-project invokes v29 gates", "verify-v29-static.sh" in verify_project and "verify-v29-regressions.sh" in verify_project)
check("verify-project retains all Gradle gates", all(command in verify_project for command in [
    "./gradlew clean",
    "./gradlew testDebugUnitTest",
    "./gradlew lintDebug",
    "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV29 sync-engine checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
