#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "NOTICE: verify-v21-regressions.sh is retained for compatibility; running the v24 sequential regression suite." >&2
exec "$ROOT_DIR/scripts/verify-v24-regressions.sh"
