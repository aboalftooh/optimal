#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KOTLIN_HOME_DIR="$(cd "$(dirname "$(readlink -f "$(command -v kotlinc)")")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME_DIR/lib/kotlinx-coroutines-core-jvm.jar"
[[ -f "$COROUTINES_JAR" ]] || { echo "FAIL: Kotlin coroutines jar is unavailable" >&2; exit 1; }
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

cat > "$TMP_DIR/android_net.kt" <<'KT'
package android.net
class Uri { companion object { fun parse(value: String): Uri = Uri() } }
KT
cat > "$TMP_DIR/android_database.kt" <<'KT'
package android.database
interface Cursor : java.io.Closeable {
    fun moveToFirst(): Boolean
    fun getColumnIndex(name: String): Int
    fun getString(index: Int): String
}
KT
cat > "$TMP_DIR/android_content.kt" <<'KT'
package android.content
import android.database.Cursor
import android.net.Uri
import java.io.File
import java.io.InputStream
open class ContentResolver {
    open fun getType(uri: Uri): String? = null
    open fun openInputStream(uri: Uri): InputStream? = null
    open fun delete(uri: Uri, where: String?, args: Array<String>?): Int = 0
    open fun query(uri: Uri, projection: Array<String>?, selection: String?, selectionArgs: Array<String>?, sortOrder: String?): Cursor? = null
}
open class Context {
    open val filesDir: File = File(".")
    open val contentResolver: ContentResolver = ContentResolver()
}
KT
cat > "$TMP_DIR/android_graphics.kt" <<'KT'
package android.graphics
object BitmapFactory {
    class Options { var inJustDecodeBounds = false; var outWidth = 0; var outHeight = 0 }
    fun decodeFile(path: String, options: Options): Any? = null
}
KT
cat > "$TMP_DIR/android_media.kt" <<'KT'
package android.media
class MediaMetadataRetriever {
    fun setDataSource(path: String) = Unit
    fun extractMetadata(key: Int): String? = null
    fun release() = Unit
    companion object {
        const val METADATA_KEY_HAS_VIDEO = 17
        const val METADATA_KEY_VIDEO_WIDTH = 18
        const val METADATA_KEY_VIDEO_HEIGHT = 19
        const val METADATA_KEY_DURATION = 9
    }
}
KT
cat > "$TMP_DIR/android_provider.kt" <<'KT'
package android.provider
object OpenableColumns { const val DISPLAY_NAME = "_display_name" }
KT
cat > "$TMP_DIR/android_webkit.kt" <<'KT'
package android.webkit
class MimeTypeMap {
    fun getExtensionFromMimeType(mime: String): String? = null
    companion object { private val value = MimeTypeMap(); fun getSingleton(): MimeTypeMap = value }
}
KT
cat > "$TMP_DIR/hilt.kt" <<'KT'
package dagger.hilt.android.qualifiers
@Target(AnnotationTarget.VALUE_PARAMETER, AnnotationTarget.FIELD)
annotation class ApplicationContext
KT
cat > "$TMP_DIR/inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FUNCTION, AnnotationTarget.FIELD)
annotation class Inject
@Target(AnnotationTarget.CLASS)
annotation class Singleton
KT

kotlinc -nowarn -cp "$COROUTINES_JAR" \
  "$TMP_DIR"/*.kt \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessage.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingMessageIdentity.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingAttachment.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/attachment/VertoAttachmentImporter.kt" \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/AndroidVertoAttachmentImporter.kt" \
  -d "$TMP_DIR/importer.jar" >/dev/null

echo "PASS: AndroidVertoAttachmentImporter compiled against strict Android API stubs and real coroutines."
