#!/usr/bin/env python3
"""Prove the committed Room schema gate accepts current sources and rejects drift."""
from __future__ import annotations

import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
GENERATOR_PATH = ROOT / "scripts/generate-room-baseline.py"
SCHEMA_DIR = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"


def load_generator():
    spec = importlib.util.spec_from_file_location("optimal_room_generator", GENERATOR_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load Room schema generator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    checks: list[tuple[str, bool]] = []

    current = subprocess.run(
        [sys.executable, str(GENERATOR_PATH), "--check"],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    checks.append(("current source and committed schema match", current.returncode == 0))

    module = load_generator()
    generated = module.build_schema()
    schema_path = SCHEMA_DIR / f"{generated['database']['version']}.json"
    committed = json.loads(schema_path.read_text(encoding="utf-8"))
    checks.append(("structural comparator accepts current schema", module.structural(committed) == module.structural(generated)))

    drifted = copy.deepcopy(generated)
    drifted["database"]["entities"][0]["fields"].append(
        {
            "fieldPath": "unpublishedColumn",
            "columnName": "unpublishedColumn",
            "affinity": "TEXT",
            "notNull": False,
        },
    )
    checks.append(("structural comparator detects a source-only column", module.structural(committed) != module.structural(drifted)))

    original_builder = module.build_schema
    original_argv = sys.argv[:]
    try:
        module.build_schema = lambda: drifted
        sys.argv = [str(GENERATOR_PATH), "--check"]
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            drift_result = module.main()
        checks.append(("verification command returns failure on unpublished drift", drift_result != 0))
    finally:
        module.build_schema = original_builder
        sys.argv = original_argv

    passed = sum(ok for _, ok in checks)
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}: {name}")
    print(f"Room schema drift contract: {passed}/{len(checks)} PASS")
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
