#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mapfile -t FILES < <(
  printf '%s\n' \
    "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMaintenanceProjectionDao.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/LinkedCompanyVertoInvoiceSource.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/OptimalVertoV23Api.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/SupabaseVertoInvoiceV23Transport.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceV23Dto.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceV23Mapper.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceV23Transport.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/di/FinanceDataModule.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/VertoInvoiceSnapshot.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/InvoiceProjectionRepository.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/VertoInvoiceSource.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/SyncVertoInvoices.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardViewModel.kt" \
    "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt" \
    "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/FakeInvoiceProjectionDao.kt" \
    "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/FakeVertoPageDaos.kt" \
    "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/InvoiceProjectionRepositoryTestFixtures.kt" \
    "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/VertoInvoicePageCommitTest.kt" \
    "$ROOT_DIR/feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceV23MapperTest.kt"
  find "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance" \
    -type f -name '*VertoMaintenance*.kt' -o -name 'MaintenanceSourceFeedModule.kt'
  find "$ROOT_DIR/feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/data/remote" \
    -type f -name '*.kt'
)
for file in "${FILES[@]}"; do
  [[ -f "$file" ]] || { echo "FAIL: missing v60 Kotlin source: $file" >&2; exit 1; }
done
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: v60 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v60 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} v60 production/test files; unresolved Android/Gradle symbols were intentionally ignored."
