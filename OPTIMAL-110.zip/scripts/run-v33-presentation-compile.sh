#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs"/{androidx/lifecycle,androidx/compose/runtime,dagger/hilt/android/lifecycle,javax/inject,kotlinx/coroutines/flow,com/optimal/fleet/core/common/analytics,com/optimal/fleet/core/session,com/optimal/fleet/core/model/audit,com/optimal/fleet/feature/vehicles/domain/model,com/optimal/fleet/feature/vehicles/domain/usecase,com/optimal/fleet/feature/maintenance/domain/model,com/optimal/fleet/feature/maintenance/domain/query,com/optimal/fleet/feature/maintenance/domain/usecase,com/optimal/fleet/feature/maintenance/domain/history,com/optimal/fleet/feature/finance/domain/invoice/model,com/optimal/fleet/feature/finance/domain/invoice/query,com/optimal/fleet/feature/finance/domain/invoice/usecase,com/optimal/fleet/feature/finance/presentation,com/optimal/fleet/feature/notifications/domain}
cat > "$TMP_DIR/stubs/androidx/lifecycle/Lifecycle.kt" <<'KT'
package androidx.lifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
open class ViewModel
class SavedStateHandle(private val values: Map<String, Any?> = emptyMap()) { @Suppress("UNCHECKED_CAST") fun <T> get(key: String): T? = values[key] as? T }
val ViewModel.viewModelScope: CoroutineScope get() = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
KT
cat > "$TMP_DIR/stubs/androidx/compose/runtime/Immutable.kt" <<'KT'
package androidx.compose.runtime
@Target(AnnotationTarget.CLASS) annotation class Immutable
KT
cat > "$TMP_DIR/stubs/dagger/hilt/android/lifecycle/HiltViewModel.kt" <<'KT'
package dagger.hilt.android.lifecycle
@Target(AnnotationTarget.CLASS) annotation class HiltViewModel
KT
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION) annotation class Inject
KT
cat > "$TMP_DIR/stubs/kotlinx/coroutines/flow/Update.kt" <<'KT'
package kotlinx.coroutines.flow
import kotlinx.coroutines.InternalCoroutinesApi
inline fun <T> MutableStateFlow<T>.update(function: (T) -> T) { value = function(value) }
@OptIn(InternalCoroutinesApi::class)
suspend fun <T> Flow<T>.collect(action: suspend (T) -> Unit) { collect(object : FlowCollector<T> { override suspend fun emit(value: T) = action(value) }) }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/common/analytics/Analytics.kt" <<'KT'
package com.optimal.fleet.core.common.analytics
enum class AnalyticsAction { CLEAR_SEARCH, RETRY, ADD_VEHICLE }
enum class AnalyticsFilter { ARCHIVED, ACTIVE }
enum class AnalyticsItemType { VEHICLE }
enum class AnalyticsScreen { VEHICLES }
sealed interface AnalyticsEvent {
 data class ScreenViewed(val screen: AnalyticsScreen): AnalyticsEvent
 data class SearchStateChanged(val screen: AnalyticsScreen, val used: Boolean): AnalyticsEvent
 data class PrimaryAction(val screen: AnalyticsScreen, val action: AnalyticsAction): AnalyticsEvent
 data class FilterChanged(val screen: AnalyticsScreen, val filter: AnalyticsFilter): AnalyticsEvent
 data class ItemOpened(val screen: AnalyticsScreen, val item: AnalyticsItemType): AnalyticsEvent
}
interface AnalyticsTracker { fun track(event: AnalyticsEvent) }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/session/Session.kt" <<'KT'
package com.optimal.fleet.core.session
import kotlinx.coroutines.flow.Flow
data class ActiveSession(val userId: String, val companyId: String, val userDisplayName: String, val companyName: String)
interface SessionReader { fun observeActiveSession(): Flow<ActiveSession?>; suspend fun currentSession(): ActiveSession? }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/model/audit/Audit.kt" <<'KT'
package com.optimal.fleet.core.model.audit
import com.optimal.fleet.core.model.paging.*
import kotlinx.coroutines.flow.Flow
enum class AuditActorSource { USER, VERTO, SYSTEM }
enum class AuditEntityType { VEHICLE, MAINTENANCE_OPERATION, INVOICE, OTHER }
enum class AuditAction { COMPANY_CREATED, MEMBER_ADDED, MEMBER_UPDATED, MEMBER_INVITED, MEMBER_INVITE_RESENT, MEMBER_INVITE_REVOKED, MEMBER_JOINED, MEMBER_DISABLED, MEMBER_ENABLED, VEHICLE_CREATED, VEHICLE_UPDATED, VEHICLE_ARCHIVED, MAINTENANCE_CREATED, MAINTENANCE_UPDATED, MAINTENANCE_COMPLETED, MAINTENANCE_IMPORTED, FOLLOW_UP_CONVERTED, INVOICE_IMPORTED, INVOICE_UPDATED, INVOICE_VOIDED, INVOICE_LINKED, ADDITIONAL_COST_CREATED, SYNC_BATCH_COMPLETED, SYNC_CONFLICT_RESOLVED }
data class AuditChange(val fieldName: String)
data class AuditEvent(val id:String,val summary:String,val actorDisplayName:String,val actorSource:AuditActorSource,val action:AuditAction,val changes:List<AuditChange>,val occurredAtEpochMillis:Long)
interface ActivityQuery {
 suspend fun loadCompanyActivityPage(companyId:String, request:PageRequest):PageSlice<AuditEvent>
 suspend fun loadEntityActivityPage(companyId:String, entityType:AuditEntityType, entityId:String, request:PageRequest):PageSlice<AuditEvent>
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt" <<'KT'
package com.optimal.fleet.feature.vehicles.domain.model
data class VehicleFilter(val query:String="", val includeArchived:Boolean=false)
data class Vehicle(val id:String,val name:String,val plateNumber:String,val brand:String?,val model:String?,val manufactureYear:Int?,val odometerKm:Long?,val isArchived:Boolean)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/vehicles/domain/usecase/Load.kt" <<'KT'
package com.optimal.fleet.feature.vehicles.domain.usecase
import com.optimal.fleet.core.model.paging.*
import com.optimal.fleet.feature.vehicles.domain.model.*
class LoadVehiclesPage { suspend operator fun invoke(filter:VehicleFilter, request:PageRequest):PageSlice<Vehicle> = PageSlice.empty() }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/domain/model/Models.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.domain.model
enum class MaintenanceOperationType { PARTS_ONLY, FULL_MAINTENANCE }
enum class OperationSource { MANUAL, VERTO }
enum class OperationStatus { IN_PROGRESS, COMPLETED }
data class MaintenanceOperationSummary(val id:String,val vehicleName:String,val plateNumber:String,val type:MaintenanceOperationType,val description:String,val status:OperationStatus,val source:OperationSource,val startedAtEpochMillis:Long,val completedAtEpochMillis:Long?,val odometerKm:Long?,val totalCostMinor:Long,val invoiceNumber:String?)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/domain/query/Query.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.domain.query
import com.optimal.fleet.feature.maintenance.domain.model.*
enum class MaintenancePeriod { ALL, LAST_30_DAYS, LAST_90_DAYS }
data class MaintenanceOperationFilter(val status:OperationStatus=OperationStatus.IN_PROGRESS,val query:String="",val source:OperationSource?=null,val type:MaintenanceOperationType?=null,val period:MaintenancePeriod=MaintenancePeriod.ALL)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/domain/usecase/Load.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.domain.usecase
import com.optimal.fleet.core.model.paging.*
import com.optimal.fleet.feature.maintenance.domain.model.*
import com.optimal.fleet.feature.maintenance.domain.query.*
class LoadMaintenanceOperationsPage { suspend operator fun invoke(filter:MaintenanceOperationFilter,request:PageRequest):PageSlice<MaintenanceOperationSummary> = PageSlice.empty() }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/domain/history/Load.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.domain.history
import com.optimal.fleet.core.model.paging.*
import com.optimal.fleet.feature.maintenance.domain.model.*
class LoadMaintenanceHistoryPage { suspend operator fun invoke(query:String,request:PageRequest):PageSlice<MaintenanceOperationSummary> = PageSlice.empty() }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/finance/domain/invoice/model/Models.kt" <<'KT'
package com.optimal.fleet.feature.finance.domain.invoice.model
data class InvoiceProjection(val id:String,val invoiceNumber:String,val invoiceType:String,val category:String?,val sourceStatus:String,val totalMinor:Long,val remainingMinor:Long?,val voided:Boolean,val invoiceDateEpochMillis:Long,val requiresVehicleLink:Boolean)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/finance/domain/invoice/query/Query.kt" <<'KT'
package com.optimal.fleet.feature.finance.domain.invoice.query
enum class InvoiceListFilter { ALL, NEEDS_LINK, OUTSTANDING, PAID, VOIDED }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/finance/domain/invoice/usecase/UseCases.kt" <<'KT'
package com.optimal.fleet.feature.finance.domain.invoice.usecase
import com.optimal.fleet.core.model.paging.*
import com.optimal.fleet.feature.finance.domain.invoice.model.*
import com.optimal.fleet.feature.finance.domain.invoice.query.*
import kotlinx.coroutines.flow.Flow
class LoadInvoiceProjectionsPage { suspend operator fun invoke(query:String,filter:InvoiceListFilter,request:PageRequest):PageSlice<InvoiceProjection> = PageSlice.empty() }
class ObserveInvoiceOutstandingTotal { operator fun invoke():Flow<Long?> = kotlinx.coroutines.flow.flowOf(null) }
sealed interface SyncVertoInvoicesResult { data class Success(val inserted:Int,val updated:Int):SyncVertoInvoicesResult; data object CompanyNotLinked:SyncVertoInvoicesResult; data object NoActiveSession:SyncVertoInvoicesResult; data class Unavailable(val reason:String):SyncVertoInvoicesResult; data object InvalidPayload:SyncVertoInvoicesResult }
class SyncVertoInvoices { suspend operator fun invoke():SyncVertoInvoicesResult = SyncVertoInvoicesResult.NoActiveSession }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/finance/presentation/Money.kt" <<'KT'
package com.optimal.fleet.feature.finance.presentation
object MoneyTextFormatter { fun formatMinor(value:Long):String = value.toString() }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/notifications/domain/Notifications.kt" <<'KT'
package com.optimal.fleet.feature.notifications.domain
import com.optimal.fleet.core.model.paging.*
import kotlinx.coroutines.flow.Flow
data class NotificationTarget(val value:String="")
data class NotificationItem(val id:String,val title:String,val message:String,val actionLabel:String,val occurredAtEpochMillis:Long,val isRead:Boolean,val target:NotificationTarget)
class ObserveNotificationCenter { fun unreadCount():Flow<Int> = kotlinx.coroutines.flow.flowOf(0); suspend fun loadPage(request:PageRequest):PageSlice<NotificationItem> = PageSlice.empty() }
sealed interface NotificationGenerationResult { data object SessionMissing:NotificationGenerationResult; data class Success(val insertedCount:Int):NotificationGenerationResult }
class GenerateAndDeliverNotifications { suspend operator fun invoke():NotificationGenerationResult = NotificationGenerationResult.SessionMissing }
class MarkNotificationRead { suspend operator fun invoke(id:String) {} }
class MarkAllNotificationsRead { suspend operator fun invoke() {} }
KT

kotlinc -nowarn -cp "$COROUTINES_JAR" \
  $(find "$TMP_DIR/stubs" -name '*.kt' | sort) \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesContract.kt" \
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListContract.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListViewModel.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryContract.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryViewModel.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListContract.kt" \
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt" \
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsContract.kt" \
  "$ROOT_DIR/feature/notifications/src/main/java/com/optimal/fleet/feature/notifications/presentation/NotificationsViewModel.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityContract.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityViewModel.kt" \
  -d "$TMP_DIR/v33-presentation.jar"
echo "PASS: six paged ViewModels and contracts compile"
echo "V33 focused presentation compilation: 1/1"
