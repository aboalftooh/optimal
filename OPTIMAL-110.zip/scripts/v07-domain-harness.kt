package v07harness

import com.optimal.fleet.feature.maintenance.domain.complete.MaintenanceCompletion
import com.optimal.fleet.feature.maintenance.domain.complete.MaintenanceCompletionValidationIssue
import com.optimal.fleet.feature.maintenance.domain.complete.MaintenanceCompletionValidator
import com.optimal.fleet.feature.maintenance.domain.complete.MaintenanceFollowUpDraft
import com.optimal.fleet.feature.maintenance.domain.followup.FollowUpStatus
import com.optimal.fleet.feature.maintenance.domain.followup.MaintenanceFollowUpClassifier
import java.time.Clock
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private var checks = 0
private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks++
    println("PASS: $name")
}

fun main() {
    val normalized = MaintenanceCompletionValidator.normalize(
        MaintenanceCompletion("  تم تغيير الزيت  ", 10, 20_000, 100, 50, null),
    )
    verify("completion description normalized", normalized.finalDescription == "تم تغيير الزيت")
    verify("valid completion accepted", MaintenanceCompletionValidator.validate(normalized) == null)
    verify(
        "blank description rejected",
        MaintenanceCompletionValidator.validate(normalized.copy(finalDescription = "")) ==
            MaintenanceCompletionValidationIssue.MissingDescription,
    )
    verify(
        "negative odometer rejected",
        MaintenanceCompletionValidator.validate(normalized.copy(odometerKm = -1)) ==
            MaintenanceCompletionValidationIssue.InvalidOdometer,
    )
    verify(
        "negative parts cost rejected",
        MaintenanceCompletionValidator.validate(normalized.copy(partsCostMinor = -1)) ==
            MaintenanceCompletionValidationIssue.InvalidPartsCost,
    )
    verify(
        "negative service cost rejected",
        MaintenanceCompletionValidator.validate(normalized.copy(serviceCostMinor = -1)) ==
            MaintenanceCompletionValidationIssue.InvalidServiceCost,
    )
    verify(
        "follow-up requires reason",
        MaintenanceCompletionValidator.validate(
            normalized.copy(followUp = MaintenanceFollowUpDraft(" ", 100, null)),
        ) == MaintenanceCompletionValidationIssue.MissingFollowUpReason,
    )
    verify(
        "follow-up requires trigger",
        MaintenanceCompletionValidator.validate(
            normalized.copy(followUp = MaintenanceFollowUpDraft("زيت", null, null)),
        ) == MaintenanceCompletionValidationIssue.MissingFollowUpTrigger,
    )

    val clock = Clock.fixed(Instant.parse("2026-07-26T10:00:00Z"), ZoneOffset.UTC)
    val classifier = MaintenanceFollowUpClassifier(clock)
    fun epoch(value: String) = LocalDate.parse(value).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    verify("future date upcoming", classifier.classify(epoch("2026-07-27"), null, null) == FollowUpStatus.UPCOMING)
    verify("today due", classifier.classify(epoch("2026-07-26"), null, null) == FollowUpStatus.DUE)
    verify("past date overdue", classifier.classify(epoch("2026-07-25"), null, null) == FollowUpStatus.OVERDUE)
    verify("matching odometer due", classifier.classify(null, 30_000, 30_000) == FollowUpStatus.DUE)
    verify("exceeded odometer overdue", classifier.classify(null, 30_000, 30_001) == FollowUpStatus.OVERDUE)
    verify(
        "most urgent trigger wins",
        classifier.classify(epoch("2026-08-01"), 30_000, 30_001) == FollowUpStatus.OVERDUE,
    )
    println("V07 domain harness: $checks/$checks")
}
