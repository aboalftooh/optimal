#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v50 Verto permission management."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "models": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt",
    "usecases": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberUseCases.kt",
    "repository": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberRepository.kt",
    "repo_impl": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SupabaseMemberRepository.kt",
    "remote": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/MemberRemoteDataSource.kt",
    "api": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/remote/OptimalMembersApi.kt",
    "contract": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersContract.kt",
    "viewmodel": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt",
    "dialogs": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersDialogs.kt",
    "components": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt",
    "audit": ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/audit/MemberAuditDataSource.kt",
    "migration": ROOT / "supabase/migrations/20260731005000_optimal_verto_permission_management.sql",
    "preflight": ROOT / "supabase/tests/v50_verto_permission_management_preflight.sql",
    "scenarios": ROOT / "supabase/tests/v50_verto_permission_management_scenarios.sql",
    "domain_test": ROOT / "feature/settings/src/test/java/com/optimal/fleet/feature/settings/domain/members/VertoPermissionManagementTest.kt",
    "vm_test": ROOT / "feature/settings/src/test/java/com/optimal/fleet/feature/settings/presentation/members/MemberViewModelTest.kt",
}
checks = []

def check(name, condition):
    checks.append((name, condition))
    if not condition:
        raise AssertionError(name)

def text(key):
    return FILES[key].read_text(encoding="utf-8")

for name, path in FILES.items():
    check(f"exists:{name}", path.is_file())

models = text("models")
check("permission value object", "data class VertoCommunicationPermissions" in models)
check("send normalized by view", "if (canView) this else copy(canSend = false)" in models)
check("result has network failure", "data object NetworkError : MemberPermissionChangeResult" in models)

usecases = text("usecases")
check("update usecase exists", "class UpdateMemberVertoPermissions" in usecases)
check("send without view rejected", "permissions.canSend && !permissions.canView" in usecases)
check("manager role constrained", "MemberRole.OWNER" in usecases and "MemberRole.MANAGER" in usecases)
check("actor must hold matching management capability", "managementCapability" in usecases and "MemberAccessPolicy.can(actor, managementCapability)" in usecases)
check("member update requires status management", "MemberCapability.CHANGE_MEMBER_STATUS" in usecases)
check("invite update requires invite management", "MemberCapability.CREATE_MEMBER_INVITE" in usecases)
check("actor must view", "MemberCapability.VIEW_VERTO_CHAT" in usecases)
check("actor must send before granting send", "requested.canSend" in usecases and "MemberCapability.SEND_VERTO_CHAT" in usecases)
check("invite carries permissions", "vertoPermissions = normalizedPermissions" in usecases)

repo = text("repository")
check("repository update contract", "suspend fun updateVertoPermissions" in repo)
check("repository invite permission contract", "vertoPermissions: VertoCommunicationPermissions" in repo)

remote = text("remote")
api = text("api")
check("remote update adapter", "override suspend fun updateVertoPermissions" in remote)
check("remote create carries booleans", "canViewVertoChat" in remote and "canSendVertoChat" in remote)
check("member rpc endpoint", "optimal_update_member_verto_permissions" in api)
check("invite v50 endpoint", "optimal_create_member_invite_v50" in api)
check("serialized view field", 'SerialName("p_view_verto_chat")' in api)
check("serialized send field", 'SerialName("p_send_verto_chat")' in api)

impl = text("repo_impl")
update_impl = impl[impl.index("override suspend fun updateVertoPermissions"):impl.index("private suspend fun refreshSuccess")]
check("server first", update_impl.index("remote.updateVertoPermissions") < update_impl.index("local.cacheMember(companyId, result.value)"))
check("room only after success", "is MemberRemoteResult.Success" in update_impl and "local.cacheMember" in update_impl)
check("tenant response checked", "REMOTE_COMPANY_MISMATCH" in impl)
check("network result explicit", "result.error is IOException" in impl)
check("local persistence failure explicit", "MemberPermissionChangeResult.StorageError" in update_impl)
check("invite permission denial mapped", "verto_permission_management_required" in impl and "invalid_verto_permission_selection" in impl)
check("before after audit", "audit.vertoPermissionsChanged" in impl and "beforeView" in impl and "afterView" in impl)

contract = text("contract")
viewmodel = text("viewmodel")
dialogs = text("dialogs")
components = text("components")
check("member editor state", "permissionEditorMember" in contract)
check("invite and member management gates split", "canManageInviteVertoPermissions" in contract and "canManageVertoPermissions" in contract)
check("invite permission state", "inviteCanViewVertoChat" in contract and "inviteCanSendVertoChat" in contract)
check("member editor events", "SaveMemberPermissions" in contract)
check("owner manager UI gate", "canManageVertoPermissions" in viewmodel and "MemberRole.OWNER" in viewmodel)
check("send toggle forces view", "permissionDraftCanView = if (event.enabled) true" in viewmodel)
check("view off clears send", "permissionDraftCanSend = if (event.enabled)" in viewmodel)
check("offline message denies save claim", "لم تُحفظ التغييرات" in viewmodel)
check("member dialog exists", "fun MemberVertoPermissionsDialog" in dialogs)
check("invite section exists", 'Text("التواصل مع Verto"' in dialogs)
check("view switch tagged", '"member-verto-view"' in dialogs)
check("send switch tagged", '"member-verto-send"' in dialogs)
check("member card editor action", '"صلاحيات التواصل مع Verto"' in components)
check("invite summary visible", "Verto: رؤية وإرسال" in components)

audit = text("audit")
check("audit action used", "MEMBER_VERTO_PERMISSIONS_UPDATED" in audit)
check("audit boolean fields", "canViewVertoChat" in audit and "canSendVertoChat" in audit)
check("audit no raw permissions", "permissionsJson" not in audit)

sql = text("migration")
check("server manager helper", "optimal_can_manage_verto_permissions" in sql)
check("server role gate", "actor.role in ('OWNER', 'MANAGER')" in sql)
check("server requires matching management capability", "p_management_capability" in sql and "CHANGE_MEMBER_STATUS" in sql and "CREATE_MEMBER_INVITE" in sql)
check("server auth derived", "actor.auth_user_id = auth.uid()" in sql)
check("server target tenant gate", "target.company_id = v_actor.company_id" in sql)
check("server send requires view", "p_send_verto_chat and not p_view_verto_chat" in sql)
check("server stores view", "'{VIEW_VERTO_CHAT}'" in sql)
check("server stores send", "'{SEND_VERTO_CHAT}'" in sql)
check("server safe audit", "raise log 'optimal_verto_permissions_changed" in sql)
log_lines = "\n".join(line for line in sql.splitlines() if "raise log" in line.lower())
check("server log no message body", "body_text" not in log_lines and "attachment" not in log_lines)
check("direct writes revoked", "revoke insert, update, delete on table public.optimal_members" in sql)
check("only authenticated executes RPC", "grant execute on function public.optimal_update_member_verto_permissions" in sql)
check("invite reuses secured creator", "public.optimal_create_member_invite(p_display_name, p_phone)" in sql)

preflight = text("preflight")
scenarios = text("scenarios")
for token in [
    "v50_member_permission_rpc_missing_security_guards",
    "v50_invite_permission_rpc_incomplete",
    "v50_direct_member_table_write_grant_present",
    "v50_sensitive_permission_audit_payload",
]:
    check(f"preflight:{token}", token in preflight)
for token in [
    "v50_invite_permissions_not_persisted",
    "v50_grant_not_persisted",
    "v50_revoke_not_persisted",
    "v50_send_without_view_accepted",
    "v50_manager_without_member_management_accepted",
    "v50_non_manager_mutation_accepted",
]:
    check(f"scenario:{token}", token in scenarios)

for label, sql_text in (("migration", sql), ("preflight", preflight), ("scenarios", scenarios)):
    structural_sql = re.sub(r"'(?:''|[^'])*'", "", sql_text)
    structural_sql = re.sub(r"--[^\n]*", "", structural_sql)
    check(f"syntax:{label}:dollar-quotes", sql_text.count("$$") % 2 == 0)
    check(f"syntax:{label}:parentheses", structural_sql.count("(") == structural_sql.count(")"))
    check(f"syntax:{label}:merge-markers", "<<<<<<<" not in sql_text and ">>>>>>>" not in sql_text)

domain_test = text("domain_test")
vm_test = text("vm_test")
for token in ["ownerCanGrantViewAndSend", "inviteCarriesVertoPermissions", "ordinaryMemberCannotGrantAccess", "sendWithoutViewIsRejectedBeforeRepository", "managerWithoutMemberManagementCannotEditPermissions", "managerWithoutSendCannotGrantSend"]:
    check(f"domain test:{token}", token in domain_test)
check("viewmodel save test", "ownerCanPersistVertoPermissions" in vm_test)
check("viewmodel invite permission test", "invitePersistsSelectedVertoPermissions" in vm_test)

runner = ROOT / "scripts/run-v50-member-permission-harness.sh"
harness = ROOT / "scripts/v50-member-permission-harness.kt"
wrapper = ROOT / "scripts/verify-v50-static.sh"
check("domain harness runner exists", runner.is_file())
check("domain harness source exists", harness.is_file())
check("wrapper runs domain harness", "run-v50-member-permission-harness.sh" in wrapper.read_text(encoding="utf-8"))

print(f"v50 Verto permission management contract: {len(checks)}/{len(checks)} PASS")
