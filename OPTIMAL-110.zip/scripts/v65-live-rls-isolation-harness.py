#!/usr/bin/env python3
"""Run OPTIMAL v65 live RLS/isolation tests against a disposable staging DB.

The database URL is read only from V65_DATABASE_URL. It is never printed.
The harness is destructive only in the sense that scenario SQL performs writes
inside transactions and rolls them back; explicit test-database consent remains
mandatory to avoid accidental production use.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "supabase/tests"

SQL_SEQUENCE = [
    "v65_rls_isolation_security_preflight.sql",
    "v41_verto_conversation_scenarios.sql",
    "v42_verto_message_rpc_scenarios.sql",
    "v43_verto_attachment_scenarios.sql",
    "v44_verto_invoice_scenarios.sql",
    "v45_verto_maintenance_scenarios.sql",
    "v49_verto_chat_permissions_scenarios.sql",
    "v50_verto_permission_management_scenarios.sql",
    "v65_rls_isolation_security_scenarios.sql",
]


def run_psql(psql: str, database_url: str, sql_file: Path) -> None:
    print(f"LIVE SQL: {sql_file.relative_to(ROOT)}")
    env = os.environ.copy()
    env["PGCONNECT_TIMEOUT"] = env.get("PGCONNECT_TIMEOUT", "15")
    # Keep the credential-bearing URI out of argv/process listings.
    env.pop("V65_DATABASE_URL", None)
    env["PGDATABASE"] = database_url
    subprocess.run(
        [psql, "--no-psqlrc", "--set", "ON_ERROR_STOP=1", "--file", str(sql_file)],
        cwd=ROOT,
        env=env,
        check=True,
    )


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--allow-destructive", action="store_true")
    result.add_argument("--confirm", default="")
    result.add_argument("--psql", default="psql")
    return result


def main() -> int:
    args = parser().parse_args()
    database_url = os.environ.get("V65_DATABASE_URL", "").strip()
    if not database_url:
        print("LIVE BLOCKED: V65_DATABASE_URL is not configured", file=sys.stderr)
        return 2
    if not args.allow_destructive:
        print("LIVE BLOCKED: --allow-destructive is required", file=sys.stderr)
        return 2
    if args.confirm != "V65_TEST_DATABASE_ONLY":
        print("LIVE BLOCKED: --confirm V65_TEST_DATABASE_ONLY is required", file=sys.stderr)
        return 2

    psql = shutil.which(args.psql)
    if psql is None:
        print(f"LIVE BLOCKED: psql executable not found: {args.psql}", file=sys.stderr)
        return 2

    missing = [name for name in SQL_SEQUENCE if not (TESTS / name).is_file()]
    if missing:
        print("LIVE BLOCKED: missing SQL files: " + ", ".join(missing), file=sys.stderr)
        return 2

    try:
        for name in SQL_SEQUENCE:
            run_psql(psql, database_url, TESTS / name)
    except subprocess.CalledProcessError as exc:
        print(f"LIVE FAILED: psql exited with code {exc.returncode}", file=sys.stderr)
        return 1

    print(f"LIVE PASS: {len(SQL_SEQUENCE)}/{len(SQL_SEQUENCE)} SQL suites")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
