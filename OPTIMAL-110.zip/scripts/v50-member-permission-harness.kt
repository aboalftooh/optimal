package com.optimal.fleet.feature.settings.domain.members

import com.optimal.fleet.core.model.access.MemberCapability
import com.optimal.fleet.core.model.access.MemberRole
import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.core.session.SessionReader
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking

private var passed = 0

private fun checkCase(name: String, condition: Boolean) {
    check(condition) { name }
    passed += 1
    println("PASS: $name")
}

fun main() = runBlocking {
    run {
        val repository = HarnessRepository(MemberRole.OWNER)
        val result = UpdateMemberVertoPermissions(HarnessSession(), repository)(
            "target",
            VertoCommunicationPermissions(canView = true, canSend = true),
        )
        checkCase(
            "owner grants view and send",
            result is MemberPermissionChangeResult.Success &&
                repository.lastPermissions == VertoCommunicationPermissions(true, true),
        )
    }

    run {
        val repository = HarnessRepository(MemberRole.OWNER)
        val requested = VertoCommunicationPermissions(canView = true, canSend = true)
        CreateMemberInvite(HarnessSession(), repository)(
            displayName = "New member",
            phone = "+249912345678",
            vertoPermissions = requested,
        )
        checkCase("invite carries selected Verto permissions", repository.lastInvitePermissions == requested)
    }

    run {
        val repository = HarnessRepository(MemberRole.MEMBER)
        val result = UpdateMemberVertoPermissions(HarnessSession(), repository)(
            "target",
            VertoCommunicationPermissions(canView = true, canSend = false),
        )
        checkCase(
            "ordinary member is denied before repository mutation",
            result == MemberPermissionChangeResult.PermissionDenied && repository.lastPermissions == null,
        )
    }
    run {
        val repository = HarnessRepository(MemberRole.OWNER)
        val result = UpdateMemberVertoPermissions(HarnessSession(), repository)(
            "target",
            VertoCommunicationPermissions(canView = false, canSend = true),
        )
        checkCase(
            "send without view is rejected",
            result == MemberPermissionChangeResult.InvalidSelection && repository.lastPermissions == null,
        )
    }

    run {
        val repository = HarnessRepository(
            MemberRole.MANAGER,
            mapOf(MemberCapability.CHANGE_MEMBER_STATUS to false),
        )
        val result = UpdateMemberVertoPermissions(HarnessSession(), repository)(
            "target",
            VertoCommunicationPermissions(canView = true, canSend = false),
        )
        checkCase(
            "manager without member-management capability is denied",
            result == MemberPermissionChangeResult.PermissionDenied && repository.lastPermissions == null,
        )
    }

    run {
        val repository = HarnessRepository(
            MemberRole.MANAGER,
            mapOf(MemberCapability.SEND_VERTO_CHAT to false),
        )
        val result = UpdateMemberVertoPermissions(HarnessSession(), repository)(
            "target",
            VertoCommunicationPermissions(canView = true, canSend = true),
        )
        checkCase(
            "manager cannot grant send they do not hold",
            result == MemberPermissionChangeResult.PermissionDenied && repository.lastPermissions == null,
        )
    }
    println("V50 member permission domain harness: $passed/6 PASS")
}

private class HarnessSession : SessionReader {
    private val active = ActiveSession("actor", "company", "Actor", "Company")
    override fun observeActiveSession(): Flow<ActiveSession?> = MutableStateFlow(active)
    override suspend fun currentSession(): ActiveSession = active
}

private class HarnessRepository(
    actorRole: MemberRole,
    actorOverrides: Map<MemberCapability, Boolean> = emptyMap(),
) : MemberRepository {
    private val actor = Member(
        id = "actor",
        companyId = "company",
        displayName = "Actor",
        phone = null,
        isActive = true,
        lastActiveAtEpochMillis = 0,
        role = actorRole,
        permissionOverrides = actorOverrides,
    )
    private val target = Member(
        id = "target",
        companyId = "company",
        displayName = "Target",
        phone = null,
        isActive = true,
        lastActiveAtEpochMillis = 0,
    )
    var lastPermissions: VertoCommunicationPermissions? = null
    var lastInvitePermissions: VertoCommunicationPermissions? = null

    override fun observeDirectory(companyId: String, currentUserId: String): Flow<MemberDirectory> =
        MutableStateFlow(MemberDirectory(currentUserId, listOf(actor, target), emptyList()))

    override suspend fun findMember(companyId: String, memberId: String): Member? = when (memberId) {
        actor.id -> actor
        target.id -> target
        else -> null
    }

    override suspend fun refreshDirectory(companyId: String) = DirectoryRefreshResult.Success

    override suspend fun createInvite(
        companyId: String,
        actorUserId: String,
        displayName: String,
        phone: String,
        vertoPermissions: VertoCommunicationPermissions,
    ): InviteMutationResult {
        lastInvitePermissions = vertoPermissions
        return InviteMutationResult.PermissionDenied
    }

    override suspend fun resendInvite(companyId: String, actorUserId: String, inviteId: String) =
        InviteMutationResult.PermissionDenied

    override suspend fun revokeInvite(companyId: String, actorUserId: String, inviteId: String) =
        InviteRevocationResult.PermissionDenied

    override suspend fun acceptInvite(code: String) = InviteAcceptanceResult.InvalidCode

    override suspend fun changeMemberStatus(
        companyId: String,
        actorUserId: String,
        memberId: String,
        active: Boolean,
    ) = MemberStatusChangeResult.PermissionDenied

    override suspend fun updateVertoPermissions(
        companyId: String,
        actorUserId: String,
        memberId: String,
        permissions: VertoCommunicationPermissions,
    ): MemberPermissionChangeResult {
        lastPermissions = permissions
        return MemberPermissionChangeResult.Success(target)
    }
}
