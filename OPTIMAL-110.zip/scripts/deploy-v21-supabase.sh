#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

MODE="${1:---dry-run}"
if [[ "$MODE" != "--dry-run" && "$MODE" != "--apply" ]]; then
  echo "Usage: $0 [--dry-run|--apply]" >&2
  exit 2
fi
if ! command -v supabase >/dev/null 2>&1; then
  echo "BLOCKED: Supabase CLI is not installed." >&2
  exit 2
fi
if [[ -z "${SUPABASE_PROJECT_REF:-}" ]]; then
  echo "BLOCKED: SUPABASE_PROJECT_REF is required." >&2
  exit 2
fi

supabase link --project-ref "$SUPABASE_PROJECT_REF"
supabase db push --dry-run

if [[ "$MODE" == "--apply" ]]; then
  supabase db push
  echo "APPLIED: migrations pushed. Run scripts/v21-live-backend-smoke.py with test-user credentials."
else
  echo "DRY-RUN ONLY: no migration was applied. Re-run with --apply after review."
fi
