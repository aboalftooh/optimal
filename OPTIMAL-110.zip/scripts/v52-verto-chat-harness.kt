import com.optimal.fleet.feature.verto.domain.model.*

private fun message(id: String, time: Long, state: VertoDeliveryState = VertoDeliveryState.SENT) = VertoMessage(
    localId = "local-$id",
    remoteId = id,
    clientMessageId = null,
    senderSide = VertoSenderSide.OPTIMAL,
    senderDisplayName = "مستخدم",
    senderRole = "MANAGER",
    kind = VertoMessageKind.TEXT,
    bodyText = "رسالة",
    remoteStatus = VertoMessageStatus.ACTIVE,
    deliveryState = state,
    serverCreatedAtEpochMillis = time,
    localCreatedAtEpochMillis = time - 1,
)

fun main() {
    val ordered = listOf(message("b", 1000), message("a", 1000), message("c", 2000))
        .sortedWith(compareBy<VertoMessage> { it.sortTimestampEpochMillis }.thenBy { it.stableIdentity })
    check(ordered.map { it.stableIdentity } == listOf("a", "b", "c"))
    println("PASS: equal server timestamps retain deterministic identity order")

    check(VertoMessagePage(ordered.takeLast(2), 2, 3).hasOlderMessages)
    println("PASS: local page reports older cached messages")

    check(!VertoMessagePage(ordered, 3, 3).hasOlderMessages)
    println("PASS: complete local page reports no older messages")

    check(message("failed", 3000, VertoDeliveryState.FAILED_RETRYABLE).deliveryState == VertoDeliveryState.FAILED_RETRYABLE)
    println("PASS: failed outgoing state remains visible in read model")

    val attachment = VertoAttachment(null, "attachment-a", VertoAttachmentKind.DOCUMENT, "application/pdf", 1024)
    check(attachment.kind == VertoAttachmentKind.DOCUMENT && attachment.sizeBytes == 1024L)
    println("PASS: attachment preview metadata is domain-valid")

    println("V52 Verto chat domain harness: 5/5 PASS")
}
