package com.optimal.fleet.feature.auth.data

import com.optimal.fleet.core.common.error.DomainError
import com.optimal.fleet.core.network.supabase.SupabaseAuthSession
import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.feature.auth.data.audit.MembershipAuditPort
import com.optimal.fleet.feature.auth.data.local.LocalSessionStore
import com.optimal.fleet.feature.auth.data.local.PendingChallengeStore
import com.optimal.fleet.feature.auth.data.local.PersistedProfile
import com.optimal.fleet.feature.auth.data.local.RemoteProfileStore
import com.optimal.fleet.feature.auth.data.mapper.OnboardingMapper
import com.optimal.fleet.feature.auth.data.remote.AuthRemoteDataSource
import com.optimal.fleet.feature.auth.data.remote.CurrentMemberProfileResult
import com.optimal.fleet.feature.auth.data.remote.InvitePhoneValidationResult
import com.optimal.fleet.feature.auth.data.remote.OnboardingRemoteDataSource
import com.optimal.fleet.feature.auth.data.remote.RemoteMemberProfile
import com.optimal.fleet.feature.auth.data.remote.RemoteOnboardingCompletionResult
import com.optimal.fleet.feature.auth.data.remote.RemoteOtpRequestResult
import com.optimal.fleet.feature.auth.data.remote.RemoteOtpVerificationResult
import com.optimal.fleet.feature.auth.data.remote.RemoteRefreshResult
import com.optimal.fleet.feature.auth.data.remote.RemoteSignOutResult
import com.optimal.fleet.feature.auth.domain.model.JoinCodeValidationResult
import com.optimal.fleet.feature.auth.domain.model.OnboardingCompletionResult
import com.optimal.fleet.feature.auth.domain.model.OnboardingMode
import com.optimal.fleet.feature.auth.domain.model.OtpRequestResult
import com.optimal.fleet.feature.auth.domain.model.OtpVerificationResult
import com.optimal.fleet.feature.auth.domain.model.PendingOnboardingFlow
import com.optimal.fleet.feature.auth.domain.model.PendingOnboardingStage
import com.optimal.fleet.feature.auth.domain.model.RestorePendingOnboardingResult
import com.optimal.fleet.feature.auth.domain.model.RestoreSessionResult
import com.optimal.fleet.feature.auth.domain.model.ValidatedJoinCode
import java.time.Clock
import java.time.Instant
import java.time.ZoneId
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.yield

private var assertions = 0

private fun verify(condition: Boolean, message: String) {
    check(condition) { message }
    assertions += 1
}

fun main() = runBlocking {
    val clock = MutableClock(1_000_000L)
    val auth = FakeAuthRemote()
    val onboarding = FakeOnboardingRemote()
    val local = FakeLocalSessionStore()
    val pending = FakePendingChallengeStore()
    val profiles = FakeRemoteProfileStore()
    val audit = FakeAuditPort()

    fun repository() = SupabaseOnboardingRepository(
        authRemote = auth,
        onboardingRemote = onboarding,
        localSessionStore = local,
        pendingChallengeStore = pending,
        remoteProfileStore = profiles,
        auditWriter = audit,
        onboardingMapper = OnboardingMapper(),
        clock = clock,
    )

    val first = repository()
    val request = first.requestOtp(
        mode = OnboardingMode.JoinCompany,
        joinCode = "12345678",
        normalizedPhone = "+249912345678",
    )
    verify(request is OtpRequestResult.Success, "request succeeds")
    verify(auth.requestCount == 1, "one remote request")
    verify(pending.value?.stage == PendingOnboardingStage.OtpPending, "pending stage persisted")
    verify(pending.value?.challengeId == (request as OtpRequestResult.Success).challenge.id, "challenge persisted")
    verify(pending.value?.joinCode == "12345678", "flow context persisted")

    val recreated = repository()
    val restored = recreated.restorePendingOnboarding()
    verify(restored is RestorePendingOnboardingResult.Restored, "pending flow survives recreation")
    verify((restored as RestorePendingOnboardingResult.Restored).flow.normalizedPhone == "+249912345678", "phone restored")

    val verified = recreated.verifyOtp(request.challenge.id, "654321")
    verify(verified == OtpVerificationResult.Verified, "verification succeeds")
    verify(local.authSession != null, "auth session persisted")
    verify(pending.value?.stage == PendingOnboardingStage.OtpVerified, "verified flow persisted")
    verify(pending.value?.challengeId == null, "used challenge invalidated")

    onboarding.currentProfile = CurrentMemberProfileResult.Success(null)
    val preMembershipSessionRestore = repository().restoreSession()
    verify(preMembershipSessionRestore == RestoreSessionResult.Success(null), "pre-membership restore has no active session")
    verify(local.authSession != null, "pre-membership restore preserves verified auth session")
    verify(pending.value?.stage == PendingOnboardingStage.OtpVerified, "pre-membership restore preserves verified flow")

    val afterVerificationRecreation = repository().restorePendingOnboarding()
    verify(afterVerificationRecreation is RestorePendingOnboardingResult.Restored, "verified flow survives recreation")
    verify(
        (afterVerificationRecreation as RestorePendingOnboardingResult.Restored).flow.stage == PendingOnboardingStage.OtpVerified,
        "verified stage restored",
    )

    val completed = repository().completeOnboarding(
        mode = OnboardingMode.JoinCompany,
        joinCode = "12345678",
        userDisplayName = "أحمد",
        normalizedPhone = "+249912345678",
    )
    verify(completed is OnboardingCompletionResult.Success, "onboarding completes")
    verify(pending.value == null, "pending flow cleared after completion")
    verify(audit.appendCount == 1, "membership audit appended")

    val expiredRequest = repository().requestOtp(
        mode = OnboardingMode.JoinCompany,
        joinCode = "12345678",
        normalizedPhone = "+249912345678",
    ) as OtpRequestResult.Success
    clock.advance(6 * 60 * 1000L)
    verify(repository().verifyOtp(expiredRequest.challenge.id, "654321") == OtpVerificationResult.Expired, "expired challenge rejected")
    verify(pending.value == null, "expired challenge cleared")

    clock.set(2_000_000L)
    auth.requestGate = CompletableDeferred()
    val duplicateRepo = repository()
    val blocked = async {
        duplicateRepo.requestOtp(
            OnboardingMode.JoinCompany,
            "12345678",
            "+249912345678",
        )
    }
    while (auth.requestCount < 3) yield()
    val duplicate = duplicateRepo.requestOtp(
        OnboardingMode.JoinCompany,
        "12345678",
        "+249912345678",
    )
    verify(duplicate == OtpRequestResult.RequestInProgress, "duplicate request rejected while in flight")
    auth.requestGate?.complete(Unit)
    verify(blocked.await() is OtpRequestResult.Success, "original request completes")
    auth.requestGate = null

    val active = sampleSession()
    local.activeSession = active
    local.authSession = SupabaseAuthSession(
        accessToken = "access",
        refreshToken = "refresh",
        expiresInSeconds = 3600,
        expiresAtEpochSeconds = clock.millis() / 1000L + 10,
    )
    auth.refreshResult = RemoteRefreshResult.Refreshed(
        SupabaseAuthSession(
            accessToken = "new-access",
            refreshToken = "new-refresh",
            expiresInSeconds = 3600,
        ),
    )
    onboarding.currentProfile = CurrentMemberProfileResult.Success(sampleProfile())
    val sessionRestore = repository().restoreSession()
    verify(sessionRestore == RestoreSessionResult.Success(active), "session restored")
    verify(auth.refreshCount == 1, "near-expiry session refreshed")
    verify(local.authSession?.accessToken == "new-access", "refreshed tokens saved")

    repository().signOut()
    verify(local.authSession == null, "sign-out clears auth session")
    verify(local.activeSession == null, "sign-out clears active session")
    verify(pending.value == null, "sign-out clears pending flow")

    println("V31 auth/process recreation harness: $assertions/$assertions")
}

private class MutableClock(private var now: Long) : Clock() {
    override fun getZone(): ZoneId = ZoneId.of("UTC")
    override fun withZone(zone: ZoneId): Clock = this
    override fun instant(): Instant = Instant.ofEpochMilli(now)
    override fun millis(): Long = now
    fun advance(delta: Long) { now += delta }
    fun set(value: Long) { now = value }
}

private class FakeAuthRemote : AuthRemoteDataSource {
    override val isConfigured = true
    var requestCount = 0
    var refreshCount = 0
    var requestGate: CompletableDeferred<Unit>? = null
    var refreshResult: RemoteRefreshResult = RemoteRefreshResult.Rejected

    override suspend fun requestOtp(normalizedPhone: String): RemoteOtpRequestResult {
        requestCount += 1
        requestGate?.await()
        return RemoteOtpRequestResult.Accepted
    }

    override suspend fun verifyOtp(normalizedPhone: String, code: String) =
        RemoteOtpVerificationResult.Verified(
            SupabaseAuthSession("access", "refresh", 3600),
        )

    override suspend fun refresh(refreshToken: String): RemoteRefreshResult {
        refreshCount += 1
        return refreshResult
    }

    override suspend fun signOut() = RemoteSignOutResult.Completed
}

private class FakeOnboardingRemote : OnboardingRemoteDataSource {
    override val isConfigured = true
    var currentProfile: CurrentMemberProfileResult = CurrentMemberProfileResult.Success(sampleProfile())

    override suspend fun validateJoinCode(code: String, mode: OnboardingMode) =
        JoinCodeValidationResult.Valid(ValidatedJoinCode("company-1", "شركة الندى"))

    override suspend fun validateInvitePhone(code: String, normalizedPhone: String) =
        InvitePhoneValidationResult.Match

    override suspend fun completeOnboarding(
        mode: OnboardingMode,
        joinCode: String,
        userDisplayName: String,
    ) = RemoteOnboardingCompletionResult.Success(sampleProfile().copy(displayName = userDisplayName))

    override suspend fun currentMemberProfile() = currentProfile
}

private class FakeLocalSessionStore : LocalSessionStore {
    var authSession: SupabaseAuthSession? = null
    var activeSession: ActiveSession? = null

    override fun currentAuthSession() = authSession
    override fun saveAuthSession(session: SupabaseAuthSession) { authSession = session }
    override fun clearAuthSession() { authSession = null }
    override suspend fun clearActiveSession() { activeSession = null }
    override suspend fun clearAll() { authSession = null; activeSession = null }
    override suspend fun activeSessionIfTokenValid(authSession: SupabaseAuthSession, nowEpochSeconds: Long) =
        if (authSession.resolvedExpiryEpochSeconds(nowEpochSeconds) > nowEpochSeconds) activeSession else null
}

private class FakePendingChallengeStore : PendingChallengeStore {
    var value: PendingOnboardingFlow? = null
    override fun current() = value
    override fun save(flow: PendingOnboardingFlow) { value = flow }
    override fun clear() { value = null }
}

private class FakeRemoteProfileStore : RemoteProfileStore {
    override suspend fun persist(profile: RemoteMemberProfile) = PersistedProfile(
        session = sampleSession().copy(userDisplayName = profile.displayName),
        restoredExistingUser = false,
    )
}

private class FakeAuditPort : MembershipAuditPort {
    var appendCount = 0
    override suspend fun appendIfNew(profile: PersistedProfile) { appendCount += 1 }
}

private fun sampleSession() = ActiveSession(
    userId = "user-1",
    companyId = "company-1",
    userDisplayName = "أحمد",
    companyName = "شركة الندى",
)

private fun sampleProfile() = RemoteMemberProfile(
    companyId = "company-1",
    companyName = "شركة الندى",
    memberId = "user-1",
    displayName = "أحمد",
    phone = "+249912345678",
    normalizedPhone = "+249912345678",
    isActive = true,
)
