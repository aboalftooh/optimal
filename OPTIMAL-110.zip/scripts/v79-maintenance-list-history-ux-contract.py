#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
list_route_path = root / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListRoute.kt"
list_components_path = root / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListComponents.kt"
history_route_path = root / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryRoute.kt"
history_components_path = root / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryComponents.kt"
test_path = root / "feature/maintenance/src/androidTest/java/com/optimal/fleet/feature/maintenance/presentation/MaintenanceUiTest.kt"

list_route = list_route_path.read_text()
list_components = list_components_path.read_text()
history_route = history_route_path.read_text()
history_components = history_components_path.read_text()
tests = test_path.read_text()
ui = "\n".join([list_route, list_components, history_route, history_components])
checks = []


def check(label: str, condition: bool):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + ": " + label)


def sha256(path: str) -> str:
    return hashlib.sha256((root / path).read_bytes()).hexdigest()


def tree_digest(path: str) -> str:
    base = root / path
    digest = hashlib.sha256()
    for file in sorted(base.rglob("*.kt")):
        digest.update(str(file.relative_to(root)).encode())
        digest.update(b"\0")
        digest.update(file.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


protected_files = {
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListContract.kt": "b20cdceec0307ac4d11656fe7eabb8b328213ab761d1c57931dd036e4a5cba8d",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListViewModel.kt": "a66ce3ed1dc7aae31e237351d773c80404c7e7123570fae85b1c6e65b386ad13",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryContract.kt": "e69ac9f673407ee47138a0913ef8268db75af40b68229b630a62b7a595d50425",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryViewModel.kt": "8a6d88b07e51534f7dd1e30a8ee2ef4455fca5a6e4d4e1685ce5e5a3aed97162",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt": "c0da7f24661b7154379589b0295fa27eb90b1e37b93d051c51a6704f744e373c",
}
protected_trees = {
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain": "fc1435c6e223816aee066b433aa917678877e8c84a44466d542e45489904a127",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data": "b98dc8bf1d693c0336b4f647af61e000a6fa46323770ff14842438937087c931",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details": "da466cc08e4bc4c64a257686d7bf5febd777e2139b225354addb441ed6df2c3e",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create": "0bda1ad304038ff291dbc3b1cec5023ef7c41f705571ed87e08d96940bb91adc",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup": "d9634142b5243c71002ef13f7a8fc9e76cfd9686bed84588939996f593297a8b",
}

check("Maintenance List route exists", list_route_path.is_file())
check("Maintenance List components exist", list_components_path.is_file())
check("Maintenance History route exists", history_route_path.is_file())
check("Maintenance History components exist", history_components_path.is_file())
check("Maintenance UI test exists", test_path.is_file())

for name, text in [("list route", list_route), ("list components", list_components), ("history route", history_route), ("history components", history_components)]:
    check(f"{name} has no legacy Design System import", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", text) is None)
    check(f"{name} has no AppCard", "AppCard" not in text)
    check(f"{name} has no direct dp literal", re.search(r"\b\d+(?:\.\d+)?\.dp\b", text) is None)
    check(f"{name} has no raw hex colors", "0xFF" not in text)

check("list uses v2 segmented control", "component.v2.OptimalSegmentedControl" in list_route)
check("list uses v2 segment model", "component.v2.OptimalSegmentOption" in list_route)
check("list keeps exactly two business tabs", list_route.count("OptimalSegmentOption(OperationStatus.") == 2)
check("in-progress tab preserved", 'OperationStatus.IN_PROGRESS, "جاري المعالجة", "maintenance-tab-in-progress"' in list_route)
check("completed tab preserved", 'OperationStatus.COMPLETED, "مكتمل", "maintenance-tab-completed"' in list_route)
check("list uses v2 search", "component.v2.OptimalSearchField" in list_route)
check("search event preserved", "MaintenanceListUiEvent.SearchChanged(it)" in list_route)
check("clear-search event preserved", "MaintenanceListUiEvent.ClearSearch" in list_route)
check("status-change event preserved", "MaintenanceListUiEvent.StatusChanged(it)" in list_route)

check("source filters use v2 chips", "component.v2.OptimalFilterChip" in list_route)
check("source filter group exists", 'testTag = "maintenance-source-filters"' in list_route)
check("type filter group exists", 'testTag = "maintenance-type-filters"' in list_route)
check("period filter group exists", 'testTag = "maintenance-period-filters"' in list_route)
for event in ["SourceChanged", "TypeChanged", "PeriodChanged"]:
    check(f"filter event preserved: {event}", f"MaintenanceListUiEvent.{event}" in list_route)
for label in ["كل المصادر", "يدوي", "Verto", "كل الأنواع", "قطع فقط", "صيانة كاملة", "كل الفترات", "30 يومًا", "90 يومًا"]:
    check(f"filter label retained: {label}", f'"{label}"' in list_route)

check("local-first notice uses flat list row", 'title = "سجل الصيانة متاح دون اتصال"' in list_route and "OptimalListRow(" in list_route)
check("history shortcut preserved", "MaintenanceListUiEvent.OpenHistory" in list_route and 'testTag("open-maintenance-history")' in list_route)
check("follow-up shortcut preserved", "MaintenanceListUiEvent.OpenFollowUps" in list_route and 'testTag("open-maintenance-followups")' in list_route)
check("add operation event preserved", "MaintenanceListUiEvent.AddOperation" in list_route)
check("add operation tag preserved", 'testTag("add-maintenance-operation")' in list_route)
check("list loading uses v2 state", "component.v2.OptimalLoadingState" in list_route)
check("list error uses v2 state", "component.v2.OptimalErrorState" in list_route)
check("list empty uses v2 state", "component.v2.OptimalEmptyState" in list_route)
check("retry event preserved", "MaintenanceListUiEvent.Retry" in list_route)

check("maintenance item uses v2 list row", "component.v2.OptimalListRow" in list_components)
check("maintenance item test tag preserved", 'testTag("maintenance-operation-${operation.id}")' in list_components)
check("operation selection event preserved", "MaintenanceListUiEvent.OperationSelected(operation.id)" in list_route)
check("maintenance item shows description", "subtitle = operation.description" in list_components)
check("maintenance metadata retains plate", "operation.plateNumber" in list_components)
check("maintenance metadata retains type", "operation.typeLabel" in list_components)
check("maintenance metadata retains source", "operation.sourceLabel" in list_components)
check("maintenance metadata retains date", "operation.dateLabel" in list_components)
check("maintenance metadata retains invoice", "operation.invoiceNumber" in list_components)
check("maintenance item retains total", "operation.totalLabel" in list_components)

check("unified status badge uses v2", "component.v2.OptimalStatusBadge" in list_components)
check("in-progress has readable status", 'OperationStatus.IN_PROGRESS -> "جاري المعالجة"' in list_components)
check("completed has readable status", 'OperationStatus.COMPLETED -> "مكتمل"' in list_components)
check("in-progress status is semantic info", "OperationStatus.IN_PROGRESS -> OptimalStatusTone.Info" in list_components)
check("completed status is semantic success", "OperationStatus.COMPLETED -> OptimalStatusTone.Success" in list_components)

check("list has explicit append-error presentation", "state.appendErrorMessage?.let" in list_route)
check("list append error has text", 'title = "تعذر تحميل المزيد"' in list_route)
check("list append retry uses existing LoadMore", list_route.count("MaintenanceListUiEvent.LoadMore") >= 2)
check("list append retry tag exists", 'testTag("maintenance-load-more-retry")' in list_route)
check("list normal load-more tag preserved", 'testTag("maintenance-load-more")' in list_route)
check("list load-more respects loading state", "enabled = !state.isLoadingMore" in list_route)

check("history uses v2 search", "component.v2.OptimalSearchField" in history_route)
check("history uses v2 loading", "component.v2.OptimalLoadingState" in history_route)
check("history uses v2 error", "component.v2.OptimalErrorState" in history_route)
check("history uses v2 empty", "component.v2.OptimalEmptyState" in history_route)
check("history retry event preserved", "MaintenanceHistoryUiEvent.Retry" in history_route)
check("vehicle-scoped search label preserved", '"ابحث في سجل صيانة السيارة"' in history_route)
check("global history search label preserved", '"ابحث في سجل الصيانة"' in history_route)
check("history search event preserved", "MaintenanceHistoryUiEvent.SearchChanged(it)" in history_route)
check("history clear keeps existing SearchChanged contract", 'MaintenanceHistoryUiEvent.SearchChanged("")' in history_route)

check("history item uses v2 list row", "component.v2.OptimalListRow" in history_components)
check("history item selection tag preserved", 'testTag("history-${item.id}")' in history_components)
check("history selection event preserved", "MaintenanceHistoryUiEvent.ItemSelected(item.id)" in history_route)
check("history item uses completed semantic badge", 'text = "مكتمل"' in history_components and "OptimalStatusTone.Success" in history_components)
check("history metadata retains plate", "item.plateNumber" in history_components)
check("history metadata retains type", "item.typeLabel" in history_components)
check("history metadata retains source", "item.sourceLabel" in history_components)
check("history metadata retains completion date", "item.completionDateLabel" in history_components)
check("history metadata retains odometer", "item.odometerLabel" in history_components)
check("history preserves original-invoice financial message", '"القيم المالية في الفاتورة الأصلية"' in history_components)
check("history retains total when present", "item.totalLabel?.let" in history_components)

check("history has explicit append-error presentation", "state.appendErrorMessage?.let" in history_route)
check("history append error has text", 'title = "تعذر تحميل المزيد"' in history_route)
check("history append retry uses existing LoadMore", history_route.count("MaintenanceHistoryUiEvent.LoadMore") >= 2)
check("history append retry tag exists", 'testTag("history-load-more-retry")' in history_route)
check("history normal load-more tag preserved", 'testTag("history-load-more")' in history_route)
check("history load-more respects loading state", "enabled = !state.isLoadingMore" in history_route)

check("list uses content inset token", "OptimalContentInsets.horizontal" in list_route)
check("history uses content inset token", "OptimalContentInsets.horizontal" in history_route)
check("list uses spacing tokens", "OptimalSpacing.medium" in list_route)
check("history uses spacing tokens", "OptimalSpacing.medium" in history_route)
check("shared maintenance icon uses touch target token", "OptimalTouchTarget.minimum" in list_components)
check("shared maintenance icon uses icon size token", "OptimalIconSize.standard" in list_components)

check("new status/selection UI test added", "maintenanceRowShowsUnifiedStatusAndPreservesSelectionEvent" in tests)
check("list pagination retry UI test added", "maintenanceAppendFailureRetriesThroughExistingLoadMoreEvent" in tests)
check("history selection UI test added", "historyRowPreservesSelectionEvent" in tests)
check("history pagination retry UI test added", "historyAppendFailureRetriesThroughExistingLoadMoreEvent" in tests)
check("existing two-tab UI test retained", "listShowsOnlyTwoBusinessTabs" in tests)
check("existing completed-tab event UI test retained", "tappingCompletedTabEmitsStatusChange" in tests)
check("details UI test retained", "completedDetailsDoNotShowEditAction" in tests)

for path, expected in protected_files.items():
    check(f"protected unchanged: {path}", sha256(path) == expected)
for path, expected in protected_trees.items():
    check(f"protected tree unchanged: {path}", tree_digest(path) == expected)

failed = [label for label, ok in checks if not ok]
print(f"\nSESSION-79 static contract: {len(checks) - len(failed)}/{len(checks)} PASS")
if failed:
    raise SystemExit("Failed checks: " + "; ".join(failed))
