#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component"
V2 = LEGACY / "v2"
PREVIEW = ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/preview/OptimalComponentPreviews.kt"
CURRENT = ROOT / "docs/design-system/CURRENT-DESIGN-STATE.md"
LEDGER = ROOT / "docs/design-system/MIGRATION-LEDGER.md"
CATALOG = ROOT / "docs/design-system/COMPONENT-CATALOG.md"

checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

required_apis = {
    "OptimalButtons.kt": [
        "OptimalPrimaryButton", "OptimalSecondaryButton", "OptimalTertiaryButton",
        "OptimalDestructiveButton", "OptimalIconButton",
    ],
    "OptimalFields.kt": ["OptimalTextField", "OptimalMoneyField", "OptimalSelectionField"],
    "OptimalSearchAndChips.kt": ["OptimalSearchField", "OptimalChip", "OptimalFilterChip"],
    "OptimalStatus.kt": ["OptimalStatusBadge", "OptimalStatusTone"],
    "OptimalRows.kt": ["OptimalSectionHeader", "OptimalListRow"],
    "OptimalCards.kt": ["OptimalMetricCard", "OptimalActionCard", "OptimalFormSection"],
    "OptimalScreenStates.kt": ["OptimalLoadingState", "OptimalEmptyState", "OptimalErrorState"],
    "OptimalDialogs.kt": ["OptimalDialog", "OptimalConfirmationDialog", "OptimalBottomSheet"],
    "OptimalBottomActions.kt": ["OptimalBottomActionBar"],
    "OptimalSegments.kt": ["OptimalSegmentedControl", "OptimalSegmentOption"],
    "OptimalComponentDefaults.kt": ["OptimalComponentDefaults"],
}

for file_name, apis in required_apis.items():
    path = V2 / file_name
    check(f"file {file_name}", path.is_file())
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8")
    check(
        f"package {file_name}",
        "package com.optimal.fleet.designsystem.component.v2" in text,
    )
    for api in apis:
        check(f"API {api}", re.search(rf"\b{re.escape(api)}\b", text) is not None)

v2_files = sorted(V2.glob("*.kt"))
v2_text = "\n".join(path.read_text(encoding="utf-8") for path in v2_files)
check("no raw Color hex in v2 components", "Color(0x" not in v2_text)

# Component-owned direct dp values must stay centralized in OptimalComponentDefaults.
for path in v2_files:
    if path.name == "OptimalComponentDefaults.kt":
        continue
    text = path.read_text(encoding="utf-8")
    check(f"no direct dp in {path.name}", re.search(r"\b\d+(?:\.\d+)?\.dp\b", text) is None)

# Legacy sources stay byte-identical to v72 so v73 does not silently restyle
# non-migrated production screens.
legacy_hashes = {
    "OptimalPrimaryButton.kt": "ea2a035900f446a4427314ef8c70916d09cbe47313c26563d577b3932a21d2aa",
    "OptimalButtons.kt": "162515fc693285cea44bd372f79f96fd0082f22d375acd8bfffbe50479ea9f9d",
    "OptimalFields.kt": "307e8f4ec85905d747d0d6168b1fcad39f0d8d82b9cbff4a9d142a6bac7bc79f",
    "OptimalSearchAndFilters.kt": "fa86600f7bc5240852d9f1b1dc3fb2740e04c16b57110b4e56d41e03c5589d86",
    "OptimalHeader.kt": "3e43e103f30c99a1540285f897535e58b8b557808981eb2206bd2185d0121a16",
    "OptimalScreenStates.kt": "c3188a34a4727f9f49a7affb750ddf95960e7280ce0952095ae8aee3d9af7fe1",
    "OptimalDialogs.kt": "fa6433183e277df69bb0981510fe7fcb0a46ba3a4395b2b051699c9fc45ef753",
    "OptimalSegments.kt": "07b11e49350af1fceaf3684efa0a8f9ef61b5edd8fad548f11149c0d0e76aac5",
    "OptimalEmptyCards.kt": "d29ae00decf12265949e297feb55025e161ca11046ef5cee8dd70cd7f867d472",
    "OptimalCards.kt": "371c5a1e13e8c3c8626059db1a751ddea560964b508c0e7f00be8679db1132b7",
    "OptimalNavigation.kt": "ee2570efda33604e97b5fe59a1be03be79d8c9d005676d932b69f7274336f5cf",
    "OptimalOfflineStatus.kt": "7a89cc01c8c5d3312abf776415592a45b80d8b0316aa50c2ad8095f3f33129d6",
    "OptimalMoneyText.kt": "201dfa687e61c4f913e4d638832e2229af61b68a9fa0191b5aa8bfa451c28401",
    "OptimalFeaturePlaceholder.kt": "d5bc567b8909f75a2acc92e84d6499f42c2b914348eb3c86fe0f7bc4b2eec013",
}
for legacy, expected in legacy_hashes.items():
    path = LEGACY / legacy
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else "missing"
    check(f"legacy unchanged {legacy}", actual == expected)

preview_text = PREVIEW.read_text(encoding="utf-8") if PREVIEW.exists() else ""
preview_apis = [api for items in required_apis.values() for api in items]
for api in preview_apis:
    if api in {"OptimalComponentDefaults", "OptimalStatusTone"}:
        continue
    check(f"preview catalog references {api}", api in preview_text)
check("preview uses semantic status tones", "OptimalStatusTone." in preview_text)

catalog_text = CATALOG.read_text(encoding="utf-8") if CATALOG.exists() else ""
check("component catalog exists", CATALOG.is_file())
check("catalog contains Keep", "### Keep" in catalog_text)
check("catalog contains Replace", "### Replace" in catalog_text)
check("catalog contains Deprecated", "### Deprecated" in catalog_text)
check("catalog documents v2 namespace", "component.v2" in catalog_text)
check("current state is v73", CURRENT.is_file() and "CURRENT DESIGN STATE — v73" in CURRENT.read_text(encoding="utf-8"))
check("ledger marks Core Components migrated v73", LEDGER.is_file() and "| Core Components | Migrated | v73 |" in LEDGER.read_text(encoding="utf-8"))

# Session isolation: v2 must not import the legacy component namespace.
for path in v2_files:
    text = path.read_text(encoding="utf-8")
    bad = re.search(r"import\s+com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", text)
    check(f"no legacy component import in {path.name}", bad is None)

failed = 0
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" — {detail}" if detail else ""))
    if not ok:
        failed += 1
print(f"\nSESSION-73 static checks: {len(checks)-failed}/{len(checks)} passed")
sys.exit(1 if failed else 0)
