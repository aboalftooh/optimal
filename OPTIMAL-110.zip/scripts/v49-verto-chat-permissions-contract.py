#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v49 Verto chat authorization."""
from __future__ import annotations

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
CORE_ACCESS = ROOT / "core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt"
SETTINGS_POLICY = ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt"
VERTO_AUTH = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/access/RoomVertoChatAuthorization.kt"
VERTO_CONTRACT = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/access/VertoChatAuthorization.kt"
VERTO_USECASES = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt"
VERTO_REPOSITORY = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt"
MIGRATION = ROOT / "supabase/migrations/20260731004900_optimal_verto_chat_permissions.sql"
PREFLIGHT = ROOT / "supabase/tests/v49_verto_chat_permissions_preflight.sql"
SCENARIOS = ROOT / "supabase/tests/v49_verto_chat_permissions_scenarios.sql"
ROOT_GRADLE = ROOT / "build.gradle.kts"
CI_FAST = ROOT / "scripts/ci-fast.sh"
CI_FULL = ROOT / "scripts/ci-full.sh"
VERIFY_PROJECT = ROOT / "scripts/verify-project.sh"
WRAPPER = ROOT / "scripts/verify-v49-static.sh"

checks: list[tuple[str, bool, str]] = []


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, condition, detail))
    if not condition:
        raise AssertionError(f"{name}: {detail}")


for path in [CORE_ACCESS, SETTINGS_POLICY, VERTO_AUTH, VERTO_CONTRACT, VERTO_USECASES, VERTO_REPOSITORY, MIGRATION, PREFLIGHT, SCENARIOS]:
    check(f"exists: {path.relative_to(ROOT)}", path.is_file())

core = read(CORE_ACCESS)
check("view capability declared", 'VIEW_VERTO_CHAT("VIEW_VERTO_CHAT")' in core)
check("send capability declared", 'SEND_VERTO_CHAT("SEND_VERTO_CHAT")' in core)
check("owner defaults all capabilities", "MemberRole.OWNER to MemberCapability.values().toSet()" in core)
check("manager defaults all capabilities", "MemberRole.MANAGER to MemberCapability.values().toSet()" in core)
for role in ["ENGINEER", "ACCOUNTANT", "DRIVER", "MEMBER"]:
    check(f"{role} keeps only management defaults", f"MemberRole.{role} to memberManagementCapabilities" in core)
check("send requires view in Android policy", "effective.remove(MemberCapability.SEND_VERTO_CHAT)" in core)
check("inactive Android member fails closed", "if (!isActive || role == MemberRole.UNKNOWN) return emptySet()" in core)
check("Settings delegates to shared policy", "CoreMemberAccessPolicy" in read(SETTINGS_POLICY))

contract = read(VERTO_CONTRACT)
for operation in ["OBSERVE_LINK_STATE", "OBSERVE_MESSAGES", "REFRESH_MESSAGES", "SEND_MESSAGE"]:
    check(f"operation declared: {operation}", operation in contract)
check("grant implementation is internal", "internal data class GrantedVertoChatAccess" in contract)
check("authorization has structured denial", "VertoChatDenialReason" in contract and "Denied(" in contract)

repository = read(VERTO_REPOSITORY)
check("link observation requires grant", "observeLinkState(grant: VertoChatAccessGrant)" in repository)
check("message observation requires grant", "observeMessages(grant: VertoChatAccessGrant)" in repository)
check("refresh requires grant", "refresh(grant: VertoChatAccessGrant)" in repository)
check("repository exposes permission denial", "PermissionDenied" in repository)

usecases = read(VERTO_USECASES)
for usecase in ["ObserveVertoLinkState", "ObserveVertoMessages", "RefreshVertoConversation", "AuthorizeVertoMessageSend"]:
    check(f"use case checks authorization: {usecase}", f"class {usecase}" in usecases)
check("refresh checks before repository", usecases.index("authorization.authorize(VertoChatOperation.REFRESH_MESSAGES)") < usecases.index("repository.refresh(access.grant)"))

auth = read(VERTO_AUTH)
check("Room member snapshot used", "LocalUserDao" in auth and "findActiveUser" in auth)
check("shared policy used by Verto", "MemberAccessPolicy.can" in auth)
check("unknown permission fails closed", "MemberCapability.fromWire(key) ?: return null" in auth)
check("inactive member denied", "VertoChatDenialReason.MEMBER_INACTIVE" in auth)
check("safe local audit written", "AuditAction.VERTO_CHAT_ACCESS_DENIED" in auth)
for forbidden in ["bodyText", "attachment", "phone", "permissionsJson" + " ="]:
    check(f"audit does not include sensitive field: {forbidden}", forbidden not in auth.split("AuditEventDraft(", 1)[-1])

sql = read(MIGRATION)
for capability in ["VIEW_VERTO_CHAT", "SEND_VERTO_CHAT"]:
    check(f"SQL capability present: {capability}", capability in sql)
check("SQL permission constraints validated", sql.count("validate constraint") >= 2)
check("SQL owner manager defaults", "m.role in ('OWNER', 'MANAGER')" in sql)
check("SQL send requires effective view", sql.count("m.permissions ->> 'VIEW_VERTO_CHAT'") >= 2)
check("inactive SQL member denied", "and m.is_active = true" in sql)
check("invite role copied", "role = v_invite.role" in sql and "v_invite.role," in sql)
check("invite permissions copied", "permissions = v_invite.permissions" in sql and "v_invite.permissions," in sql)
check("safe server denial log", "optimal_log_verto_capability_denial" in sql and "raise log" in sql)
check("server log excludes message payload", "body_text" not in sql[sql.index("create or replace function public.optimal_log_verto_capability_denial"):sql.index("create or replace function public.optimal_verto_current_context")])
check("RPC context checks view", "p_require_view and not public.optimal_member_has_capability" in sql)
check("RPC context checks send", "p_require_send and not public.optimal_member_has_capability" in sql)
for table in ["optimal_verto_conversations", "optimal_verto_messages", "optimal_verto_message_receipts", "optimal_verto_conversation_states"]:
    check(f"RLS policy or defense for {table}", table in sql and "create policy" in sql)
    check(f"direct Android grant revoked: {table}", f"revoke all on table public.{table}" in sql)
check("backend contract not promoted", "set verto_chat_ready = false" in sql and "contract_version = 23" not in sql)

preflight = read(PREFLIGHT)
check("preflight validates unknown keys", "v49_unknown_permission_accepted" in preflight)
check("preflight validates invitation persistence", "v49_invite_permissions_not_persisted_to_member" in preflight)
check("preflight validates direct grants absent", "v49_direct_android_table_grant_present" in preflight)

scenarios = read(SCENARIOS)
for token in [
    "v49_owner_defaults_invalid",
    "v49_manager_defaults_invalid",
    "v49_member_defaults_not_denied",
    "v49_view_only_override_invalid",
    "v49_delegated_member_invalid",
    "v49_send_bypassed_view",
    "v49_inactive_member_retained_capability",
]:
    check(f"SQL scenario: {token}", token in scenarios)

unit_tests = [
    ROOT / "core/model/src/test/kotlin/com/optimal/fleet/core/model/access/MemberAccessPolicyTest.kt",
    ROOT / "feature/settings/src/test/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicyTest.kt",
    ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAuthorizationUseCaseTest.kt",
]
check("three authorization test files exist", all(path.is_file() for path in unit_tests))
check("Gradle registers v49 gate", "vertoChatPermissionsContractCheck" in read(ROOT_GRADLE))
check("staticQualityCheck includes v49 gate", "vertoChatPermissionsContractCheck," in read(ROOT_GRADLE))
check("ci-fast runs v49 gate", "v49-verto-chat-permissions-contract.py" in read(CI_FAST))
check("ci-full retains v49 through current wrapper", any(x in read(CI_FULL) for x in ("verify-v49-static.sh", "verify-v53-static.sh", "verify-v54-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh")))
check("verify-project retains v49 through current wrapper", any(x in read(VERIFY_PROJECT) for x in ("verify-v49-static.sh", "verify-v53-static.sh", "verify-v54-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh")))
check("v49 wrapper delegates to v48", "verify-v48-static.sh" in read(WRAPPER))
test_text = "\n".join(read(path) for path in unit_tests)
for token in ["ownerAndManagerDefaultToViewAndSend", "sendCannotBeGrantedWithoutView", "deniedRefreshNeverInvokesRepository"]:
    check(f"unit coverage token: {token}", token in test_text)

passed = sum(1 for _, ok, _ in checks if ok)
print(f"v49 Verto chat permissions contract: {passed}/{len(checks)} PASS")
