#!/usr/bin/env python3
"""Executable model of v54 stable identity, timeout and retry semantics."""
from dataclasses import dataclass

@dataclass
class LocalMessage:
    local_id: str
    client_id: str
    idempotency: str
    body: str
    state: str = "PENDING"
    remote_id: str | None = None

class IdempotentServer:
    def __init__(self):
        self.by_key = {}
        self.created = 0

    def send(self, message: LocalMessage, lose_response=False):
        if message.idempotency not in self.by_key:
            self.created += 1
            self.by_key[message.idempotency] = f"remote-{self.created}"
        remote = self.by_key[message.idempotency]
        if lose_response:
            raise TimeoutError("response lost after commit")
        return remote

message = LocalMessage("local-1", "client-1", "idem-1", "مرحبا")
server = IdempotentServer()
assert message.state == "PENDING"
try:
    message.state = "SENDING"
    server.send(message, lose_response=True)
except TimeoutError:
    message.state = "FAILED_RETRYABLE"
assert message.state == "FAILED_RETRYABLE"
message.state = "PENDING"
message.state = "SENDING"
message.remote_id = server.send(message)
message.state = "SENT"
assert message.remote_id == "remote-1"
assert server.created == 1
assert len(server.by_key) == 1

permission_granted = False
pending = LocalMessage("local-2", "client-2", "idem-2", "محظور")
if not permission_granted:
    pending.state = "FAILED_TERMINAL"
assert pending.state == "FAILED_TERMINAL"
assert "idem-2" not in server.by_key

assert "   ".strip() == ""
print("v54 Local-first retry harness: 10/10 PASS")
