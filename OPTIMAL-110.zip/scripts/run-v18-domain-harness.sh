#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/LocalOtpRepository.kt" ]]; then
  echo "SKIP: v18 local-OTP harness was superseded by the v19 Supabase Auth path."
  exit 0
fi
OUT_DIR="$ROOT_DIR/.tmp-v18-domain-harness"
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR/stubs/javax/inject" "$OUT_DIR/stubs/kotlinx/coroutines"

cat > "$OUT_DIR/stubs/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
STUB

cat > "$OUT_DIR/stubs/kotlinx/coroutines/CancellationException.kt" <<'STUB'
package kotlinx.coroutines
typealias CancellationException = java.util.concurrent.CancellationException
STUB

kotlinc \
  "$OUT_DIR/stubs/javax/inject/Inject.kt" \
  "$OUT_DIR/stubs/kotlinx/coroutines/CancellationException.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/CompanyBootstrapCommand.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/CompanyBootstrapRepository.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/LocalOtpRepository.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RequestLocalOtpUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/VerifyLocalOtpUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/CompleteLocalOnboardingUseCase.kt" \
  "$ROOT_DIR/scripts/v18-domain-harness.kt" \
  -include-runtime \
  -d "$OUT_DIR/v18-domain-harness.jar"

java -jar "$OUT_DIR/v18-domain-harness.jar"
