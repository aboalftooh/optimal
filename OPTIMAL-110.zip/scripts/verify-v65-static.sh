#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v65-rls-isolation-security-contract.py
python3 scripts/security-release-check.py
./scripts/verify-v64-static.sh
python3 -m py_compile \
  scripts/v65-rls-isolation-security-contract.py \
  scripts/v65-live-rls-isolation-harness.py
bash -n scripts/verify-v65-static.sh
