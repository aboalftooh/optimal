#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, ok, detail))


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

base = "feature/finance/src/main/java/com/optimal/fleet/feature/finance"
dash = f"{base}/presentation/dashboard"
inv = f"{base}/presentation/invoices"
semantics = read(f"{base}/presentation/FinancePresentationSemantics.kt")
dashboard = read(f"{dash}/FinanceDashboardScreen.kt")
dash_components = read(f"{dash}/FinanceDashboardComponents.kt")
add_cost = read(f"{dash}/AddCostDialog.kt")
details_route = read(f"{inv}/InvoiceDetailsRoute.kt")
details = read(f"{inv}/InvoiceDetailsScreen.kt")
details_components = read(f"{inv}/InvoiceDetailsComponents.kt")
invoice_list = read(f"{inv}/InvoiceListScreen.kt")
list_components = read(f"{inv}/InvoiceListComponents.kt")
finance_nav = read(f"{base}/navigation/FinanceNavigation.kt")
app_nav = read("app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt")

# SESSION-104 monetary typography contract.
check("finance amount helper exists", "fun FinanceAmountText(" in semantics)
check("finance amount helper always uses Amount role", "style = OptimalTypographyRoles.amount" in semantics)
check("finance amount helper has no local font weight override", "fontWeight =" not in semantics)

# SCR-019 + STA-044..049: finance dashboard and AddCost dialog.
check("finance dashboard exists", "fun FinanceDashboardScreen(" in dashboard)
check("finance loading canonical", "OptimalLoadingState(" in dashboard and 'testTag("finance-loading")' in dashboard)
check("finance summary uses dashboard hero", "OptimalHeroSurface(" in dash_components and 'testTag("finance-total-hero")' in dash_components)
check("finance hero preserves operation total", "summary.operationTotalLabel" in dash_components)
check("finance monetary metrics canonical", dash_components.count("OptimalMetricCard(") >= 3)
check("finance refresh action canonical", "OptimalSecondaryButton(" in dash_components and "FinanceDashboardUiEvent.Refresh" in dashboard)
check("finance refresh busy state preserved", 'if (isRefreshing) "جارٍ التحديث"' in dash_components and "!isRefreshing" in dash_components)
check("finance unlinked state semantic", 'title = "Verto غير مرتبط"' in dash_components and "OptimalStatusTone.Warning" in dash_components)
check("finance message semantic", "OptimalInlineStatus(" in dashboard and 'testTag("finance-message")' in dashboard)
check("additional costs header preserved", 'title = "التكاليف الإضافية"' in dashboard)
check("additional cost open callback preserved", "FinanceDashboardUiEvent.OpenAddCost" in dashboard)
check("additional costs empty state canonical", 'title = "لا توجد تكاليف إضافية"' in dashboard and "FinanceInlineEmptyRow(" in dashboard)
check("additional costs empty primitive semantic", "OptimalInlineStatus(" in dash_components and "OptimalStatusTone.Neutral" in dash_components)
check("additional cost rows canonical", "OptimalListRow(" in dash_components and "AdditionalCostRow(" in dash_components)
check("Verto invoice section preserved", 'title = "فواتير Verto"' in dashboard)
check("Verto invoices empty preserved", 'title = "لا توجد فواتير Verto"' in dashboard)
check("finance invoice selection preserved", "FinanceDashboardUiEvent.InvoiceSelected(invoice.id)" in dashboard)
check("dashboard finance rows use amount helper", "FinanceAmountText(cost.amountLabel)" in dash_components and "FinanceAmountText(invoice.totalLabel)" in dash_components)

check("add-cost dialog canonical", "OptimalDialog(" in add_cost and 'testTag("add-cost-dialog")' in add_cost)
check("add-cost form canonical", "OptimalFormSection(" in add_cost)
check("add-cost description canonical", "OptimalTextField(" in add_cost and 'testTag = "cost-description"' in add_cost)
check("add-cost amount canonical", "OptimalMoneyField(" in add_cost and 'testTag = "cost-amount"' in add_cost)
check("add-cost date preserved", 'testTag = "cost-date"' in add_cost)
check("add-cost attachment preserved", 'testTag = "cost-attachment"' in add_cost)
check("add-cost field errors preserved", all(x in add_cost for x in ["descriptionError", "amountError", "dateError"]))
check("add-cost general error semantic", "OptimalInlineStatus(" in add_cost and "OptimalStatusTone.Danger" in add_cost)
check("add-cost save callback preserved", "FinanceDashboardUiEvent.SaveAdditionalCost" in add_cost)
check("add-cost close callback preserved", "FinanceDashboardUiEvent.CloseAddCost" in add_cost)
check("add-cost saving disable preserved", "enabled = !state.isSavingCost" in add_cost)

# SCR-020 + STA-050..051: details.
check("invoice details loading canonical", "state.isLoading -> OptimalLoadingState(" in details_route)
check("invoice details loading tag preserved", 'testTag("invoice-details-loading")' in details_route)
check("invoice details missing canonical", "state.invoice == null -> OptimalEmptyState(" in details_route)
check("invoice details missing copy preserved", 'title = "الفاتورة غير موجودة"' in details_route)
check("invoice details screen exists", "fun InvoiceDetailsScreen(" in details)
check("invoice details uses canonical hero", "OptimalHeroSurface(" in details_components and 'testTag("invoice-details-summary")' in details_components)
check("invoice hero shows identity", "invoice.numberLabel" in details_components)
check("invoice hero shows status", "OptimalStatusBadge(" in details_components and "financeInvoiceStatusTone" in details_components)
check("invoice hero shows total amount", "FinanceAmountText(" in details_components and "invoice.totalLabel" in details_components and "prominent = true" in details_components)
check("invoice facts section preserved", 'title = "بيانات الفاتورة"' in details)
check("invoice source id preserved", 'label = "معرف المصدر"' in details and "invoice.sourceId" in details)
check("invoice money section preserved", 'title = "المبالغ والدفع"' in details and "InvoiceMoneySection(invoice)" in details)
check("invoice paid and remaining metrics canonical", 'label = "المدفوع"' in details_components and 'label = "المتبقي"' in details_components)
check("invoice cost classification preserved", 'title = "تصنيف التكلفة"' in details_components)
check("invoice items section preserved", 'title = "بنود الفاتورة"' in details)
check("invoice items empty semantic", 'title = "لا توجد بنود محفوظة"' in details_components and "OptimalInlineStatus(" in details_components)
check("invoice line items canonical", 'testTag("invoice-line-item-${item.id}")' in details_components and "OptimalListRow(" in details_components)
check("invoice line amount uses amount helper", "FinanceAmountText(item.totalLabel)" in details_components)
check("official maintenance preserved", "OfficialMaintenanceSection(" in details and "maintenance.images.forEachIndexed" in details_components)
check("official image callback preserved", "onOpenImage(image.attachmentId)" in details_components)
check("legacy invoice notice semantic", "LegacyInvoiceLinkNotice" in details_components and "OptimalStatusTone.Warning" in details_components)
check("linked invoice notice semantic", "LinkedInvoiceRow" in details_components and "OptimalStatusTone.Success" in details_components)
check("financial source note semantic", 'title = "مرجع المبالغ"' in details and "OptimalInlineStatus(" in details)

# SCR-021 + STA-052..056: unreachable InvoiceList remains visually migrated but unreachable.
check("invoice list screen exists", "fun InvoiceListScreen(" in invoice_list)
check("invoice list summary hero canonical", "OptimalHeroSurface(" in list_components and 'testTag("invoice-remaining-hero")' in list_components)
check("invoice list remaining amount uses Amount helper", "FinanceAmountText(" in list_components and "state.totalRemainingLabel" in list_components)
check("invoice list refresh preserved", "InvoiceListUiEvent.Refresh" in invoice_list and "OptimalSecondaryButton(" in list_components)
check("invoice list message semantic", "OptimalInlineStatus(" in list_components and 'testTag("invoice-message")' in list_components)
check("invoice list search canonical", "OptimalSearchField(" in invoice_list and "InvoiceListUiEvent.SearchChanged(it)" in invoice_list)
check("invoice list clear search preserved", "InvoiceListUiEvent.ClearSearch" in invoice_list)
check("invoice list filters canonical", "OptimalFilterChip(" in invoice_list)
for label, enum in [("الكل", "ALL"), ("عليكم", "OUTSTANDING"), ("مدفوعة", "PAID"), ("ملغاة", "VOIDED")]:
    check(f"invoice filter preserved {enum}", f"InvoiceListFilter.{enum}" in invoice_list and f'"{label}"' in invoice_list)
check("invoice list loading canonical", "state.isLoading -> OptimalLoadingState(" in invoice_list and 'testTag("invoice-loading")' in invoice_list)
check("invoice list error canonical", "state.errorMessage != null -> OptimalErrorState(" in invoice_list and "InvoiceListUiEvent.Retry" in invoice_list)
check("invoice list empty canonical", "state.invoices.isEmpty() -> OptimalEmptyState(" in invoice_list)
check("invoice list empty/no-result copies preserved", '"لا توجد فواتير محفوظة"' in invoice_list and '"لا توجد نتائج"' in invoice_list)
check("invoice list rows canonical", "InvoiceListRow(" in invoice_list and "OptimalListRow(" in list_components)
check("invoice list selection preserved", "InvoiceListUiEvent.InvoiceSelected(invoice.id)" in invoice_list)
check("invoice list load-more action canonical", "OptimalSecondaryButton(" in invoice_list and "InvoiceListUiEvent.LoadMore" in invoice_list)
check("invoice append error semantic", 'item(key = "invoice-append-error")' in invoice_list and "OptimalInlineStatus(" in invoice_list and "OptimalStatusTone.Danger" in invoice_list)
check("invoice append retry preserved", 'actionLabel = "إعادة المحاولة"' in invoice_list and "InvoiceListUiEvent.LoadMore" in invoice_list)
check("invoice list amount helper used", "FinanceAmountText(invoice.totalLabel)" in list_components)

# Reachability freeze: InvoiceList stays absent from navigation, details route stays present.
check("finance navigation keeps dashboard", "FinanceDashboardConnected" in finance_nav)
check("finance navigation keeps invoice details", "InvoiceDetailsConnected" in finance_nav and "INVOICE_DETAILS_ROUTE" in finance_nav)
check("InvoiceListConnected remains absent from finance navigation", "InvoiceListConnected" not in finance_nav)
check("InvoiceList route is not added to app nav", "InvoiceListConnected" not in app_nav and "InvoiceListRoute" not in app_nav)

# Functional freeze: these v103 non-visual files must remain byte-identical.
expected_hashes = {
    f"{dash}/FinanceDashboardContract.kt": "5e683ce7edf66627cfa801b6bb64d2de4d5b5e42ab72ac2d12d181a26ed1d256",
    f"{dash}/FinanceDashboardViewModel.kt": "5a2b5745b9bf0875c103a810adfd5e48d8fba2bb2222344e42638a1e663ffd44",
    f"{inv}/InvoiceDetailsContract.kt": "5996c5f0695ad26a506f04995c2ef6a1c99fe56387080a8a61bd3cf871991ac6",
    f"{inv}/InvoiceDetailsViewModel.kt": "7adb86c50b5bbe080b67765b6f74fabfdf149429823d4d1b0a484c5a8ddc043d",
    f"{inv}/InvoiceListContract.kt": "f2e2da2e64b1e1fc5ccc13e00cff8a903a0c874afe3d59e32d4d4149ff2bd579",
    f"{inv}/InvoiceListViewModel.kt": "5e1a51d4e262dbaa6f44c1588de71c5b1fc2fde59818f9152d5b57826d370a80",
    f"{base}/navigation/FinanceNavigation.kt": "caa42fbea7bb0d8b83bf9dfdd8c3c79ea21158f39ecc01a1714f1d0adbefd675",
    "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt": "fb2e94c9b53dd8094967a886004d1a86304b02d35a80900f9e8029e7df8003ad",
}
for rel, expected in expected_hashes.items():
    actual = sha256(rel)
    check(f"v103 functional boundary unchanged: {Path(rel).name}", actual == expected, actual)

# Ledger / allowlist acceptance.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
rows = re.findall(r"^\| ((?:SCR|DLG|OVL|CMP|STA)-\d{3}) \|.*\| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| SESSION-\d+ \|$", ledger, flags=re.M)
statuses = dict(rows)
expected_104 = {"SCR-019", "SCR-020", "SCR-021", "DLG-003", *(f"STA-{i:03d}" for i in range(44, 57))}
check("ledger retains 123 rows", len(rows) == 123, str(len(rows)))
check("all SESSION-104 inventory migrated", all(statuses.get(i) == "MIGRATED" for i in expected_104), str(sorted(i for i in expected_104 if statuses.get(i) != "MIGRATED")))
check("ledger migrated total is 86", sum(status == "MIGRATED" for _, status in rows) == 86)
check("ledger unmigrated total is 37", sum(status == "UNMIGRATED" for _, status in rows) == 37)
check("ledger has no blocked rows", all(status != "BLOCKED" for _, status in rows))

allow = [line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines() if line.strip() and not line.lstrip().startswith("#")]
check("Finance UI removed from allowlist", not any(path.startswith(f"{base}/presentation/") for path in allow))
check("remaining allowlist is 22 UI files", len(allow) == 22, str(len(allow)))

# Every Finance Compose UI file must now be free of local visual-language violations.
ui_files: list[Path] = []
for path in sorted((ROOT / f"{base}/presentation").rglob("*.kt")):
    text = path.read_text(encoding="utf-8")
    if "@Composable" not in text and "@androidx.compose.runtime.Composable" not in text:
        continue
    ui_files.append(path)
    rel = path.relative_to(ROOT).as_posix()
    check(f"{rel} has no raw dp", re.search(r"(?<![A-Za-z0-9_])\d+(?:\.\d+)?\.dp\b", text) is None)
    check(f"{rel} has no raw hex color", "Color(0x" not in text)
    check(f"{rel} has no local font family", "FontFamily(" not in text and "fontFamily =" not in text)
    check(f"{rel} has no raw font size", re.search(r"fontSize\s*=\s*\d+(?:\.\d+)?\.sp\b", text) is None)
    check(f"{rel} has no raw rounded shape", "RoundedCornerShape(" not in text)
    check(f"{rel} has no direct Material field", re.search(r"(?<![A-Za-z0-9_])(?:OutlinedTextField|TextField)\s*\(", text) is None)
    check(f"{rel} has no direct Material button", re.search(r"(?<![A-Za-z0-9_])(?:Button|OutlinedButton|TextButton)\s*\(", text) is None)
    check(f"{rel} has no direct AlertDialog", re.search(r"(?<![A-Za-z0-9_])AlertDialog\s*\(", text) is None)
check("Finance has 11 Compose UI files", len(ui_files) == 11, str(len(ui_files)))

proc = subprocess.run([sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")], cwd=ROOT, text=True, capture_output=True)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("compliance guard passes", proc.returncode == 0)

failed = [item for item in checks if not item[1]]
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-104 static acceptance: {len(checks)-len(failed)}/{len(checks)}")
sys.exit(1 if failed else 0)
