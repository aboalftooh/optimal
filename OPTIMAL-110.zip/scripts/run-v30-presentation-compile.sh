#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs/androidx/lifecycle" "$TMP_DIR/stubs/androidx/compose/runtime" "$TMP_DIR/stubs/dagger/hilt/android/lifecycle" "$TMP_DIR/stubs/javax/inject" "$TMP_DIR/stubs/kotlinx/coroutines/flow"

cat > "$TMP_DIR/stubs/androidx/lifecycle/Lifecycle.kt" <<'STUB'
package androidx.lifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
open class ViewModel
val ViewModel.viewModelScope: CoroutineScope
    get() = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
STUB

cat > "$TMP_DIR/stubs/androidx/compose/runtime/Immutable.kt" <<'STUB'
package androidx.compose.runtime
@Target(AnnotationTarget.CLASS)
annotation class Immutable
STUB

cat > "$TMP_DIR/stubs/dagger/hilt/android/lifecycle/HiltViewModel.kt" <<'STUB'
package dagger.hilt.android.lifecycle
@Target(AnnotationTarget.CLASS)
annotation class HiltViewModel
STUB

cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
STUB

cat > "$TMP_DIR/stubs/kotlinx/coroutines/flow/Update.kt" <<'STUB'
package kotlinx.coroutines.flow
import kotlinx.coroutines.InternalCoroutinesApi
inline fun <T> MutableStateFlow<T>.update(function: (T) -> T) {
    value = function(value)
}
@OptIn(InternalCoroutinesApi::class)
suspend fun <T> Flow<T>.collect(action: suspend (T) -> Unit) {
    collect(object : FlowCollector<T> {
        override suspend fun emit(value: T) = action(value)
    })
}
STUB

COMMON=(
  "$TMP_DIR/stubs/androidx/lifecycle/Lifecycle.kt"
  "$TMP_DIR/stubs/androidx/compose/runtime/Immutable.kt"
  "$TMP_DIR/stubs/dagger/hilt/android/lifecycle/HiltViewModel.kt"
  "$TMP_DIR/stubs/javax/inject/Inject.kt"
  "$TMP_DIR/stubs/kotlinx/coroutines/flow/Update.kt"
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt"
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorPresentation.kt"
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt"
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt"
)

kotlinc -cp "$COROUTINES_JAR" \
  "${COMMON[@]}" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/OnboardingRepository.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/ValidateJoinCodeUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RequestOtpUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/VerifyOtpUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/CompleteOnboardingUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RestoreSessionUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RestorePendingOnboardingUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/DiscardPendingOnboardingUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/SignOutUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthContract.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt" \
  -d "$TMP_DIR/auth-presentation.jar"

echo "PASS: Auth contracts and ViewModel compile"

kotlinc -cp "$COROUTINES_JAR" \
  "${COMMON[@]}" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/InviteCodePolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberRepository.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberUseCases.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyContract.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyViewModel.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersContract.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt" \
  -d "$TMP_DIR/settings-presentation.jar"

echo "PASS: Member contracts and ViewModels compile"
echo "V30 focused presentation compilation: 2/2"
