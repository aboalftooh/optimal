#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

REPORT_DIR="${V66_REPORT_DIR:-build/reports/v66}"
mkdir -p "$REPORT_DIR"

python3 scripts/v66-comprehensive-regression-contract.py
python3 scripts/v66-comprehensive-regression.py --shard foundation --report "$REPORT_DIR/foundation.json"
python3 scripts/v66-comprehensive-regression.py --shard backend --report "$REPORT_DIR/backend.json"
python3 scripts/v66-comprehensive-regression.py --shard verto --report "$REPORT_DIR/verto.json"
python3 scripts/v66-comprehensive-regression.py --shard legacy --report "$REPORT_DIR/legacy.json"
python3 -m py_compile \
  scripts/v66-test-inventory-contract.py \
  scripts/v66-comprehensive-regression.py \
  scripts/v66-comprehensive-regression-contract.py
bash -n scripts/verify-v66-static.sh
