#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v56 Verto local audio recording."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "manifest": ROOT / "feature/verto/src/main/AndroidManifest.xml",
    "audio_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/audio/VertoAudioRecorder.kt",
    "recorder": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/AndroidVertoAudioRecorder.kt",
    "usecase": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAudioUseCases.kt",
    "module": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/di/VertoAttachmentModule.kt",
    "model": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoOutgoingAttachment.kt",
    "validator": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/attachment/VertoAttachmentImporter.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt",
    "picker": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentPickerCoordinator.kt",
    "route": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "playback": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAudioPlayback.kt",
    "tests": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAudioUseCaseTest.kt",
    "state_tests": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoChatUiStateTest.kt",
}
CHAT_PRESENTATION_DIR = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation"
CHAT_PRESENTATION_FILES = (
    "VertoChatScreen.kt",
    "VertoChatChrome.kt",
    "VertoChatMessages.kt",
    "VertoChatAttachments.kt",
    "VertoChatComposer.kt",
    "VertoChatFormatting.kt",
)

def chat_presentation_text() -> str:
    return "\n".join(
        (CHAT_PRESENTATION_DIR / name).read_text(encoding="utf-8")
        for name in CHAT_PRESENTATION_FILES
    )

checks = []
def text(name):
    path = FILES[name]
    assert path.is_file(), f"missing {path.relative_to(ROOT)}"
    if name == "screen":
        return chat_presentation_text()
    return path.read_text(encoding="utf-8")
def check(label, condition):
    assert condition, label
    checks.append(label)

manifest = text("manifest")
check("manifest runtime microphone permission", 'android.permission.RECORD_AUDIO' in manifest)

contract = text("audio_contract")
for token in ["interface VertoAudioRecorder", "fun start()", "fun stop()", "fun cancel()", "fun discard(localPrivatePath: String)", "AlreadyRecording", "NotRecording", "EMPTY_FILE", "INVALID_CONTENT", "STORAGE_FAILED"]:
    check(f"audio contract:{token}", token in contract)

recorder = text("recorder")
for token in ["MediaRecorder", "AudioSource.MIC", "OutputFormat.MPEG_4", "AudioEncoder.AAC", "MediaMetadataRetriever", "METADATA_KEY_DURATION", "AUDIO_MP4_MIME", "filesDir", "verto/audio-drafts", "verto/attachments", ".m4a.part", ".m4a", "AtomicMoveNotSupportedException", "synchronized(lock)", "cleanupInterruptedDrafts", "stagingFile.delete()", "recorder.stop()", "recorder.reset()", "release()"]:
    check(f"recorder:{token}", token in recorder)
check("actual metadata duration is required", "durationMillis == null || durationMillis <= 0L" in recorder)
check("private relative path persisted", 'localPrivatePath = "$ATTACHMENT_DIRECTORY/$generatedName"' in recorder)
check("draft discard canonical path", "target.path.startsWith(attachmentRoot.path + File.separator)" in recorder)
check("no public storage", all(x not in recorder for x in ["Environment.getExternalStorage", "MediaStore", "getExternalFilesDir"]))
check("no artificial duration/size ceiling", all(x not in recorder for x in ["setMaxDuration", "setMaxFileSize"]))

usecase = text("usecase")
for token in ["StartVertoAudioRecordingUseCase", "authorizeSend()", "recorder.start()", "StopVertoAudioRecordingUseCase", "CancelVertoAudioRecordingUseCase", "SendVertoAudioDraftUseCase", "DiscardVertoAudioDraftUseCase", "repository.enqueueAttachmentMessage", "recorder.discard"]:
    check(f"usecase:{token}", token in usecase)
check("authorization precedes microphone", usecase.index("authorizeSend()") < usecase.index("recorder.start()"))
check("audio kind asserted before save", "require(attachment.kind == VertoAttachmentKind.AUDIO)" in usecase)

module = text("module")
check("recorder Hilt binding", "bindVertoAudioRecorder" in module and "AndroidVertoAudioRecorder" in module)

model = text("model")
check("actual positive duration invariant", "Audio attachments require an actual positive duration" in model)
check("picker cannot forge audio selection", "expectedKind != VertoAttachmentKind.AUDIO" in model)
validator = text("validator")
for token in ["AUDIO_MP4_MIME", '"audio/aac"', '"audio/mp4a-latm"', '"m4a"']:
    check(f"validator:{token}", token in validator)
repo = text("repository")
check("audio message persisted", "VertoAttachmentKind.AUDIO -> VertoMessageKind.AUDIO" in repo)
start = repo.index("override suspend fun enqueueAttachmentMessage")
end = repo.index("override suspend fun syncPendingTextMessage", start)
check("v56 does not schedule upload", "SyncOperationType.UPLOAD" not in repo[start:end])
check("audio remains local-ready", "VertoAttachmentTransferState.LOCAL_READY.name" in repo[start:end])

ui = text("contract")
for token in ["VertoAudioDraftUiState", "recordingAudio", "audioRecordingElapsedMillis", "audioDraft", "audioOperationInProgress", "composerLockedByAudio", "audioRecordEnabled", "audioDraftSendEnabled", "StartAudioRecording", "StopAudioRecording", "CancelAudioRecording", "SendAudioDraft", "DiscardAudioDraft"]:
    check(f"ui contract:{token}", token in ui)
picker = text("picker")
for token in ["recordAudio", "RequestPermission", "Manifest.permission.RECORD_AUDIO", "onAudioPermissionGranted"]:
    check(f"picker:{token}", token in picker)
route = text("route")
for token in ["onAudioPermissionGranted", "StartAudioRecording", "StopAudioRecording", "CancelAudioRecording", "SendAudioDraft", "DiscardAudioDraft", "DisposableEffect"]:
    check(f"route:{token}", token in route)
viewmodel = text("viewmodel")
for token in ["beginAudioRecording", "finishAudioRecording", "cancelActiveAudioRecording", "saveAudioDraft", "discardPendingAudioDraft", "startRecordingTimer", "System.nanoTime", "pendingAudioAttachment", "audioGeneration", "cancelAudioRecordingUseCase", "conversationChanged", "!snapshot.sendAuthorized", "onCleared"]:
    check(f"viewmodel:{token}", token in viewmodel)
screen = text("screen")
for token in ["VertoAudioRecordingComposer", "VertoAudioDraftComposer", "rememberVertoAudioPlaybackState", "AUDIO_RECORD_TAG", "AUDIO_STOP_TAG", "AUDIO_PREVIEW_TAG", "AUDIO_DISCARD_TAG", "AUDIO_SEND_TAG", "formatDuration", "VertoAttachmentKind.AUDIO"]:
    check(f"screen:{token}", token in screen)
playback = text("playback")
for token in ["MediaPlayer", "canonicalFile", "startsWith", "prepare()", "pause()", "release()", "isPlaying", "positionMillis"]:
    check(f"playback:{token}", token in playback)
check("playback reads app-private files", "applicationContext.filesDir" in playback)

unit = text("tests")
for token in ["deniedSendPermissionDoesNotOpenTheMicrophone", "stoppedRecordingReturnsActualDurationAndPrivatePath", "localSaveFailureKeepsDraftAvailableForRetry", "explicitDiscardDeletesOnlyThePrivateDraft"]:
    check(f"unit test:{token}", token in unit)
state_tests = text("state_tests")
for token in ["activeRecordingLocksTextAndAttachmentsButAllowsStop", "audioDraftCanBeSavedOrDiscardedWithoutEnablingTextSend"]:
    check(f"state test:{token}", token in state_tests)


build = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
ci_fast = (ROOT / "scripts/ci-fast.sh").read_text(encoding="utf-8")
ci_full = (ROOT / "scripts/ci-full.sh").read_text(encoding="utf-8")
verify_project = (ROOT / "scripts/verify-project.sh").read_text(encoding="utf-8")
check("Gradle registers v56 gate", "vertoAudioContractCheck" in build and "scripts/v56-verto-audio-contract.py" in build)
check("staticQualityCheck depends on v56", "vertoAudioContractCheck," in build)
check("ci-fast starts with v56", "scripts/v56-verto-audio-contract.py" in ci_fast and "scripts/v56-verto-audio-harness.py" in ci_fast)
check("ci-full preserves v56 through latest wrapper", any(f"verify-v{version}-static.sh" in ci_full for version in range(56, 60)))
check("verify-project preserves v56 through latest wrapper", any(f"verify-v{version}-static.sh" in verify_project for version in range(56, 60)))

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains immutable", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("no v56 Supabase migration", not any((ROOT / "supabase/migrations").glob("*v56*")))
all_text = "\n".join(path.read_text(encoding="utf-8") for path in FILES.values())
check("no merge markers", not any(marker in all_text for marker in ("<<<<<<<", "=======", ">>>>>>>")))
print(f"v56 Verto audio contract: {len(checks)}/{len(checks)} PASS")
