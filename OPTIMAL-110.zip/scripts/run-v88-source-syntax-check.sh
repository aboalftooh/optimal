#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/ui/OptimalApp.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalColors.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalSpacing.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalFields.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalRows.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2/OptimalSegments.kt"
  "$ROOT_DIR/core/designsystem/src/main/java/com/optimal/fleet/designsystem/preview/OptimalComponentPreviews.kt"
  "$ROOT_DIR/core/designsystem/src/test/java/com/optimal/fleet/designsystem/FoundationContractTest.kt"
  "$ROOT_DIR/core/designsystem/src/androidTest/java/com/optimal/fleet/designsystem/DesignSystemComponentTest.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthComponents.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthOnboardingSteps.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthAccountContent.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsComponents.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsComponents.kt"
  "$ROOT_DIR/feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailComponents.kt"
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatAttachments.kt"
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoHomeEntry.kt"
)
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 90s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected|conflicting declarations)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected|conflicting declarations)' "$OUT"
  echo "FAIL: v88 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v88 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} changed v88 Kotlin/test files; unresolved Android/Compose symbols were intentionally ignored without Gradle classpath."
