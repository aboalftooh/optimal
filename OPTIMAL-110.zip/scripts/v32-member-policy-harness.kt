import com.optimal.fleet.core.model.access.MemberCapability
import com.optimal.fleet.core.model.access.MemberRole
import com.optimal.fleet.feature.settings.domain.members.Member
import com.optimal.fleet.feature.settings.domain.members.MemberAccessPolicy

private var passed = 0
private var total = 0
private fun checkContract(name: String, condition: Boolean) {
    total++
    check(condition) { "FAIL: $name" }
    passed++
    println("PASS: $name")
}

private fun member(
    role: MemberRole,
    active: Boolean = true,
    overrides: Map<MemberCapability, Boolean> = emptyMap(),
) = Member("member", "company-a", "عضو", null, active, 0L, role, overrides)

fun main() {
    val managementCapabilities = setOf(
        MemberCapability.VIEW_MEMBER_DIRECTORY,
        MemberCapability.CREATE_MEMBER_INVITE,
        MemberCapability.RESEND_MEMBER_INVITE,
        MemberCapability.REVOKE_MEMBER_INVITE,
        MemberCapability.CHANGE_MEMBER_STATUS,
    )
    listOf(MemberRole.OWNER, MemberRole.MANAGER).forEach { role ->
        checkContract("$role gets all capabilities", member(role).capabilities == MemberCapability.values().toSet())
    }
    listOf(MemberRole.ENGINEER, MemberRole.ACCOUNTANT, MemberRole.DRIVER, MemberRole.MEMBER).forEach { role ->
        checkContract("$role keeps management defaults only", member(role).capabilities == managementCapabilities)
    }
    checkContract("unknown role fails closed", member(MemberRole.UNKNOWN).capabilities.isEmpty())
    checkContract("inactive member fails closed", member(MemberRole.MEMBER, active = false).capabilities.isEmpty())
    checkContract(
        "explicit false override revokes one capability",
        !MemberAccessPolicy.can(
            member(MemberRole.MEMBER, overrides = mapOf(MemberCapability.REVOKE_MEMBER_INVITE to false)),
            MemberCapability.REVOKE_MEMBER_INVITE,
        ),
    )
    checkContract(
        "delegated member can view and send Verto chat",
        member(
            MemberRole.MEMBER,
            overrides = mapOf(
                MemberCapability.VIEW_VERTO_CHAT to true,
                MemberCapability.SEND_VERTO_CHAT to true,
            ),
        ).capabilities.containsAll(setOf(MemberCapability.VIEW_VERTO_CHAT, MemberCapability.SEND_VERTO_CHAT)),
    )
    checkContract(
        "send cannot bypass view",
        MemberCapability.SEND_VERTO_CHAT !in member(
            MemberRole.MEMBER,
            overrides = mapOf(MemberCapability.SEND_VERTO_CHAT to true),
        ).capabilities,
    )
    println("V32 member policy harness: $passed/$total")
}
