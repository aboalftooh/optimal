#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILES=(
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsScreen.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsComponents.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersRoute.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreen.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersDialogs.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityScreen.kt"
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityComponents.kt"
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountRoute.kt"
  "$ROOT_DIR/feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreenV84Test.kt"
  "$ROOT_DIR/feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityScreenV84Test.kt"
  "$ROOT_DIR/feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AccountRouteV84Test.kt"
)
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 90s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: v84 Kotlin parser diagnostics found" >&2
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then
  echo "FAIL: v84 Kotlin parser timed out" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} changed v84 Kotlin/test files; unresolved Android/Compose symbols were intentionally ignored without Gradle classpath."
