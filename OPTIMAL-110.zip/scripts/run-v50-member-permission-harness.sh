#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p \
  "$TMP_DIR/stubs/javax/inject" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/common/error" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/session"
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/common/error/DomainError.kt" <<'KT'
package com.optimal.fleet.core.common.error
open class DomainError
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/session/Session.kt" <<'KT'
package com.optimal.fleet.core.session
import kotlinx.coroutines.flow.Flow
data class ActiveSession(
    val userId: String,
    val companyId: String,
    val userDisplayName: String,
    val companyName: String,
)
interface SessionReader {
    fun observeActiveSession(): Flow<ActiveSession?>
    suspend fun currentSession(): ActiveSession?
}
KT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  "$TMP_DIR/stubs/javax/inject/Inject.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/session/Session.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberRepository.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/InviteCodePolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberUseCases.kt" \
  "$ROOT_DIR/scripts/v50-member-permission-harness.kt" \
  -include-runtime -d "$TMP_DIR/v50-member-permission.jar"
java -cp "$TMP_DIR/v50-member-permission.jar:$COROUTINES_JAR" \
  com.optimal.fleet.feature.settings.domain.members.V50_member_permission_harnessKt
