#!/usr/bin/env python3
"""Fail-closed regression guard for the Kotlin/JUnit test inventory frozen at v66."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "config" / "v66-test-baseline.txt"

MINIMUMS = {
    "app": 34,
    "core/common": 2,
    "core/database": 24,
    "core/designsystem": 2,
    "core/model": 2,
    "core/session": 1,
    "core/testing": 1,
    "feature/auth": 6,
    "feature/finance": 17,
    "feature/home": 4,
    "feature/maintenance": 21,
    "feature/notifications": 5,
    "feature/settings": 8,
    "feature/vehicles": 7,
    "feature/verto": 12,
}

CRITICAL_TESTS = {
    "authentication": "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/SessionUseCasesTest.kt",
    "tenant_session": "core/session/src/test/kotlin/com/optimal/fleet/core/session/ActiveSessionTest.kt",
    "vehicle_validation": "feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleValidationTest.kt",
    "offline_operation": "feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/CreateMaintenanceOperationTest.kt",
    "completion_idempotency": "feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/complete/CompletionIdempotencyTest.kt",
    "money_precision": "feature/finance/src/test/java/com/optimal/fleet/feature/finance/domain/MoneyPrecisionTest.kt",
    "invoice_deduplication": "feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/InvoiceDeduplicationTest.kt",
    "room_migration": "core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV3MigrationTest.kt",
    "member_access": "feature/settings/src/test/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicyTest.kt",
    "notification_deduplication": "feature/notifications/src/test/java/com/optimal/fleet/feature/notifications/NotificationDeduplicationTest.kt",
    "verto_authorization": "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAuthorizationUseCaseTest.kt",
    "attachment_transfer": "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAttachmentTransferPolicyTest.kt",
    "rtl_accessibility": "core/designsystem/src/androidTest/java/com/optimal/fleet/designsystem/RtlSemanticsTest.kt",
}

FORBIDDEN_DISABLE_PATTERNS = {
    "JUnit Ignore": re.compile(r"@Ignore\b"),
    "JUnit5 Disabled": re.compile(r"@Disabled\b"),
    "forced false assumption": re.compile(r"assume(?:True|That)\s*\(\s*false\b", re.IGNORECASE),
}


def module_of(path: str) -> str:
    parts = Path(path).parts
    if not parts:
        return ""
    if parts[0] == "app":
        return "app"
    if parts[0] in {"core", "feature"} and len(parts) >= 2:
        return f"{parts[0]}/{parts[1]}"
    return parts[0]


def discover() -> set[str]:
    found: set[str] = set()
    for top in ("app", "core", "feature"):
        for path in (ROOT / top).rglob("*Test.kt"):
            rel = path.relative_to(ROOT).as_posix()
            if "/src/test/" in rel or "/src/androidTest/" in rel:
                found.add(rel)
    return found


def main() -> int:
    checks: list[tuple[str, bool, str]] = []

    baseline_lines = [line.strip() for line in BASELINE.read_text(encoding="utf-8").splitlines() if line.strip()]
    baseline = set(baseline_lines)
    current = discover()

    checks.append(("baseline has 146 unique tests", len(baseline_lines) == 146 and len(baseline) == 146, f"count={len(baseline_lines)}, unique={len(baseline)}"))
    checks.append(("no v66 baseline test was deleted", baseline <= current, f"missing={sorted(baseline-current)}"))

    unit = {path for path in current if "/src/test/" in path}
    android = {path for path in current if "/src/androidTest/" in path}
    checks.append(("unit-test floor retained", len(unit) >= 109, f"current={len(unit)}, floor=109"))
    checks.append(("instrumented-test floor retained", len(android) >= 37, f"current={len(android)}, floor=37"))

    counts = Counter(module_of(path) for path in current)
    for module, minimum in MINIMUMS.items():
        checks.append((f"module floor {module}", counts[module] >= minimum, f"current={counts[module]}, floor={minimum}"))

    for scenario, path in CRITICAL_TESTS.items():
        checks.append((f"critical scenario {scenario}", path in current, path))

    disabled: list[str] = []
    malformed: list[str] = []
    for rel in sorted(baseline):
        text = (ROOT / rel).read_text(encoding="utf-8")
        if "@Test" not in text:
            malformed.append(rel)
        for label, pattern in FORBIDDEN_DISABLE_PATTERNS.items():
            if pattern.search(text):
                disabled.append(f"{rel}: {label}")
    checks.append(("baseline files contain executable test declarations", not malformed, f"without @Test={malformed}"))
    checks.append(("baseline tests are not explicitly disabled", not disabled, f"disabled={disabled}"))

    failures = 0
    for name, ok, detail in checks:
        if ok:
            print(f"PASS: {name}")
        else:
            failures += 1
            print(f"FAIL: {name} ({detail})")

    print(f"V66 test inventory: {len(checks)-failures}/{len(checks)} PASS; current files={len(current)} (unit={len(unit)}, androidTest={len(android)})")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
