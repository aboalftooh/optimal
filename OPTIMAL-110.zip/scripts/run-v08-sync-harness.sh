#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "NOTICE: v08 sync harness is superseded by the compile-valid v29 sync engine harness."
exec "$ROOT_DIR/scripts/run-v29-sync-harness.sh"
