#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=''):
    checks.append((name, bool(condition), detail))

def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

required = [
    'core/database/src/main/java/com/optimal/fleet/core/database/entity/MaintenanceFollowUpEntity.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceCompletionDbResult.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/FollowUpConversionDbResult.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceFollowUpRow.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/complete/MaintenanceCompletion.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/complete/MaintenanceCompletionValidation.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/complete/CompleteMaintenanceOperation.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/MaintenanceFollowUp.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/MaintenanceFollowUpClassifier.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/ObserveMaintenanceFollowUps.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/followup/CreateOperationFromFollowUp.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/history/ObserveMaintenanceHistory.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceOperationCompleter.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceHistoryQuery.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceFollowUpRepository.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryRoute.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history/MaintenanceHistoryViewModel.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpRoute.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpViewModel.kt',
]
for rel in required:
    check(f'required {rel}', (ROOT / rel).is_file())

entity = read(required[0])
dao = read('core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceDao.kt')
database = read('core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt')
migration = read('core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt')
repo = '\n'.join((ROOT / f'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/{part}.kt').read_text(encoding='utf-8') for part in ['RoomMaintenanceCreateRepository', 'RoomMaintenanceEditRepository', 'RoomMaintenanceCompleteRepository', 'RoomMaintenanceFollowUpRepository'])
completion = read(required[4])
validator = read(required[5])
complete_uc = read(required[6])
followup = read(required[7])
classifier = read(required[8])
observe_followup = read(required[9])
convert_uc = read(required[10])
history_uc = read(required[11])
details_contract = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt')
details_vm = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt')
details_route = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsRoute.kt')
nav = read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt')
app_nav = read('app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt')
app_dest = read('app/src/main/java/com/optimal/fleet/navigation/AppDestination.kt')

# Room and migration
for field in ['companyId','vehicleId','sourceOperationId','reason','dueDateEpochMillis','dueOdometerKm','convertedOperationId','createdByUserId','syncState']:
    check(f'follow-up field {field}', f'val {field}:' in entity)
check('follow-up source unique per company', 'Index(value = ["sourceOperationId", "companyId"], unique = true)' in entity)
check('follow-up company/vehicle FK', 'childColumns = ["vehicleId", "companyId"]' in entity)
check('follow-up source operation FK', 'childColumns = ["sourceOperationId", "companyId"]' in entity)
check('follow-up converted operation FK', 'childColumns = ["convertedOperationId", "companyId"]' in entity)
check('follow-up creator FK', 'childColumns = ["createdByUserId", "companyId"]' in entity)
check('delete restricted', entity.count('onDelete = ForeignKey.RESTRICT') == 5)
check('database version five or later', any(f'version = {v}' in database for v in range(5, 20)))
check('follow-up entity registered', 'MaintenanceFollowUpEntity::class' in database)
check('migration 4 to 5 exists', 'MIGRATION_4_5' in migration and 'Migration(4, 5)' in migration)
check('migration creates follow-up table', 'CREATE TABLE IF NOT EXISTS `maintenance_follow_ups`' in migration)
check('full migration chain', all(x in migration for x in ['MIGRATION_1_2','MIGRATION_2_3','MIGRATION_3_4','MIGRATION_4_5']))
check('schema five exported', (ROOT / 'core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/5.json').is_file())
check('no destructive migration', 'fallbackToDestructiveMigration' not in '\n'.join(
    p.read_text(encoding='utf-8') for p in ROOT.rglob('*.kt')
    if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix()
))

# Atomic completion and history
check('completion DAO transaction', '@Transaction' in dao and 'completeWithFollowUpAndAudit' in dao)
check('completion guarded by in-progress', "AND status = 'IN_PROGRESS'" in dao)
check('completion detects completed', 'current.status == "COMPLETED"' in dao)
check('completion updates vehicle only if newer', 'updateVehicleOdometerIfNewer' in dao and 'odometerKm < :odometerKm' in dao)
check('completion inserts optional follow-up', 'followUp?.let { insertFollowUp(it) }' in dao)
check('completion inserts audit last', 'insertAudit(audit)' in dao)
check('history reads completed operations', 'observeCompletedHistory' in dao and "status = 'COMPLETED'" in dao)
check('history is no duplicated table', 'maintenance_history' not in database.lower())
check('no delete operation query', not re.search(r'DELETE\s+FROM\s+maintenance_operations', dao, re.I))
check('repository implements completion/history/follow-up', all(x in repo for x in ['MaintenanceOperationCompleter','MaintenanceHistoryQuery','MaintenanceFollowUpRepository']))
check('repository protects Verto costs', 'current.source == OperationSource.VERTO.name' in repo)
check('repository writes completion action', 'MaintenanceAuditAction.COMPLETED' in repo)
check('repository writes follow-up conversion action', 'MaintenanceAuditAction.FOLLOW_UP_CONVERTED' in repo)
check('conversion is transaction', '@Transaction' in dao and 'convertFollowUpToOperation' in dao)
check('conversion marks follow-up', 'markFollowUpConverted' in dao)
check('conversion creates in-progress operation', 'status = OperationStatus.IN_PROGRESS.name' in repo)
check('conversion prefills reason', 'description = followUp.reason' in repo)

# Domain
for field in ['finalDescription','completedAtEpochMillis','odometerKm','partsCostMinor','serviceCostMinor','followUp']:
    check(f'completion field {field}', f'val {field}:' in completion)
for token in ['MissingDescription','MissingCompletionDate','InvalidOdometer','InvalidPartsCost','InvalidServiceCost','MissingFollowUpReason','MissingFollowUpTrigger']:
    check(f'validator issue {token}', token in validator)
check('completion normalizes text', 'finalDescription.trim()' in validator and 'reason.trim()' in validator)
check('use case reads session', 'sessionReader.currentSession()' in complete_uc)
check('use case validates before write', 'MaintenanceCompletionValidator.validate' in complete_uc)
check('classifier has injected clock', 'private val clock: Clock' in classifier and '@Inject constructor' in classifier)
for token in ['UPCOMING','DUE','OVERDUE']:
    check(f'follow-up state {token}', token in followup)
check('classifier uses local day', 'toLocalDate()' in classifier)
check('classifier chooses most urgent', 'maxByOrNull' in classifier)
check('follow-up observe company scoped', 'session.companyId' in observe_followup)
check('follow-up sorted by urgency', 'compareByDescending' in observe_followup)
check('history explicitly filters completed', 'OperationStatus.COMPLETED' in history_uc)
check('history company scoped', 'session.companyId' in history_uc)
check('conversion use case reads session', 'sessionReader.currentSession()' in convert_uc)

# Presentation/navigation
check('details exposes complete capability', 'val canComplete' in details_contract)
check('details has completion events', all(x in details_contract for x in ['StartCompletion','ConfirmCompletion','CancelCompletion']))
check('viewmodel uses complete use case', 'CompleteMaintenanceOperation' in details_vm)
check('viewmodel uses injected clock', 'private val clock: Clock' in details_vm)
check('Verto costs read only in VM', 'details.source == OperationSource.VERTO' in details_vm)
check('completion route exists', 'MaintenanceCompletionContent' in details_route)
check('completion button exists', 'complete-maintenance-operation' in details_route)
check('follow-up fields exist', all(x in details_route for x in ['followup-reason','followup-date','followup-odometer']))
check('history route connected', 'MAINTENANCE_HISTORY_ROUTE' in nav and 'MaintenanceHistoryConnected' in nav)
check('follow-up route connected', 'MAINTENANCE_FOLLOW_UP_ROUTE' in nav and 'MaintenanceFollowUpConnected' in nav)
check('app navigates history', 'onOpenHistory' in app_nav and 'MAINTENANCE_HISTORY_ROUTE' in app_nav)
check('app navigates follow-ups', 'onOpenFollowUps' in app_nav and 'MAINTENANCE_FOLLOW_UP_ROUTE' in app_nav)
check('destination titles specific before generic', app_dest.find('MAINTENANCE_HISTORY_ROUTE') < app_dest.find('startsWith("maintenance/")'))
check('version v07 or later', bool(re.search(r'versionName = \"0\.(?:[7-9]|[1-9]\d)\.', read('app/build.gradle.kts'))))

# Boundaries and tests
for p in (ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain').rglob('*.kt'):
    content = p.read_text(encoding='utf-8')
    check(f'domain pure {p.name}', not re.search(r'^import (android\.|androidx\.room)', content, re.M))
for p in (ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation').rglob('*.kt'):
    content = p.read_text(encoding='utf-8')
    check(f'presentation boundary {p.name}', 'core.database' not in content and '.data.' not in content)
for rel in [
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/complete/CompleteOperationTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/complete/CompletionIdempotencyTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/history/MaintenanceHistoryQueryTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/followup/FollowUpClassificationTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/followup/FollowUpToOperationTest.kt',
    'core/database/src/androidTest/java/com/optimal/fleet/core/database/MaintenanceCompletionDaoTest.kt',
    'app/src/test/java/com/optimal/fleet/MaintenanceCompletionArchitectureTest.kt',
]:
    check(f'test {rel}', (ROOT / rel).is_file())

for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f' — {detail}' if detail and not ok else ''))
passed = sum(ok for _, ok, _ in checks)
print(f'\nV07 static checks: {passed}/{len(checks)}')
sys.exit(0 if passed == len(checks) else 1)
