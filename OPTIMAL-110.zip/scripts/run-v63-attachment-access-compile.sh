#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/stubs"/{javax/inject,kotlinx/serialization,retrofit2/http,retrofit2,com/optimal/fleet/core/network/supabase}
cat > "$TMP_DIR/stubs/javax/inject/Annotations.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION) annotation class Singleton
KT
cat > "$TMP_DIR/stubs/kotlinx/serialization/Annotations.kt" <<'KT'
package kotlinx.serialization
@Target(AnnotationTarget.CLASS) annotation class Serializable
@Target(AnnotationTarget.PROPERTY) annotation class SerialName(val value: String)
KT
cat > "$TMP_DIR/stubs/retrofit2/Retrofit.kt" <<'KT'
package retrofit2
open class Retrofit { fun <T> create(service: Class<T>): T = error(service.name) }
open class ResponseBody { fun string(): String = "" }
open class Response<T> {
    val isSuccessful: Boolean get() = false
    fun body(): T? = null
    fun errorBody(): ResponseBody? = null
    fun code(): Int = 500
}
KT
cat > "$TMP_DIR/stubs/retrofit2/http/Annotations.kt" <<'KT'
package retrofit2.http
@Target(AnnotationTarget.FUNCTION) annotation class POST(val value: String)
@Target(AnnotationTarget.VALUE_PARAMETER) annotation class Body
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/network/supabase/Supabase.kt" <<'KT'
package com.optimal.fleet.core.network.supabase
@Target(AnnotationTarget.VALUE_PARAMETER, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION) annotation class SupabaseRetrofit
interface SupabaseConfig { val isConfigured: Boolean }
class SupabaseAuthSession
interface AuthSessionStore { fun current(): SupabaseAuthSession? }
KT
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  $(find "$TMP_DIR/stubs" -type f -name '*.kt' | sort) \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/verto/TemporaryVertoAttachmentAccess.kt" \
  "$ROOT_DIR/core/network/src/main/java/com/optimal/fleet/core/network/verto/SupabaseTemporaryVertoAttachmentAccess.kt" \
  -d "$TMP_DIR/v63-attachment-access.jar"
echo "PASS: temporary Verto attachment access compiles against its network contracts"
echo "V63 attachment access compilation: 1/1"
