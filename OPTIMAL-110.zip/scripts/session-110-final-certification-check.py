#!/usr/bin/env python3
from __future__ import annotations
from collections import Counter
from pathlib import Path
import hashlib, re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
CHECKS=[]
def check(name, ok, detail=''):
    CHECKS.append((name,bool(ok),str(detail)))
def read(rel): return (ROOT/rel).read_text(encoding='utf-8')

# Authoritative inventory closure.
ledger=read('docs/design-system/FULL_UI_MIGRATION_LEDGER.md')
row_re=re.compile(r'^\| ((?:SCR|DLG|OVL|CMP|STA)-(\d{3})) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| (SESSION-\d+) \|$',re.M)
rows=row_re.findall(ledger)
ids=[r[0] for r in rows]; statuses={r[0]:r[8] for r in rows}; counts=Counter(i.split('-')[0] for i in ids)
expected=([f'SCR-{i:03d}' for i in range(1,28)]+[f'DLG-{i:03d}' for i in range(1,6)]+[f'OVL-{i:03d}' for i in range(1,3)]+['CMP-001']+[f'STA-{i:03d}' for i in range(1,89)])
check('inventory contains exactly 123 canonical rows',len(rows)==123,len(rows))
check('inventory IDs are unique and complete',set(ids)==set(expected) and len(ids)==len(set(ids)),f'unique={len(set(ids))}')
check('all 123 inventory rows are MIGRATED',all(statuses.get(i)=='MIGRATED' for i in expected))
for prefix,n in [('SCR',27),('DLG',5),('OVL',2),('CMP',1),('STA',88)]:
    check(f'{prefix} final count is {n}',counts[prefix]==n,counts[prefix])
check('ledger summary is 123/123 migrated','| **TOTAL** | **123** | **123** | **0** | **0** |' in ledger)

# Frozen UI source inventory from SESSION-108 remains exact.
manifest=[x.strip() for x in read('docs/design-system/SESSION-108-UI-SOURCE-MANIFEST.txt').splitlines() if x.strip() and not x.lstrip().startswith('#')]
feature=sorted(p.relative_to(ROOT).as_posix() for p in (ROOT/'feature').glob('**/src/main/java/**/*.kt') if '@Composable' in p.read_text(encoding='utf-8',errors='ignore'))
app=sorted(p.relative_to(ROOT).as_posix() for p in (ROOT/'app').glob('**/src/main/java/**/*.kt') if '@Composable' in p.read_text(encoding='utf-8',errors='ignore'))
core=sorted(p.relative_to(ROOT).as_posix() for p in (ROOT/'core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2').glob('*.kt'))+['core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTheme.kt','core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTypography.kt']
discovered=feature+app+core
check('frozen production UI manifest remains 81 files',len(manifest)==81 and set(manifest)==set(discovered),f'manifest={len(manifest)} discovered={len(discovered)}')
check('feature Compose UI remains 64 files',len(feature)==64,len(feature))
check('all frozen UI source files exist',all((ROOT/p).is_file() for p in manifest))

# Original navigation inventory contract: 19 registered destinations + 5 top-level destinations.
nav_files=sorted((ROOT/'feature').glob('**/src/main/java/**/navigation/*.kt'))
nav_text='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in nav_files)
registered=len(re.findall(r'\bcomposable\s*\(',nav_text))
check('registered Compose Navigation destinations remain 19',registered==19,registered)
app_dest=read('app/src/main/java/com/optimal/fleet/navigation/AppDestination.kt')
expected_top=[('Home','HOME_ROUTE','الرئيسية'),('Vehicles','VEHICLES_ROUTE','السيارات'),('Maintenance','MAINTENANCE_ROUTE','الصيانة'),('Finance','FINANCE_ROUTE','المالية'),('More','SETTINGS_ROUTE','المزيد')]
for enum_name,route,label in expected_top:
    pattern=rf'{enum_name}\s*\(\s*route\s*=\s*{route}\s*,\s*label\s*=\s*"{re.escape(label)}"'
    check(f'top-level destination preserved: {label}',re.search(pattern,app_dest,re.S) is not None)
check('top-level destination enum remains exactly five',len(re.findall(r'^\s{4}(Home|Vehicles|Maintenance|Finance|More)\(',app_dest,re.M))==5)

# Reachability and embedded component invariants.
finance_nav=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt')
settings_nav=read('feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation/SettingsNavigation.kt')
app_nav=read('app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt')
production_kt='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for base in [ROOT/'app/src/main/java',ROOT/'feature'] for p in base.glob('**/*.kt'))
check('InvoiceListScreen source still exists',(ROOT/'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt').is_file())
check('InvoiceListScreen remains unreachable','InvoiceListConnected' not in finance_nav and 'InvoiceListConnected' not in app_nav and 'InvoiceListRoute' not in app_nav)
check('JoinCompanyRoute source still exists',(ROOT/'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRoute.kt').is_file())
check('JoinCompany destination remains registered','composable(route = MEMBER_JOIN_ROUTE)' in settings_nav and 'JoinCompanyConnected' in settings_nav)
check('JoinCompany remains without a production navigate call',re.search(r'navigate\s*\(\s*(?:MEMBER_JOIN_ROUTE|"settings/join-company")',production_kt) is None)
check('CMP-001 VertoHomeEntry remains integrated','VertoHomeEntryConnected' in app_nav and 'vertoEntryContent = {' in app_nav and 'navController.navigate(VertoDestination.CONVERSATION)' in app_nav)
check('CMP-001 remains MIGRATED',statuses.get('CMP-001')=='MIGRATED')

# Legacy/mixed-path closure and canonical compliance.
legacy=[]; sheets=[]
for rel in manifest:
    text=read(rel)
    if re.search(r'import\s+com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)',text): legacy.append(rel)
    if rel.startswith(('feature/','app/')) and re.search(r'\b(?:ModalBottomSheet|BottomSheetScaffold|StandardBottomSheet|OptimalBottomSheet|rememberModalBottomSheetState)\b',text): sheets.append(rel)
check('legacy visual import paths remain 0',not legacy,legacy)
check('production Bottom Sheets remain 0',not sheets,sheets)
allow=[x.strip() for x in read('scripts/design-system-migration-allowlist.txt').splitlines() if x.strip() and not x.lstrip().startswith('#')]
check('design-system migration allowlist is empty',not allow,allow)
proc=subprocess.run([sys.executable,str(ROOT/'scripts/design-system-compliance-guard.py')],cwd=ROOT,text=True,capture_output=True)
print(proc.stdout,end='')
if proc.stderr: print(proc.stderr,end='',file=sys.stderr)
check('design-system compliance guard passes',proc.returncode==0)
check('raw feature palettes = 0','Active violations: 0' in proc.stdout and 'raw-color' not in '\n'.join(line for line in proc.stdout.splitlines() if line.startswith('FAIL ')))
check('competing feature font families = 0','Active violations: 0' in proc.stdout and 'local-font-family' not in '\n'.join(line for line in proc.stdout.splitlines() if line.startswith('FAIL ')))
check('feature-local canonical component duplicates = 0','canonical-component-reimplementation' not in '\n'.join(line for line in proc.stdout.splitlines() if line.startswith('FAIL ')))

# Functional/source freeze: no production src/main file may differ from OPTIMAL-v109 input.
freeze=read('docs/design-system/SESSION-110-PRODUCTION-SOURCE-SHA256.txt').splitlines()
entries={}
for line in freeze:
    if not line or line.startswith('#'): continue
    path,digest=line.rsplit('  ',1); entries[path]=digest
current=[]
for base in [ROOT/'app/src/main',ROOT/'feature',ROOT/'core']:
    if not base.exists(): continue
    for p in base.rglob('*'):
        if p.is_file() and ('/src/main/' in p.as_posix() or base.as_posix().endswith('app/src/main')):
            current.append(p.relative_to(ROOT).as_posix())
current=set(current)
check('production source freeze path set unchanged',current==set(entries),f'expected={len(entries)} current={len(current)}')
changed=[]
for rel,digest in entries.items():
    p=ROOT/rel
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest: changed.append(rel)
check('unapproved production/business/navigation/data changes = 0',not changed,changed)

# Final state document must lock the program with no next migration session.
current_state=read('docs/design-system/CURRENT-DESIGN-STATE.md')
check('current design state identifies SESSION-110', 'CURRENT DESIGN STATE — SESSION-110' in current_state)
check('design-system migration program is statically complete', 'Migration program status:** STATIC COMPLETE / FINAL BUILD CERTIFICATION BLOCKED' in current_state)
check('no SESSION-111 migration is introduced', 'SESSION-111' not in current_state)

# SESSION-109 certification was re-run on the unchanged v109 production source before the final documentation lock.
s109_verification=read('docs/design-system/SESSION-109-VERIFICATION.md')
check('SESSION-109 certification record remains 57/57 PASS', '57/57 PASS' in s109_verification)
check('SESSION-109 certification script remains present', (ROOT/'scripts/session-109-responsive-rtl-accessibility-check.py').is_file())

failed=[x for x in CHECKS if not x[1]]
for name,ok,detail in CHECKS:
    print(('PASS' if ok else 'FAIL')+': '+name+(f' [{detail}]' if detail else ''))
print(f'\nSESSION-110 static certification: {len(CHECKS)-len(failed)}/{len(CHECKS)}')
sys.exit(1 if failed else 0)
