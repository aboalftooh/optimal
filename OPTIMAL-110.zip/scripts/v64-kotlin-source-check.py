#!/usr/bin/env python3
"""Focused lexical integrity checks for Kotlin files changed by v64."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    "core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionIdentity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncLeaseRecoveryCoordinator.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncStatusStore.kt",
    "app/src/main/java/com/optimal/fleet/work/SyncScheduler.kt",
    "app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/SyncVertoInvoices.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/SyncVertoMaintenanceProjections.kt",
    "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
]

def strip_strings_and_comments(text: str) -> str:
    out = []
    i = 0
    state = "code"
    while i < len(text):
        pair = text[i:i+2]
        if state == "code":
            if text.startswith('"""', i): state = "triple"; out.extend("   "); i += 3; continue
            if pair == "//": state = "line"; out.extend("  "); i += 2; continue
            if pair == "/*": state = "block"; out.extend("  "); i += 2; continue
            if text[i] == '"': state = "string"; out.append(" "); i += 1; continue
            if text[i] == "'": state = "char"; out.append(" "); i += 1; continue
            out.append(text[i]); i += 1; continue
        if state == "line":
            if text[i] == "\n": state = "code"; out.append("\n")
            else: out.append(" ")
            i += 1; continue
        if state == "block":
            if pair == "*/": state = "code"; out.extend("  "); i += 2
            else: out.append("\n" if text[i] == "\n" else " "); i += 1
            continue
        if state == "triple":
            if text.startswith('"""', i): state = "code"; out.extend("   "); i += 3
            else: out.append("\n" if text[i] == "\n" else " "); i += 1
            continue
        if state in ("string", "char"):
            quote = '"' if state == "string" else "'"
            if text[i] == "\\": out.extend("  "); i += 2
            elif text[i] == quote: state = "code"; out.append(" "); i += 1
            else: out.append("\n" if text[i] == "\n" else " "); i += 1
    if state not in ("code", "line"):
        raise AssertionError(f"unterminated lexical state: {state}")
    return "".join(out)

pairs = {"(": ")", "[": "]", "{": "}"}
for rel in FILES:
    path = ROOT / rel
    if not path.is_file(): raise AssertionError(f"missing {rel}")
    text = path.read_text(encoding="utf-8")
    if not text.startswith("package "): raise AssertionError(f"missing package in {rel}")
    clean = strip_strings_and_comments(text)
    stack = []
    for index, char in enumerate(clean):
        if char in pairs: stack.append((char, index))
        elif char in pairs.values():
            if not stack or pairs[stack[-1][0]] != char:
                raise AssertionError(f"unbalanced {char} in {rel} at {index}")
            stack.pop()
    if stack: raise AssertionError(f"unclosed {stack[-1][0]} in {rel}")
print(f"v64 Kotlin lexical check: {len(FILES)}/{len(FILES)} PASS")
