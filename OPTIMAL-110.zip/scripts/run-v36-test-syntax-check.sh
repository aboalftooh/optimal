#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
mapfile -t FILES < <(find core/testing/src app/src/test app/src/androidTest feature/*/src/test -type f -name '*.kt' | sort)
OUT="$(mktemp)"
JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180 kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  echo "FAIL: Kotlin parser diagnostics found" >&2
  exit 1
fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} testing files; unresolved Android/JUnit symbols were intentionally ignored without Gradle classpath."
