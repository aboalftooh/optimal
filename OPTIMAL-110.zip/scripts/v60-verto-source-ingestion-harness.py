#!/usr/bin/env python3
"""Executable transaction model for OPTIMAL v60 Verto invoice/maintenance page ingestion."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass

DB = sqlite3.connect(":memory:")
DB.execute("PRAGMA foreign_keys = ON")
DB.executescript(
    """
    create table invoice_heads(
        id text primary key,
        company_id text not null,
        source_id text not null unique,
        source_updated integer not null,
        total_minor integer not null,
        contract_version integer not null check(contract_version in (22, 23)),
        currency text not null check(currency = 'SDG'),
        requires_link integer not null check(requires_link in (0, 1))
    );
    create table invoice_items(
        id text primary key,
        company_id text not null,
        invoice_id text not null,
        source_item_id text not null,
        source_updated integer not null,
        unique(invoice_id, source_item_id),
        foreign key(invoice_id) references invoice_heads(id) on delete cascade
    );
    create table maintenance_heads(
        id text primary key,
        company_id text not null,
        source_id text not null unique,
        source_updated integer not null,
        vehicle_remote_id text not null
    );
    create table maintenance_media(
        id text primary key,
        company_id text not null,
        maintenance_id text not null,
        source_media_id text not null,
        kind text not null check(kind = 'IMAGE'),
        mime text,
        unique(maintenance_id, source_media_id),
        foreign key(maintenance_id) references maintenance_heads(id) on delete cascade
    );
    create table cursors(
        company_id text not null,
        feed_key text not null,
        updated_at integer not null,
        remote_id text not null,
        primary key(company_id, feed_key)
    );
    """
)

checks: list[str] = []


def check(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(name)
    checks.append(name)


def cursor_gt(left: tuple[int, str], right: tuple[int, str]) -> bool:
    return left > right


def validate_page(records: list[dict], next_cursor: tuple[int, str] | None, id_key: str) -> None:
    cursors = [(r["updated"], r[id_key]) for r in records]
    if any(not cursor_gt(b, a) for a, b in zip(cursors, cursors[1:])):
        raise ValueError("page_not_strictly_ordered")
    if len({r[id_key] for r in records}) != len(records):
        raise ValueError("duplicate_source_identity")
    expected = max(cursors) if cursors else None
    if expected != next_cursor:
        raise ValueError("cursor_page_mismatch")


def commit_invoice_page(
    company: str,
    records: list[dict],
    next_cursor: tuple[int, str] | None,
    fail_before_cursor: bool = False,
) -> None:
    validate_page(records, next_cursor, "source_id")
    with DB:
        previous = DB.execute(
            "select updated_at, remote_id from cursors where company_id=? and feed_key='VERTO_INVOICES_V23'",
            (company,),
        ).fetchone()
        if next_cursor is not None and previous is not None and not cursor_gt(next_cursor, previous):
            raise ValueError("invoice_cursor_not_advanced")
        for record in records:
            if record["contract"] != 23 or record["currency"] != "SDG" or record["requires_link"]:
                raise ValueError("invoice_contract_invalid")
            if any(item["updated"] != record["updated"] for item in record["items"]):
                raise ValueError("item_version_mismatch")
            row = DB.execute(
                "select id, source_updated, contract_version from invoice_heads where company_id=? and source_id=?",
                (company, record["source_id"]),
            ).fetchone()
            if row is None:
                head_id = f"verto:{record['source_id']}"
                DB.execute(
                    "insert into invoice_heads values(?,?,?,?,?,?,?,?)",
                    (
                        head_id,
                        company,
                        record["source_id"],
                        record["updated"],
                        record["total"],
                        record["contract"],
                        record["currency"],
                        int(record["requires_link"]),
                    ),
                )
            elif record["updated"] > row[1] or (record["updated"] == row[1] and record["contract"] > row[2]):
                head_id = row[0]
                DB.execute(
                    """update invoice_heads
                       set source_updated=?, total_minor=?, contract_version=?, currency=?, requires_link=?
                       where id=? and company_id=?""",
                    (
                        record["updated"],
                        record["total"],
                        record["contract"],
                        record["currency"],
                        int(record["requires_link"]),
                        head_id,
                        company,
                    ),
                )
            else:
                continue
            DB.execute("delete from invoice_items where company_id=? and invoice_id=?", (company, head_id))
            for item in record["items"]:
                DB.execute(
                    "insert into invoice_items values(?,?,?,?,?)",
                    (f"item:{record['source_id']}:{item['id']}", company, head_id, item["id"], item["updated"]),
                )
        if fail_before_cursor:
            raise RuntimeError("simulated_failure")
        if next_cursor is not None:
            DB.execute(
                "insert into cursors values(?,?,?,?) on conflict(company_id,feed_key) do update set updated_at=excluded.updated_at, remote_id=excluded.remote_id",
                (company, "VERTO_INVOICES_V23", next_cursor[0], next_cursor[1]),
            )


def commit_maintenance_page(
    company: str,
    records: list[dict],
    next_cursor: tuple[int, str] | None,
    fail_before_cursor: bool = False,
) -> None:
    validate_page(records, next_cursor, "source_id")
    with DB:
        previous = DB.execute(
            "select updated_at, remote_id from cursors where company_id=? and feed_key='VERTO_MAINTENANCE_V23'",
            (company,),
        ).fetchone()
        if next_cursor is not None and previous is not None and not cursor_gt(next_cursor, previous):
            raise ValueError("maintenance_cursor_not_advanced")
        for record in records:
            if not record["vehicle_remote_id"]:
                raise ValueError("trusted_vehicle_required")
            if any(media["kind"] != "IMAGE" for media in record["media"]):
                raise ValueError("image_metadata_only")
            row = DB.execute(
                "select id, source_updated from maintenance_heads where company_id=? and source_id=?",
                (company, record["source_id"]),
            ).fetchone()
            if row is None:
                head_id = f"verto-maintenance:{record['source_id']}"
                DB.execute(
                    "insert into maintenance_heads values(?,?,?,?,?)",
                    (head_id, company, record["source_id"], record["updated"], record["vehicle_remote_id"]),
                )
            elif record["updated"] > row[1]:
                head_id = row[0]
                DB.execute(
                    "update maintenance_heads set source_updated=?, vehicle_remote_id=? where id=? and company_id=?",
                    (record["updated"], record["vehicle_remote_id"], head_id, company),
                )
            else:
                continue
            DB.execute("delete from maintenance_media where company_id=? and maintenance_id=?", (company, head_id))
            for media in record["media"]:
                DB.execute(
                    "insert into maintenance_media values(?,?,?,?,?,?)",
                    (
                        f"media:{record['source_id']}:{media['id']}",
                        company,
                        head_id,
                        media["id"],
                        media["kind"],
                        media.get("mime"),
                    ),
                )
        if fail_before_cursor:
            raise RuntimeError("simulated_failure")
        if next_cursor is not None:
            DB.execute(
                "insert into cursors values(?,?,?,?) on conflict(company_id,feed_key) do update set updated_at=excluded.updated_at, remote_id=excluded.remote_id",
                (company, "VERTO_MAINTENANCE_V23", next_cursor[0], next_cursor[1]),
            )


invoice_v1 = {
    "source_id": "invoice-a",
    "updated": 100,
    "total": 1000,
    "contract": 23,
    "currency": "SDG",
    "requires_link": False,
    "items": [{"id": "a", "updated": 100}, {"id": "b", "updated": 100}],
}
commit_invoice_page("company-a", [invoice_v1], (100, "invoice-a"))
check("invoice_head_inserted", DB.execute("select count(*) from invoice_heads").fetchone()[0] == 1)
check("invoice_full_items_inserted", DB.execute("select count(*) from invoice_items").fetchone()[0] == 2)
check("invoice_cursor_committed", DB.execute("select updated_at from cursors where feed_key='VERTO_INVOICES_V23'").fetchone()[0] == 100)

invoice_v2 = {**invoice_v1, "updated": 200, "total": 1500, "items": [{"id": "c", "updated": 200}]}
commit_invoice_page("company-a", [invoice_v2], (200, "invoice-a"))
check("invoice_head_updated", DB.execute("select total_minor from invoice_heads").fetchone()[0] == 1500)
check("invoice_items_replaced", DB.execute("select source_item_id from invoice_items").fetchall() == [("c",)])
check("invoice_cursor_advanced", DB.execute("select updated_at from cursors where feed_key='VERTO_INVOICES_V23'").fetchone()[0] == 200)

DB.execute(
    "insert into invoice_heads values(?,?,?,?,?,?,?,?)",
    ("verto:invoice-legacy", "company-legacy", "invoice-legacy", 250, 700, 22, "SDG", 1),
)
legacy_v23 = {
    **invoice_v1,
    "source_id": "invoice-legacy",
    "updated": 250,
    "total": 700,
    "items": [{"id": "legacy-item", "updated": 250}],
}
commit_invoice_page("company-legacy", [legacy_v23], (250, "invoice-legacy"))
legacy_head = DB.execute(
    "select contract_version, requires_link from invoice_heads where company_id='company-legacy'",
).fetchone()
check("invoice_equal_timestamp_upgrades_v22_to_v23", legacy_head == (23, 0))
check(
    "invoice_equal_timestamp_populates_items",
    DB.execute("select source_item_id from invoice_items where company_id='company-legacy'").fetchall()
    == [("legacy-item",)],
)

before_invoice = tuple(DB.execute("select count(*) from invoice_heads union all select count(*) from invoice_items").fetchall())
try:
    commit_invoice_page(
        "company-a",
        [{**invoice_v1, "source_id": "invoice-b", "updated": 300, "items": [{"id": "x", "updated": 300}]}],
        (300, "invoice-b"),
        fail_before_cursor=True,
    )
except RuntimeError:
    pass
check("invoice_failure_rolled_back_heads_items", tuple(DB.execute("select count(*) from invoice_heads union all select count(*) from invoice_items").fetchall()) == before_invoice)
check("invoice_failure_did_not_advance_cursor", DB.execute("select updated_at from cursors where feed_key='VERTO_INVOICES_V23'").fetchone()[0] == 200)

maintenance_v1 = {
    "source_id": "maintenance-a",
    "updated": 110,
    "vehicle_remote_id": "vehicle-a",
    "media": [{"id": "m1", "kind": "IMAGE", "mime": "image/jpeg"}, {"id": "m2", "kind": "IMAGE", "mime": None}],
}
commit_maintenance_page("company-a", [maintenance_v1], (110, "maintenance-a"))
check("maintenance_head_inserted", DB.execute("select count(*) from maintenance_heads").fetchone()[0] == 1)
check("maintenance_full_media_inserted", DB.execute("select count(*) from maintenance_media").fetchone()[0] == 2)
check("maintenance_cursor_committed", DB.execute("select updated_at from cursors where feed_key='VERTO_MAINTENANCE_V23'").fetchone()[0] == 110)

maintenance_v2 = {**maintenance_v1, "updated": 210, "media": [{"id": "m3", "kind": "IMAGE", "mime": "image/png"}]}
commit_maintenance_page("company-a", [maintenance_v2], (210, "maintenance-a"))
check("maintenance_media_replaced", DB.execute("select source_media_id from maintenance_media").fetchall() == [("m3",)])
check("maintenance_cursor_advanced", DB.execute("select updated_at from cursors where feed_key='VERTO_MAINTENANCE_V23'").fetchone()[0] == 210)
check("feed_cursors_are_independent", DB.execute("select count(*) from cursors where company_id='company-a'").fetchone()[0] == 2)

before_maintenance = tuple(DB.execute("select count(*) from maintenance_heads union all select count(*) from maintenance_media").fetchall())
try:
    commit_maintenance_page(
        "company-a",
        [{**maintenance_v1, "source_id": "maintenance-b", "updated": 310, "media": [{"id": "z", "kind": "IMAGE", "mime": "image/jpeg"}]}],
        (310, "maintenance-b"),
        fail_before_cursor=True,
    )
except RuntimeError:
    pass
check("maintenance_failure_rolled_back_projection_media", tuple(DB.execute("select count(*) from maintenance_heads union all select count(*) from maintenance_media").fetchall()) == before_maintenance)
check("maintenance_failure_did_not_advance_cursor", DB.execute("select updated_at from cursors where feed_key='VERTO_MAINTENANCE_V23'").fetchone()[0] == 210)

for label, action in [
    ("invoice_rejects_stale_cursor", lambda: commit_invoice_page("company-a", [invoice_v2], (200, "invoice-a"))),
    ("invoice_rejects_wrong_currency", lambda: commit_invoice_page("company-b", [{**invoice_v1, "currency": "USD"}], (100, "invoice-a"))),
    ("invoice_rejects_item_version_mismatch", lambda: commit_invoice_page("company-b", [{**invoice_v1, "items": [{"id": "a", "updated": 99}]}], (100, "invoice-a"))),
    ("maintenance_rejects_manual_vehicle", lambda: commit_maintenance_page("company-b", [{**maintenance_v1, "vehicle_remote_id": ""}], (110, "maintenance-a"))),
    ("maintenance_rejects_non_image", lambda: commit_maintenance_page("company-b", [{**maintenance_v1, "media": [{"id": "m", "kind": "VIDEO"}]}], (110, "maintenance-a"))),
    ("page_rejects_cursor_mismatch", lambda: commit_invoice_page("company-b", [invoice_v1], (101, "invoice-a"))),
]:
    try:
        action()
    except (ValueError, sqlite3.IntegrityError):
        check(label, True)
    else:
        check(label, False)

check("foreign_keys_clean", DB.execute("pragma foreign_key_check").fetchall() == [])
check("database_quick_check", DB.execute("pragma quick_check").fetchone()[0] == "ok")
print(f"v60 Verto source ingestion harness: {len(checks)}/{len(checks)} PASS")
