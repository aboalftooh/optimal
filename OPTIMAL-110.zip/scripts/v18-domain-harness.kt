import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.feature.auth.domain.model.CompanyBootstrapCommand
import com.optimal.fleet.feature.auth.domain.model.LocalAccountBootstrap
import com.optimal.fleet.feature.auth.domain.model.LocalAccountDisabledException
import com.optimal.fleet.feature.auth.domain.model.LocalCompanyMismatchException
import com.optimal.fleet.feature.auth.domain.model.LocalOtpChallenge
import com.optimal.fleet.feature.auth.domain.model.OnboardingCompletionResult
import com.optimal.fleet.feature.auth.domain.model.OtpVerificationResult
import com.optimal.fleet.feature.auth.domain.repository.CompanyBootstrapRepository
import com.optimal.fleet.feature.auth.domain.repository.LocalOtpRepository
import com.optimal.fleet.feature.auth.domain.usecase.CompleteLocalOnboardingUseCase
import com.optimal.fleet.feature.auth.domain.usecase.RequestLocalOtpUseCase
import com.optimal.fleet.feature.auth.domain.usecase.VerifyLocalOtpUseCase
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) {
            outcome = result
        }
    })
    return requireNotNull(outcome) { "Suspending harness did not complete synchronously" }.getOrThrow()
}

fun main() {
    val otpRepository = RecordingOtpRepository()
    val requestOtp = RequestLocalOtpUseCase(otpRepository)
    val invalidRequest = runSuspend { requestOtp("123") }
    verify("invalid phone fails before repository", invalidRequest.isFailure && otpRepository.requests == 0)

    val validRequest = runSuspend { requestOtp("+249 912-345-678") }
    verify("valid phone requests challenge", validRequest.isSuccess && otpRepository.requests == 1)
    verify("phone normalized before repository", otpRepository.lastPhone == "+249912345678")

    val verifyOtp = VerifyLocalOtpUseCase(otpRepository)
    verify(
        "missing challenge rejected",
        runSuspend { verifyOtp(null, "123456") } == OtpVerificationResult.MissingChallenge,
    )
    verify(
        "invalid OTP rejected before repository",
        runSuspend { verifyOtp("challenge-1", "123") } == OtpVerificationResult.InvalidCode && otpRepository.verifications == 0,
    )
    verify(
        "valid OTP delegated",
        runSuspend { verifyOtp("challenge-1", "123456") } == OtpVerificationResult.Verified && otpRepository.verifications == 1,
    )

    val companyRepository = RecordingCompanyRepository()
    val complete = CompleteLocalOnboardingUseCase(companyRepository)
    verify(
        "blank company rejected",
        runSuspend { complete(" ", "أحمد", "0912345678") } is OnboardingCompletionResult.ValidationError,
    )
    verify(
        "blank user rejected",
        runSuspend { complete("شركة الندى", " ", "0912345678") } is OnboardingCompletionResult.ValidationError,
    )
    verify(
        "bad phone rejected",
        runSuspend { complete("شركة الندى", "أحمد", "123") } is OnboardingCompletionResult.ValidationError,
    )

    val success = runSuspend { complete("  شركة الندى  ", "  أحمد  ", "+249 912-345-678") }
    verify("valid account completes", success is OnboardingCompletionResult.Success)
    verify("company normalized", companyRepository.lastCommand?.companyName == "شركة الندى")
    verify("user normalized", companyRepository.lastCommand?.userDisplayName == "أحمد")
    verify("phone normalized", companyRepository.lastCommand?.phone == "+249912345678")

    companyRepository.mode = RecordingCompanyRepository.Mode.DISABLED
    verify(
        "disabled account mapped",
        runSuspend { complete("شركة الندى", "أحمد", "0912345678") } == OnboardingCompletionResult.DisabledAccount,
    )
    companyRepository.mode = RecordingCompanyRepository.Mode.MISMATCH
    verify(
        "company mismatch mapped",
        runSuspend { complete("شركة أخرى", "أحمد", "0912345678") } == OnboardingCompletionResult.CompanyMismatch,
    )
    companyRepository.mode = RecordingCompanyRepository.Mode.ERROR
    verify(
        "storage error mapped",
        runSuspend { complete("شركة الندى", "أحمد", "0912345678") } is OnboardingCompletionResult.StorageError,
    )

    println("RESULT: $checks/$checks passed")
}

private class RecordingOtpRepository : LocalOtpRepository {
    var requests = 0
    var verifications = 0
    var lastPhone: String? = null

    override suspend fun request(normalizedPhone: String): LocalOtpChallenge {
        requests += 1
        lastPhone = normalizedPhone
        return LocalOtpChallenge(
            id = "challenge-1",
            normalizedPhone = normalizedPhone,
            debugCode = "123456",
            expiresAtEpochMillis = Long.MAX_VALUE,
        )
    }

    override suspend fun verify(challengeId: String, code: String): OtpVerificationResult {
        verifications += 1
        return OtpVerificationResult.Verified
    }

    override suspend fun clear(challengeId: String) = Unit
}

private class RecordingCompanyRepository : CompanyBootstrapRepository {
    enum class Mode { SUCCESS, DISABLED, MISMATCH, ERROR }

    var mode = Mode.SUCCESS
    var lastCommand: CompanyBootstrapCommand? = null

    override suspend fun createLocalCompany(command: CompanyBootstrapCommand): ActiveSession = session(command)

    override suspend fun createOrRestoreLocalAccount(command: CompanyBootstrapCommand): LocalAccountBootstrap {
        lastCommand = command
        return when (mode) {
            Mode.SUCCESS -> LocalAccountBootstrap(session(command), restoredExistingUser = false)
            Mode.DISABLED -> throw LocalAccountDisabledException()
            Mode.MISMATCH -> throw LocalCompanyMismatchException()
            Mode.ERROR -> error("disk")
        }
    }

    private fun session(command: CompanyBootstrapCommand) = ActiveSession(
        userId = "user-1",
        companyId = "company-1",
        userDisplayName = command.userDisplayName,
        companyName = command.companyName,
    )
}
