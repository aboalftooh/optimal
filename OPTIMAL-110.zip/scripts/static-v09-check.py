#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def read(rel): return (ROOT/rel).read_text(encoding='utf-8')
def check(name, ok):
    checks.append(bool(ok)); print(('PASS' if ok else 'FAIL')+': '+name)

required=[
'core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceProjectionEntity.kt',
'core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceSourceAuditEntity.kt',
'core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceProjection.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/VertoInvoiceSnapshot.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/InvoiceSourceVersionPolicy.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/InvoiceProjectionRepository.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/VertoInvoiceSource.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/SyncVertoInvoices.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceDto.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceMapper.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/LinkedCompanyVertoInvoiceSource.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/DeferredVertoInvoiceTransport.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt',
'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt',
]
for rel in required: check('required '+rel,(ROOT/rel).is_file())

entity=read(required[0]); audit=read(required[1]); dao=read(required[2]); db=read('core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt'); mig=read('core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt')
for field in ['companyId','vertoInvoiceId','vertoOrganizationId','vertoClientId','invoiceNumber','invoiceType','totalMinor','paidMinor','remainingMinor','partsCostMinor','serviceCostMinor','sourceStatus','voided','invoiceDateEpochMillis','sourceUpdatedAtEpochMillis','cachedAtEpochMillis','requiresVehicleLink']:
    check('projection field '+field,f'val {field}:' in entity)
check('verto invoice unique index','Index(value = ["vertoInvoiceId"], unique = true)' in entity)
check('projection company FK','childColumns = ["companyId"]' in entity and 'ForeignKey.CASCADE' in entity)
check('source audit immutable history',all(f'val {x}:' in audit for x in ['action','changedFields','previousSourceUpdatedAtEpochMillis','newSourceUpdatedAtEpochMillis']))
check('room version seven or later', any(f'version = {v}' in db for v in range(7, 100)))
check('projection entities registered',all(x in db for x in ['InvoiceProjectionEntity::class','InvoiceSourceAuditEntity::class']))
check('invoice dao exposed','abstract fun invoiceProjectionDao()' in db)
check('migration 6 to 7','MIGRATION_6_7' in mig and 'Migration(6, 7)' in mig)
check('migration creates projections','CREATE TABLE IF NOT EXISTS `verto_invoice_projections`' in mig)
check('migration creates source audit','CREATE TABLE IF NOT EXISTS `invoice_source_audit`' in mig)
check('migration creates unique remote id index','CREATE UNIQUE INDEX IF NOT EXISTS `index_verto_invoice_projections_vertoInvoiceId`' in mig)
check('schema seven exported',(ROOT/'core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/7.json').is_file())
for token in ['observeInvoices','observeInvoice','findByVertoInvoiceId','latestSourceUpdate','insertWithAudit','updateWithAudit']:
    check('invoice dao '+token,token in dao)

# Contract is grounded in the actual schema snapshot supplied by the owner.
dto=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceDto.kt')
for serial in ['id','organization_id','client_id','invoice_number','type','description','total_amount','status','category','voided','created_at','updated_at']:
    check('confirmed dto column '+serial,f'@SerialName("{serial}")' in dto)
for invented in ['vehicle_id','plate_number','vin','odometer','parts_cost','service_cost','paid','remaining','source_version']:
    check('dto does not invent '+invented,f'@SerialName("{invented}")' not in dto)
check('dto remains data only',(ROOT/'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceDto.kt').is_file() and not (ROOT/'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/VertoInvoiceDto.kt').exists())

mapper=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceMapper.kt')
for null_field in ['paidMinor = null','remainingMinor = null','partsCostMinor = null','serviceCostMinor = null']:
    check('unknown source field honest '+null_field,null_field in mapper)
check('money avoids floating point','BigDecimal' in mapper and 'Double' not in mapper)
check('timestamps become source version','sourceUpdatedAtEpochMillis' in mapper)
check('unmatched invoice marked for linking','requiresVehicleLink = true' in mapper)

repo=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt')
check('upsert uses source version policy','InvoiceSourceVersionPolicy.decide' in repo)
check('same deterministic local id','"verto:$vertoInvoiceId"' in repo)
check('source changes audited','VERTO_INVOICE_UPDATED' in repo and 'updateWithAudit' in repo)
check('source void audited','VERTO_INVOICE_VOIDED' in repo)
check('no delete from source sync','delete' not in repo.lower())

source=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/LinkedCompanyVertoInvoiceSource.kt')
deferred=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/DeferredVertoInvoiceTransport.kt')
check('company link uses company remote id','companyDao.findById(companyId)?.remoteId' in source)
check('unlinked company explicit','CompanyNotLinked' in source)
check('invalid payload does not reach repository','InvalidPayload' in source)
check('deferred transport keeps cache','last data' not in deferred.lower() or 'آخر بيانات محفوظة' in deferred)
check('no Supabase SDK added','supabase' not in read('feature/finance/build.gradle.kts').lower())

for p in (ROOT/'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain').rglob('*.kt'):
    content=p.read_text(encoding='utf-8')
    check('domain clean '+p.name,all(x not in content for x in ['androidx.room','android.','VertoInvoiceDto','CompanyDao']))
for p in (ROOT/'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation').rglob('*.kt'):
    content=p.read_text(encoding='utf-8')
    check('presentation clean '+p.name,all(x not in content for x in ['androidx.room','InvoiceProjectionDao','VertoInvoiceDto','VertoInvoiceTransport']))

details_contract=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt')
details_route=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt')
check('invoice details read only','AmountChanged' not in details_contract and 'Save' not in details_contract)
check('invoice details has no editable money field','TextField' not in details_route)
check('source ownership communicated','للقراءة فقط' in details_route)
check('cache unavailable message present','آخر بيانات محفوظة' in deferred)
check('finance navigation has details','INVOICE_DETAILS_ROUTE' in read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt'))
check('app navigation opens details','invoiceDetailsRoute' in read('app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt'))
check('version v09 or later', bool(re.search(r'versionName = \"0\.(?:9|[1-9]\d)\.', read('app/build.gradle.kts'))))
check('remote transport still safely disabled','buildConfigField("boolean", "SYNC_ENABLED", "false")' in read('app/build.gradle.kts'))
production = '\n'.join(p.read_text(encoding='utf-8') for p in ROOT.rglob('*.kt') if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix() and '/build/' not in p.as_posix())
check('no destructive migration','fallbackToDestructiveMigration' not in production)

for rel in [
'feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/InvoiceUpsertTest.kt',
'feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/InvoiceDeduplicationTest.kt',
'feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/SourceVersionTest.kt',
'feature/finance/src/test/java/com/optimal/fleet/feature/finance/data/verto/VertoOwnershipTest.kt',
'feature/finance/src/test/java/com/optimal/fleet/feature/finance/presentation/InvoiceProjectionViewModelTest.kt',
'feature/finance/src/test/java/com/optimal/fleet/feature/finance/InvoiceProjectionArchitectureTest.kt',
'core/database/src/androidTest/java/com/optimal/fleet/core/database/InvoiceDaoMigrationTest.kt',
]: check('test '+rel,(ROOT/rel).is_file())

passed=sum(checks); total=len(checks)
print(f'\nV09 static checks: {passed}/{total}')
sys.exit(0 if passed==total else 1)
