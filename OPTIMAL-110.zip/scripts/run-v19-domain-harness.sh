#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$(mktemp -d)"
trap 'rm -rf "$OUT_DIR"' EXIT
mkdir -p "$OUT_DIR/stubs/javax/inject"
cat > "$OUT_DIR/stubs/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
STUB
kotlinc \
  "$OUT_DIR/stubs/javax/inject/Inject.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/OnboardingRepository.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingInputPolicy.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/ValidateJoinCodeUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RequestOtpUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/VerifyOtpUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/CompleteOnboardingUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RestoreSessionUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RestorePendingOnboardingUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/DiscardPendingOnboardingUseCase.kt" \
  "$ROOT_DIR/feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/SignOutUseCase.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/InviteCodePolicy.kt" \
  "$ROOT_DIR/scripts/v19-domain-harness.kt" \
  -include-runtime \
  -d "$OUT_DIR/v19-domain-harness.jar"
java -jar "$OUT_DIR/v19-domain-harness.jar"
