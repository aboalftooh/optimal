#!/usr/bin/env python3
"""Static acceptance gate for OPTIMAL v64 unified, session-safe synchronization."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []

def check(label: str, condition: bool) -> None:
    checks.append((label, condition))
    if not condition:
        raise AssertionError(label)

def read(path: str) -> str:
    target = ROOT / path
    check(f"file:{path}", target.is_file())
    return target.read_text(encoding="utf-8")

scheduler = read("app/src/main/java/com/optimal/fleet/work/SyncScheduler.kt")
worker = read("app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt")
entry = read("app/src/main/java/com/optimal/fleet/work/SyncWorkerEntryPoint.kt")
application = read("app/src/main/java/com/optimal/fleet/OptimalApplication.kt")
unified = read("app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt")
status = read("app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncStatusStore.kt")
status_vm = read("app/src/main/java/com/optimal/fleet/sync/SyncStatusViewModel.kt")
manager = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt")
claimer = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchClaimer.kt")
recovery = read("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncLeaseRecoveryCoordinator.kt")
queue_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt")
message_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMessageDao.kt")
attachment_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoAttachmentDao.kt")
invoice_sync = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/SyncVertoInvoices.kt")
maintenance_sync = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/SyncVertoMaintenanceProjections.kt")
maintenance_import = read("app/src/main/java/com/optimal/fleet/coordinator/verto/VertoMaintenanceAutoImportCoordinator.kt")
message_pull = read("feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt")
message_repo = read("feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt")
transient = read("feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoTransientStateRecovery.kt")
app_build = read("app/build.gradle.kts")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")

for token in (
    "OutboxUnifiedSyncParticipant",
    "InvoiceFeedUnifiedSyncParticipant",
    "MaintenanceFeedUnifiedSyncParticipant",
    "MessagePullUnifiedSyncParticipant",
):
    check(f"unified:participant:{token}", token in unified)
for order in ("order: Int = 10", "order: Int = 20", "order: Int = 30", "order: Int = 40"):
    check(f"unified:ordered:{order}", order in unified)
check("unified:mutex", "mutex.tryLock()" in unified)
check("unified:session-before-after", unified.count("isCurrent(expectedSession)") >= 3)
check("unified:retry-result", "shouldRetryWorker" in unified and "retryParticipants" in unified)

check("scheduler:one-time-unique", "enqueueUniqueWork" in scheduler and "UNIQUE_ONE_TIME_WORK" in scheduler)
check("scheduler:periodic-unique", "enqueueUniquePeriodicWork" in scheduler and "UNIQUE_PERIODIC_WORK" in scheduler)
check("scheduler:network", "NetworkType.CONNECTED" in scheduler)
check("scheduler:backoff", "BackoffPolicy.EXPONENTIAL" in scheduler)
check("scheduler:session-input", "KEY_EXPECTED_USER_ID" in scheduler and "KEY_EXPECTED_COMPANY_ID" in scheduler)
check("scheduler:append-or-replace", "ExistingWorkPolicy.APPEND_OR_REPLACE" in scheduler)
check("scheduler:logout-cancel", "cancelUniqueWork(UNIQUE_ONE_TIME_WORK)" in scheduler)

check("worker:unified-only", "unifiedSyncCoordinator().run(activeSession)" in worker)
for forbidden in ("syncManager().runBatch", "syncVertoInvoices().invoke", "pullVertoMessages().invoke"):
    check(f"worker:no-direct:{forbidden}", forbidden not in worker)
check("worker:stale-input-noop", "expectedUser != activeSession.userId" in worker and "expectedCompany != activeSession.companyId" in worker)
check("worker:post-run-session-check", "activeSession.identity().matches(current)" in worker)
check("entry:unified", "fun unifiedSyncCoordinator(): UnifiedSyncCoordinator" in entry)

check("application:session-observer", "observeActiveSession()" in application and "distinctUntilChangedBy" in application)
check("application:logout-cancel", "syncScheduler.cancelOneTime()" in application)
check("application:new-session-schedule", "scheduleNow(session.userId, session.companyId)" in application)

check("queue:company-due", "findDueForCompany" in queue_dao)
check("queue:company-expired", "findExpiredLeasesForCompany" in queue_dao)
check("queue:company-claim", "claimDueBatchForCompany" in queue_dao)
check("queue:session-release", "releaseLeaseForSessionChange" in queue_dao)
check("claimer:company-boundary", "it.companyId == companyId" in claimer)
check("manager:expected-session", "expectedSession: ActiveSession" in manager)
check("manager:pre-post-remote-check", manager.count("isCurrent(expectedSession)") >= 4)
check("manager:release-stale", "releaseForSessionChange" in manager)
check("manager:no-cross-company", "operation.companyId == expectedSession.companyId" in manager)

check("recovery:expired-company-scoped", "recoverExpiredLeases(companyId" in recovery)
check("recovery:process-death-code", "PROCESS_DEATH_RECOVERY" in recovery)
check("recovery:session-change-code", "SESSION_CHANGED_DURING_SYNC" in recovery)
check("recovery:transient-participants", "recoverTransientState" in recovery)
check("message:stale-sending-recovery", "deliveryState = 'FAILED_RETRYABLE'" in message_dao and "deliveryState = 'SENDING'" in message_dao)
check("attachment:stale-transfer-recovery", "transferState IN ('UPLOADING', 'FINALIZING')" in attachment_dao)
check("transient:atomic", "transactionRunner.run" in transient)

for label, source in (
    ("invoice", invoice_sync),
    ("maintenance", maintenance_sync),
    ("maintenance-import", maintenance_import),
    ("message-pull", message_pull),
    ("message-repository", message_repo),
):
    check(f"session:{label}:changed", "SessionChanged" in source)
check("invoice:before-commit-check", invoice_sync.count("identity().matches") >= 3)
check("maintenance:before-commit-check", maintenance_sync.count("identity().matches") >= 3)
check("message:before-persist-check", message_repo.count("matchesActiveSession()") >= 4)

check("status:friendly-enum", "UnifiedSyncRuntimeState" in status)
check("status:no-error-text", "Throwable" not in status and "stackTrace" not in status)
check("status:ui-combined", "UnifiedSyncStatusStore" in status_vm and "OfflineVisualState" in status_vm)

check("android:version-stable", "versionCode = 32" in app_build and 'versionName = "0.37.0-v37"' in app_build)
check("room:version-stable", "version = 3" in database)
check("backend:no-v64-migration", not any((ROOT / "supabase/migrations").glob("*v64*")))
for path in (
    "scripts/v64-unified-sync-harness.py",
    "scripts/v64-kotlin-source-check.py",
    "scripts/run-v64-source-syntax-check.sh",
    "scripts/run-v64-unified-semantic-compile.sh",
    "scripts/verify-v64-static.sh",
    "docs/sessions/v64.md",
    "docs/verifications/verification-v64.md",
):
    check(f"delivery:{path}", (ROOT / path).is_file())

print(f"v64 unified sync contract: {len(checks)}/{len(checks)} PASS")
