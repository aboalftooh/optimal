#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))
    print(f"{'PASS' if condition else 'FAIL'}: {name}")

required = [
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SupabaseSyncTransport.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/remote/OptimalSyncApi.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/SupabaseVertoInvoiceTransport.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/OptimalVertoApi.kt",
    "supabase/migrations/20260728002000_optimal_sync_verto.sql",
    "docs/integrations/supabase-sync-verto-contract-v20.md",
    "docs/sessions/v20-remote-sync-verto-feed.md",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

build = text("app/build.gradle.kts")
database = text("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
migrations = text("core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt")
sync_module = text("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt")
sync_transport = text("app/src/main/java/com/optimal/fleet/coordinator/sync/SupabaseSyncTransport.kt")
sync_api = text("app/src/main/java/com/optimal/fleet/coordinator/sync/remote/OptimalSyncApi.kt")
scheduler = text("app/src/main/java/com/optimal/fleet/work/SyncScheduler.kt")
worker = text("app/src/main/java/com/optimal/fleet/work/OptimalSyncWorker.kt")
entry = text("app/src/main/java/com/optimal/fleet/work/SyncWorkerEntryPoint.kt")
sync_manager = text("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt")
sync_participant = text("app/src/main/java/com/optimal/fleet/coordinator/sync/SyncParticipant.kt")
vehicle_participant = text("app/src/main/java/com/optimal/fleet/coordinator/sync/VehicleSyncParticipant.kt")
maintenance_participant = text("app/src/main/java/com/optimal/fleet/coordinator/sync/MaintenanceSyncParticipant.kt")
vehicle_dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt")
maintenance_dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceDao.kt")
company = text("core/database/src/main/java/com/optimal/fleet/core/database/entity/CompanyEntity.kt")
company_dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/CompanyDao.kt")
finance_dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/FinanceDao.kt")
home_dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/HomeDashboardDao.kt")
verto_transport = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/SupabaseVertoInvoiceTransport.kt")
verto_api = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/OptimalVertoApi.kt")
verto_source = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/LinkedCompanyVertoInvoiceSource.kt")
verto_dto = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceDto.kt")
verto_mapper = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceMapper.kt")
verto_cursor_contract = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/repository/InvoiceProjectionRepository.kt")
verto_sync_use_case = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/SyncVertoInvoices.kt")
invoice_projection_dao = text("core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceProjectionDao.kt")
finance_di = text("feature/finance/src/main/java/com/optimal/fleet/feature/finance/di/FinanceDataModule.kt")
sql = text("supabase/migrations/20260728002000_optimal_sync_verto.sql")

version_code_match = re.search(r"versionCode\s*=\s*(\d+)", build)
version_name_match = re.search(r'versionName\s*=\s*"0\.(\d+)\.0-v(\d+)"', build)
check("versionCode 16 or newer", bool(version_code_match and int(version_code_match.group(1)) >= 16))
check(
    "versionName v20 or newer",
    bool(
        version_name_match
        and version_name_match.group(1) == version_name_match.group(2)
        and int(version_name_match.group(1)) >= 20
    ),
)
check("remote sync enabled", 'buildConfigField("boolean", "SYNC_ENABLED", "true")' in build)
check("Room schema 13", "version = 13" in database)
check("Room migration 12 to 13", "MIGRATION_12_13" in migrations and "isVertoLinked" in migrations)
check("migration registered", "MIGRATION_12_13," in migrations.split("val ALL", 1)[1])
check("company keeps separate Verto link flag", "isVertoLinked" in company)
check("company DAO caches Verto link", "updateVertoLinkStatus" in company_dao)
check("finance no longer treats remoteId as Verto link", "c.remoteId" not in finance_dao and "c.isVertoLinked" in finance_dao)
check("home no longer treats remoteId as Verto link", "company.remoteId" not in home_dao and "company.isVertoLinked" in home_dao)

check("live sync transport bound", "SupabaseSyncTransport" in sync_module)
check("deferred sync transport removed", not (ROOT / "app/src/main/java/com/optimal/fleet/coordinator/sync/DeferredSyncTransport.kt").exists())
check("sync RPC apply endpoint", "optimal_apply_sync_operation" in sync_api)
check("sync RPC resolve endpoint", "optimal_resolve_sync_conflict" in sync_api)
check("payload parsed as JSON", "parseToJsonElement" in sync_transport)
check("local company resolved to remote OPTIMAL company", "companyDao.findById" in sync_transport and ".remoteId" in sync_transport)
check("HTTP retry policy explicit", all(x in sync_transport for x in ["408", "429", ">= 500", "RetryableFailure"]))
check("auth and membership failures explicit", all(x in sync_transport for x in ["AUTH_SESSION_REQUIRED", "ACTIVE_MEMBERSHIP_REQUIRED"]))
check("conflict payload returned", "SyncPushResult.Conflict" in sync_transport and "remotePayload" in sync_transport)
check("scheduler requires backend configuration", "supabaseConfig.isConfigured" in scheduler)
check("worker refreshes session first", worker.index("restoreSession") < worker.index("syncManager"))
check("worker refreshes Verto after queue", worker.index("syncManager") < worker.index("syncVertoInvoices"))
check("worker entry exposes session and Verto use cases", "RestoreSessionUseCase" in entry and "SyncVertoInvoices" in entry)
check("participant success callback declared", "onSucceeded" in sync_participant and "SyncPushResult.Success" in sync_participant)
check("success callback runs before queue completion", sync_manager.index("participant.onSucceeded(operation, result)") < sync_manager.index("queueStore.markSucceeded", sync_manager.index("is SyncPushResult.Success")))
check("resolved success callback runs before queue completion", "participant.onSucceeded(operation, resolved)" in sync_manager)
check("vehicle success binds remote identity", "markRemoteSyncSucceeded" in vehicle_participant and "remoteId = result.remoteId" in vehicle_participant)
check("maintenance success binds remote identity", "markOperationRemoteSyncSucceeded" in maintenance_participant and "remoteId = result.remoteId" in maintenance_participant)
check("follow-up success marks local projection", "markFollowUpRemoteSyncSucceeded" in maintenance_participant)
check("newer vehicle edits remain pending", "updatedAtEpochMillis <= :syncedVersion" in vehicle_dao and "ELSE syncStatus" in vehicle_dao)
check("newer maintenance edits remain pending", maintenance_dao.count("updatedAtEpochMillis <= :syncedVersion") >= 2 and "ELSE syncState" in maintenance_dao)

check("live Verto transport bound", "SupabaseVertoInvoiceTransport" in finance_di)
check("deferred Verto transport removed", not (ROOT / "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/DeferredVertoInvoiceTransport.kt").exists())
check("Verto feed RPC endpoint", "optimal_verto_invoice_feed" in verto_api)
check("Verto transport distinguishes not linked", "NotLinked" in verto_transport and "verto_company_not_linked" in verto_transport)
check("Verto link state cached", "updateVertoLinkStatus" in verto_source)
check("Verto uses OPTIMAL remote company id", "optimalCompanyRemoteId" in verto_source)
check("Verto paid field supported", "paid_amount" in verto_dto and "paidMinor" in verto_mapper)
check("Verto remaining field supported", "remaining_amount" in verto_dto and "remainingMinor" in verto_mapper)
check("Verto parts and service split supported", all(x in verto_dto for x in ["parts_cost_amount", "service_cost_amount"]))
check("Verto values remain source mapped", all(x in verto_mapper for x in ["dto.paidAmount", "dto.remainingAmount", "dto.partsCostAmount", "dto.serviceCostAmount"]))
check("Verto cursor includes timestamp and invoice id", all(x in verto_cursor_contract for x in ["data class VertoInvoiceCursor", "updatedAtEpochMillis", "invoiceId"]))
check("local cursor ordering is deterministic", "ORDER BY sourceUpdatedAtEpochMillis DESC, vertoInvoiceId DESC" in invoice_projection_dao)
check("sync use case reads tuple cursor", "latestSourceCursor" in verto_sync_use_case and "source.fetchInvoices(session.companyId, cursor)" in verto_sync_use_case)
check("Verto RPC receives invoice id cursor", "p_after_invoice_id" in verto_api)
check("Verto feed advances through equal timestamps", "s.verto_invoice_id > coalesce(p_after_invoice_id, '')" in sql)

check("sync records table", "create table if not exists public.optimal_sync_records" in sql)
check("idempotency receipts table", "create table if not exists public.optimal_sync_receipts" in sql)
check("receipt binds operation identity", "operation_type text not null" in sql[sql.index("create table if not exists public.optimal_sync_receipts"):sql.index("create index if not exists optimal_sync_records")])
check("idempotency requests are concurrency serialized", sql.count("pg_advisory_xact_lock(hashtextextended(p_idempotency_key, 0))") == 2)
check("idempotency reuse validated in apply and resolve", sql.count("v_receipt.operation_type <> p_operation_type") == 2)
check("conflict resolution validates idempotency metadata", "char_length(btrim(coalesce(p_idempotency_key, ''))) < 8 or p_winning_version <= 0" in sql)
check("sync tables RLS enabled", all(f"alter table public.{t} enable row level security" in sql for t in ["optimal_sync_records", "optimal_sync_receipts"]))
check("direct sync table access revoked", all(f"revoke all on table public.{t} from anon, authenticated" in sql for t in ["optimal_sync_records", "optimal_sync_receipts"]))
check("active membership enforced", "optimal_is_active_company_member(p_company_id)" in sql)
check("aggregate allowlist enforced", "unsupported_aggregate" in sql)
check("operation allowlist enforced", "unsupported_operation" in sql)
check("idempotency key reuse blocked", "idempotency_key_reused" in sql)
check("same receipt returned safely", "v_receipt.remote_id" in sql and "v_receipt.remote_version" in sql)
check("conflict returns remote payload", "'CONFLICT'" in sql and "v_record.payload" in sql)
check("sync RPC authenticated only", "to authenticated" in sql[sql.index("optimal_apply_sync_operation"):])
check("payload local company id not used for authorization", "payload.companyId is an opaque local Room identifier" in sql)

check("separate Verto link table", "create table if not exists public.optimal_verto_links" in sql)
check("separate Verto snapshot table", "create table if not exists public.optimal_verto_invoice_snapshots" in sql)
check("Verto tables RLS enabled", all(f"alter table public.{t} enable row level security" in sql for t in ["optimal_verto_links", "optimal_verto_invoice_snapshots"]))
check("Verto direct client access revoked", all(f"revoke all on table public.{t} from anon, authenticated" in sql for t in ["optimal_verto_links", "optimal_verto_invoice_snapshots"]))
check("Verto writes reserved to service role", "grant all on table public.optimal_verto_links to service_role" in sql and "grant all on table public.optimal_verto_invoice_snapshots to service_role" in sql)
check("Verto feed checks link", "verto_company_not_linked" in sql)
check("Verto feed checks active membership", "optimal_is_active_company_member(p_company_id)" in sql[sql.index("optimal_verto_invoice_feed"):])
check("Verto feed incremental cursor", "p_updated_after_ms" in sql and "source_updated_at" in sql)
check("admin link RPC service role only", "optimal_admin_link_verto_client" in sql and "to service_role" in sql[sql.index("optimal_admin_link_verto_client"):])

production_kotlin = "\n".join(p.read_text(encoding="utf-8") for p in ROOT.rglob("src/main/**/*.kt"))
check("no service role in Android Kotlin", "service_role" not in production_kotlin.lower())
check("domain remains free of Retrofit", not any(re.search(r"^import retrofit2", p.read_text(encoding="utf-8"), re.M) for p in (ROOT / "feature").rglob("domain/**/*.kt")))
check("presentation remains free of DAO and Retrofit", not any(re.search(r"^import (retrofit2|androidx\.room|.*\.dao\.)", p.read_text(encoding="utf-8"), re.M) for p in (ROOT / "feature").rglob("presentation/**/*.kt")))

passed = sum(ok for _, ok in checks)
print(f"\nRESULT: {passed}/{len(checks)} passed")
sys.exit(0 if passed == len(checks) else 1)
