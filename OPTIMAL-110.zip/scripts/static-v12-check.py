#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
passed = 0
failed = 0

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def check(name: str, condition: bool):
    global passed, failed
    if condition:
        passed += 1
        print(f"PASS: {name}")
    else:
        failed += 1
        print(f"FAIL: {name}")

required = [
    "core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt",
    "core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditContracts.kt",
    "core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditRedactionPolicy.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/AuditEventEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/AuditEventDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/AuditEventSchema.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/audit/AuditChangeCodec.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/audit/RoomAuditStore.kt",
    "app/src/main/java/com/optimal/fleet/infrastructure/audit/AuditModule.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityContract.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityViewModel.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

models = read(required[0])
contracts = read(required[1])
policy = read(required[2])
entity = read(required[3])
dao = read(required[4])
schema = read(required[5])
store = read(required[7])
module = read(required[8])
activity = read(required[9]) + read(required[10]) + read(required[11])

check("three actor sources", all(value in models for value in ["USER", "VERTO", "SYSTEM"]))
check("audit draft has company", "val companyId: String" in models)
check("audit draft has actor", "val actorUserId: String?" in models)
check("audit draft has action", "val action: AuditAction" in models)
check("audit draft has source", "val actorSource: AuditActorSource" in models)
check("audit draft has before after changes", "beforeValue" in models and "afterValue" in models)
check("audit supports vehicle scope", "val vehicleId: String?" in models)
check("audit supports operation scope", "val operationId: String?" in models)
check("audit has source reference", "val sourceReference: String?" in models)

check("append port exists", "interface AuditPort" in contracts and "suspend fun append" in contracts)
check("activity query exists", "interface ActivityQuery" in contracts)
check("company activity query", "observeCompanyActivity" in contracts)
check("entity activity query", "observeEntityActivity" in contracts)
check("vehicle activity query", "observeVehicleActivity" in contracts)
check("operation activity query", "observeOperationActivity" in contracts)

check("redaction blocks passwords", '"password"' in policy)
check("redaction blocks tokens", '"token"' in policy)
check("redaction blocks secrets", '"secret"' in policy)
check("redaction blocks attachment URI", '"attachmenturi"' in policy)
check("redaction removes unchanged", "beforeValue != it.afterValue" in policy or "it.beforeValue != it.afterValue" in policy)
check("redaction bounds summary", "MAX_SUMMARY_LENGTH" in policy)
check("redaction bounds changes", "MAX_CHANGES" in policy)

check("audit entity table", 'tableName = "audit_events"' in entity)
check("audit entity company FK", "entity = CompanyEntity::class" in entity)
check("audit entity composite timeline index", 'Index(value = ["companyId", "entityType", "entityId", "occurredAtEpochMillis"])' in entity)
check("audit entity actor snapshot", "actorDisplayName" in entity)
check("audit entity encoded changes", "encodedChanges" in entity)

check("DAO insert abort", "OnConflictStrategy.ABORT" in dao)
check("DAO has no update", "@Update" not in dao and not re.search(r"fun\s+update", dao, re.I))
check("DAO has no delete", "@Delete" not in dao and not re.search(r"fun\s+(delete|remove|clear)", dao, re.I))
check("DAO queries all company scoped", dao.count("companyId = :companyId") >= 4)
check("DAO queries bounded", dao.count("LIMIT :limit") >= 4)
check("database blocks update", "BEFORE UPDATE ON `audit_events`" in schema)
check("database blocks delete", "BEFORE DELETE ON `audit_events`" in schema)

migration = read("core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
db_module = read("core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt")
check("Room version 10 or later", any(token in database for token in ["version = 10", "version = 11", "version = 12"]))
check("migration 9 to 10 exists", "MIGRATION_9_10" in migration)
check("migration creates audit table", "CREATE TABLE IF NOT EXISTS `audit_events`" in migration)
check("migration installs guards", "AuditEventSchema.installAppendOnlyGuards" in migration)
check("migration included", "MIGRATION_9_10," in migration and "val ALL: Array<Migration>" in migration)
check("database includes entity", "AuditEventEntity::class" in database)
check("database exposes dao", "abstract fun auditEventDao(): AuditEventDao" in database)
check("fresh database installs guards", ".addCallback" in db_module and "installAppendOnlyGuards" in db_module)

check("store sanitizes before append", "AuditRedactionPolicy.sanitize" in store)
check("store resolves actor name", "findActiveUser" in store)
check("store owns encoding", "AuditChangeCodec.encode" in store)
check("store caps query size", "MAX_QUERY_LIMIT" in store)
check("single audit implementation", module.count("RoomAuditStore") == 2)
check("audit port binding", "bindAuditPort" in module)
check("activity query binding", "bindActivityQuery" in module)

coverage_files = [
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomCompanyBootstrapRepository.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/RoomMaintenanceImportPort.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomAdditionalCostRepository.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/verto/RoomVertoLinkAuditPort.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt",
]
for path in coverage_files:
    text = read(path)
    check(f"port coverage {path}", "AuditPort" in text and ".append(" in text)

check("global activity screen", "سجل النشاط" in activity)
check("activity shows actor", "actorLabel" in activity)
check("activity shows source", "sourceLabel" in activity)
check("activity shows timestamp", "timestampLabel" in activity)
check("activity has loading state", "activity-loading" in activity)
check("activity has empty state", "activity-empty" in activity)
check("activity has list state", "activity-list" in activity)

settings_nav = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation/SettingsNavigation.kt")
vehicle_route = read("feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt")
maintenance_route = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsRoute.kt")
check("activity route scoped by entity", "ACTIVITY_ENTITY_TYPE_ARG" in settings_nav and "ACTIVITY_ENTITY_ID_ARG" in settings_nav)
check("vehicle activity entry", "سجل نشاط السيارة" in vehicle_route)
check("operation activity entry", "سجل نشاط العملية" in maintenance_route)

presentation_violations = []
for file in (ROOT / "feature").rglob("*.kt"):
    if "/presentation/" in file.as_posix():
        text = file.read_text(encoding="utf-8")
        if "core.database" in text or "infrastructure.audit" in text:
            presentation_violations.append(str(file.relative_to(ROOT)))
check("presentation avoids DB and infrastructure", not presentation_violations)

for test in [
    "AuditAppendOnlyTest.kt",
    "AuditCoverageTest.kt",
    "AuditRedactionTest.kt",
    "ActivityQueryTest.kt",
    "AuditArchitectureTest.kt",
]:
    check(f"test exists {test}", any(path.name == test for path in ROOT.rglob("*.kt")))

build = read("app/build.gradle.kts")
check("version v12 or later", bool(re.search(r'versionName = \"0\.(?:1[2-9]|[2-9]\d)\.', build)))
check("version code 8 or later", bool(re.search(r"versionCode\s*=\s*(?:[89]|[1-9][0-9]+)", build)))

print(f"RESULT: {passed}/{passed + failed} passed")
raise SystemExit(1 if failed else 0)
