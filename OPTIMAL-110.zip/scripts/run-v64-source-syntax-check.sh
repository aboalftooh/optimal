#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mapfile -t FILES < <(find \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/work" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session" \
  -type f -name '*.kt' | sort)
FILES+=(
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/OptimalApplication.kt"
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/verto/VertoMaintenanceAutoImportCoordinator.kt"
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/sync/SyncStatusViewModel.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMessageDao.kt"
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoAttachmentDao.kt"
  "$ROOT_DIR/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/usecase/SyncVertoInvoices.kt"
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/SyncVertoMaintenanceProjections.kt"
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt"
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt"
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/sync/SyncManagerTest.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/sync/SyncWorkerTest.kt"
  "$ROOT_DIR/app/src/test/java/com/optimal/fleet/sync/UnifiedSyncCoordinatorTest.kt"
)
OUT="$(mktemp)"; JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180s kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
PATTERN='error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)'
if grep -Eiq "$PATTERN" "$OUT"; then
  grep -Ein "$PATTERN" "$OUT"
  echo "FAIL: v64 Kotlin parser diagnostics found" >&2
  exit 1
fi
[[ $STATUS -ne 124 ]] || { echo "FAIL: v64 Kotlin parser timed out" >&2; exit 1; }
printf 'PASS: Kotlin parser accepted %s v64 source files; unresolved Android/Gradle symbols were intentionally ignored.\n' "${#FILES[@]}"
