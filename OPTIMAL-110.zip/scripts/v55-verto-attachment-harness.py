#!/usr/bin/env python3
"""Executable v55 model: import once, persist private metadata, survive restart."""
from dataclasses import dataclass
from pathlib import Path
import json
import tempfile

SUPPORTED = {
    "image/jpeg": "IMAGE",
    "video/mp4": "VIDEO",
    "application/pdf": "DOCUMENT",
    "application/msword": "DOCUMENT",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "DOCUMENT",
}

@dataclass(frozen=True)
class Attachment:
    local_id: str
    message_id: str
    kind: str
    mime: str
    size: int
    private_path: str
    state: str = "LOCAL_READY"

checks = 0
with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    source = root / "picker-source.pdf"
    source.write_bytes(b"%PDF-1.7\nlocal-first")
    private = root / "files" / "verto" / "attachments" / "a.pdf"
    private.parent.mkdir(parents=True)

    mime = "application/pdf"
    expected = "DOCUMENT"
    assert SUPPORTED.get(mime) == expected
    checks += 1

    payload = source.read_bytes()
    assert payload and payload.startswith(b"%PDF-")
    checks += 1

    temp = private.with_suffix(".pdf.part")
    temp.write_bytes(payload)
    temp.replace(private)
    assert private.read_bytes() == payload
    checks += 1

    attachment = Attachment("a-1", "m-1", expected, mime, len(payload), "verto/attachments/a.pdf")
    db = root / "room.json"
    db.write_text(json.dumps(attachment.__dict__), encoding="utf-8")
    checks += 1

    del attachment
    restored = json.loads(db.read_text(encoding="utf-8"))
    assert restored["private_path"] == "verto/attachments/a.pdf"
    assert restored["state"] == "LOCAL_READY"
    assert (root / "files" / restored["private_path"]).is_file()
    checks += 1

    assert "picker-source" not in restored["private_path"]
    checks += 1

    empty = root / "empty.doc"
    empty.write_bytes(b"")
    assert empty.stat().st_size == 0
    checks += 1

    unsupported = "application/zip"
    assert unsupported not in SUPPORTED
    checks += 1

    cancelled_selection = None
    assert cancelled_selection is None
    checks += 1

    denied_before_read = True
    reads = 0
    if not denied_before_read:
        reads += 1
    assert reads == 0
    checks += 1

print(f"v55 local attachment harness: {checks}/{checks} PASS")
