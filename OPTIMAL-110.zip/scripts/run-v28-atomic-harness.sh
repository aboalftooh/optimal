#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/com/optimal/fleet/core/database/sync"
cat > "$TMP_DIR/com/optimal/fleet/core/database/sync/PendingSyncOperationEntity.kt" <<'STUB'
package com.optimal.fleet.core.database.sync

data class PendingSyncOperationEntity(
    val id: String,
    val companyId: String,
    val aggregateType: String,
    val aggregateId: String,
    val operationType: String,
    val payload: String,
    val idempotencyKey: String,
    val localVersion: Long,
    val state: String,
    val attemptCount: Int,
    val nextAttemptAtEpochMillis: Long,
    val leaseUntilEpochMillis: Long?,
    val lastErrorCode: String?,
    val remoteId: String?,
    val remoteVersion: Long?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

object SyncQueueState {
    const val PENDING = "PENDING"
}
STUB
kotlinc \
    "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/transaction/AtomicWriteTransactionRunner.kt" \
    "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/LocalWriteVersion.kt" \
    "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncOutboxEntryFactory.kt" \
    "$TMP_DIR/com/optimal/fleet/core/database/sync/PendingSyncOperationEntity.kt" \
    "$ROOT_DIR/scripts/v28-atomic-harness.kt" \
    -include-runtime -d "$TMP_DIR/v28-atomic-harness.jar"
java -jar "$TMP_DIR/v28-atomic-harness.jar"
