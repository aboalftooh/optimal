#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Run sequentially. Parallel kotlinc invocations can contend for compiler resources
# and previously made otherwise-valid harnesses appear hung.
SCRIPTS=(
  scripts/run-v07-domain-harness.sh
  scripts/run-v10-linking-harness.sh
  scripts/run-v11-finance-harness.sh
  scripts/run-v12-audit-harness.sh
  scripts/run-v13-member-harness.sh
  scripts/run-v14-notification-harness.sh
  scripts/run-v15-domain-harness.sh
  scripts/run-v18-onboarding-harness.sh
  scripts/run-v19-domain-harness.sh
)
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

passed_checks=0
for script in "${SCRIPTS[@]}"; do
  name="$(basename "$script" .sh)"
  log="$TMP_DIR/$name.log"
  echo "===== $script ====="
  if timeout --kill-after=10s 240s "$script" >"$log" 2>&1; then
    cat "$log"
    count="$(grep -c '^PASS:' "$log" || true)"
    passed_checks=$((passed_checks + count))
  else
    status=$?
    cat "$log"
    if [[ "$status" == "124" || "$status" == "137" ]]; then
      echo "NOTICE: $script timed out once; retrying after compiler cleanup." >&2
      sleep 2
      if timeout --kill-after=10s 240s "$script" >"$log.retry" 2>&1; then
        cat "$log.retry"
        count="$(grep -c '^PASS:' "$log.retry" || true)"
        passed_checks=$((passed_checks + count))
        continue
      fi
      status=$?
      cat "$log.retry"
    fi
    echo "FAIL: $script exited with status $status" >&2
    exit "$status"
  fi
done

echo "V24 regression harnesses: ${passed_checks}/${passed_checks} PASS"
