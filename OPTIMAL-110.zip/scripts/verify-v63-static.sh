#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# v63 acceptance and executable policy scenarios.
python3 scripts/v63-invoice-vehicle-history-contract.py
python3 scripts/v63-invoice-vehicle-history-harness.py

# Direct predecessor and ingestion regressions touched by this read-model work.
python3 scripts/v62-manual-invoice-link-retirement-contract.py
python3 scripts/v62-manual-invoice-link-retirement-harness.py
python3 scripts/v61-verto-maintenance-import-contract.py
python3 scripts/v61-verto-maintenance-import-harness.py
python3 scripts/v60-verto-source-ingestion-contract.py
python3 scripts/v60-verto-source-ingestion-harness.py
python3 scripts/v59-room-v3-contract.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/v58-verto-daily-cycle-contract.py
bash scripts/run-v58-verto-daily-cycle-harness.sh
python3 scripts/v47-verto-feature-architecture.py

# Cross-project structure/security and focused v63 Kotlin checks.
python3 scripts/static-architecture-check.py
python3 scripts/security-release-check.py
bash scripts/run-v63-source-syntax-check.sh
bash scripts/run-v63-attachment-access-compile.sh
bash scripts/run-v63-finance-presentation-compile.sh
