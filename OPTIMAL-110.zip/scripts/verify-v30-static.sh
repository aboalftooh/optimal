#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/static-architecture-check.py
python3 scripts/static-v30-check.py
./scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
./scripts/run-v30-error-harness.sh
./scripts/run-v30-presentation-compile.sh
python3 scripts/v29-sync-contract.py
