#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
paths = {
    'details_route': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt',
    'details_screen': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreen.kt',
    'details_components': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsComponents.kt',
    'add_cost': 'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/AddCostDialog.kt',
    'details_tests': 'feature/finance/src/androidTest/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsScreenTest.kt',
    'dashboard_tests': 'feature/finance/src/androidTest/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreenTest.kt',
}
text = {name: (root / rel).read_text() for name, rel in paths.items()}
checks = []

def check(label, cond):
    checks.append((label, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + label)

def sha(rel):
    return hashlib.sha256((root / rel).read_bytes()).hexdigest()

def tree(rel):
    h = hashlib.sha256()
    for f in sorted((root / rel).rglob('*.kt')):
        h.update(str(f.relative_to(root)).encode())
        h.update(b'\0')
        h.update(f.read_bytes())
        h.update(b'\0')
    return h.hexdigest()

for name in ['details_route', 'details_screen', 'details_components', 'add_cost']:
    source = text[name]
    check(f'{name} has no legacy DS import', re.search(r'import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', source) is None)
    check(f'{name} has no AppCard', 'AppCard' not in source)
    check(f'{name} has no direct dp literal', re.search(r'\b\d+(?:\.\d+)?\.dp\b', source) is None)
    check(f'{name} has no raw hex colors', '0xFF' not in source)

for token in ['LazyColumn', 'OptimalSectionHeader', 'InvoiceSummaryHeader', 'InvoiceMoneySection', 'InvoiceItemsSection', 'OfficialMaintenanceSection', 'OptimalListRow']:
    check(f'details screen uses {token}', token in text['details_screen'])
for label in ['بيانات الفاتورة', 'المبالغ والدفع', 'بنود الفاتورة', 'سجل الصيانة الرسمي', 'مرجع المبالغ']:
    check(f'details section {label}', label in text['details_screen'])
for tag in ['invoice-details', 'invoice-finance-source-note']:
    check(f'details screen tag {tag}', f'"{tag}"' in text['details_screen'])
check('official image event preserved', 'InvoiceDetailsEvent.OpenOfficialImage' in text['details_screen'])
check('linked maintenance state preserved', 'linkedMaintenanceOperationId' in text['details_screen'])
check('legacy read-only notice preserved', 'showsLegacyLinkNotice' in text['details_screen'])

for token in ['OptimalListRow', 'OptimalMetricCard', 'OptimalStatusBadge', 'OptimalSecondaryButton']:
    check(f'details components use {token}', token in text['details_components'])
for tag in ['invoice-details-summary', 'invoice-money', 'invoice-total', 'invoice-line-items', 'official-maintenance-record', 'legacy-invoice-link-read-only', 'invoice-linked']:
    check(f'details component tag {tag}', f'"{tag}"' in text['details_components'])
check('details status uses semantic finance status mapping', 'financeInvoiceStatusTone' in text['details_components'])
check('line item uses semantic amount helper', 'FinanceAmountText(item.totalLabel)' in text['details_components'])
check('line items are flat v2 rows', 'invoice-line-item-${item.id}' in text['details_components'] and 'AppCard' not in text['details_components'])
check('invoice total is a true metric card', 'label = "الإجمالي"' in text['details_components'] and 'OptimalMetricCard' in text['details_components'])
check('paid payment metric retained', 'label = "المدفوع"' in text['details_components'])
check('remaining payment metric retained', 'label = "المتبقي"' in text['details_components'])
check('parts classification retained', 'invoice.partsCostLabel' in text['details_components'])
check('service classification retained', 'invoice.serviceCostLabel' in text['details_components'])
check('official attachments are secondary actions', 'OptimalSecondaryButton' in text['details_components'] and 'official-image-${image.attachmentId}' in text['details_components'])
check('no invented destructive action', 'OptimalDestructiveButton' not in text['details_components'] + text['details_screen'])

check('details route uses v2 loading state', 'component.v2.OptimalLoadingState' in text['details_route'])
check('details route uses v2 empty state', 'component.v2.OptimalEmptyState' in text['details_route'])
check('details loading tag preserved', 'invoice-details-loading' in text['details_route'])
check('details missing tag preserved', 'invoice-details-missing' in text['details_route'])

for token in ['OptimalDialog', 'OptimalFormSection', 'OptimalTextField', 'OptimalMoneyField']:
    check(f'add cost uses {token}', token in text['add_cost'])
for tag in ['add-cost-dialog', 'cost-description', 'cost-amount', 'cost-date', 'cost-attachment', 'save-additional-cost', 'cancel-additional-cost']:
    check(f'add cost tag {tag}', f'"{tag}"' in text['add_cost'])
for event in ['CloseAddCost', 'SaveAdditionalCost', 'CostDescriptionChanged', 'CostAmountChanged', 'CostDateChanged', 'CostAttachmentChanged']:
    check(f'add cost event preserved {event}', f'FinanceDashboardUiEvent.{event}' in text['add_cost'])
check('add cost saving disables form controls', text['add_cost'].count('enabled = !state.isSavingCost') >= 5)
check('add cost amount uses SDG money field', 'currencyLabel = "ج.س"' in text['add_cost'])
check('add cost validation is field-adjacent', all(token in text['add_cost'] for token in ['descriptionError', 'amountError', 'dateError', 'isError = descriptionError != null', 'isError = amountError != null', 'isError = dateError != null']))
check('add cost IME flow added', all(token in text['add_cost'] for token in ['ImeAction.Next', 'ImeAction.Done', 'amountFocus.requestFocus()', 'dateFocus.requestFocus()', 'attachmentFocus.requestFocus()', 'focusManager.clearFocus()']))
check('add cost initial focus added', 'descriptionFocus.requestFocus()' in text['add_cost'])

check('details hierarchy UI coverage added', 'detailsUseV2HierarchyAndExposePaymentAndLineItems' in text['details_tests'])
check('details attachment event UI coverage added', 'officialAttachmentPreservesExistingOpenImageEvent' in text['details_tests'])
check('add cost v2 UI coverage added', 'addCostDialogUsesV2FieldsAndPreservesSaveEvent' in text['dashboard_tests'])
check('existing add cost open test preserved', 'addCostActionOpensTheExistingDialogContract' in text['dashboard_tests'])
check('v82 finance dashboard coverage preserved', 'dashboardPrioritizesFinancialMetricsAndSemanticInvoiceStatus' in text['dashboard_tests'])

protected_files = {
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardContract.kt': '5e683ce7edf66627cfa801b6bb64d2de4d5b5e42ab72ac2d12d181a26ed1d256',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardViewModel.kt': '5a2b5745b9bf0875c103a810adfd5e48d8fba2bb2222344e42638a1e663ffd44',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardRoute.kt': '410617f86e4f5ebe8cbf4646d383fb02c0a02a548d69fd06f3263b73e00775ff',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardScreen.kt': '3c2f49ae33c34f48d8297a05f7f11ef56511b6e8df5fcf95cf9d5bd39dcfe67d',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardComponents.kt': '7586a8644a6c4db1939555b764df06482f6c68e4cae16be14c57053aeb0cac97',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListContract.kt': 'f2e2da2e64b1e1fc5ccc13e00cff8a903a0c874afe3d59e32d4d4149ff2bd579',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListViewModel.kt': '5e1a51d4e262dbaa6f44c1588de71c5b1fc2fde59818f9152d5b57826d370a80',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt': '1e5b7d34fbf6b9bb2f469b54163b1aa7e5731ee41cc7d177dd80fe6d17f3966f',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt': '8ed6cf164c06128f89fc1b66a475070317179df12343ac9c6835240ed88252ef',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListComponents.kt': '108bf146c36e79de5add21c97f2d73d0c76973260af7e5dbcd86fda2a17a7332',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsContract.kt': '5996c5f0695ad26a506f04995c2ef6a1c99fe56387080a8a61bd3cf871991ac6',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt': '7adb86c50b5bbe080b67765b6f74fabfdf149429823d4d1b0a484c5a8ddc043d',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt': 'caa42fbea7bb0d8b83bf9dfdd8c3c79ea21158f39ecc01a1714f1d0adbefd675',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/FinancePresentationSemantics.kt': '3a389f23856ae8ceae8ba1f221ea9675cb5990def8474bc3cae6d4628efb323c',
}
protected_trees = {
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain': 'cf35dc56144df412c34ad3369e96f66df33a2943ccbd169ef5ffba23e6314719',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data': '22274749f891e4fd08e614be3bd0ae7e17da0ad5fc9e6d1a03de63ebc84cce1e',
}
for rel, digest in protected_files.items():
    check('protected file unchanged ' + rel, sha(rel) == digest)
for rel, digest in protected_trees.items():
    check('protected tree unchanged ' + rel, tree(rel) == digest)

failed = [item for item in checks if not item[1]]
print(f'v83 Invoice Details + Add Cost UX contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
