#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
base = root / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details"
paths = {
    "route": base / "MaintenanceDetailsRoute.kt",
    "details": base / "MaintenanceDetailsContent.kt",
    "components": base / "MaintenanceDetailsComponents.kt",
    "completion": base / "MaintenanceCompletionContent.kt",
    "edit": base / "MaintenanceEditContent.kt",
}
texts = {name: path.read_text() for name, path in paths.items()}
tests = (root / "feature/maintenance/src/androidTest/java/com/optimal/fleet/feature/maintenance/presentation/MaintenanceUiTest.kt").read_text()
checks = []

def check(label, condition):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + ": " + label)

def sha(path):
    return hashlib.sha256((root / path).read_bytes()).hexdigest()

def tree(path):
    h = hashlib.sha256()
    for f in sorted((root / path).rglob("*.kt")):
        h.update(str(f.relative_to(root)).encode()); h.update(b"\0"); h.update(f.read_bytes()); h.update(b"\0")
    return h.hexdigest()

protected_files = {
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt": "c5b3abf17663444b636e7fa9c46d58b9f07bb17124429d6d2ef05ef3ad05c178",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt": "857dc3a32745af87bd922bcb8e55c31448c5d89ee8aa97aa3d0e64d3952d7c37",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsFormParser.kt": "4c40149311690cfb622169ab3c13e2a4d04f7a5592f45c8c951dcd214de32049",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsStateReducer.kt": "52f32e8197add31391ecfac2708f7125039343058db8fd3f409d451ff2565757",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsUiMapper.kt": "f5def88b9e2e7189d045b4bb0a7fac7fb0f6812fad9730fa506af7425c0bf3a0",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt": "c0da7f24661b7154379589b0295fa27eb90b1e37b93d051c51a6704f744e373c",
}
protected_trees = {
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain": "fc1435c6e223816aee066b433aa917678877e8c84a44466d542e45489904a127",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data": "b98dc8bf1d693c0336b4f647af61e000a6fa46323770ff14842438937087c931",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list": "9ab2d6c6d4c2a0690af36e24a2f33e195c3b04fc45f2371a5b0e7350abe64d1e",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/history": "39e542db263960ba05ebad210af70fe44b68a3323babc44ae43e34269a8304a9",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/create": "0bda1ad304038ff291dbc3b1cec5023ef7c41f705571ed87e08d96940bb91adc",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup": "d9634142b5243c71002ef13f7a8fc9e76cfd9686bed84588939996f593297a8b",
}

for name, path in paths.items():
    check(f"{name} exists", path.is_file())
    text = texts[name]
    check(f"{name} has no legacy Design System import", re.search(r"import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", text) is None)
    check(f"{name} has no AppCard", "AppCard" not in text)
    check(f"{name} has no direct dp literal", re.search(r"\b\d+(?:\.\d+)?\.dp\b", text) is None)
    check(f"{name} has no raw hex colors", "0xFF" not in text)

route = texts["route"]
details = texts["details"]
components = texts["components"]
completion = texts["completion"]
edit = texts["edit"]

check("route uses v2 loading state", "component.v2.OptimalLoadingState" in route)
check("route uses v2 empty state", "component.v2.OptimalEmptyState" in route)
check("route preserves completing branch", "state.isCompleting -> MaintenanceCompletionContent(state, onEvent)" in route)
check("route preserves editing branch", "state.isEditing -> MaintenanceEditContent(state, onEvent)" in route)

check("details has summary header", "MaintenanceSummaryHeader(details)" in details)
check("summary has dedicated test tag", 'testTag("maintenance-details-summary")' in components)
check("status uses semantic v2 badge", "OptimalStatusBadge(" in components and "OptimalStatusTone.Info" in components and "OptimalStatusTone.Success" in components)
check("status test tag exists", 'testTag("maintenance-details-status")' in components)
check("summary retains vehicle name", "details.vehicleName" in components)
check("summary retains plate", "details.plateNumber" in components)
check("summary retains type", "details.typeLabel" in components)
check("summary retains source", "details.sourceLabel" in components)

for title in ["ملخص العملية", "التكلفة", "المراجع والمرفقات", "نشاط العملية", "إجراءات العملية"]:
    check(f"details section retained: {title}", f'"{title}"' in details)
check("description retained", "details.description" in details)
check("start time retained", "details.startedAtLabel" in details)
check("completion time retained", "details.completedAtLabel" in details)
check("odometer retained", "details.odometerLabel" in details)
check("manual financial visibility retained", "details.showsFinancialValues" in details)
check("total retained as metric", "details.totalLabel" in details and "OptimalMetricCard(" in details)
check("parts cost retained", "details.partsCostLabel" in details)
check("service cost retained", "details.serviceCostLabel" in details)
check("Verto finance message retained", '"تظهر في فاتورة Verto الأصلية فقط."' in details)
check("invoice retained", "details.invoiceNumber" in details)
check("attachments retained", "details.attachmentNames" in details)
check("official record retained", "details.officialRecord" in details and "OfficialMaintenanceRecordSection" in details)
check("official image event retained", "MaintenanceDetailsUiEvent.OpenOfficialImage(it)" in details)
check("activity event retained", "MaintenanceDetailsUiEvent.OpenActivity" in details)
check("completion event retained", "MaintenanceDetailsUiEvent.StartCompletion" in details)
check("edit event retained", "MaintenanceDetailsUiEvent.StartEdit" in details)
check("dismiss-message event retained", "MaintenanceDetailsUiEvent.DismissMessage" in details)
check("completed read-only tag retained", 'testTag("maintenance-read-only")' in details)

check("completion uses v2 bottom action bar", "component.v2.OptimalBottomActionBar" in completion)
check("completion primary event preserved", "MaintenanceDetailsUiEvent.ConfirmCompletion" in completion)
check("completion cancel event preserved", "MaintenanceDetailsUiEvent.CancelCompletion" in completion)
check("completion confirm tag preserved", 'testTag("confirm-maintenance-completion")' in completion)
check("completion saving label retained", '"جارٍ الإكمال…"' in completion)
check("completion has result section", 'title = "نتيجة الصيانة"' in completion)
check("completion has cost section", 'title = "التكلفة"' in completion)
check("completion has follow-up section", 'title = "متابعة دورية اختيارية"' in completion)
for event in ["CompletionDescriptionChanged", "CompletionDateChanged", "CompletionOdometerChanged", "CompletionPartsCostChanged", "CompletionServiceCostChanged", "FollowUpReasonChanged", "FollowUpDateChanged", "FollowUpOdometerChanged"]:
    check(f"completion field event preserved: {event}", f"MaintenanceDetailsUiEvent.{event}" in completion)
for tag in ["completion-description", "completion-date", "completion-odometer", "completion-parts-cost", "completion-service-cost", "followup-reason", "followup-date", "followup-odometer"]:
    check(f"completion field tag exists: {tag}", f'"{tag}"' in completion)
check("completion field errors are inline", "completionErrorText" in completion and "completionSupportingText" in completion)
check("completion non-field save error is explicit", 'testTag("maintenance-completion-message")' in completion)
check("Verto completion costs remain disabled", "val costsEditable = details.source == OperationSource.MANUAL" in completion)

check("edit uses v2 bottom action bar", "component.v2.OptimalBottomActionBar" in edit)
check("edit uses v2 segmented control", "component.v2.OptimalSegmentedControl" in edit)
check("edit keeps two operation types", edit.count("OptimalSegmentOption(MaintenanceOperationType.") == 2)
check("edit type event preserved", "MaintenanceDetailsUiEvent.TypeChanged(it)" in edit)
check("edit description event preserved", "MaintenanceDetailsUiEvent.DescriptionChanged(it)" in edit)
check("edit odometer event preserved", "MaintenanceDetailsUiEvent.OdometerChanged(it)" in edit)
check("edit parts event preserved", "MaintenanceDetailsUiEvent.PartsCostChanged(it)" in edit)
check("edit service event preserved", "MaintenanceDetailsUiEvent.ServiceCostChanged(it)" in edit)
check("edit save event preserved", "MaintenanceDetailsUiEvent.SaveEdit" in edit)
check("edit cancel event preserved", "MaintenanceDetailsUiEvent.CancelEdit" in edit)
check("edit save tag preserved", 'testTag("save-maintenance-edit")' in edit)
check("edit field errors are inline", "editErrorText" in edit)
check("edit non-field save error is explicit", 'testTag("maintenance-edit-message")' in edit)

check("shared money field uses v2 money field", "component.v2.OptimalMoneyField" in components)
check("official record uses v2 form section", "component.v2.OptimalFormSection" in components)
check("official image tag retained", 'testTag("maintenance-official-image-${image.attachmentId}")' in components)

check("new summary/completion-event UI test added", "inProgressDetailsShowsSummaryAndPreservesCompletionEvent" in tests)
check("new inline validation UI test added", "completionValidationMessageIsRenderedAtTheField" in tests)
check("existing completed read-only UI test retained", "completedDetailsDoNotShowEditAction" in tests)

for path, expected in protected_files.items():
    check(f"protected unchanged: {path}", sha(path) == expected)
for path, expected in protected_trees.items():
    check(f"protected tree unchanged: {path}", tree(path) == expected)

failed = [label for label, ok in checks if not ok]
print(f"\nSESSION-80 static contract: {len(checks) - len(failed)}/{len(checks)} PASS")
if failed:
    raise SystemExit("Failed checks: " + "; ".join(failed))
