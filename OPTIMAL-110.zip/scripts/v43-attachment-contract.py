#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v43 private Verto attachments."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
V42 = ROOT / "supabase/migrations/20260731004200_optimal_verto_message_rpcs.sql"
V43 = ROOT / "supabase/migrations/20260731004300_optimal_verto_private_attachments.sql"
PREFLIGHT = ROOT / "supabase/tests/v43_verto_attachment_preflight.sql"
SCENARIOS = ROOT / "supabase/tests/v43_verto_attachment_scenarios.sql"
ACCESS_EDGE = ROOT / "supabase/functions/verto-attachment-access/index.ts"
CLEANUP_EDGE = ROOT / "supabase/functions/verto-attachment-cleanup/index.ts"
SESSION = ROOT / "docs/sessions/v43.md"
DEPLOYMENT = ROOT / "docs/integrations/verto-private-attachments-deployment-v43.md"
ADR = ROOT / "docs/adr/ADR-verto-integration-v23.md"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
MATRIX = ROOT / "docs/integrations/verto-contract-matrix-v23.md"
ROOT_GRADLE = ROOT / "build.gradle.kts"
CI_FAST = ROOT / "scripts/ci-fast.sh"
CI_FULL = ROOT / "scripts/ci-full.sh"
VERIFY_PROJECT = ROOT / "scripts/verify-project.sh"

checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, condition))


def contains_all(text: str, values: list[str]) -> bool:
    return all(value in text for value in values)


def function_block(sql: str, name: str, next_name: str | None = None) -> str:
    marker = f"create or replace function public.{name}("
    start = sql.find(marker)
    if start < 0:
        return ""
    if next_name:
        end = sql.find(f"create or replace function public.{next_name}(", start + len(marker))
        if end >= 0:
            return sql[start:end]
    return sql[start:]


required = [
    V42,
    V43,
    PREFLIGHT,
    SCENARIOS,
    ACCESS_EDGE,
    CLEANUP_EDGE,
    SESSION,
    DEPLOYMENT,
    ADR,
    CONTRACT,
    MATRIX,
    ROOT_GRADLE,
    CI_FAST,
    CI_FULL,
    VERIFY_PROJECT,
]
for path in required:
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())

if not all(path.is_file() for path in required):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

v42 = V42.read_text(encoding="utf-8")
v43 = V43.read_text(encoding="utf-8")
preflight = PREFLIGHT.read_text(encoding="utf-8")
scenarios = SCENARIOS.read_text(encoding="utf-8")
access_edge = ACCESS_EDGE.read_text(encoding="utf-8")
cleanup_edge = CLEANUP_EDGE.read_text(encoding="utf-8")
session = SESSION.read_text(encoding="utf-8")
deployment = DEPLOYMENT.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
matrix = MATRIX.read_text(encoding="utf-8")
root_gradle = ROOT_GRADLE.read_text(encoding="utf-8")
ci_fast = CI_FAST.read_text(encoding="utf-8")
ci_full = CI_FULL.read_text(encoding="utf-8")
verify_project = VERIFY_PROJECT.read_text(encoding="utf-8")

limits = function_block(v43, "optimal_verto_attachment_limits", "optimal_verto_attachment_json")
serializer = function_block(v43, "optimal_verto_message_json", "optimal_verto_begin_attachment")
begin = function_block(v43, "optimal_verto_begin_attachment", "optimal_verto_storage_upload_allowed")
upload_allowed = function_block(v43, "optimal_verto_storage_upload_allowed", "optimal_verto_storage_object_lifecycle")
lifecycle = function_block(v43, "optimal_verto_storage_object_lifecycle", "optimal_verto_finalize_attachment")
finalize = function_block(v43, "optimal_verto_finalize_attachment", "optimal_verto_attachment_access_grant")
access_grant = function_block(v43, "optimal_verto_attachment_access_grant", "optimal_verto_send_message")
send = function_block(v43, "optimal_verto_send_message", "optimal_verto_claim_stale_attachments")
claim = function_block(v43, "optimal_verto_claim_stale_attachments", "optimal_verto_mark_attachments_cleaned")
mark_cleaned = function_block(v43, "optimal_verto_mark_attachments_cleaned")

# Migration ordering and session scope.
migrations = sorted(p.name for p in (ROOT / "supabase/migrations").glob("*.sql"))
check("order:v43-after-v42", migrations.index(V43.name) > migrations.index(V42.name))
check("scope:no-kotlin-production", not any(token in v43 for token in (".kt", "Room", "OptimalDatabase")))
check("scope:contract-version-not-promoted", "set contract_version = 23" not in v43.lower())
check("scope:attachment-readiness-stays-false", contains_all(v43, ["set verto_attachments_ready = false", "where singleton = true"]))
check("scope:no-public-url", "getPublicUrl" not in access_edge and "public = true" not in v43.lower())
check("scope:no-android-service-role", "SUPABASE_SERVICE_ROLE_KEY" not in v43 and "BuildConfig" not in access_edge)

# No invented production limits. Numeric fixtures are allowed only in rollback scenarios.
check("limits:no-max-bytes-default", re.search(r"['\"]max_bytes['\"]\s*,\s*\d", v43) is None)
check("limits:no-max-duration-default", re.search(r"['\"]max_duration_ms['\"]\s*,\s*\d", v43) is None)
check("limits:no-access-ttl-default", re.search(r"['\"]access_ttl_seconds['\"]\s*,\s*\d", v43) is None)
check("limits:no-abandon-age-default", re.search(r"['\"]abandon_after_seconds['\"]\s*,\s*\d", v43) is None)
check("limits:no-verto-limits-write", "set verto_limits" not in v43.lower())
check("limits:fail-closed", contains_all(limits, ["verto_attachment_limits_not_configured", "errcode = '55000'", "max_bytes", "mime_types", "max_duration_ms"]))
check("limits:all-four-kinds", "array['IMAGE', 'VIDEO', 'AUDIO', 'DOCUMENT']" in limits)
check("limits:positive-published-values", contains_all(limits, ["access_ttl_seconds", "abandon_after_seconds", "^[1-9][0-9]*$"]))
check("limits:session-documents-blocker", contains_all(session, ["تمنع اختراع", "BACKEND_NOT_READY", "LIMIT CONFIGURATION BLOCKED"]))
check("limits:deployment-shape", contains_all(deployment, ["access_ttl_seconds", "abandon_after_seconds", "max_bytes", "max_duration_ms", "ACTUAL_MIME"]))

# Private bucket and metadata table.
check("storage:requires-supabase-schema", contains_all(v43, ["storage.buckets", "storage.objects", "supabase_storage_schema_required"]))
check("storage:fixed-private-bucket", contains_all(v43, ["'optimal-verto-private'", "public = false", "set public = false"]))
check("storage:no-bucket-public-true", not re.search(r"optimal-verto-private[^;]+public\s*=\s*true", v43, re.S | re.I))
check("schema:attachment-table", "create table if not exists public.optimal_verto_message_attachments" in v43)
for column in [
    "conversation_id uuid not null",
    "message_id uuid",
    "uploader_user_id uuid not null",
    "client_attachment_id uuid not null",
    "idempotency_key uuid not null",
    "mime_type text not null",
    "size_bytes bigint not null",
    "duration_ms bigint",
    "original_name text",
    "bucket_id text not null",
    "object_path text not null",
    "state text not null",
    "uploaded_at timestamptz",
    "finalized_at timestamptz",
    "abandoned_at timestamptz",
    "cleaned_at timestamptz",
]:
    check(f"schema:column:{column.split()[0]}", column in v43)
check("schema:conversation-fk", "optimal_verto_message_attachments_conversation_id_fkey" in v43)
check("schema:message-composite-fk", contains_all(v43, ["foreign key (conversation_id, message_id)", "references public.optimal_verto_messages(conversation_id, id)"]))
check("schema:client-identity-unique", "optimal_verto_message_attachments_client_identity_key" in v43)
check("schema:idempotency-unique", "optimal_verto_message_attachments_idempotency_key" in v43)
check("schema:object-path-unique", "optimal_verto_message_attachments_object_path_key" in v43)
check("schema:one-attachment-per-message", "optimal_verto_message_attachments_message_idx" in v43)
check("schema:closed-kinds", "check (kind in ('IMAGE', 'VIDEO', 'AUDIO', 'DOCUMENT'))" in v43)
check("schema:closed-states", "PENDING_UPLOAD', 'UPLOADED', 'READY', 'REJECTED', 'ABANDONED" in v43)
check("schema:positive-size", "check (size_bytes > 0)" in v43)
check("schema:duration-rules", contains_all(v43, ["kind in ('IMAGE', 'DOCUMENT') and duration_ms is null", "kind in ('VIDEO', 'AUDIO') and duration_ms is not null and duration_ms > 0"]))
check("schema:fixed-path-constraint", "object_path = 'verto/' || conversation_id::text || '/' || id::text" in v43)
check("schema:display-name-only", contains_all(v43, ["original_name", "regexp_replace", "object_path"]))
check("schema:cleanup-index", "optimal_verto_message_attachments_cleanup_idx" in v43)

# RLS and direct access boundary.
check("rls:enabled", "alter table public.optimal_verto_message_attachments enable row level security" in v43)
check("rls:forced", "alter table public.optimal_verto_message_attachments force row level security" in v43)
check("rls:no-direct-grant", contains_all(v43, ["revoke all on table public.optimal_verto_message_attachments", "from public, anon, authenticated"]))
check("rls:service-role-only-table", "grant all on table public.optimal_verto_message_attachments to service_role" in v43)
check("rls:no-direct-public-policy", "on public.optimal_verto_message_attachments" not in v43[v43.find("create policy"):])
check("preflight:checks-force-rls", contains_all(preflight, ["relrowsecurity", "relforcerowsecurity"]))
check("preflight:checks-no-direct-policy", "v43_direct_attachment_policy_exposed" in preflight)
check("preflight:checks-no-direct-privilege", "v43_direct_attachment_privilege_exposed" in preflight)

# Begin lifecycle.
check("begin:security-definer", contains_all(begin, ["security definer", "set search_path = pg_catalog, public, auth, extensions"]))
check("begin:server-context", "optimal_verto_current_context(true, true)" in begin)
check("begin:published-limits", "optimal_verto_attachment_limits()" in begin)
check("begin:identity-required", "attachment_identity_required" in begin)
check("begin:closed-kind", "invalid_attachment_kind" in begin)
check("begin:non-empty-size", "attachment_size_invalid" in begin)
check("begin:max-size", "attachment_size_exceeds_limit" in begin)
check("begin:mime-allowlist", "attachment_mime_not_allowed" in begin)
check("begin:duration-required", "attachment_duration_required" in begin)
check("begin:duration-max", "attachment_duration_exceeds_limit" in begin)
check("begin:no-duration-for-static", "attachment_duration_not_allowed" in begin)
check("begin:sanitizes-name", contains_all(begin, ["regexp_replace", "p_original_name", "255"]))
check("begin:advisory-lock", "pg_advisory_xact_lock" in begin)
check("begin:idempotency-replay", contains_all(begin, ["attachment_idempotency_conflict", "idempotency_key = p_idempotency_key", "client_attachment_id = p_client_attachment_id"]))
check("begin:server-generated-id", "v_attachment_id := extensions.gen_random_uuid()" in begin)
check("begin:server-generated-path", "'verto/' || v_context.conversation_id::text || '/' || v_attachment_id::text" in begin)
check("begin:pending-only", "'PENDING_UPLOAD'" in begin)
check("begin:no-company-payload", all(token not in begin for token in ("p_company_id", "p_conversation_id", "p_user_id")))
check("begin:authenticated-grant", "grant execute on function public.optimal_verto_begin_attachment" in v43)

# Storage upload policy and object lifecycle.
check("upload-policy:auth-context", "optimal_verto_current_context(true, true)" in upload_allowed)
check("upload-policy:owner", "a.uploader_user_id = v_context.auth_user_id" in upload_allowed)
check("upload-policy:conversation", "a.conversation_id = v_context.conversation_id" in upload_allowed)
check("upload-policy:path", contains_all(upload_allowed, ["a.bucket_id = p_bucket_id", "a.object_path = p_object_path"]))
check("upload-policy:pending", "a.state = 'PENDING_UPLOAD'" in upload_allowed)
check("upload-policy:unlinked", "a.message_id is null" in upload_allowed)
check("upload-policy:insert-only", contains_all(v43, ["create policy optimal_verto_private_upload_insert", "for insert", "to authenticated", "with check"]))
check("upload-policy:no-select-update-delete", re.findall(r"create policy (optimal_verto_private_[a-z0-9_]+)", v43, re.I) == ["optimal_verto_private_upload_insert"])
check("lifecycle:storage-trigger", contains_all(v43, ["optimal_verto_private_object_lifecycle", "after insert or update or delete on storage.objects"]))
check("lifecycle:uploaded-not-ready", contains_all(lifecycle, ["set state = 'UPLOADED'", "a.state = 'PENDING_UPLOAD'", "set state = 'READY'"]) is False)
check("lifecycle:delete-abandons", contains_all(lifecycle, ["tg_op = 'DELETE'", "set state = 'ABANDONED'", "message_id is null"]))

# Finalize.
check("finalize:security-definer", contains_all(finalize, ["security definer", "set search_path = pg_catalog, public, auth, storage"]))
check("finalize:server-context", "optimal_verto_current_context(true, true)" in finalize)
check("finalize:owner", "uploader_user_id is distinct from v_context.auth_user_id" in finalize)
check("finalize:row-lock", "for update" in finalize)
check("finalize:idempotent-ready", contains_all(finalize, ["if v_attachment.state = 'READY'", "return public.optimal_verto_attachment_json"]))
check("finalize:terminal-replay", "v_attachment.state in ('REJECTED', 'ABANDONED')" in finalize)
check("finalize:object-exists", contains_all(finalize, ["from storage.objects", "attachment_object_not_ready"]))
check("finalize:actual-size", contains_all(finalize, ["v_actual_size", "metadata ->> 'size'", "v_attachment.size_bytes"]))
check("finalize:actual-mime", contains_all(finalize, ["mimetype", "contentType", "v_attachment.mime_type"]))
check("finalize:mismatch-rejected", "set state = 'REJECTED'" in finalize)
check("finalize:success-ready", contains_all(finalize, ["set state = 'READY'", "finalized_at = coalesce"]))
check("finalize:authenticated-grant", "grant execute on function public.optimal_verto_finalize_attachment(uuid)" in v43)

# Message link and feed serialization.
check("serializer:attachment-json", "public.optimal_verto_attachment_json(a.id)" in serializer)
check("serializer:empty-array-fallback", "'[]'::jsonb" in serializer)
check("serializer:message-relation", "where a.message_id = m.id" in serializer)
check("send:same-signature", "p_attachment_ids uuid[] default '{}'::uuid[]" in send)
check("send:text-zero-attachment", "text_message_must_not_have_attachments" in send)
check("send:attachment-exactly-one", "attachment_message_requires_one_attachment" in send)
check("send:audio-null-body", "audio_message_body_must_be_null" in send)
check("send:ready-required", "attachment_not_ready" in send)
check("send:kind-match", "attachment_kind_mismatch" in send)
check("send:owner", "uploader_user_id is distinct from v_context.auth_user_id" in send)
check("send:unlinked", "attachment_already_linked" in send)
check("send:atomic-link", contains_all(send, ["insert into public.optimal_verto_messages", "set message_id = v_message.id", "attachment_link_conflict"]))
check("send:idempotent-attachment-array", contains_all(send, ["v_existing_attachment_ids", "is distinct from p_attachment_ids"]))
check("send:v42-backend-not-ready-removed", "verto_attachments_not_ready" not in send)
check("scenarios:upload-success-message-failure", contains_all(scenarios, ["Successful upload/finalize followed by message failure", "v43_failed_message_destroyed_retryable_attachment"]))

# Temporary access via Edge resolver.
check("access:grant-server-context", "optimal_verto_current_context(true, false)" in access_grant)
check("access:ready-only", "a.state = 'READY'" in access_grant)
check("access:conversation-boundary", "a.conversation_id = v_context.conversation_id" in access_grant)
check("access:published-ttl", contains_all(access_grant, ["access_ttl_seconds", "expires_in_seconds", "expires_at"]))
check("access:private-path-only", contains_all(access_grant, ["bucket_id", "object_path"]))
check("access:edge-validates-jwt", contains_all(access_edge, ["authorization", "Bearer ", "SUPABASE_ANON_KEY"]))
check("access:edge-calls-grant", "optimal_verto_attachment_access_grant" in access_edge)
check("access:edge-service-signs", contains_all(access_edge, ["SUPABASE_SERVICE_ROLE_KEY", "createSignedUrl"]))
check("access:wire-response", contains_all(access_edge, ["signed_url", "expires_at", "mime_type", "size_bytes"]))
check("access:no-permanent-url-storage", "signed_url" not in v43)

# Orphan cleanup.
check("cleanup:published-age", "abandon_after_seconds" in claim)
check("cleanup:pending-uploaded-ready", "a.state in ('PENDING_UPLOAD', 'UPLOADED', 'READY')" in claim and "a.state in ('REJECTED', 'ABANDONED')" in claim)
check("cleanup:unlinked-only", "a.message_id is null" in claim)
check("cleanup:skip-locked", "for update skip locked" in claim)
check("cleanup:abandoned-state", "set state = 'ABANDONED'" in claim)
check("cleanup:returns-private-path", contains_all(claim, ["attachment_id", "bucket_id", "object_path"]))
check("cleanup:service-only-claim", contains_all(v43, ["revoke all on function public.optimal_verto_claim_stale_attachments", "grant execute on function public.optimal_verto_claim_stale_attachments(integer)", "to service_role"]))
check("cleanup:mark-only-abandoned", contains_all(mark_cleaned, ["state = 'ABANDONED'", "message_id is null", "cleaned_at"]))
check("cleanup:service-only-mark", "grant execute on function public.optimal_verto_mark_attachments_cleaned(uuid[])" in v43)
check("cleanup:edge-secret", contains_all(cleanup_edge, ["VERTO_ATTACHMENT_CLEANUP_SECRET", "x-cleanup-secret"]))
check("cleanup:edge-removes-storage", ".remove(" in cleanup_edge)
check("cleanup:edge-marks-cleaned", "optimal_verto_mark_attachments_cleaned" in cleanup_edge)
check("cleanup:no-service-key-in-doc-client", "داخل التطبيق" in deployment and "Service Role" in deployment)

# Live/staging coverage.
for token in [
    "v43_unsupported_mime_was_accepted",
    "v43_empty_file_was_accepted",
    "v43_forged_upload_path_authorized",
    "v43_finalize_retry_not_idempotent",
    "v43_inactive_link_begin_was_accepted",
    "v43_cross_tenant_upload_path_authorized",
    "v43_cross_tenant_finalize_was_accepted",
    "v43_cross_tenant_access_was_accepted",
    "v43_metadata_mismatch_not_rejected",
    "v43_stale_orphan_not_claimed",
]:
    check(f"scenario:{token}", token in scenarios)
check("scenario:rollback", scenarios.rstrip().endswith("rollback;"))
check("scenario:test-limits-explicitly-fixtures", "test fixtures only" in scenarios.lower())
check("preflight:private-bucket", "v43_private_bucket_missing_or_public" in preflight)
check("preflight:storage-policy", "v43_storage_insert_policy_missing" in preflight)
check("preflight:no-storage-read-policy", "v43_storage_read_or_mutation_policy_exposed" in preflight)
check("preflight:cleanup-not-authenticated", "v43_cleanup_rpc_exposed_to_android" in preflight)
check("preflight:readiness-false", "v43_attachment_readiness_promoted_before_live_gate" in preflight)

# Documentation contract alignment.
check("docs:adr-private-storage", contains_all(ADR.read_text(encoding="utf-8"), ["Bucket خاص", "Begin → Upload → Finalize", "ABANDONED"]))
check("docs:backend-rpcs", contains_all(contract, ["optimal_verto_begin_attachment", "optimal_verto_finalize_attachment", "optimal_verto_attachment_access"]))
check("docs:matrix-attachment", contains_all(matrix, ["Matrix المرفق", "client_attachment_id", "signed URL"]))
check("docs:session-next-v44", "v44" in session)
check("docs:deployment-no-copy-fixture", "لا تُنسخ أرقام سيناريو الاختبار" in deployment)
check("docs:deployment-no-public-fallback", "لا تحوله Public" in deployment)

# CI/Gradle integration.
check("gradle:v43-task", "vertoAttachmentContractCheck" in root_gradle and "scripts/v43-attachment-contract.py" in root_gradle)
check("gradle:static-quality-dependency", "vertoAttachmentContractCheck," in root_gradle)
check("ci-fast:v43", "python3 scripts/v43-attachment-contract.py" in ci_fast)
check("ci-full:v43", any(name in ci_full for name in ("verify-v43-static.sh", "verify-v44-static.sh", "verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh", "verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-project:v43", any(name in verify_project for name in ("verify-v43-static.sh", "verify-v44-static.sh", "verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh", "verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))

passed = sum(1 for _, ok in checks if ok)
failed = [(name, ok) for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
print(f"RESULT {passed}/{len(checks)}")
if failed:
    sys.exit(1)
