#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$TMP_DIR/stubs"/{androidx/lifecycle,androidx/compose/runtime,dagger/hilt/android/lifecycle,javax/inject,kotlinx/coroutines/flow,com/optimal/fleet/feature/maintenance/navigation,com/optimal/fleet/feature/maintenance/presentation/list}
cat > "$TMP_DIR/stubs/androidx/lifecycle/Lifecycle.kt" <<'KT'
package androidx.lifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
open class ViewModel
class SavedStateHandle(private val values: Map<String, Any?> = emptyMap()) {
    @Suppress("UNCHECKED_CAST") operator fun <T> get(key: String): T? = values[key] as? T
}
val ViewModel.viewModelScope: CoroutineScope get() = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
KT
cat > "$TMP_DIR/stubs/androidx/compose/runtime/Immutable.kt" <<'KT'
package androidx.compose.runtime
@Target(AnnotationTarget.CLASS) annotation class Immutable
KT
cat > "$TMP_DIR/stubs/dagger/hilt/android/lifecycle/HiltViewModel.kt" <<'KT'
package dagger.hilt.android.lifecycle
@Target(AnnotationTarget.CLASS) annotation class HiltViewModel
KT
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
KT
cat > "$TMP_DIR/stubs/kotlinx/coroutines/flow/Update.kt" <<'KT'
package kotlinx.coroutines.flow
import kotlinx.coroutines.InternalCoroutinesApi
inline fun <T> MutableStateFlow<T>.update(function: (T) -> T) { value = function(value) }
@OptIn(InternalCoroutinesApi::class)
suspend fun <T> Flow<T>.collect(action: suspend (T) -> Unit) {
    collect(object : FlowCollector<T> { override suspend fun emit(value: T) = action(value) })
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/navigation/Nav.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.navigation
const val MAINTENANCE_OPERATION_ID_ARG = "operationId"
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/maintenance/presentation/list/Format.kt" <<'KT'
package com.optimal.fleet.feature.maintenance.presentation.list
internal fun formatMoney(minorUnits: Long): String = minorUnits.toString()
KT
mapfile -t DOMAIN_FILES < <(find "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain" -type f -name '*.kt' | sort)
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  $(find "$TMP_DIR/stubs" -type f -name '*.kt' | sort) \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/paging/PageSlice.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/verto/TemporaryVertoAttachmentAccess.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionIdentity.kt" \
  "$ROOT_DIR/core/session/src/main/kotlin/com/optimal/fleet/core/session/SessionReader.kt" \
  "${DOMAIN_FILES[@]}" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsStateReducer.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsFormParser.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsUiMapper.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt" \
  -d "$TMP_DIR/v34-maintenance-presentation.jar"
echo "PASS: maintenance details contract, reducer, parser, mapper and ViewModel compile"
echo "V34 maintenance presentation compilation: 1/1"
