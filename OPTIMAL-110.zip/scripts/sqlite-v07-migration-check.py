#!/usr/bin/env python3
import sqlite3
import tempfile
from pathlib import Path

passed = 0
checks = 0

def verify(name, condition):
    global passed, checks
    checks += 1
    if not condition:
        raise AssertionError(name)
    passed += 1
    print(f'PASS: {name}')

with tempfile.TemporaryDirectory() as temp:
    path = Path(temp) / 'optimal.db'
    db = sqlite3.connect(path)
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript('''
    CREATE TABLE companies(id TEXT PRIMARY KEY NOT NULL, remoteId TEXT, name TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL, syncStatus TEXT NOT NULL);
    CREATE TABLE local_users(id TEXT PRIMARY KEY NOT NULL, companyId TEXT NOT NULL, remoteId TEXT, displayName TEXT NOT NULL, phone TEXT, isActive INTEGER NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL, syncStatus TEXT NOT NULL, UNIQUE(id,companyId), FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT);
    CREATE TABLE vehicles(id TEXT PRIMARY KEY NOT NULL, companyId TEXT NOT NULL, remoteId TEXT, name TEXT NOT NULL, plateNumber TEXT NOT NULL, normalizedPlateNumber TEXT NOT NULL, brand TEXT, model TEXT, manufactureYear INTEGER, odometerKm INTEGER, department TEXT, driverName TEXT, archivedAtEpochMillis INTEGER, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL, syncStatus TEXT NOT NULL, UNIQUE(id,companyId), FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT);
    CREATE TABLE maintenance_operations(id TEXT PRIMARY KEY NOT NULL, companyId TEXT NOT NULL, vehicleId TEXT NOT NULL, remoteId TEXT, clientGeneratedId TEXT NOT NULL UNIQUE, type TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL, startedAtEpochMillis INTEGER NOT NULL, completedAtEpochMillis INTEGER, odometerKm INTEGER, partsCostMinor INTEGER NOT NULL, serviceCostMinor INTEGER NOT NULL, source TEXT NOT NULL, createdByUserId TEXT NOT NULL, updatedByUserId TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL, syncState TEXT NOT NULL, UNIQUE(id,companyId), FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT, FOREIGN KEY(vehicleId,companyId) REFERENCES vehicles(id,companyId) ON DELETE RESTRICT, FOREIGN KEY(createdByUserId,companyId) REFERENCES local_users(id,companyId) ON DELETE RESTRICT, FOREIGN KEY(updatedByUserId,companyId) REFERENCES local_users(id,companyId) ON DELETE RESTRICT);
    CREATE TABLE maintenance_audit_events(id TEXT PRIMARY KEY NOT NULL, companyId TEXT NOT NULL, operationId TEXT NOT NULL, actorUserId TEXT NOT NULL, action TEXT NOT NULL, changedFields TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, syncState TEXT NOT NULL, FOREIGN KEY(operationId,companyId) REFERENCES maintenance_operations(id,companyId) ON DELETE RESTRICT, FOREIGN KEY(actorUserId,companyId) REFERENCES local_users(id,companyId) ON DELETE RESTRICT);
    ''')
    # Migration 4 -> 5
    db.executescript('''
    CREATE TABLE IF NOT EXISTS maintenance_follow_ups(
      id TEXT PRIMARY KEY NOT NULL, companyId TEXT NOT NULL, vehicleId TEXT NOT NULL,
      sourceOperationId TEXT NOT NULL, reason TEXT NOT NULL, dueDateEpochMillis INTEGER,
      dueOdometerKm INTEGER, convertedOperationId TEXT, createdByUserId TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL, syncState TEXT NOT NULL,
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT,
      FOREIGN KEY(vehicleId,companyId) REFERENCES vehicles(id,companyId) ON DELETE RESTRICT,
      FOREIGN KEY(sourceOperationId,companyId) REFERENCES maintenance_operations(id,companyId) ON DELETE RESTRICT,
      FOREIGN KEY(convertedOperationId,companyId) REFERENCES maintenance_operations(id,companyId) ON DELETE RESTRICT,
      FOREIGN KEY(createdByUserId,companyId) REFERENCES local_users(id,companyId) ON DELETE RESTRICT
    );
    CREATE UNIQUE INDEX index_maintenance_follow_ups_id_companyId ON maintenance_follow_ups(id,companyId);
    CREATE UNIQUE INDEX index_maintenance_follow_ups_sourceOperationId_companyId ON maintenance_follow_ups(sourceOperationId,companyId);
    CREATE INDEX index_maintenance_follow_ups_vehicleId_companyId ON maintenance_follow_ups(vehicleId,companyId);
    CREATE INDEX index_maintenance_follow_ups_companyId_convertedOperationId ON maintenance_follow_ups(companyId,convertedOperationId);
    CREATE INDEX index_maintenance_follow_ups_companyId_dueDateEpochMillis ON maintenance_follow_ups(companyId,dueDateEpochMillis);
    CREATE INDEX index_maintenance_follow_ups_companyId_dueOdometerKm ON maintenance_follow_ups(companyId,dueOdometerKm);
    ''')
    verify('follow-up table created', db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='maintenance_follow_ups'").fetchone() is not None)
    verify('source operation uniqueness index', db.execute("SELECT name FROM sqlite_master WHERE name='index_maintenance_follow_ups_sourceOperationId_companyId'").fetchone() is not None)

    for company,user,vehicle in [('c1','u1','v1'),('c2','u2','v2')]:
        db.execute('INSERT INTO companies VALUES (?,?,?,?,?,?)',(company,None,company,1,1,'PENDING'))
        db.execute('INSERT INTO local_users VALUES (?,?,?,?,?,?,?,?,?)',(user,company,None,user,None,1,1,1,'PENDING'))
        db.execute('INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(vehicle,company,None,vehicle,vehicle,vehicle,None,None,None,10000,None,None,None,1,1,'PENDING'))
    op=('o1','c1','v1',None,'client-o1','FULL_MAINTENANCE','عملية','IN_PROGRESS',1,None,10000,0,0,'MANUAL','u1','u1',1,1,'PENDING')
    db.execute('INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',op)
    db.commit()

    with db:
        current=db.execute("SELECT vehicleId,status FROM maintenance_operations WHERE companyId='c1' AND id='o1'").fetchone()
        changed=db.execute("UPDATE maintenance_operations SET description=?,status='COMPLETED',completedAtEpochMillis=?,odometerKm=?,partsCostMinor=?,serviceCostMinor=?,updatedAtEpochMillis=? WHERE companyId=? AND id=? AND status='IN_PROGRESS'",('تمت',100,20000,1000,500,100,'c1','o1')).rowcount
        if changed == 1:
            db.execute("UPDATE vehicles SET odometerKm=?,updatedAtEpochMillis=? WHERE companyId=? AND id=? AND (odometerKm IS NULL OR odometerKm < ?)",(20000,100,'c1',current[0],20000))
            db.execute("INSERT INTO maintenance_follow_ups VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",('f1','c1','v1','o1','تغيير زيت',200,30000,None,'u1',100,100,'PENDING'))
            db.execute("INSERT INTO maintenance_audit_events VALUES (?,?,?,?,?,?,?,?)",('a1','c1','o1','u1','COMPLETED','status,followUp',100,'PENDING'))
    verify('completion guarded update succeeds once', changed == 1)
    verify('operation completed', db.execute("SELECT status FROM maintenance_operations WHERE id='o1'").fetchone()[0]=='COMPLETED')
    verify('vehicle odometer raised', db.execute("SELECT odometerKm FROM vehicles WHERE id='v1'").fetchone()[0]==20000)
    verify('follow-up inserted', db.execute("SELECT COUNT(*) FROM maintenance_follow_ups").fetchone()[0]==1)
    verify('audit inserted', db.execute("SELECT action FROM maintenance_audit_events WHERE id='a1'").fetchone()[0]=='COMPLETED')
    verify('completed visible in history query', db.execute("SELECT id FROM maintenance_operations WHERE companyId='c1' AND status='COMPLETED'").fetchall()==[('o1',)])

    second=db.execute("UPDATE maintenance_operations SET completedAtEpochMillis=999 WHERE companyId='c1' AND id='o1' AND status='IN_PROGRESS'").rowcount
    verify('second completion blocked', second == 0)
    verify('follow-up not duplicated', db.execute("SELECT COUNT(*) FROM maintenance_follow_ups WHERE sourceOperationId='o1' AND companyId='c1'").fetchone()[0]==1)

    try:
        db.execute("INSERT INTO maintenance_follow_ups VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",('bad','c1','v2','o1','خطأ',None,1,None,'u1',1,1,'PENDING'))
        db.commit(); cross=False
    except sqlite3.IntegrityError:
        db.rollback(); cross=True
    verify('cross-company vehicle rejected', cross)

    newop=('o2','c1','v1',None,'client-o2','FULL_MAINTENANCE','تغيير زيت','IN_PROGRESS',300,None,None,0,0,'MANUAL','u1','u1',300,300,'PENDING')
    with db:
        db.execute('INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',newop)
        converted=db.execute("UPDATE maintenance_follow_ups SET convertedOperationId='o2',updatedAtEpochMillis=300 WHERE companyId='c1' AND id='f1' AND convertedOperationId IS NULL").rowcount
        if converted == 1:
            db.execute("INSERT INTO maintenance_audit_events VALUES (?,?,?,?,?,?,?,?)",('a2','c1','o2','u1','FOLLOW_UP_CONVERTED','followUpId',300,'PENDING'))
    verify('follow-up conversion marks source', converted == 1 and db.execute("SELECT convertedOperationId FROM maintenance_follow_ups WHERE id='f1'").fetchone()[0]=='o2')
    verify('converted operation prefilled', db.execute("SELECT description,status FROM maintenance_operations WHERE id='o2'").fetchone()==('تغيير زيت','IN_PROGRESS'))
    verify('second conversion blocked', db.execute("UPDATE maintenance_follow_ups SET convertedOperationId='x' WHERE id='f1' AND convertedOperationId IS NULL").rowcount==0)
    verify('converted follow-up excluded from active list', db.execute("SELECT COUNT(*) FROM maintenance_follow_ups WHERE companyId='c1' AND convertedOperationId IS NULL").fetchone()[0]==0)

print(f'SQLite v07 checks: {passed}/{checks}')
