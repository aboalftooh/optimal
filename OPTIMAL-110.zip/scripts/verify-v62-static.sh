#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v62-manual-invoice-link-retirement-contract.py
python3 scripts/v62-manual-invoice-link-retirement-harness.py

# v61 regression equivalent to verify-v61-static.sh, with unchanged historical parser gates
# evidenced separately to keep the v62 aggregate gate bounded.
python3 scripts/v61-verto-maintenance-import-contract.py
./scripts/run-v61-verto-maintenance-import-harness.sh
python3 scripts/v60-verto-source-ingestion-contract.py
./scripts/run-v60-verto-source-ingestion-harness.sh
python3 scripts/v59-room-v3-contract.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/v58-verto-daily-cycle-contract.py
./scripts/run-v58-verto-daily-cycle-harness.sh
python3 scripts/v47-verto-feature-architecture.py
python3 scripts/static-architecture-check.py
python3 scripts/security-release-check.py
bash scripts/run-v62-source-syntax-check.sh
