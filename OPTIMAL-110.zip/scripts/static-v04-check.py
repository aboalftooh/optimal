#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=''):
    checks.append((name, bool(condition), detail))

required = [
    'core/database/src/main/java/com/optimal/fleet/core/database/entity/VehicleEntity.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/entity/VehicleAuditEntity.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/Vehicle.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleDraft.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleValidation.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/repository/VehicleRepository.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/ObserveVehiclesUseCase.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/ObserveVehicleUseCase.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/SaveVehicleUseCase.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/usecase/ArchiveVehicleUseCase.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleMappers.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/di/VehicleDataModule.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesContract.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorContract.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailContract.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesViewModel.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorViewModel.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailViewModel.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehiclesRoute.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleEditorRoute.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/presentation/VehicleDetailRoute.kt',
    'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/navigation/VehiclesNavigation.kt',
]
for rel in required:
    check(f'required {rel}', (ROOT / rel).is_file())

entity = (ROOT / required[0]).read_text(encoding='utf-8')
audit = (ROOT / required[1]).read_text(encoding='utf-8')
dao = (ROOT / required[2]).read_text(encoding='utf-8')
migration = (ROOT / required[3]).read_text(encoding='utf-8')
database = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt').read_text(encoding='utf-8')
db_module = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt').read_text(encoding='utf-8')

for field in ['id', 'companyId', 'remoteId', 'name', 'plateNumber', 'normalizedPlateNumber', 'odometerKm', 'archivedAtEpochMillis', 'updatedAtEpochMillis', 'syncStatus']:
    check(f'vehicle field {field}', f'val {field}:' in entity)
check('vehicle company foreign key', 'entity = CompanyEntity::class' in entity and 'childColumns = ["companyId"]' in entity)
check('vehicle delete restricted', 'onDelete = ForeignKey.RESTRICT' in entity)
check('vehicle composite identity', 'Index(value = ["id", "companyId"], unique = true)' in entity)
check('plate unique within company', 'Index(value = ["companyId", "normalizedPlateNumber"], unique = true)' in entity)
check('vehicle sync fields', all(x in entity for x in ['remoteId', 'updatedAtEpochMillis', 'syncStatus']))

for field in ['companyId', 'vehicleId', 'actorUserId', 'action', 'previousOdometerKm', 'newOdometerKm', 'reason', 'createdAtEpochMillis', 'syncStatus']:
    check(f'audit field {field}', f'val {field}:' in audit)
check('audit vehicle composite foreign key', 'parentColumns = ["id", "companyId"]' in audit and 'childColumns = ["vehicleId", "companyId"]' in audit)
check('audit actor composite foreign key', 'childColumns = ["actorUserId", "companyId"]' in audit)
check('audit is restricted from cascade delete', audit.count('onDelete = ForeignKey.RESTRICT') == 2)

check('DAO observes company scope', 'WHERE companyId = :companyId' in dao)
check('DAO search by name', "name LIKE '%' || :query || '%'" in dao)
check('DAO search by plate', "plateNumber LIKE '%' || :query || '%'" in dao)
check('DAO filters archived', ':includeArchived = 1 OR archivedAtEpochMillis IS NULL' in dao)
check('DAO reads detail company scoped', 'companyId = :companyId AND id = :vehicleId' in dao)
check('DAO has duplicate plate query', 'findByNormalizedPlate' in dao and 'excludedVehicleId' in dao)
check('DAO transaction create with audit', '@Transaction' in dao and 'insertVehicleWithAudit' in dao)
check('DAO transaction update with audit', 'updateVehicleWithAudit' in dao and 'insertAudit(event)' in dao)
check('DAO exposes no delete', '@Delete' not in dao and not re.search(r'fun\s+delete', dao))

check('database version is at least 2', bool(re.search(r'version\s*=\s*([2-9]|[1-9][0-9]+)', database)))
check('database registers vehicles', 'VehicleEntity::class' in database and 'VehicleAuditEntity::class' in database)
check('database exposes vehicle DAO', 'abstract fun vehicleDao(): VehicleDao' in database)
check('migration 1 to 2', 'Migration(1, 2)' in migration and 'MIGRATION_1_2' in migration)
check('migration creates vehicles', 'CREATE TABLE IF NOT EXISTS `vehicles`' in migration)
check('migration creates audit', 'CREATE TABLE IF NOT EXISTS `vehicle_audit_events`' in migration)
check('migration creates scoped plate index', 'index_vehicles_companyId_normalizedPlateNumber' in migration)
check('database installs migration', '.addMigrations(*DatabaseMigrations.ALL)' in db_module)
check('no destructive migration in production', not any(
    'fallbackToDestructiveMigration' in p.read_text(encoding='utf-8')
    for base in [ROOT / 'app/src/main', ROOT / 'core', ROOT / 'feature']
    for p in base.rglob('*.kt')
    if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix()
))

feature_root = ROOT / 'feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles'
domain_files = list((feature_root / 'domain').rglob('*.kt'))
presentation_files = list((feature_root / 'presentation').rglob('*.kt'))
data_files = list((feature_root / 'data').rglob('*.kt'))
check('vehicle domain exists', bool(domain_files))
check('vehicle presentation exists', bool(presentation_files))
check('vehicle data exists', bool(data_files))

domain_forbidden = []
for p in domain_files:
    text = p.read_text(encoding='utf-8')
    if re.search(r'^import (android\.|androidx\.room|retrofit2\.|com\.optimal\.fleet\.core\.database)', text, re.M):
        domain_forbidden.append(str(p.relative_to(ROOT)))
check('vehicle domain is pure Kotlin', not domain_forbidden, ', '.join(domain_forbidden))

presentation_forbidden = []
for p in presentation_files:
    text = p.read_text(encoding='utf-8')
    if re.search(r'^import .*\.(data|dao)\.', text, re.M) or re.search(r'^import .*core\.database', text, re.M):
        presentation_forbidden.append(str(p.relative_to(ROOT)))
check('presentation does not import data or database', not presentation_forbidden, ', '.join(presentation_forbidden))
check('UI does not accept companyId', 'companyId' not in '\n'.join(p.read_text(encoding='utf-8') for p in presentation_files))
check('DAO imported only in data', all('/data/' in p.as_posix() for p in data_files if 'VehicleDao' in p.read_text(encoding='utf-8')))
check('feature does not import another feature', not any(
    re.search(r'import com\.optimal\.fleet\.feature\.(?!vehicles\.)', p.read_text(encoding='utf-8'))
    for p in feature_root.rglob('*.kt')
))

validator = (ROOT / required[6]).read_text(encoding='utf-8')
check('name required', 'MissingName' in validator and 'draft.name.isBlank()' in validator)
check('plate required', 'MissingPlateNumber' in validator and 'draft.plateNumber.isBlank()' in validator)
check('other fields optional in draft', all(f'val {x}: ' in (ROOT / required[5]).read_text(encoding='utf-8') and '= null' in (ROOT / required[5]).read_text(encoding='utf-8').split(f'val {x}: ',1)[1].split('\n',1)[0] for x in ['brand', 'model', 'manufactureYear', 'odometerKm', 'department', 'driverName']))
check('lower odometer warning rule', 'LowerOdometerReasonRequired' in validator and 'draft.odometerKm < previousOdometerKm' in validator)
check('plate normalization exists', 'normalizePlateNumber' in validator)

save_uc = (ROOT / required[10]).read_text(encoding='utf-8')
archive_uc = (ROOT / required[11]).read_text(encoding='utf-8')
observe_uc = (ROOT / required[8]).read_text(encoding='utf-8')
check('save gets company from session', 'sessionReader.currentSession()' in save_uc and 'companyId = session.companyId' in save_uc)
check('save gets actor from session', 'actorUserId = session.userId' in save_uc)
check('archive gets company from session', 'sessionReader.currentSession()' in archive_uc and 'session.companyId' in archive_uc)
check('observe gets company from session', 'observeActiveSession()' in observe_uc and 'session.companyId' in observe_uc)

repo = (ROOT / required[12]).read_text(encoding='utf-8')
check('repository maps Room to Domain', '.toDomain()' in repo)
check('repository creates audit actions', all(x in repo for x in ['VEHICLE_CREATED', 'VEHICLE_UPDATED', 'VEHICLE_ARCHIVED']))
check('repository archives instead of deletes', 'archivedAtEpochMillis = now' in repo and 'delete' not in repo.lower())
check('repository prepares pending sync', repo.count('DatabaseConstants.SYNC_PENDING') >= 3)
check('repository uses scoped duplicate query', 'companyId = companyId' in repo and 'findByNormalizedPlate' in repo)

contracts = '\n'.join((ROOT / rel).read_text(encoding='utf-8') for rel in required[15:18])
check('immutable UI states', contracts.count('@Immutable') >= 6)
check('UDF events exist', contracts.count('sealed interface') >= 6 and 'UiEvent' in contracts and 'UiEffect' in contracts)
check('editor state has lower reading warning', 'lowerOdometerWarning' in contracts and 'lowerOdometerReason' in contracts)

routes = '\n'.join((ROOT / rel).read_text(encoding='utf-8') for rel in required[21:24])
check('list has search', 'vehicle-search' in routes and 'SearchChanged' in routes)
check('list has archive toggle', 'إظهار السيارات المؤرشفة' in routes)
check('editor has minimum required fields', 'اسم أو وصف السيارة *' in routes and 'رقم اللوحة *' in routes)
check('editor has optional fields', all(x in routes for x in ['الماركة', 'الموديل', 'القسم — اختياري', 'السائق — اختياري']))
check('lower odometer dialog exists', 'قراءة العداد أقل' in routes and 'سبب الاستثناء' in routes)
check('detail supports edit and archive', 'edit-vehicle' in routes and 'archive-vehicle' in routes)

nav = (ROOT / required[24]).read_text(encoding='utf-8')
app_nav = (ROOT / 'app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt').read_text(encoding='utf-8')
check('vehicle list route exists', 'VEHICLES_ROUTE' in nav)
check('vehicle detail route exists', 'VEHICLE_DETAIL_ROUTE' in nav)
check('vehicle editor route exists', 'VEHICLE_EDITOR_ROUTE' in nav)
check('app owns vehicle navigation callbacks', 'vehicleEditorRoute' in app_nav and 'vehicleDetailRoute' in app_nav)

build = (ROOT / 'feature/vehicles/build.gradle.kts').read_text(encoding='utf-8').lower()
check('vehicles depends on database', 'project(":core:database")' in build)
check('vehicles depends on session', 'project(":core:session")' in build)
check('vehicles has Hilt', 'libs.plugins.hilt' in build and 'libs.hilt.android' in build)
check('Clock provider owned by app composition root', (ROOT / 'app/src/main/java/com/optimal/fleet/di/TimeModule.kt').is_file() and sum('fun provideClock()' in p.read_text(encoding='utf-8') for p in ROOT.rglob('*.kt') if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix()) == 1)
check('vehicles has no backend SDK', all(x not in build for x in ['retrofit', 'supabase', 'firebase']))

required_tests = [
    'feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/domain/model/VehicleValidationTest.kt',
    'feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryTest.kt',
    'feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/domain/usecase/SaveVehicleUseCaseTest.kt',
    'feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/presentation/VehicleViewModelTest.kt',
    'core/database/src/androidTest/java/com/optimal/fleet/core/database/VehicleDaoTest.kt',
    'app/src/test/java/com/optimal/fleet/VehicleArchitectureTest.kt',
    'feature/vehicles/src/androidTest/java/com/optimal/fleet/feature/vehicles/presentation/VehicleScreensTest.kt',
]
for rel in required_tests:
    check(f'test {rel}', (ROOT / rel).is_file())

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f' — {detail}' if detail and not passed else ''))
passed = sum(1 for _, ok, _ in checks if ok)
print(f'\nV04 static checks: {passed}/{len(checks)}')
sys.exit(0 if passed == len(checks) else 1)
