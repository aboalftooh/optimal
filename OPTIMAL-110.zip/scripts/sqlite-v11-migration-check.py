#!/usr/bin/env python3
import sqlite3

checks = 0

def check(name, condition):
    global checks
    if not condition:
        raise AssertionError(name)
    checks += 1
    print(f'PASS: {name}')

con = sqlite3.connect(':memory:')
con.execute('PRAGMA foreign_keys = ON')
con.executescript('''
CREATE TABLE companies (
  id TEXT NOT NULL PRIMARY KEY,
  remoteId TEXT,
  name TEXT NOT NULL,
  createdAtEpochMillis INTEGER NOT NULL,
  updatedAtEpochMillis INTEGER NOT NULL,
  syncStatus TEXT NOT NULL
);
CREATE TABLE local_users (
  id TEXT NOT NULL PRIMARY KEY,
  companyId TEXT NOT NULL,
  remoteId TEXT,
  displayName TEXT NOT NULL,
  phone TEXT,
  isActive INTEGER NOT NULL,
  createdAtEpochMillis INTEGER NOT NULL,
  updatedAtEpochMillis INTEGER NOT NULL,
  syncStatus TEXT NOT NULL,
  FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX index_local_users_id_companyId ON local_users(id, companyId);
CREATE TABLE maintenance_operations (
  id TEXT PRIMARY KEY NOT NULL,
  companyId TEXT NOT NULL,
  startedAtEpochMillis INTEGER NOT NULL,
  completedAtEpochMillis INTEGER,
  partsCostMinor INTEGER NOT NULL,
  serviceCostMinor INTEGER NOT NULL
);
CREATE TABLE verto_invoice_projections (
  id TEXT PRIMARY KEY NOT NULL,
  companyId TEXT NOT NULL,
  totalMinor INTEGER NOT NULL,
  paidMinor INTEGER,
  remainingMinor INTEGER,
  voided INTEGER NOT NULL,
  invoiceDateEpochMillis INTEGER NOT NULL
);
''')

con.execute("ALTER TABLE companies ADD COLUMN currencyCode TEXT NOT NULL DEFAULT 'SDG'")
con.executescript('''
CREATE TABLE additional_costs (
  id TEXT NOT NULL PRIMARY KEY,
  companyId TEXT NOT NULL,
  remoteId TEXT,
  description TEXT NOT NULL,
  amountMinor INTEGER NOT NULL,
  currencyCode TEXT NOT NULL,
  occurredAtEpochMillis INTEGER NOT NULL,
  attachmentUri TEXT,
  createdByUserId TEXT NOT NULL,
  createdAtEpochMillis INTEGER NOT NULL,
  updatedAtEpochMillis INTEGER NOT NULL,
  syncState TEXT NOT NULL,
  FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY(createdByUserId, companyId) REFERENCES local_users(id, companyId) ON DELETE RESTRICT
);
CREATE INDEX index_additional_costs_companyId ON additional_costs(companyId);
CREATE INDEX index_additional_costs_companyId_occurredAtEpochMillis ON additional_costs(companyId, occurredAtEpochMillis);
CREATE INDEX index_additional_costs_createdByUserId_companyId ON additional_costs(createdByUserId, companyId);
CREATE UNIQUE INDEX index_additional_costs_remoteId ON additional_costs(remoteId);
''')

con.executemany(
    'INSERT INTO companies(id, remoteId, name, createdAtEpochMillis, updatedAtEpochMillis, syncStatus) VALUES(?,?,?,?,?,?)',
    [('linked', 'verto-client', 'شركة مرتبطة', 1, 1, 'PENDING'), ('local', None, 'شركة محلية', 1, 1, 'PENDING')],
)
check('default currency is SDG', con.execute("SELECT currencyCode FROM companies WHERE id='linked'").fetchone()[0] == 'SDG')
con.executemany(
    'INSERT INTO local_users VALUES(?,?,?,?,?,?,?,?,?)',
    [('u1', 'linked', None, 'مستخدم', None, 1, 1, 1, 'PENDING'), ('u2', 'local', None, 'مستخدم', None, 1, 1, 1, 'PENDING')],
)
con.executemany(
    'INSERT INTO verto_invoice_projections VALUES(?,?,?,?,?,?,?)',
    [('i1', 'linked', 100000, 25000, 75000, 0, 100), ('i2', 'linked', 50000, 50000, 0, 0, 200), ('i3', 'linked', 99999, 0, 99999, 1, 300)],
)
con.executemany(
    'INSERT INTO maintenance_operations VALUES(?,?,?,?,?,?)',
    [('m1', 'linked', 100, 200, 30000, 20000), ('m2', 'local', 100, None, 40000, 10000)],
)
con.executemany(
    'INSERT INTO additional_costs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
    [('a1', 'linked', None, 'ترحيل', 5000, 'SDG', 150, None, 'u1', 150, 150, 'PENDING'), ('a2', 'local', None, 'غسيل', 2000, 'SDG', 150, None, 'u2', 150, 150, 'PENDING')],
)

summary_sql = '''
SELECT
  CASE WHEN c.remoteId IS NULL OR TRIM(c.remoteId)='' THEN 0 ELSE 1 END,
  COALESCE((SELECT SUM(CASE WHEN vi.voided=1 THEN 0 WHEN vi.remainingMinor IS NOT NULL THEN MAX(vi.remainingMinor,0) WHEN vi.paidMinor IS NOT NULL THEN MAX(vi.totalMinor-vi.paidMinor,0) ELSE MAX(vi.totalMinor,0) END) FROM verto_invoice_projections vi WHERE vi.companyId=c.id AND vi.invoiceDateEpochMillis>=? AND vi.invoiceDateEpochMillis<?),0),
  COALESCE((SELECT SUM(CASE WHEN vi.voided=1 THEN 0 WHEN vi.paidMinor IS NOT NULL THEN MAX(vi.paidMinor,0) WHEN vi.remainingMinor IS NOT NULL THEN MAX(vi.totalMinor-vi.remainingMinor,0) ELSE 0 END) FROM verto_invoice_projections vi WHERE vi.companyId=c.id AND vi.invoiceDateEpochMillis>=? AND vi.invoiceDateEpochMillis<?),0),
  COALESCE((SELECT SUM(m.partsCostMinor) FROM maintenance_operations m WHERE m.companyId=c.id AND COALESCE(m.completedAtEpochMillis,m.startedAtEpochMillis)>=? AND COALESCE(m.completedAtEpochMillis,m.startedAtEpochMillis)<?),0),
  COALESCE((SELECT SUM(m.serviceCostMinor) FROM maintenance_operations m WHERE m.companyId=c.id AND COALESCE(m.completedAtEpochMillis,m.startedAtEpochMillis)>=? AND COALESCE(m.completedAtEpochMillis,m.startedAtEpochMillis)<?),0),
  COALESCE((SELECT SUM(a.amountMinor) FROM additional_costs a WHERE a.companyId=c.id AND a.occurredAtEpochMillis>=? AND a.occurredAtEpochMillis<?),0)
FROM companies c WHERE c.id=?
'''
params = (0, 1000, 0, 1000, 0, 1000, 0, 1000, 0, 1000)
linked = con.execute(summary_sql, params + ('linked',)).fetchone()
check('linked company detected', linked[0] == 1)
check('owed ignores voided invoice', linked[1] == 75000)
check('paid includes source payments', linked[2] == 75000)
check('parts costs come from maintenance', linked[3] == 30000)
check('service costs come from maintenance', linked[4] == 20000)
check('additional costs are separate', linked[5] == 5000)
check('operation total excludes owed/paid', linked[3] + linked[4] + linked[5] == 55000)

local = con.execute(summary_sql, params + ('local',)).fetchone()
check('unlinked company detected', local[0] == 0)
check('unlinked company has no Verto owed', local[1] == 0)
check('unlinked company retains local parts', local[3] == 40000)
check('unlinked company retains local service', local[4] == 10000)
check('unlinked company retains additional cost', local[5] == 2000)

before = con.execute("SELECT totalMinor, paidMinor, remainingMinor FROM verto_invoice_projections WHERE id='i1'").fetchone()
con.execute("INSERT INTO additional_costs VALUES('a3','linked',NULL,'رسوم',1000,'SDG',160,NULL,'u1',160,160,'PENDING')")
after = con.execute("SELECT totalMinor, paidMinor, remainingMinor FROM verto_invoice_projections WHERE id='i1'").fetchone()
check('additional cost cannot mutate invoice projection', before == after)

try:
    con.execute("INSERT INTO additional_costs VALUES('bad','linked',NULL,'خطأ',100,'SDG',170,NULL,'u2',170,170,'PENDING')")
    cross_company_blocked = False
except sqlite3.IntegrityError:
    cross_company_blocked = True
check('cross-company creator is blocked', cross_company_blocked)

check('additional cost indexes exist', len(con.execute("PRAGMA index_list('additional_costs')").fetchall()) >= 4)
print(f'RESULT: {checks}/{checks} passed')
