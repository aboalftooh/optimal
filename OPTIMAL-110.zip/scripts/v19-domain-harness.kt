import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.feature.auth.domain.model.JoinCodeValidationResult
import com.optimal.fleet.feature.auth.domain.model.OnboardingCompletionResult
import com.optimal.fleet.feature.auth.domain.model.OnboardingMode
import com.optimal.fleet.feature.auth.domain.model.OtpChallenge
import com.optimal.fleet.feature.auth.domain.model.OtpRequestResult
import com.optimal.fleet.feature.auth.domain.model.OtpVerificationResult
import com.optimal.fleet.feature.auth.domain.model.RestorePendingOnboardingResult
import com.optimal.fleet.feature.auth.domain.model.RestoreSessionResult
import com.optimal.fleet.feature.auth.domain.model.ValidatedJoinCode
import com.optimal.fleet.feature.auth.domain.repository.OnboardingRepository
import com.optimal.fleet.feature.auth.domain.usecase.CompleteOnboardingUseCase
import com.optimal.fleet.feature.auth.domain.usecase.DiscardPendingOnboardingUseCase
import com.optimal.fleet.feature.auth.domain.usecase.RestorePendingOnboardingUseCase
import com.optimal.fleet.feature.auth.domain.usecase.RestoreSessionUseCase
import com.optimal.fleet.feature.auth.domain.usecase.SignOutUseCase
import com.optimal.fleet.feature.auth.domain.usecase.OnboardingInputPolicy
import com.optimal.fleet.feature.auth.domain.usecase.RequestOtpUseCase
import com.optimal.fleet.feature.auth.domain.usecase.ValidateJoinCodeUseCase
import com.optimal.fleet.feature.auth.domain.usecase.VerifyOtpUseCase
import com.optimal.fleet.feature.settings.domain.members.InviteCodePolicy
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) {
            outcome = result
        }
    })
    return requireNotNull(outcome).getOrThrow()
}

fun main() {
    verify("Sudan local mobile becomes E.164", OnboardingInputPolicy.normalizePhone("0912 345 678") == "+249912345678")
    verify("Sudan nine-digit mobile becomes E.164", OnboardingInputPolicy.normalizePhone("912345678") == "+249912345678")
    verify("international phone remains E.164", OnboardingInputPolicy.normalizePhone("+249 912-345-678") == "+249912345678")
    verify("short phone rejected", !OnboardingInputPolicy.isValidPhone("123"))
    verify("invite policy matches auth phone canonicalization", InviteCodePolicy.normalizePhone("0912345678") == "+249912345678")
    verify("join code strips separators", OnboardingInputPolicy.normalizeJoinCode("12-34 56 78") == "12345678")
    verify("OTP strips separators", OnboardingInputPolicy.normalizeOtp("12 34-56") == "123456")

    val repository = RecordingOnboardingRepository()
    verify(
        "malformed join code never reaches repository",
        runSuspend { ValidateJoinCodeUseCase(repository)("123", OnboardingMode.JoinCompany) } == JoinCodeValidationResult.Invalid &&
            repository.validatedCode == null,
    )
    verify(
        "valid join code is normalized",
        runSuspend { ValidateJoinCodeUseCase(repository)("12 34 56 78", OnboardingMode.JoinCompany) } is JoinCodeValidationResult.Valid &&
            repository.validatedCode == "12345678" &&
            repository.validatedMode == OnboardingMode.JoinCompany,
    )
    verify(
        "OTP request canonicalizes Sudan phone",
        runSuspend { RequestOtpUseCase(repository)(OnboardingMode.JoinCompany, "12345678", "0912345678") } is OtpRequestResult.Success &&
            repository.requestedPhone == "+249912345678" &&
            repository.requestedMode == OnboardingMode.JoinCompany,
    )
    verify(
        "missing challenge is rejected locally",
        runSuspend { VerifyOtpUseCase(repository)(null, "123456") } == OtpVerificationResult.MissingChallenge,
    )
    verify(
        "valid OTP delegates normalized value",
        runSuspend { VerifyOtpUseCase(repository)("challenge-1", "12 34-56") } == OtpVerificationResult.Verified &&
            repository.verifiedCode == "123456",
    )
    verify(
        "onboarding trims name and canonicalizes phone",
        runSuspend {
            CompleteOnboardingUseCase(repository)(OnboardingMode.JoinCompany, "12345678", "  أحمد  ", "0912345678")
        } is OnboardingCompletionResult.Success &&
            repository.completedName == "أحمد" &&
            repository.completedPhone == "+249912345678" &&
            repository.completedMode == OnboardingMode.JoinCompany,
    )

    verify(
        "session restoration delegates to the repository",
        runSuspend { RestoreSessionUseCase(repository)() } == RestoreSessionResult.Success(null) &&
            repository.restoreSessionCalls == 1,
    )
    verify(
        "pending onboarding restoration delegates to the repository",
        runSuspend { RestorePendingOnboardingUseCase(repository)() } == RestorePendingOnboardingResult.None &&
            repository.restorePendingCalls == 1,
    )
    runSuspend { DiscardPendingOnboardingUseCase(repository)() }
    verify("discard pending onboarding delegates once", repository.discardCalls == 1)
    runSuspend { SignOutUseCase(repository)() }
    verify("sign out delegates once", repository.signOutCalls == 1)

    println("RESULT: $checks/$checks passed")
}

private class RecordingOnboardingRepository : OnboardingRepository {
    var validatedCode: String? = null
    var validatedMode: OnboardingMode? = null
    var requestedPhone: String? = null
    var requestedMode: OnboardingMode? = null
    var verifiedCode: String? = null
    var completedName: String? = null
    var completedMode: OnboardingMode? = null
    var completedPhone: String? = null
    var restoreSessionCalls: Int = 0
    var restorePendingCalls: Int = 0
    var discardCalls: Int = 0
    var signOutCalls: Int = 0

    override suspend fun validateJoinCode(code: String, mode: OnboardingMode): JoinCodeValidationResult {
        validatedCode = code
        validatedMode = mode
        return JoinCodeValidationResult.Valid(ValidatedJoinCode("company-1", "شركة النيل"))
    }

    override suspend fun requestOtp(
        mode: OnboardingMode,
        joinCode: String,
        normalizedPhone: String,
    ): OtpRequestResult {
        requestedMode = mode
        requestedPhone = normalizedPhone
        return OtpRequestResult.Success(OtpChallenge("challenge-1", normalizedPhone, Long.MAX_VALUE))
    }

    override suspend fun verifyOtp(challengeId: String, code: String): OtpVerificationResult {
        verifiedCode = code
        return OtpVerificationResult.Verified
    }

    override suspend fun completeOnboarding(
        mode: OnboardingMode,
        joinCode: String,
        userDisplayName: String,
        normalizedPhone: String,
    ): OnboardingCompletionResult {
        completedMode = mode
        completedName = userDisplayName
        completedPhone = normalizedPhone
        return OnboardingCompletionResult.Success(
            ActiveSession("user-1", "company-1", userDisplayName, "شركة النيل"),
            restoredExistingUser = false,
        )
    }

    override suspend fun restoreSession(): RestoreSessionResult {
        restoreSessionCalls += 1
        return RestoreSessionResult.Success(null)
    }
    override suspend fun restorePendingOnboarding(): RestorePendingOnboardingResult {
        restorePendingCalls += 1
        return RestorePendingOnboardingResult.None
    }
    override suspend fun discardPendingOnboarding() {
        discardCalls += 1
    }
    override suspend fun signOut() {
        signOutCalls += 1
    }
}
