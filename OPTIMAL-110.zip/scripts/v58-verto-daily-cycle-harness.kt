import com.optimal.fleet.feature.verto.domain.model.VertoArchivePolicy
import com.optimal.fleet.feature.verto.domain.model.VertoMessageCursor
import com.optimal.fleet.feature.notifications.domain.NotificationEventPolicy

private var passed = 0
private fun check(label: String, condition: Boolean) {
    require(condition) { label }
    passed += 1
    println("PASS: $label")
}

fun main() {
    val archivedAt = VertoMessageCursor(1_000L, "00000000-0000-0000-0000-000000000010")
    check("empty conversation can remain archived", VertoArchivePolicy.remainsArchived(true, null, null))
    check(
        "first message reopens empty archived conversation",
        !VertoArchivePolicy.remainsArchived(
            true,
            null,
            VertoMessageCursor(1_100L, "00000000-0000-0000-0000-000000000011"),
        ),
    )
    check("same cursor remains archived", VertoArchivePolicy.remainsArchived(true, archivedAt, archivedAt))
    check(
        "older cursor remains archived",
        VertoArchivePolicy.remainsArchived(
            true,
            archivedAt,
            VertoMessageCursor(900L, "00000000-0000-0000-0000-000000000009"),
        ),
    )
    check(
        "newer timestamp reopens conversation",
        !VertoArchivePolicy.remainsArchived(
            true,
            archivedAt,
            VertoMessageCursor(1_001L, "00000000-0000-0000-0000-000000000011"),
        ),
    )
    check(
        "equal timestamp with later id reopens conversation",
        !VertoArchivePolicy.remainsArchived(
            true,
            archivedAt,
            VertoMessageCursor(1_000L, "00000000-0000-0000-0000-000000000011"),
        ),
    )
    check("explicit unarchive wins", !VertoArchivePolicy.remainsArchived(false, archivedAt, archivedAt))
    val firstKey = NotificationEventPolicy.vertoMessageKey("user-1", "message-1")
    check("same user and message retain one dedup key", firstKey == NotificationEventPolicy.vertoMessageKey("user-1", "message-1"))
    check("different users retain independent notification keys", firstKey != NotificationEventPolicy.vertoMessageKey("user-2", "message-1"))
    println("v58 daily-cycle policy harness: $passed/$passed PASS")
}
