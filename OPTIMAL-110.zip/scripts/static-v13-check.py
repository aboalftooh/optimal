#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
passed = 0
failed = 0

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f"PASS: {name}")
    else:
        failed += 1
        print(f"FAIL: {name}")

required = [
    "core/session/src/main/kotlin/com/optimal/fleet/core/session/MemberSessionInvalidator.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/MemberInviteEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/MemberDao.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/InviteCodePolicy.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberSafetyPolicies.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberRepository.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberUseCases.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/RoomMemberRepository.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SecureInviteCodeGenerator.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/Sha256InviteCodeHasher.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersRoute.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyViewModel.kt",
    "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRoute.kt",
]
for path in required:
    check(f"exists {path}", (ROOT / path).is_file())

database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
migration = read("core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt")
entity = read(required[1])
dao = read(required[2])
repo = read(required[8])
models = read(required[3])
policy = read(required[5])
member_vm = read(required[11])
member_ui = read(required[12])
join_vm = read(required[13])
join_ui = read(required[14])
settings_nav = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation/SettingsNavigation.kt")
auth_route = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthRoute.kt")
session_store = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/RoomSessionStore.kt")
audit_models = read("core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt")

check("Room version 11 or later", any(token in database for token in ["version = 11", "version = 12"]))
check("member invite entity registered", "MemberInviteEntity::class" in database)
check("member dao exposed", "abstract fun memberDao(): MemberDao" in database)
check("migration 10 to 11 exists", "MIGRATION_10_11" in migration)
check("migration included", "MIGRATION_10_11," in migration.split("val ALL", 1)[-1])
check("migration adds normalized phone", "ADD COLUMN `normalizedPhone`" in migration)
check("migration adds last activity", "ADD COLUMN `lastActiveAtEpochMillis`" in migration)
check("migration creates invites", "CREATE TABLE IF NOT EXISTS `member_invites`" in migration)
check("invite code hash unique", 'Index(value = ["codeHash"], unique = true)' in entity)
check("invite company scoped", 'val companyId: String' in entity)
check("invite one-time fields", all(x in entity for x in ["state", "usedAtEpochMillis", "usedByUserId"]))
check("member list company scoped", "WHERE companyId = :companyId" in dao)
check("active count guard query", "activeMemberCount" in dao)
check("atomic invite consumption query", "markInviteUsed" in dao and "state = 'PENDING'" in dao)
check("expired invite update", "markInviteExpired" in dao)

check("full access has no role model", "Role" not in models and "Permission" not in models)
check("full access UI statement", "وصولًا كاملًا" in member_ui)
check("self disable policy", "SELF_BLOCKED" in policy)
check("last member policy", "LAST_ACTIVE_MEMBER_BLOCKED" in policy)
check("repository uses policy", "MemberDisablePolicy.decide" in repo)
check("repository blocks one-time reuse", "InviteConsumptionPolicy.decide" in repo)
check("repository hashes code", "codeHasher.hash" in repo)
check("repository never audits plain code", "plainCode" not in re.sub(r"private suspend fun insertFreshInvite[\s\S]*", "", repo))
check("72 hour expiry", "72L * 60L * 60L" in read(required[4]))
check("session invalidation contract", "MemberSessionInvalidator" in session_store)
check("session invalidation clears member", "clearForMember" in session_store)
check("disable calls invalidator", "invalidateMemberSession" in repo)

for action in ["MEMBER_INVITED", "MEMBER_INVITE_RESENT", "MEMBER_JOINED", "MEMBER_DISABLED", "MEMBER_ENABLED"]:
    check(f"audit action {action}", action in audit_models and action in repo)

check("member list UI", "members-list" in member_ui)
check("pending invitation UI", "دعوات معلقة" in member_ui)
check("invite form", "invite-name" in member_ui and "invite-phone" in member_ui)
check("generated code shown once", "generated-invite-code" in member_ui)
check("member status actions", "تعطيل" in member_ui and "تفعيل" in member_ui)
check("self disable button disabled", "member.isCurrentUser" in member_ui)
check("join code UI", "join-code" in join_ui and "join-submit" in join_ui)
check("join outcomes clear", all(x in join_vm for x in ["انتهت صلاحية", "سابقًا", "تم إلغاء"]))
check("settings members route", "MEMBERS_ROUTE" in settings_nav)
check("join route", "MEMBER_JOIN_ROUTE" in settings_nav)
check("auth offers join", "open-join-company" in auth_route)

production_roots = [
    ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members",
    ROOT / "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members",
]
violations = []
for root in production_roots:
    for file in root.rglob("*.kt"):
        text = file.read_text(encoding="utf-8")
        if re.search(r"\b(Role|Permission|Permissions)\b|صلاحيات|أدوار", text, re.I):
            violations.append(str(file.relative_to(ROOT)))
check("no role or permission concepts", not violations)

for test in ["InviteCodeTest.kt", "InviteOneTimeUseTest.kt", "DisableMemberTest.kt", "LastMemberGuardTest.kt", "MemberViewModelTest.kt", "NoPermissionsArchitectureTest.kt"]:
    check(f"test exists {test}", any(p.name == test for p in ROOT.rglob("*.kt")))

build = read("app/build.gradle.kts")
check("version v13 or later", bool(re.search(r'versionName = \"0\.(1[3-9]|[2-9][0-9])\.0-v[0-9]+\"', build)))
check("version code 9 or later", bool(re.search(r"versionCode = ([9]|[1-9][0-9]+)", build)))

print(f"RESULT: {passed}/{passed + failed} passed")
raise SystemExit(1 if failed else 0)
