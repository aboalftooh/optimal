#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mapfile -t FILES < <(find "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto" -type f -name '*.kt' | sort)
OUT="$(mktemp)"
trap 'rm -f "$OUT" /tmp/v56-verto-parser.jar' EXIT
set +e
timeout 90s kotlinc "${FILES[@]}" -d /tmp/v56-verto-parser.jar >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  exit 1
fi
[[ $STATUS -ne 124 ]] || { echo "FAIL: Kotlin parser timed out" >&2; exit 1; }
echo "PASS: Kotlin parser accepted ${#FILES[@]} v56 Verto production files; unresolved Android symbols were intentionally ignored without Gradle classpath."
