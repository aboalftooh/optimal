#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v51 Verto home entry and local link state."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "repo": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "module": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/di/VertoConversationModule.kt",
    "usecases": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt",
    "state": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoEntryContract.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoEntryViewModel.kt",
    "card": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoHomeEntry.kt",
    "entry": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "navigation": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/navigation/VertoNavigation.kt",
    "nav_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/navigation/VertoNavigationContract.kt",
    "home": ROOT / "feature/home/src/main/java/com/optimal/fleet/feature/home/presentation/HomeRoute.kt",
    "home_navigation": ROOT / "feature/home/src/main/java/com/optimal/fleet/feature/home/navigation/HomeNavigation.kt",
    "app_navigation": ROOT / "app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt",
    "destinations": ROOT / "app/src/main/java/com/optimal/fleet/navigation/AppDestination.kt",
    "module_build": ROOT / "feature/verto/build.gradle.kts",
    "domain_test": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoAuthorizationUseCaseTest.kt",
    "state_test": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoEntryContractTest.kt",
    "nav_test": ROOT / "app/src/test/java/com/optimal/fleet/NavigationContractTest.kt",
}
checks = []

def check(name: str, condition: bool) -> None:
    checks.append((name, condition))
    if not condition:
        raise AssertionError(name)

def text(key: str) -> str:
    return FILES[key].read_text(encoding="utf-8")

for name, path in FILES.items():
    check(f"exists:{name}", path.is_file())

repo = text("repo")
check("repository uses Room conversation DAO", "VertoConversationDao" in repo)
check("repository uses Room user state DAO", "VertoConversationUserStateDao" in repo)
check("repository observes company link", "observeByCompany(grant.companyId)" in repo)
check("repository observes user unread", "userStateDao.observe(" in repo and "unreadCount" in repo)
check("repository maps linked state", "linked = true" in repo and "counterpartyDisplayName" in repo)
check("repository maps unlinked state", "VertoLinkState.unlinked" in repo)
link_read_section = repo.split("override fun observeLinkState", 1)[1].split("override fun observeMessages", 1)[0]
check("link state remains Room only", all(x not in link_read_section for x in ["remoteDataSource", "Retrofit", "HttpClient"]))
check("refresh cannot gate Room link stream", "conversationDao.observeByCompany(grant.companyId)" in link_read_section)

module = text("module")
check("repository bound by Hilt", "@Binds" in module and "VertoConversationRepository" in module)

usecases = text("usecases")
check("badge use case exists", "class ObserveVertoUnreadBadge" in usecases)
check("badge derives from link stream", "result.stream.map" in usecases)
check("badge hidden when unlinked", "state.linked && state.canView" in usecases)
check("link authorization retained", "VertoChatOperation.OBSERVE_LINK_STATE" in usecases)

state = text("state")
check("entry state immutable", "@Immutable" in state)
check("entry includes link state", "val linkState: VertoLinkState" in state)
check("entry includes unread", "val unreadCount: Long" in state)
check("entry includes denial", "val accessDenied: Boolean" in state)
check("home visibility fails closed", "!loading && !accessDenied && errorMessage == null" in state)

viewmodel = text("viewmodel")
check("viewmodel uses link use case", "ObserveVertoLinkState" in viewmodel)
check("viewmodel uses badge use case", "ObserveVertoUnreadBadge" in viewmodel)
check("viewmodel combines local streams", "combine(linkResult.stream, badgeResult.stream)" in viewmodel)
check("viewmodel fails closed", "accessDenied = true" in viewmodel)
check("viewmodel has no infrastructure import", ".data." not in viewmodel and "core.database" not in viewmodel and "core.network" not in viewmodel)

card = text("card")
check("home card label", "التواصل مع Verto" in card)
check("home card unlinked state", "غير مرتبط" in card)
check("home card unread badge", "verto-unread-badge" in card and "unreadCount > 0" in card)
check("home card hidden without access", "if (!state.isVisibleOnHome) return" in card)
check("home card test tag", 'testTag("home-verto-entry")' in card)
check("home card no network", "Retrofit" not in card and "Supabase" not in card and "HttpClient" not in card)

entry = text("entry")
check("entry route delegates local chat", "VertoChatScreen" in entry)
check("entry route collects chat state", "collectAsStateWithLifecycle" in entry)
check("entry route supports retry", "VertoChatUiEvent.Retry" in entry)
check("entry route supports local paging", "VertoChatUiEvent.LoadOlder" in entry)
check("entry destination delegated", "VertoChatScreen" in entry)

navigation = text("navigation")
contract = text("nav_contract")
check("conversation route declared", 'CONVERSATION = "verto/conversation"' in contract)
check("conversation route registered", "composable(route = VertoDestination.CONVERSATION)" in navigation)

home = text("home")
home_nav = text("home_navigation")
app_nav = text("app_navigation")
destinations = text("destinations")
check("home exposes composition slot", "vertoEntryContent: (@Composable () -> Unit)?" in home)
check("home renders keyed entry", 'item(key = "verto-entry")' in home)
check("home navigation forwards slot", "vertoEntryContent = vertoEntryContent" in home_nav)
check("app injects Verto card", "VertoHomeEntryConnected" in app_nav)
check("app navigates conversation", "navigate(VertoDestination.CONVERSATION)" in app_nav)
check("app registers Verto graph", "vertoGraph()" in app_nav)
check("Verto title mapped", '"التواصل مع Verto"' in destinations and "VertoDestination.CONVERSATION" in destinations)
check("bottom navigation remains five", text("nav_test").count("assertEquals(5, topLevelDestinations.size)") == 1)
check("Verto outside bottom navigation", "assertFalse(VertoDestination.CONVERSATION in topLevelRoutes)" in text("nav_test"))

build = text("module_build")
check("Hilt Compose dependency", "androidx.hilt.navigation.compose" in build)
check("material icons dependency", "androidx.compose.material.icons.extended" in build)

presentation_root = ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation"
presentation_text = "\n".join(p.read_text(encoding="utf-8") for p in presentation_root.glob("*.kt"))
for forbidden in ["core.database", "core.network", "retrofit2", "io.github.jan.supabase", ".data."]:
    check(f"presentation forbids:{forbidden}", forbidden not in presentation_text)

unit = text("domain_test")
for token in [
    "unreadBadgeUsesRoomBackedLinkedState",
    "unreadBadgeIsZeroWhenCompanyIsUnlinked",
    "unreadBadgeFailsClosedWithoutViewPermission",
]:
    check(f"unit:{token}", token in unit)
state_test = text("state_test")
for token in [
    "homeEntryIsHiddenWhenPermissionIsDenied",
    "unlinkedStateRemainsVisibleForAuthorizedMember",
    "linkedStateCarriesUnreadBadgeWithoutNetworkState",
]:
    check(f"state test:{token}", token in state_test)

check("no Room migration in v51", not any(ROOT.glob("supabase/migrations/*v51*")))
database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains available", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version unchanged", 'versionCode = 32' in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("domain harness runner exists", (ROOT / "scripts/run-v51-verto-entry-harness.sh").is_file())
check("domain harness source exists", (ROOT / "scripts/v51-verto-entry-harness.kt").is_file())
check("wrapper runs domain harness", "run-v51-verto-entry-harness.sh" in (ROOT / "scripts/verify-v51-static.sh").read_text(encoding="utf-8"))

print(f"v51 Verto home entry contract: {len(checks)}/{len(checks)} PASS")
