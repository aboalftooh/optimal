#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
passed = 0
failed = 0

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')

def check(name: str, condition: bool):
    global passed, failed
    if condition:
        passed += 1
        print(f'PASS: {name}')
    else:
        failed += 1
        print(f'FAIL: {name}')

required = [
    'core/database/src/main/java/com/optimal/fleet/core/database/entity/AdditionalCostEntity.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/dao/FinanceDao.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/FinancialSummaryRow.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/money/Money.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/money/MoneyParser.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/summary/FinancialSummary.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/summary/FinancialSummaryQuery.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/additionalcost/AdditionalCost.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/additionalcost/AddAdditionalCost.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomFinancialSummaryQuery.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomAdditionalCostRepository.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardViewModel.kt',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/dashboard/FinanceDashboardRoute.kt',
]
for item in required:
    check(f'exists {item}', (ROOT / item).is_file())

money = read(required[3]) + read(required[4])
check('money uses Long minor units', 'minorUnits: Long' in money)
check('money parser uses BigDecimal', 'BigDecimal' in money)
check('money does not use Double', 'Double' not in money)
check('money does not use Float', 'Float' not in money)
check('money supports SDG default', 'DEFAULT_CURRENCY_CODE = "SDG"' in money)

summary = read(required[5]) + read(required[6])
check('summary exposes owed', 'val owed: Money' in summary)
check('summary exposes paid', 'val paid: Money' in summary)
check('summary exposes parts cost', 'val partsCost: Money' in summary)
check('summary exposes service cost', 'val serviceCost: Money' in summary)
check('summary exposes additional costs', 'val additionalCosts: Money' in summary)
check('additional cost only enters operation total', 'partsCost + serviceCost + additionalCosts' in summary)

additional = read(required[7]) + read(required[8])
check('additional cost has company ownership', 'val companyId: String' in additional)
check('additional cost has description', 'val description: String' in additional)
check('additional cost has amount', 'val amount: Money' in additional)
check('additional cost has date', 'val occurredAtEpochMillis: Long' in additional)
check('additional cost has optional attachment', 'val attachmentUri: String?' in additional)
check('additional cost validates positive amount', 'amountMinor <= 0' in additional)
check('additional cost does not reference invoice projection', 'InvoiceProjection' not in additional)

finance_dao = read(required[1])
check('summary query is read-only SELECT', 'fun observeFinancialSummary' in finance_dao and 'UPDATE verto_invoice_projections' not in finance_dao)
check('owed is sourced from invoice projections', 'verto_invoice_projections' in finance_dao and 'owedMinor' in finance_dao)
check('maintenance costs are sourced locally', 'maintenance_operations' in finance_dao)
check('additional costs are separate table', 'additional_costs' in finance_dao)
check('all finance queries filter by company', finance_dao.count('companyId =') >= 4)

entity = read(required[0])
check('additional cost foreign key to company', 'entity = CompanyEntity::class' in entity)
check('additional cost foreign key to local user', 'entity = LocalUserEntity::class' in entity)
check('additional cost composite user/company key', 'childColumns = ["createdByUserId", "companyId"]' in entity)
check('additional amount stored as Long', 'val amountMinor: Long' in entity)

migration = read('core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt')
database = read('core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt')
check('Room version 9 or later', bool(re.search(r'version = (?:9|[1-9][0-9]+)', database)))
check('migration 8 to 9 exists', 'MIGRATION_8_9' in migration)
check('migration adds SDG currency', "DEFAULT 'SDG'" in migration)
check('migration creates additional costs', 'CREATE TABLE IF NOT EXISTS `additional_costs`' in migration)
check('migration included in ALL', 'val ALL' in migration and 'MIGRATION_8_9,' in migration)
check('database includes additional cost entity', 'AdditionalCostEntity::class' in database)
check('database exposes finance dao', 'abstract fun financeDao(): FinanceDao' in database)

presentation = read(required[11]) + read(required[12])
check('presentation uses UDF state', 'FinanceDashboardUiState' in presentation and 'FinanceDashboardUiEvent' in presentation)
check('presentation uses use cases', 'ObserveFinancialSummary' in presentation and 'AddAdditionalCost' in presentation)
check('presentation does not import Room', 'androidx.room' not in presentation)
check('unlinked company state is explicit', 'unlinked-company-finance' in presentation)
check('invoice source remains read-only', 'تحديث فواتير Verto' in presentation and 'SaveInvoice' not in presentation)
check('dashboard shows four required figures', all(x in presentation for x in ['عليكم', 'دفعتم', 'تكلفة القطع', 'تكلفة الصيانة']))
check('dashboard shows operation total', 'إجمالي العملية' in presentation)

nav = read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt')
check('finance root uses dashboard', 'FinanceDashboardConnected' in nav)

build = read('app/build.gradle.kts')
check('version v11 or later', bool(re.search(r'versionName = \"0\.(?:1[1-9]|[2-9]\d)\.', build)))
check('version code 7 or later', bool(re.search(r'versionCode\s*=\s*(?:[7-9]|[1-9][0-9]+)', build)))

for test in [
    'FinancialSummaryTest.kt', 'AdditionalCostTest.kt', 'MoneyPrecisionTest.kt',
    'UnlinkedCompanyFinanceTest.kt', 'FinanceViewModelTest.kt', 'FinanceArchitectureTest.kt'
]:
    check(f'test exists {test}', any(p.name == test for p in (ROOT / 'feature/finance/src/test').rglob('*.kt')))

print(f'RESULT: {passed}/{passed + failed} passed')
raise SystemExit(1 if failed else 0)
