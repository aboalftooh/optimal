#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# v10's manual-link write path was deliberately retired in v62. Re-running the
# old harness would demand a prohibited production regression, so the current
# v62 retirement contract and policy harness replace that one historical gate.
COMMANDS=(
  "./scripts/run-v07-domain-harness.sh"
  "python3 scripts/v62-manual-invoice-link-retirement-contract.py"
  "python3 scripts/v62-manual-invoice-link-retirement-harness.py"
  "./scripts/run-v11-finance-harness.sh"
  "./scripts/run-v12-audit-harness.sh"
  "./scripts/run-v13-member-harness.sh"
  "./scripts/run-v14-notification-harness.sh"
  "./scripts/run-v15-domain-harness.sh"
  "./scripts/run-v18-onboarding-harness.sh"
  "./scripts/run-v19-domain-harness.sh"
)

passed=0
for command in "${COMMANDS[@]}"; do
  echo "===== $command ====="
  # Commands are project-owned constants, never user input.
  timeout --kill-after=10s 360s bash -lc "$command"
  passed=$((passed + 1))
  rm -rf .tmp-v*-harness
  echo "V66_LEGACY PASS $command"
done

if [[ "$passed" -ne "${#COMMANDS[@]}" ]]; then
  echo "FAIL: legacy compatibility suite completed $passed/${#COMMANDS[@]} commands" >&2
  exit 1
fi

echo "V66 legacy compatibility regressions: $passed/${#COMMANDS[@]} PASS"
