#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

REPORT_DIR="${V67_REPORT_DIR:-docs/evidence/v67/reports}"
mkdir -p "$REPORT_DIR"

python3 scripts/v67-release-acceptance-contract.py
V66_REPORT_DIR="$REPORT_DIR/v66" ./scripts/verify-v66-static.sh
python3 scripts/security-release-check.py
python3 -m py_compile \
  scripts/v67-release-acceptance-contract.py \
  scripts/v67-live-e2e-preflight.py \
  scripts/v67-package-audit.py
bash -n scripts/verify-v67-static.sh
