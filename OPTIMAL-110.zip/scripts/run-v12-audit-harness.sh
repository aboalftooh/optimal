#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$(mktemp -d)"
trap 'rm -rf "$OUT_DIR"' EXIT
kotlinc \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditRedactionPolicy.kt" \
  "$ROOT_DIR/scripts/v12-audit-harness.kt" \
  -include-runtime \
  -d "$OUT_DIR/v12-audit-harness.jar"
java -jar "$OUT_DIR/v12-audit-harness.jar"
