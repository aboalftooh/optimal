#!/usr/bin/env python3
"""OPTIMAL v46 backend contract v23 static and live deployment harness.

Static mode is always run. Live mode is deliberately fail-closed and requires:
- two Supabase-compatible disposable targets: clean and upgrade,
- explicit destructive-test consent,
- a fixture SQL file with two linked companies and private media fixtures,
- independently captured registration and Storage/Edge evidence.

The script never prints database URLs or secrets.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = ROOT / "supabase/migrations"
TESTS = ROOT / "supabase/tests"
POST_DEPLOY = ROOT / "supabase/post_deploy"

V23_MIGRATIONS = [
    "20260731004000_optimal_verto_registration_compatibility.sql",
    "20260731004100_optimal_verto_conversation_message_schema.sql",
    "20260731004200_optimal_verto_message_rpcs.sql",
    "20260731004300_optimal_verto_private_attachments.sql",
    "20260731004400_optimal_verto_invoice_feed_v23.sql",
    "20260731004500_optimal_verto_maintenance_feed_v23.sql",
    "20260731004600_optimal_verto_backend_contract_gate.sql",
]
ALL_MIGRATIONS = sorted(path.name for path in MIGRATIONS.glob("*.sql"))

PREFLIGHTS = [
    "v40_verto_registration_preflight.sql",
    "v41_verto_conversation_schema_preflight.sql",
    "v42_verto_message_rpc_preflight.sql",
    "v43_verto_attachment_preflight.sql",
    "v44_verto_invoice_preflight.sql",
    "v45_verto_maintenance_preflight.sql",
]
SCENARIOS = [
    "v41_verto_conversation_scenarios.sql",
    "v42_verto_message_rpc_scenarios.sql",
    "v43_verto_attachment_scenarios.sql",
    "v44_verto_invoice_scenarios.sql",
    "v45_verto_maintenance_scenarios.sql",
]
PRIOR_PROMOTIONS = [
    "v40_promote_verto_registration_ready.sql",
    "v44_promote_verto_finance_v23_ready.sql",
    "v45_promote_verto_maintenance_ready.sql",
]

REQUIRED_REGISTRATION_EVIDENCE = {
    "valid_code",
    "expired_code_rejected",
    "used_code_rejected",
    "revoked_code_rejected",
    "same_user_retry_idempotent",
    "second_user_rejected",
    "existing_link_rejected",
    "existing_membership_rejected",
}
REQUIRED_STORAGE_EVIDENCE = {
    "private_upload",
    "finalize",
    "signed_url_read",
    "signed_url_expired",
    "cross_tenant_denied",
    "orphan_cleanup",
    "service_role_absent_from_android",
}


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        raise AssertionError(f"missing file: {relative}")
    return path.read_text(encoding="utf-8")


def normalized(text: str) -> str:
    return " ".join(text.lower().split())


def contains_all(text: str, tokens: Iterable[str]) -> bool:
    lowered = text.lower()
    return all(token.lower() in lowered for token in tokens)


def static_checks() -> tuple[int, int]:
    checks: list[tuple[str, bool]] = []

    def check(name: str, value: bool) -> None:
        checks.append((name, bool(value)))

    def wrapper_chain_contains(script_text: str, target_name: str) -> bool:
        pending = re.findall(r"verify-v\d+-static\.sh", script_text)
        visited: set[str] = set()
        while pending:
            name = pending.pop()
            if name == target_name:
                return True
            if name in visited:
                continue
            visited.add(name)
            path = ROOT / "scripts" / name
            if path.is_file():
                pending.extend(re.findall(r"verify-v\d+-static\.sh", path.read_text(encoding="utf-8")))
        return False

    migration = read("supabase/migrations/20260731004600_optimal_verto_backend_contract_gate.sql")
    promotion = read("supabase/post_deploy/v46_promote_verto_backend_v23.sql")
    preflight = read("supabase/tests/v46_backend_contract_preflight.sql")
    scenarios = read("supabase/tests/v46_backend_contract_scenarios.sql")
    post = read("supabase/tests/v46_backend_contract_post_promotion.sql")
    deployment = read("docs/integrations/verto-deployment-order-v23.md")
    session = read("docs/sessions/v46.md")
    contract = read("docs/integrations/verto-backend-contract-v23.md")
    root_gradle = read("build.gradle.kts")
    ci_fast = read("scripts/ci-fast.sh")
    ci_full = read("scripts/ci-full.sh")
    verify_project = read("scripts/verify-project.sh")
    wrapper = read("scripts/verify-v46-static.sh")
    current_wrapper = read("scripts/verify-v47-static.sh")

    check("migration:lexical-order", ALL_MIGRATIONS == sorted(ALL_MIGRATIONS))
    check("migration:v46-closes-v23-backend-bundle", V23_MIGRATIONS[-1] == "20260731004600_optimal_verto_backend_contract_gate.sql")
    v23_start = ALL_MIGRATIONS.index(V23_MIGRATIONS[0])
    check(
        "migration:v23-chain-contiguous",
        ALL_MIGRATIONS[v23_start : v23_start + len(V23_MIGRATIONS)] == V23_MIGRATIONS,
    )
    check("migration:no-promotion", "set contract_version = 23" not in migration.lower())
    check("migration:no-minimum-raise", "set minimum_android_version_code" not in migration.lower())
    check("migration:validator", "optimal_verto_v23_contract_ready" in migration)
    check("migration:validator-service-only", contains_all(migration, [
        "revoke all on function public.optimal_verto_v23_contract_ready()",
        "from public, anon, authenticated",
        "to service_role",
    ]))
    check("migration:backend-contract-recreated", contains_all(migration, [
        "drop function if exists public.optimal_backend_contract()",
        "create function public.optimal_backend_contract()",
        "security definer",
        "grant execute on function public.optimal_backend_contract() to authenticated",
    ]))

    for field in (
        "contract_version integer",
        "minimum_android_version_code integer",
        "authenticated_user_id uuid",
        "company_id uuid",
        "member_active boolean",
        "verto_registration_ready boolean",
        "verto_chat_ready boolean",
        "verto_attachments_ready boolean",
        "verto_finance_v23_ready boolean",
        "verto_maintenance_ready boolean",
        "verto_limits jsonb",
    ):
        check(f"migration:contract-field:{field}", field in migration)

    for token in (
        "IMAGE", "VIDEO", "AUDIO", "DOCUMENT",
        "access_ttl_seconds", "abandon_after_seconds", "max_bytes",
        "max_duration_ms", "mime_types", "optimal-verto-private",
    ):
        check(f"migration:limits:{token}", token in migration)

    check("promotion:transaction", contains_all(promotion, ["begin;", "pg_advisory_xact_lock", "commit;"]))
    check("promotion:version-23", "set verto_chat_ready = true" in promotion and "contract_version = 23" in promotion)
    check("promotion:attachments-ready", "verto_attachments_ready = true" in promotion)
    check("promotion:minimum-preserved", contains_all(promotion, [
        "v_minimum_before", "v_minimum_after", "v46_minimum_android_version_changed",
    ]))
    check("promotion:idempotent", contains_all(promotion, ["v_contract_version = 23", "v_already_ready", "return;"]))
    check("promotion:prior-readiness", contains_all(promotion, [
        "verto_registration_ready", "verto_finance_v23_ready", "verto_maintenance_ready",
        "v46_prior_capability_promotions_missing",
    ]))
    check("promotion:private-bucket", contains_all(promotion, ["storage.buckets", "optimal-verto-private", "b.public = false"]))
    check("promotion:no-direct-grants", "v46_direct_sensitive_table_grant_detected" in promotion)
    check("promotion:v22-compat", "optimal_verto_invoice_feed(uuid,bigint,text)" in promotion)
    check("promotion:v23-feeds", contains_all(promotion, [
        "optimal_verto_invoice_feed_v23", "optimal_verto_maintenance_feed_v23",
    ]))

    for token in (
        "v46_contract_must_remain_22_before_final_promotion",
        "v46_prior_capability_promotions_missing",
        "v46_unified_capabilities_promoted_too_early",
        "v46_required_rpc_surface_incomplete",
        "v46_direct_sensitive_table_grant_detected",
        "v46_private_bucket_missing",
    ):
        check(f"preflight:{token}", token in preflight)

    for token in (
        "v46_fixture_requires_first_linked_member",
        "v46_fixture_requires_second_linked_company_member",
        "v46_combined_contract_invariants_failed",
        "v46_first_company_contract_projection_invalid",
        "v46_second_company_contract_projection_invalid",
        "v46_half_message_cursor_was_accepted",
        "v46_half_invoice_cursor_was_accepted",
        "v46_half_maintenance_cursor_was_accepted",
        "rollback;",
    ):
        check(f"scenario:{token}", token in scenarios)

    check("post:contract-23", contains_all(post, ["contract_version <> 23", "optimal_verto_v23_contract_ready"]))
    check("post:all-capabilities", all(token in post for token in (
        "verto_registration_ready", "verto_chat_ready", "verto_attachments_ready",
        "verto_finance_v23_ready", "verto_maintenance_ready",
    )))

    check("docs:deployment-clean", "قاعدة نظيفة" in deployment and "clean" in deployment.lower())
    check("docs:deployment-upgrade", "v22" in deployment and "upgrade" in deployment.lower())
    check("docs:deployment-order", all(name in deployment for name in V23_MIGRATIONS))
    check("docs:rollback", "Rollback" in deployment or "التراجع" in deployment)
    check("docs:minimum-separate", "minimum_android_version_code" in deployment and "مستقل" in deployment)
    check("docs:session", contains_all(session, ["v46", "Backend Contract Harness", "v40–v45"]))
    check("docs:contract-status", "حالة التنفيذ بعد v46" in contract)

    check("gradle:gate", contains_all(root_gradle, [
        "vertoBackendV23ContractCheck", "scripts/verto-backend-contract-v23-harness.py",
    ]))
    check("ci-fast:gate", "scripts/verto-backend-contract-v23-harness.py" in ci_fast)
    check(
        "ci-full:wrapper",
        wrapper_chain_contains(ci_full, "verify-v46-static.sh") or
        (any(name in ci_full for name in ("verify-v55-static.sh", "verify-v56-static.sh", "verify-v63-static.sh")) and "staticQualityCheck" in ci_full),
    )
    check(
        "verify-project:wrapper",
        wrapper_chain_contains(verify_project, "verify-v46-static.sh") or
        (any(name in verify_project for name in ("verify-v55-static.sh", "verify-v56-static.sh", "verify-v63-static.sh")) and "ci-full.sh" in verify_project),
    )
    check("wrapper:v47-includes-v46", "verify-v46-static.sh" in current_wrapper)
    check("wrapper:v46-first", wrapper.find("verto-backend-contract-v23-harness.py") < wrapper.find("v45-maintenance-feed-contract.py"))
    check("wrapper:v45-regression", "v45-maintenance-feed-contract.py" in wrapper)

    sensitive = (
        "optimal_verto_registration_codes",
        "optimal_verto_conversations",
        "optimal_verto_messages",
        "optimal_verto_message_receipts",
        "optimal_verto_conversation_states",
        "optimal_verto_message_attachments",
    )
    migration_blob = "\n".join(read(f"supabase/migrations/{name}") for name in ALL_MIGRATIONS)
    for table in sensitive:
        dangerous = re.search(
            rf"grant\s+(?:all|select|insert|update|delete)[^;]*on\s+table\s+public\.{table}[^;]*to\s+(?:public|anon|authenticated)",
            migration_blob,
            re.IGNORECASE | re.DOTALL,
        )
        check(f"security:no-direct-grant:{table}", dangerous is None)

    for label, text in (
        ("migration", migration), ("promotion", promotion), ("preflight", preflight),
        ("scenarios", scenarios), ("post", post),
    ):
        check(f"syntax:{label}:dollar-quotes", text.count("$$") % 2 == 0)
        check(f"syntax:{label}:merge-markers", not any(mark in text for mark in ("<<<<<<<", "=======", ">>>>>>>")))
        check(f"syntax:{label}:parentheses", text.count("(") == text.count(")"))

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    print(f"RESULT {len(checks) - len(failed)}/{len(checks)}")
    if failed:
        print("FAILED:", ", ".join(failed), file=sys.stderr)
    return len(checks) - len(failed), len(checks)


def load_evidence(data: dict[str, object], target: str, required: set[str], section: str) -> None:
    target_data = data.get(target)
    if not isinstance(target_data, dict):
        raise RuntimeError(f"evidence target missing: {target}")
    values = target_data.get(section)
    if not isinstance(values, dict):
        raise RuntimeError(f"evidence section missing: {target}.{section}")
    missing = sorted(key for key in required if values.get(key) is not True)
    if missing:
        raise RuntimeError(f"evidence failed for {target}.{section}: {', '.join(missing)}")


def run_psql(psql: str, database_url: str, file: Path, label: str) -> None:
    print(f"LIVE {label}: {file.relative_to(ROOT)}")
    env = os.environ.copy()
    env["PGCONNECT_TIMEOUT"] = env.get("PGCONNECT_TIMEOUT", "15")
    subprocess.run(
        [psql, database_url, "--no-psqlrc", "--set", "ON_ERROR_STOP=1", "--file", str(file)],
        cwd=ROOT,
        env=env,
        check=True,
    )


def run_inline(psql: str, database_url: str, sql: str, label: str) -> None:
    print(f"LIVE {label}: baseline-state-check")
    subprocess.run(
        [psql, database_url, "--no-psqlrc", "--set", "ON_ERROR_STOP=1", "--command", sql],
        cwd=ROOT,
        env={**os.environ, "PGCONNECT_TIMEOUT": os.environ.get("PGCONNECT_TIMEOUT", "15")},
        check=True,
    )


def parse_targets(values: list[str]) -> dict[str, str]:
    targets: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise RuntimeError("target must be LABEL=DATABASE_URL")
        label, url = value.split("=", 1)
        if label not in {"clean", "upgrade"} or not url:
            raise RuntimeError("targets must be clean=... and upgrade=...")
        targets[label] = url
    if targets and set(targets) != {"clean", "upgrade"}:
        raise RuntimeError("live v46 requires both clean and upgrade targets")
    return targets


def live_harness(args: argparse.Namespace) -> None:
    targets = parse_targets(args.target)
    if not targets:
        return
    if not args.allow_destructive:
        raise RuntimeError("live mode requires --allow-destructive")
    if args.confirm != "V46_TEST_DATABASES_ONLY":
        raise RuntimeError("live mode requires --confirm V46_TEST_DATABASES_ONLY")
    if not args.fixture_sql or not args.fixture_sql.is_file():
        raise RuntimeError("live mode requires --fixture-sql")
    if not args.evidence_json or not args.evidence_json.is_file():
        raise RuntimeError("live mode requires --evidence-json")

    evidence = json.loads(args.evidence_json.read_text(encoding="utf-8"))
    if not isinstance(evidence, dict):
        raise RuntimeError("evidence root must be an object")
    for target in ("clean", "upgrade"):
        load_evidence(evidence, target, REQUIRED_REGISTRATION_EVIDENCE, "registration")
        load_evidence(evidence, target, REQUIRED_STORAGE_EVIDENCE, "storage_edge")

    psql = shutil.which(args.psql)
    if psql is None:
        raise RuntimeError(f"psql executable not found: {args.psql}")

    for label, url in targets.items():
        if label == "clean":
            run_inline(
                psql,
                url,
                "do $$ begin if to_regclass('public.optimal_companies') is not null then raise exception 'v46_clean_target_contains_optimal_schema'; end if; end $$;",
                label,
            )
            migration_names = ALL_MIGRATIONS
        else:
            run_inline(
                psql,
                url,
                "do $$ begin if to_regclass('public.optimal_companies') is null or to_regclass('public.optimal_backend_contracts') is null then raise exception 'v46_upgrade_target_missing_v22_baseline'; end if; if exists (select 1 from public.optimal_backend_contracts where singleton=true and contract_version<>22) then raise exception 'v46_upgrade_target_not_contract_22'; end if; end $$;",
                label,
            )
            migration_names = V23_MIGRATIONS

        for name in migration_names:
            run_psql(psql, url, MIGRATIONS / name, label)
        run_psql(psql, url, args.fixture_sql, label)

        for name in PREFLIGHTS:
            run_psql(psql, url, TESTS / name, label)
        for name in SCENARIOS:
            run_psql(psql, url, TESTS / name, label)
        for name in PRIOR_PROMOTIONS:
            run_psql(psql, url, POST_DEPLOY / name, label)

        run_psql(psql, url, TESTS / "v46_backend_contract_preflight.sql", label)
        run_psql(psql, url, TESTS / "v46_backend_contract_scenarios.sql", label)
        run_psql(psql, url, POST_DEPLOY / "v46_promote_verto_backend_v23.sql", label)
        run_psql(psql, url, TESTS / "v46_backend_contract_post_promotion.sql", label)
        print(f"LIVE {label}: PASS")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--target",
        action="append",
        default=[],
        metavar="LABEL=DATABASE_URL",
        help="repeat exactly for clean and upgrade disposable Supabase targets",
    )
    parser.add_argument("--fixture-sql", type=Path, help="staging-only fixture setup for two linked companies")
    parser.add_argument("--evidence-json", type=Path, help="registration and Storage/Edge live evidence")
    parser.add_argument("--allow-destructive", action="store_true")
    parser.add_argument("--confirm", default="")
    parser.add_argument("--psql", default="psql")
    return parser


def main() -> int:
    passed, total = static_checks()
    if passed != total:
        return 1
    args = build_parser().parse_args()
    try:
        live_harness(args)
    except (RuntimeError, subprocess.CalledProcessError, json.JSONDecodeError) as exc:
        print(f"LIVE BLOCKED/FAILED: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
