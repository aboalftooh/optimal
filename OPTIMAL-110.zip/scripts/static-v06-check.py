#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=''):
    checks.append((name, bool(condition), detail))

required = [
    'core/database/src/main/java/com/optimal/fleet/core/database/entity/MaintenanceAuditEntity.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceOperationListRow.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceOperationDetailsRow.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceAuditRow.kt',
    'core/database/src/main/java/com/optimal/fleet/core/database/model/MaintenanceUpdateDbResult.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationSummary.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationDetails.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceOperationEdit.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/model/MaintenanceAuditEvent.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/query/MaintenanceOperationFilter.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/query/SearchMaintenance.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceOperationQuery.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceOperationEditor.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/ObserveMaintenanceOperations.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/ObserveMaintenanceOperationDetails.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/usecase/UpdateMaintenanceOperation.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListContract.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListViewModel.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/list/MaintenanceListRoute.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContract.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsViewModel.kt',
    'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsRoute.kt',
]
for rel in required:
    check(f'required {rel}', (ROOT / rel).is_file())

texts = {rel: (ROOT / rel).read_text(encoding='utf-8') for rel in required}
dao = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceDao.kt').read_text(encoding='utf-8')
repo = '\n'.join((ROOT / f'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/{part}.kt').read_text(encoding='utf-8') for part in ['RoomMaintenanceCreateRepository', 'RoomMaintenanceEditRepository', 'RoomMaintenanceCompleteRepository', 'RoomMaintenanceFollowUpRepository'])
mapper = (ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceMappers.kt').read_text(encoding='utf-8')
di = (ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/di/MaintenanceDataModule.kt').read_text(encoding='utf-8')
nav = (ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/navigation/MaintenanceNavigation.kt').read_text(encoding='utf-8')
app_nav = (ROOT / 'app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt').read_text(encoding='utf-8')
database = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt').read_text(encoding='utf-8')
migration = (ROOT / 'core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt').read_text(encoding='utf-8')

# Database/read-model checks
for token in ['vehicleName', 'plateNumber', 'description', 'status', 'source', 'updatedAtEpochMillis']:
    check(f'list row field {token}', f'val {token}:' in texts[required[1]])
for token in ['createdByUserId', 'updatedByUserId', 'partsCostMinor', 'serviceCostMinor']:
    check(f'details row field {token}', f'val {token}:' in texts[required[2]])
for token in ['operationId', 'actorUserId', 'action', 'changedFields', 'createdAtEpochMillis', 'syncState']:
    check(f'audit entity field {token}', f'val {token}:' in texts[required[0]])
check('audit references operation composite key', 'childColumns = ["operationId", "companyId"]' in texts[required[0]])
check('audit references actor composite key', 'childColumns = ["actorUserId", "companyId"]' in texts[required[0]])
check('audit delete restricted', texts[required[0]].count('onDelete = ForeignKey.RESTRICT') == 2)
check('list query joins vehicle within company', 'vehicle.id = operation.vehicleId' in dao and 'vehicle.companyId = operation.companyId' in dao)
check('list query company scoped', 'WHERE operation.companyId = :companyId' in dao)
check('details query operation scoped', 'AND operation.id = :operationId' in dao)
check('audit query company and operation scoped', 'audit.companyId = :companyId' in dao and 'audit.operationId = :operationId' in dao)
check('update guards in-progress status', "AND status = 'IN_PROGRESS'" in dao)
check('update and audit transaction', '@Transaction' in dao and 'updateInProgressWithAudit' in dao and 'insertAudit(audit)' in dao)
check('no delete operation path', not re.search(r'fun\s+(delete|remove)Operation', dao))
check('database version at least four', any(f'version = {v}' in database for v in range(4, 100)))
check('audit entity registered', 'MaintenanceAuditEntity::class' in database)
check('migration 3 to 4 exists', 'MIGRATION_3_4' in migration and 'Migration(3, 4)' in migration)
check('migration creates audit table', 'CREATE TABLE IF NOT EXISTS `maintenance_audit_events`' in migration)
check('migration chain preserved', all(token in migration for token in ['MIGRATION_1_2', 'MIGRATION_2_3', 'MIGRATION_3_4']))
check('no destructive migration', 'fallbackToDestructiveMigration' not in '\n'.join(
    p.read_text(encoding='utf-8') for p in ROOT.rglob('*.kt')
    if '/src/test/' not in p.as_posix() and '/src/androidTest/' not in p.as_posix()
))

# Domain/query checks
summary = texts[required[5]]
details = texts[required[6]]
edit = texts[required[7]]
audit = texts[required[8]]
filter_text = texts[required[9]]
search = texts[required[10]]
query_contract = texts[required[11]]
editor_contract = texts[required[12]]
observe = texts[required[13]]
observe_details = texts[required[14]]
update_uc = texts[required[15]]

for token in ['vehicleName', 'plateNumber', 'invoiceNumber', 'totalCostMinor']:
    check(f'summary supports {token}', token in summary)
for token in ['invoiceNumber', 'attachments', 'auditEvents', 'totalCostMinor']:
    check(f'details supports {token}', token in details)
for token in ['type', 'description', 'odometerKm', 'partsCostMinor', 'serviceCostMinor']:
    check(f'edit field {token}', f'val {token}:' in edit)
check('edit normalizes description', 'description = edit.description.trim()' in edit)
check('edit validates type and description', 'MissingType' in edit and 'MissingDescription' in edit)
check('edit validates amounts', 'InvalidPartsCost' in edit and 'InvalidServiceCost' in edit)
check('audit preserves update and no forbidden workflow actions', 'UPDATED' in audit and all(x not in audit for x in ['DELETED', 'APPROVED', 'REJECTED']))
check('filter defaults in progress', 'OperationStatus.IN_PROGRESS' in filter_text)
check('filter supports source type period', all(x in filter_text for x in ['source:', 'type:', 'period:']))
check('period supports all 30 90', all(x in filter_text for x in ['ALL', 'LAST_30_DAYS', 'LAST_90_DAYS']))
for term in ['operation.vehicleName', 'operation.plateNumber', 'operation.description', 'operation.invoiceNumber']:
    check(f'search field {term}', term in search)
check('search all terms', 'terms.all(searchable::contains)' in search)
check('search sorts latest first', 'sortedByDescending(MaintenanceOperationSummary::updatedAtEpochMillis)' in search)
check('query contract read only', 'observeOperations' in query_contract and 'observeOperationDetails' in query_contract and 'suspend fun' not in query_contract)
check('editor separated from query', 'updateInProgress' in editor_contract and 'observe' not in editor_contract)
check('observe gets company from session', 'sessionReader.observeActiveSession()' in observe and 'session.companyId' in observe)
check('details gets company from session', 'sessionReader.observeActiveSession()' in observe_details and 'session.companyId' in observe_details)
check('update gets company and actor from session', 'sessionReader.currentSession()' in update_uc and 'session.companyId' in update_uc and 'session.userId' in update_uc)
check('update validates before editor', 'MaintenanceEditValidator.validate' in update_uc)
check('read-only source result modeled', 'ReadOnlySource' in editor_contract and 'ReadOnlySource' in update_uc)

# Repository/data checks
check('repository implements query and editor', all(token in repo for token in ['MaintenanceOperationQuery', 'MaintenanceOperationEditor']))
check('repository list reads Room', 'maintenanceDao.observeOperations(companyId)' in repo)
check('repository details combines Room flows', 'combine(' in repo and 'observeDetails' in repo and 'observeAuditEvents' in repo)
check('repository blocks completed edit', 'current.status != OperationStatus.IN_PROGRESS.name' in repo)
check('repository blocks Verto edit', 'current.source != OperationSource.MANUAL.name' in repo)
check('repository records changed fields', 'changedFields = buildSet' in repo)
check('repository skips no-op audit', 'if (changedFields.isEmpty())' in repo)
check('repository marks local sync pending', 'syncState = DatabaseConstants.SYNC_PENDING' in repo)
check('mapper leaves future invoice nullable', 'invoiceNumber = null' in mapper)
check('mapper leaves attachments empty until later scope', 'attachments = emptyList()' in mapper)
check('DI binds read query', 'bindMaintenanceOperationQuery' in di)
check('DI binds editor', 'bindMaintenanceOperationEditor' in di)
check('DI keeps create repository', 'bindMaintenanceOperationRepository' in di)

# Presentation checks
list_contract = texts[required[16]]
list_vm = texts[required[17]]
list_route = texts[required[18]]
details_contract = texts[required[19]]
details_vm = texts[required[20]]
details_route = texts[required[21]]
check('list state initial value', 'MaintenanceListUiState(' in list_contract and 'isLoading: Boolean = true' in list_contract)
check('list ViewModel StateFlow initial', 'MutableStateFlow(MaintenanceListUiState())' in list_vm)
check('details ViewModel StateFlow initial', 'MutableStateFlow(MaintenanceDetailsUiState())' in details_vm)
check('two tabs visible', 'جاري المعالجة' in list_route and 'مكتمل' in list_route)
check('search copy lists four fields', 'السيارة أو اللوحة أو الوصف أو رقم الفاتورة' in list_route)
check('source filters visible', 'كل المصادر' in list_route and 'يدوي' in list_route and 'Verto' in list_route)
check('type filters visible', 'قطع فقط' in list_route and 'صيانة كاملة' in list_route)
check('period filters visible', '30 يومًا' in list_route and '90 يومًا' in list_route)
check('offline local cache state visible', 'تعمل دون اتصال' in list_route)
check('empty state exists', 'maintenance-empty' in list_route)
check('error state exists', 'maintenance-error' in list_route)
check('no Paging UI dependency', 'Paging' not in list_vm and 'Paging' not in list_route)
check('completed read only in UI contract', 'status == OperationStatus.IN_PROGRESS' in details_contract)
check('Verto read only in UI contract', 'source == OperationSource.MANUAL' in details_contract)
check('details shows costs', 'تكلفة القطع' in details_route and 'تكلفة الصيانة' in details_route and 'الإجمالي' in details_route)
check('details shows source invoice attachments audit', all(x in details_route for x in ['فاتورة Verto', 'المرفقات', 'من فعل ماذا']))
check('details edit route exists', 'تعديل العملية الجارية' in details_route and 'حفظ التعديل' in details_route)
check('details does not expose delete', 'حذف' not in details_route)
check('viewmodel parses money precisely', 'MoneyInputParser.parseMinorUnits' in details_vm)
check('viewmodel caps description', 'take(2_000)' in details_vm)
check('viewmodel handles completed read only', 'CompletedOperation' in details_vm and 'المكتملة لا تُعدّل' in details_vm)
check('viewmodel handles Verto read only', 'ReadOnlySource' in details_vm and 'Verto للقراءة فقط' in details_vm)

# Navigation/build checks
check('details route exists', 'MAINTENANCE_DETAILS_ROUTE' in nav and 'maintenanceDetailsRoute' in nav)
check('app owns navigation to details', 'onOperationSelected' in app_nav and 'maintenanceDetailsRoute(operationId)' in app_nav)
check('save opens details', 'onOperationSaved' in app_nav and 'maintenanceDetailsRoute(operationId)' in app_nav)
build = (ROOT / 'feature/maintenance/build.gradle.kts').read_text(encoding='utf-8')
check('no paging dependency added', 'paging' not in build.lower())
check('no backend SDK added', all(x not in build.lower() for x in ['supabase', 'firebase', 'retrofit']))
check('version v06 or later', bool(re.search(r'versionName = \"0\.(?:[6-9]|[1-9]\d)\.', (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8'))))

# Architecture scans
feature_root = ROOT / 'feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance'
domain_files = list((feature_root / 'domain').rglob('*.kt'))
presentation_files = list((feature_root / 'presentation').rglob('*.kt'))
forbidden_domain = []
for p in domain_files:
    text = p.read_text(encoding='utf-8')
    if re.search(r'^import (android\.|androidx\.room|retrofit2\.|com\.optimal\.fleet\.core\.database)', text, re.M):
        forbidden_domain.append(str(p.relative_to(ROOT)))
check('maintenance domain pure Kotlin', not forbidden_domain, ', '.join(forbidden_domain))
forbidden_presentation = []
for p in presentation_files:
    text = p.read_text(encoding='utf-8')
    if re.search(r'^import .*\.(data|dao)\.', text, re.M) or re.search(r'^import .*core\.database', text, re.M):
        forbidden_presentation.append(str(p.relative_to(ROOT)))
check('presentation does not import data/database', not forbidden_presentation, ', '.join(forbidden_presentation))
check('presentation does not accept companyId', 'companyId' not in '\n'.join(p.read_text(encoding='utf-8') for p in presentation_files))
check('maintenance no feature implementation dependency', not any(
    re.search(r'import com\.optimal\.fleet\.feature\.(?!maintenance\.)', p.read_text(encoding='utf-8'))
    for p in feature_root.rglob('*.kt')
))

required_tests = [
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/usecase/ObserveMaintenanceOperationsTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/domain/query/SearchMaintenanceTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/presentation/MaintenanceListViewModelTest.kt',
    'feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/presentation/MaintenanceDetailsViewModelTest.kt',
    'feature/maintenance/src/androidTest/java/com/optimal/fleet/feature/maintenance/presentation/MaintenanceUiTest.kt',
    'core/database/src/androidTest/java/com/optimal/fleet/core/database/MaintenanceReadEditDaoTest.kt',
    'app/src/test/java/com/optimal/fleet/MaintenanceReadArchitectureTest.kt',
]
for rel in required_tests:
    check(f'test {rel}', (ROOT / rel).is_file())

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f' — {detail}' if detail and not passed else ''))
passed = sum(1 for _, ok, _ in checks if ok)
print(f'\nV06 static checks: {passed}/{len(checks)}')
sys.exit(0 if passed == len(checks) else 1)
