#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/kotlinx/serialization/json"
cat > "$TEMP/kotlinx/serialization/Serialization.kt" <<'STUB'
package kotlinx.serialization
@Target(AnnotationTarget.CLASS)
annotation class Serializable
@Target(AnnotationTarget.PROPERTY)
annotation class SerialName(val value: String)
STUB
cat > "$TEMP/kotlinx/serialization/json/Json.kt" <<'STUB'
package kotlinx.serialization.json
open class JsonElement
class JsonPrimitive(val content: String) : JsonElement()
val JsonElement.jsonPrimitive: JsonPrimitive get() = this as JsonPrimitive
STUB
kotlinc \
  "$TEMP/kotlinx/serialization/Serialization.kt" \
  "$TEMP/kotlinx/serialization/json/Json.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/invoice/model/VertoInvoiceSnapshot.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceDto.kt" \
  "$ROOT/feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/verto/VertoInvoiceMapper.kt" \
  "$ROOT/scripts/v20-domain-harness.kt" \
  -include-runtime -d "$TEMP/v20-harness.jar"
java -jar "$TEMP/v20-harness.jar"
