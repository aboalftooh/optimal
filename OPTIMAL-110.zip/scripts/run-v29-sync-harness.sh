#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p \
  "$TMP_DIR/javax/inject" \
  "$TMP_DIR/androidx/room" \
  "$TMP_DIR/com/optimal/fleet/core/database/entity" \
  "$TMP_DIR/com/optimal/fleet/core/model/audit" \
  "$TMP_DIR/kotlinx/coroutines" \
  "$TMP_DIR/kotlinx/coroutines/sync"

cat > "$TMP_DIR/javax/inject/Inject.kt" <<'STUB'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.FUNCTION)
annotation class Inject
@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION)
annotation class Singleton
STUB

cat > "$TMP_DIR/androidx/room/Room.kt" <<'STUB'
package androidx.room
@Target(AnnotationTarget.CLASS)
annotation class Entity(val tableName: String = "", val foreignKeys: Array<ForeignKey> = [], val indices: Array<Index> = [])
@Target(AnnotationTarget.PROPERTY)
annotation class PrimaryKey(val autoGenerate: Boolean = false)
annotation class ForeignKey(val entity: kotlin.reflect.KClass<*>, val parentColumns: Array<String>, val childColumns: Array<String>, val onDelete: Int = 0) { companion object { const val CASCADE = 5 } }
annotation class Index(val value: Array<String>, val unique: Boolean = false)
STUB

cat > "$TMP_DIR/com/optimal/fleet/core/database/entity/CompanyEntity.kt" <<'STUB'
package com.optimal.fleet.core.database.entity
class CompanyEntity
STUB

cat > "$TMP_DIR/com/optimal/fleet/core/model/audit/AuditPort.kt" <<'STUB'
package com.optimal.fleet.core.model.audit
interface AuditPort { suspend fun append(event: AuditEventDraft) }
object NoOpAuditPort : AuditPort { override suspend fun append(event: AuditEventDraft) = Unit }
STUB

cat > "$TMP_DIR/kotlinx/coroutines/Coroutines.kt" <<'STUB'
package kotlinx.coroutines
open class CancellationException : java.util.concurrent.CancellationException()
class TimeoutCancellationException : CancellationException()
suspend fun <T> withTimeout(timeMillis: Long, block: suspend () -> T): T = block()
STUB

cat > "$TMP_DIR/kotlinx/coroutines/sync/Mutex.kt" <<'STUB'
package kotlinx.coroutines.sync
class Mutex {
    private var locked = false
    fun tryLock(): Boolean = if (locked) false else { locked = true; true }
    fun unlock() { locked = false }
}
STUB

kotlinc \
  "$TMP_DIR/javax/inject/Inject.kt" \
  "$TMP_DIR/androidx/room/Room.kt" \
  "$TMP_DIR/com/optimal/fleet/core/database/entity/CompanyEntity.kt" \
  "$TMP_DIR/com/optimal/fleet/core/model/audit/AuditPort.kt" \
  "$TMP_DIR/kotlinx/coroutines/Coroutines.kt" \
  "$TMP_DIR/kotlinx/coroutines/sync/Mutex.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/DomainErrorMapper.kt" \
  "$ROOT_DIR/core/common/src/main/kotlin/com/optimal/fleet/core/common/error/SafeErrorReporter.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/audit/AuditModels.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/PendingSyncOperationEntity.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncConflictAuditEntity.kt" \
  "$ROOT_DIR/core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueConstants.kt" \
  "$ROOT_DIR/core/network/src/main/java/com/optimal/fleet/core/network/sync/SyncTransport.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncParticipant.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncQueuePort.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncRetryPolicy.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/DescriptionConflictResolver.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncRunResult.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchClaimer.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncLeaseRecoveryCoordinator.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncErrorMapping.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncOperationDispatcher.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncConflictCoordinator.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncBatchReporter.kt" \
  "$ROOT_DIR/app/src/main/java/com/optimal/fleet/coordinator/sync/SyncManager.kt" \
  "$ROOT_DIR/scripts/v29-sync-harness.kt" \
  -include-runtime -d "$TMP_DIR/v29-sync-harness.jar"
java -jar "$TMP_DIR/v29-sync-harness.jar"
