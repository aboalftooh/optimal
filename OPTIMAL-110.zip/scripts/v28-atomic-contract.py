#!/usr/bin/env python3
"""Executable SQLite contract for v28 all-or-nothing writes and idempotency."""
from __future__ import annotations

import sqlite3

checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


def scalar(db: sqlite3.Connection, sql: str, args: tuple = ()) -> int:
    return int(db.execute(sql, args).fetchone()[0])


def outbox_key(kind: str, aggregate_id: str, operation: str, version: int) -> str:
    return f"{kind}:{aggregate_id}:{operation}:{version}"


def setup() -> sqlite3.Connection:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(
        """
        CREATE TABLE companies(id TEXT PRIMARY KEY);
        CREATE TABLE vehicles(id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id));
        CREATE TABLE vehicle_audit(id TEXT PRIMARY KEY, vehicle_id TEXT NOT NULL REFERENCES vehicles(id));
        CREATE TABLE maintenance(id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id));
        CREATE TABLE invoices(id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id));
        CREATE TABLE invoice_audit(id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(id));
        CREATE TABLE costs(id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id));
        CREATE TABLE audit_events(id TEXT PRIMARY KEY, company_id TEXT NOT NULL REFERENCES companies(id));
        CREATE TABLE outbox(
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL REFERENCES companies(id),
            idempotency_key TEXT NOT NULL UNIQUE,
            aggregate_type TEXT NOT NULL,
            aggregate_id TEXT NOT NULL,
            operation_type TEXT NOT NULL,
            local_version INTEGER NOT NULL
        );
        INSERT INTO companies VALUES ('company-a');
        """
    )
    return db


def expect_failure(block) -> None:
    failed = False
    try:
        block()
    except sqlite3.IntegrityError:
        failed = True
    check("intentional database failure observed", failed)


db = setup()

# Success path: entity + local audit + unified audit + outbox commit together.
key = outbox_key("VEHICLE", "v-success", "UPSERT", 10)
with db:
    db.execute("INSERT INTO vehicles VALUES (?, ?)", ("v-success", "company-a"))
    db.execute("INSERT INTO vehicle_audit VALUES (?, ?)", ("va-success", "v-success"))
    db.execute("INSERT INTO audit_events VALUES (?, ?)", ("ga-success", "company-a"))
    db.execute(
        "INSERT INTO outbox VALUES (?, ?, ?, ?, ?, ?, ?)",
        (key, "company-a", key, "VEHICLE", "v-success", "UPSERT", 10),
    )
check("successful data committed", scalar(db, "SELECT COUNT(*) FROM vehicles WHERE id='v-success'") == 1)
check("successful local audit committed", scalar(db, "SELECT COUNT(*) FROM vehicle_audit WHERE id='va-success'") == 1)
check("successful unified audit committed", scalar(db, "SELECT COUNT(*) FROM audit_events WHERE id='ga-success'") == 1)
check("successful outbox committed", scalar(db, "SELECT COUNT(*) FROM outbox WHERE id=?", (key,)) == 1)

# Failure at data step.
def fail_data() -> None:
    with db:
        db.execute("INSERT INTO vehicles VALUES ('v-success', 'company-a')")
        db.execute("INSERT INTO audit_events VALUES ('ga-never-data', 'company-a')")
        retry_key = outbox_key("VEHICLE", "v-success", "UPSERT", 11)
        db.execute(
            "INSERT INTO outbox VALUES (?, 'company-a', ?, 'VEHICLE', 'v-success', 'UPSERT', 11)",
            (retry_key, retry_key),
        )

expect_failure(fail_data)
check("data failure leaves audit absent", scalar(db, "SELECT COUNT(*) FROM audit_events WHERE id='ga-never-data'") == 0)
check("data failure leaves outbox absent", scalar(db, "SELECT COUNT(*) FROM outbox WHERE local_version=11") == 0)

# Failure at audit step rolls data back.
db.execute("INSERT INTO audit_events VALUES ('ga-duplicate', 'company-a')")
db.commit()
def fail_audit() -> None:
    with db:
        db.execute("INSERT INTO costs VALUES ('cost-fail', 'company-a')")
        db.execute("INSERT INTO audit_events VALUES ('ga-duplicate', 'company-a')")

expect_failure(fail_audit)
check("audit failure rolls cost back", scalar(db, "SELECT COUNT(*) FROM costs WHERE id='cost-fail'") == 0)
check("audit failure preserves only original audit", scalar(db, "SELECT COUNT(*) FROM audit_events WHERE id='ga-duplicate'") == 1)

# Failure at outbox step rolls data and both audit layers back.
duplicate_key = outbox_key("VEHICLE", "v-outbox", "UPSERT", 20)
db.execute(
    "INSERT INTO outbox VALUES (?, 'company-a', ?, 'VEHICLE', 'v-outbox', 'UPSERT', 20)",
    (duplicate_key, duplicate_key),
)
db.commit()
def fail_outbox() -> None:
    with db:
        db.execute("INSERT INTO vehicles VALUES ('v-outbox', 'company-a')")
        db.execute("INSERT INTO vehicle_audit VALUES ('va-outbox', 'v-outbox')")
        db.execute("INSERT INTO audit_events VALUES ('ga-outbox', 'company-a')")
        db.execute(
            "INSERT INTO outbox VALUES (?, 'company-a', ?, 'VEHICLE', 'v-outbox', 'UPSERT', 20)",
            (duplicate_key, duplicate_key),
        )

expect_failure(fail_outbox)
check("outbox failure rolls vehicle back", scalar(db, "SELECT COUNT(*) FROM vehicles WHERE id='v-outbox'") == 0)
check("outbox failure rolls local audit back", scalar(db, "SELECT COUNT(*) FROM vehicle_audit WHERE id='va-outbox'") == 0)
check("outbox failure rolls unified audit back", scalar(db, "SELECT COUNT(*) FROM audit_events WHERE id='ga-outbox'") == 0)
check("outbox failure preserves original queue item only", scalar(db, "SELECT COUNT(*) FROM outbox WHERE id=?", (duplicate_key,)) == 1)

# Invoice projection + source audit + unified audit rollback.
def fail_invoice_audit() -> None:
    with db:
        db.execute("INSERT INTO invoices VALUES ('invoice-fail', 'company-a')")
        db.execute("INSERT INTO invoice_audit VALUES ('invoice-source-fail', 'invoice-fail')")
        db.execute("INSERT INTO audit_events VALUES ('ga-duplicate', 'company-a')")

expect_failure(fail_invoice_audit)
check("invoice audit failure rolls projection back", scalar(db, "SELECT COUNT(*) FROM invoices WHERE id='invoice-fail'") == 0)
check("invoice audit failure rolls source audit back", scalar(db, "SELECT COUNT(*) FROM invoice_audit WHERE id='invoice-source-fail'") == 0)

# Maintenance + outbox rollback on audit failure.
def fail_maintenance_audit() -> None:
    maintenance_key = outbox_key("MAINTENANCE", "m-fail", "UPSERT", 30)
    with db:
        db.execute("INSERT INTO maintenance VALUES ('m-fail', 'company-a')")
        db.execute(
            "INSERT INTO outbox VALUES (?, 'company-a', ?, 'MAINTENANCE', 'm-fail', 'UPSERT', 30)",
            (maintenance_key, maintenance_key),
        )
        db.execute("INSERT INTO audit_events VALUES ('ga-duplicate', 'company-a')")

expect_failure(fail_maintenance_audit)
check("maintenance audit failure rolls operation back", scalar(db, "SELECT COUNT(*) FROM maintenance WHERE id='m-fail'") == 0)
check("maintenance audit failure rolls outbox back", scalar(db, "SELECT COUNT(*) FROM outbox WHERE aggregate_id='m-fail'") == 0)

# Stable idempotency and logical retry.
first = outbox_key("VEHICLE", "v-retry", "UPSERT", 99)
retry = outbox_key("VEHICLE", "v-retry", "UPSERT", 99)
next_version = outbox_key("VEHICLE", "v-retry", "UPSERT", 100)
check("same logical write has stable key", first == retry)
check("new version has a distinct key", first != next_version)
with db:
    db.execute(
        "INSERT INTO outbox VALUES (?, 'company-a', ?, 'VEHICLE', 'v-retry', 'UPSERT', 99)",
        (first, first),
    )
    db.execute(
        "INSERT OR IGNORE INTO outbox VALUES (?, 'company-a', ?, 'VEHICLE', 'v-retry', 'UPSERT', 99)",
        (retry, retry),
    )
check("retry remains one logical outbox row", scalar(db, "SELECT COUNT(*) FROM outbox WHERE idempotency_key=?", (first,)) == 1)

passed = sum(ok for _, ok in checks)
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\nV28 SQLite atomic contract: {passed}/{len(checks)}")
raise SystemExit(0 if passed == len(checks) else 1)
