#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT"' EXIT
kotlinc \
  "$ROOT_DIR/feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessageCursor.kt" \
  "$ROOT_DIR/scripts/v53-verto-message-sync-harness.kt" \
  -include-runtime -d "$OUT"
java -jar "$OUT"
