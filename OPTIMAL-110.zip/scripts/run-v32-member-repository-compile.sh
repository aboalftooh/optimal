#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
KOTLIN_HOME="$(cd "$(dirname "$(command -v kotlinc)")/.." && pwd)"
COROUTINES_JAR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p \
  "$TMP_DIR/stubs/javax/inject" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/common/error" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/session" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/model/audit" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/audit" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/local" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/mapper" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/remote"
cat > "$TMP_DIR/stubs/javax/inject/Inject.kt" <<'KT'
package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD, AnnotationTarget.VALUE_PARAMETER)
annotation class Inject
@Target(AnnotationTarget.CLASS)
annotation class Singleton
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/common/error/Error.kt" <<'KT'
package com.optimal.fleet.core.common.error
open class DomainError
enum class InfrastructureBoundary { NETWORK, STORAGE, SERIALIZATION, BACKGROUND_WORK }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/session/Session.kt" <<'KT'
package com.optimal.fleet.core.session
data class ActiveSession(val userId: String = "", val companyId: String = "")
interface MemberSessionInvalidator { suspend fun invalidateMemberSession(companyId: String, userId: String) }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/model/audit/Audit.kt" <<'KT'
package com.optimal.fleet.core.model.audit
enum class AuditAction { MEMBER_INVITED, MEMBER_INVITE_RESENT, MEMBER_INVITE_REVOKED, MEMBER_VERTO_PERMISSIONS_UPDATED }
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/Entities.kt" <<'KT'
package com.optimal.fleet.core.database.entity
data class LocalUserEntity(
    val id: String,
    val companyId: String,
    val remoteId: String?,
    val displayName: String,
    val phone: String?,
    val isActive: Boolean,
    val lastActiveAtEpochMillis: Long,
)
data class MemberInviteEntity(val id: String)
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/Failure.kt" <<'KT'
package com.optimal.fleet.feature.settings.data.members
import com.optimal.fleet.core.common.error.DomainError
import com.optimal.fleet.core.common.error.InfrastructureBoundary
class MemberFailureMapper {
    fun fromThrowable(error: Exception, operation: String, boundary: InfrastructureBoundary = InfrastructureBoundary.NETWORK): DomainError = DomainError()
    fun fromHttp(code: Int, body: String?, operation: String): DomainError = DomainError()
    fun storage(operation: String, code: String): DomainError = DomainError()
    fun permission(operation: String, code: String): DomainError = DomainError()
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/remote/Remote.kt" <<'KT'
package com.optimal.fleet.feature.settings.data.members.remote
sealed interface MemberRemoteResult<out T> {
    data class Success<T>(val value: T) : MemberRemoteResult<T>
    data class HttpFailure(val code: Int, val body: String?) : MemberRemoteResult<Nothing>
    data object BackendNotConfigured : MemberRemoteResult<Nothing>
    data object Unauthorized : MemberRemoteResult<Nothing>
    data class Failure(val error: Exception) : MemberRemoteResult<Nothing>
}
data class RemoteMemberDto(val id: String, val companyId: String, val isActive: Boolean)
data class RemoteInviteDto(
    val id: String,
    val companyId: String,
    val phone: String,
    val expiresAtEpochMillis: Long,
)
data class RemoteInviteMutationDto(val invite: RemoteInviteDto, val plainCode: String)
data class RemoteDirectoryDto(
    val members: List<RemoteMemberDto>,
    val pendingInvites: List<RemoteInviteDto>,
)
interface MemberRemoteDataSource {
    suspend fun directory(): MemberRemoteResult<RemoteDirectoryDto>
    suspend fun createInvite(displayName: String, phone: String, canViewVertoChat: Boolean, canSendVertoChat: Boolean): MemberRemoteResult<RemoteInviteMutationDto>
    suspend fun resendInvite(inviteId: String): MemberRemoteResult<RemoteInviteMutationDto>
    suspend fun revokeInvite(inviteId: String): MemberRemoteResult<RemoteInviteDto>
    suspend fun setMemberActive(memberId: String, active: Boolean): MemberRemoteResult<RemoteMemberDto>
    suspend fun updateVertoPermissions(memberId: String, canViewVertoChat: Boolean, canSendVertoChat: Boolean): MemberRemoteResult<RemoteMemberDto>
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/local/Local.kt" <<'KT'
package com.optimal.fleet.feature.settings.data.members.local
import com.optimal.fleet.core.database.entity.LocalUserEntity
import com.optimal.fleet.core.database.entity.MemberInviteEntity
import com.optimal.fleet.feature.settings.data.members.remote.*
import com.optimal.fleet.feature.settings.domain.members.*
import kotlinx.coroutines.flow.Flow
interface MemberLocalDataSource {
    fun observeMembers(companyId: String): Flow<List<LocalUserEntity>>
    fun observePendingInvites(companyId: String): Flow<List<MemberInviteEntity>>
    suspend fun findMember(companyId: String, memberId: String): Member?
    suspend fun findMemberEntity(companyId: String, memberId: String): LocalUserEntity?
    suspend fun findInvite(companyId: String, inviteId: String): MemberInviteEntity?
    suspend fun remoteCompanyId(companyId: String): String?
    suspend fun cacheDirectory(localCompanyId: String, remote: RemoteDirectoryDto)
    suspend fun cacheMember(localCompanyId: String, remote: RemoteMemberDto): Member
    suspend fun cacheInvite(localCompanyId: String, actorUserId: String, remote: RemoteInviteMutationDto): CreatedInvite
    suspend fun cacheRevokedInvite(localCompanyId: String, actorUserId: String, remote: RemoteInviteDto): MemberInvite
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/mapper/Mapper.kt" <<'KT'
package com.optimal.fleet.feature.settings.data.members.mapper
import com.optimal.fleet.core.database.entity.LocalUserEntity
import com.optimal.fleet.core.database.entity.MemberInviteEntity
import com.optimal.fleet.feature.settings.domain.members.Member
import com.optimal.fleet.feature.settings.domain.members.MemberInvite
object MemberMapper {
    fun LocalUserEntity.toDomain() = Member(id, companyId, displayName, phone, isActive, lastActiveAtEpochMillis)
    fun MemberInviteEntity.toDomain() = MemberInvite(id, "company", "invite", "+249", 0L, 0L)
}
KT
cat > "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/audit/Audit.kt" <<'KT'
package com.optimal.fleet.feature.settings.data.members.audit
import com.optimal.fleet.core.model.audit.AuditAction
interface MemberAuditDataSource {
    suspend fun inviteMutated(companyId: String, actorUserId: String, inviteId: String, phone: String, expiresAtEpochMillis: Long, action: AuditAction)
    suspend fun statusChanged(companyId: String, actorUserId: String, memberId: String, before: Boolean, after: Boolean)
    suspend fun vertoPermissionsChanged(companyId: String, actorUserId: String, memberId: String, beforeView: Boolean, beforeSend: Boolean, afterView: Boolean, afterSend: Boolean)
}
KT
kotlinc -nowarn -cp "$COROUTINES_JAR" \
  "$TMP_DIR/stubs/javax/inject/Inject.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/common/error/Error.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/session/Session.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/model/audit/Audit.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/core/database/entity/Entities.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/Failure.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/remote/Remote.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/local/Local.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/mapper/Mapper.kt" \
  "$TMP_DIR/stubs/com/optimal/fleet/feature/settings/data/members/audit/Audit.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberRepository.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/data/members/SupabaseMemberRepository.kt" \
  -d "$TMP_DIR/member-repository.jar"
echo "V32 member repository focused compilation: 1/1"
