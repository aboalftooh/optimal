#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKS: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    CHECKS.append((name, ok, detail))


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


# 1) Row-by-row inventory/ledger closure.
ledger = read("docs/design-system/FULL_UI_MIGRATION_LEDGER.md")
row_re = re.compile(
    r"^\| ((?:SCR|DLG|OVL|CMP|STA)-(\d{3})) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| (UNMIGRATED|IN_PROGRESS|MIGRATED|BLOCKED) \| (SESSION-\d+) \|$",
    re.M,
)
rows = row_re.findall(ledger)
ids = [r[0] for r in rows]
statuses = {r[0]: r[8] for r in rows}
check("ledger contains exactly 123 inventory rows", len(rows) == 123, str(len(rows)))
check("ledger inventory IDs are unique", len(ids) == len(set(ids)), f"unique={len(set(ids))}")
expected_ids = (
    [f"SCR-{i:03d}" for i in range(1, 28)]
    + [f"DLG-{i:03d}" for i in range(1, 6)]
    + [f"OVL-{i:03d}" for i in range(1, 3)]
    + ["CMP-001"]
    + [f"STA-{i:03d}" for i in range(1, 89)]
)
missing = sorted(set(expected_ids) - set(ids))
extra = sorted(set(ids) - set(expected_ids))
check("no inventory row is missing", not missing, ", ".join(missing))
check("no unexpected inventory row exists", not extra, ", ".join(extra))
check("all 123 inventory rows are MIGRATED", all(statuses.get(i) == "MIGRATED" for i in expected_ids), str([i for i in expected_ids if statuses.get(i) != "MIGRATED"]))
counts = Counter(i.split("-")[0] for i in ids)
for prefix, expected in [("SCR", 27), ("DLG", 5), ("OVL", 2), ("CMP", 1), ("STA", 88)]:
    check(f"{prefix} row count is {expected}", counts[prefix] == expected, str(counts[prefix]))
summary_expectations = [
    "| SCR | 27 | 27 | 0 | 0 |",
    "| DLG | 5 | 5 | 0 | 0 |",
    "| OVL | 2 | 2 | 0 | 0 |",
    "| CMP | 1 | 1 | 0 | 0 |",
    "| STA | 88 | 88 | 0 | 0 |",
    "| **TOTAL** | **123** | **123** | **0** | **0** |",
]
for line in summary_expectations:
    check(f"ledger summary reconciled: {line.split('|')[1].strip()}", line in ledger)

# 2) Freeze and scan the exact 81 production Compose/UI sources required by SESSION-108.
manifest_path = ROOT / "docs/design-system/SESSION-108-UI-SOURCE-MANIFEST.txt"
manifest = [
    line.strip() for line in manifest_path.read_text(encoding="utf-8").splitlines()
    if line.strip() and not line.lstrip().startswith("#")
]
check("SESSION-108 UI source manifest has exactly 81 paths", len(manifest) == 81, str(len(manifest)))
check("SESSION-108 UI source manifest paths are unique", len(manifest) == len(set(manifest)), str(len(set(manifest))))
missing_files = [p for p in manifest if not (ROOT / p).is_file()]
check("all 81 inventoried UI source files still exist", not missing_files, ", ".join(missing_files))

feature_compose = sorted(
    p.relative_to(ROOT).as_posix()
    for p in (ROOT / "feature").glob("**/src/main/java/**/*.kt")
    if "@Composable" in p.read_text(encoding="utf-8", errors="ignore")
)
app_compose = sorted(
    p.relative_to(ROOT).as_posix()
    for p in (ROOT / "app").glob("**/src/main/java/**/*.kt")
    if "@Composable" in p.read_text(encoding="utf-8", errors="ignore")
)
core_runtime = sorted(
    p.relative_to(ROOT).as_posix()
    for p in (ROOT / "core/designsystem/src/main/java/com/optimal/fleet/designsystem/component/v2").glob("*.kt")
)
core_runtime += [
    "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTheme.kt",
    "core/designsystem/src/main/java/com/optimal/fleet/designsystem/OptimalTypography.kt",
]
discovered = feature_compose + app_compose + core_runtime
check("feature Compose UI discovery remains 64 files", len(feature_compose) == 64, str(len(feature_compose)))
check("app Compose UI discovery remains 3 files", len(app_compose) == 3, str(len(app_compose)))
check("runtime Design System UI source discovery remains 14 files", len(core_runtime) == 14, str(len(core_runtime)))
check("discovered production UI source set is exactly 81 files", len(discovered) == 81, str(len(discovered)))
check("no production UI source exists outside frozen SESSION-108 manifest", set(discovered) == set(manifest), f"added={sorted(set(discovered)-set(manifest))}; missing={sorted(set(manifest)-set(discovered))}")

# Scan all 81 for forbidden legacy namespaces and all product UI for visual drift.
legacy_import_hits: list[str] = []
bottom_sheet_hits: list[str] = []
for rel in manifest:
    text = read(rel)
    for m in re.finditer(r"import\s+com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)", text):
        legacy_import_hits.append(f"{rel}:{text.count(chr(10), 0, m.start())+1}")
    if rel.startswith(("feature/", "app/")):
        if re.search(r"\b(?:ModalBottomSheet|BottomSheetScaffold|StandardBottomSheet|OptimalBottomSheet|rememberModalBottomSheetState)\b", text):
            bottom_sheet_hits.append(rel)
check("81-file scan finds no legacy Design System import", not legacy_import_hits, ", ".join(legacy_import_hits))
check("production app/feature UI contains 0 Bottom Sheets", not bottom_sheet_hits, ", ".join(bottom_sheet_hits))

# Compliance guard owns detailed raw visual token/material checks for feature UI.
proc = subprocess.run(
    [sys.executable, str(ROOT / "scripts/design-system-compliance-guard.py")],
    cwd=ROOT,
    text=True,
    capture_output=True,
)
print(proc.stdout, end="")
if proc.stderr:
    print(proc.stderr, end="", file=sys.stderr)
check("design-system compliance guard passes", proc.returncode == 0)
check("compliance guard scanned all 64 feature Compose UI files", "Feature Compose UI files scanned: 64" in proc.stdout)
check("compliance guard reports 0 active violations", "Active violations: 0" in proc.stdout)

allow = [
    line.strip() for line in read("scripts/design-system-migration-allowlist.txt").splitlines()
    if line.strip() and not line.lstrip().startswith("#")
]
check("migration allowlist has 0 feature UI paths", len(allow) == 0, str(allow))

# 3) Duplicate-style cleanup: exact local filter-chip wrapper removed; all semantics/tags remain.
followup_rel = "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/followup/MaintenanceFollowUpRoute.kt"
followup = read(followup_rel)
check("obsolete FollowUpFilterChip visual wrapper removed", "fun FollowUpFilterChip(" not in followup)
for tag in ["followup-filter-all", "followup-filter-overdue", "followup-filter-due", "followup-filter-upcoming"]:
    check(f"follow-up filter tag preserved: {tag}", f'testTag("{tag}")' in followup)
check("follow-up filters use canonical OptimalFilterChip directly", followup.count("OptimalFilterChip(") >= 4, str(followup.count("OptimalFilterChip(")))
check("follow-up status callbacks preserved", followup.count("MaintenanceFollowUpUiEvent.StatusChanged") >= 4, str(followup.count("MaintenanceFollowUpUiEvent.StatusChanged")))

# 4) The two baseline-unreachable screens must remain present, migrated and unreachable.
invoice_screen = "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListScreen.kt"
invoice_route = "feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt"
join_screen = "feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/join/JoinCompanyRoute.kt"
for rel in [invoice_screen, invoice_route, join_screen]:
    check(f"unreachable UI source still present: {Path(rel).name}", (ROOT / rel).is_file())
check("SCR-021 remains MIGRATED in ledger", statuses.get("SCR-021") == "MIGRATED")
check("SCR-024 remains MIGRATED in ledger", statuses.get("SCR-024") == "MIGRATED")
finance_nav = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt")
app_nav = read("app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt")
settings_nav = read("feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation/SettingsNavigation.kt")
check("InvoiceListConnected is still absent from Finance navigation", "InvoiceListConnected" not in finance_nav)
check("InvoiceList route is still absent from app navigation", "InvoiceListConnected" not in app_nav and "InvoiceListRoute" not in app_nav)
check("JoinCompany destination remains registered", "composable(route = MEMBER_JOIN_ROUTE)" in settings_nav and "JoinCompanyConnected" in settings_nav)
check("JoinCompany route remains without app navigation call", "navigate(MEMBER_JOIN_ROUTE" not in app_nav and 'navigate("settings/join-company"' not in app_nav)
# Project-wide production check catches any newly wired navigation call/deeplink literal.
production_text = "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for base in [ROOT / "app/src/main/java", ROOT / "feature"]
    for p in base.glob("**/*.kt")
    if "/src/test/" not in p.as_posix() and "/src/androidTest/" not in p.as_posix()
)
check("JoinCompany has no production navigate(MEMBER_JOIN_ROUTE) call", re.search(r"navigate\s*\(\s*MEMBER_JOIN_ROUTE", production_text) is None)
check("JoinCompany has no production navigate literal call", re.search(r'navigate\s*\(\s*"settings/join-company"', production_text) is None)

# 5) Current-state handoff is advanced only to SESSION-109.
current = read("docs/design-system/CURRENT-DESIGN-STATE.md")
check("current design state identifies SESSION-108 baseline", "CURRENT DESIGN STATE — SESSION-108" in current)
check("current design state advances only to SESSION-109", "Next session:** SESSION-109" in current)
check("current design state records 123 MIGRATED", "123 MIGRATED" in current)

failed = [item for item in CHECKS if not item[1]]
for name, ok, detail in CHECKS:
    print(("PASS" if ok else "FAIL") + ": " + name + (f" [{detail}]" if detail else ""))
print(f"\nSESSION-108 static acceptance: {len(CHECKS)-len(failed)}/{len(CHECKS)}")
sys.exit(1 if failed else 0)
