#!/usr/bin/env python3
"""Executable v64 policy scenarios: retry, crash recovery, session change, and unique work."""
from dataclasses import dataclass

checks = 0

def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)

@dataclass
class Operation:
    company: str
    state: str = "PENDING"
    attempts: int = 0
    remote_writes: int = 0
    local_state: str = "PENDING"

class Engine:
    def __init__(self, active_company):
        self.active_company = active_company
        self.running = False

    def run(self, expected_company, op, network=True, switch_after_remote=False):
        if self.running:
            return "SKIPPED"
        self.running = True
        try:
            if self.active_company != expected_company or op.company != expected_company:
                return "SESSION_CHANGED"
            op.state = "RUNNING"
            op.local_state = "SENDING"
            if not network:
                op.state = "RETRY"
                op.local_state = "FAILED_RETRYABLE"
                op.attempts += 1
                return "RETRY"
            op.remote_writes = 1  # idempotent server identity
            if switch_after_remote:
                self.active_company = "company-b"
            if self.active_company != expected_company:
                op.state = "RETRY"
                op.local_state = "FAILED_RETRYABLE"
                return "SESSION_CHANGED"
            op.state = "SUCCEEDED"
            op.local_state = "SENT"
            return "SUCCESS"
        finally:
            self.running = False

    def recover_expired(self, expected_company, op):
        if op.company != expected_company:
            return "IGNORED_OTHER_COMPANY"
        if op.state == "RUNNING":
            op.state = "RETRY"
            op.local_state = "FAILED_RETRYABLE"
            op.attempts += 1
            return "RECOVERED"
        return "NOOP"

# Offline for a long period remains retryable and locally visible.
engine = Engine("company-a")
op = Operation("company-a")
check(engine.run("company-a", op, network=False) == "RETRY", "offline was not retried")
check(op.state == "RETRY" and op.local_state == "FAILED_RETRYABLE", "offline transient state stuck")
check(op.attempts == 1, "offline attempt was not counted")

# Network return completes the same logical operation once.
check(engine.run("company-a", op, network=True) == "SUCCESS", "network return did not complete")
check(op.remote_writes == 1, "idempotent remote write duplicated")
check(op.local_state == "SENT", "local send state not finalized")

# Crash during upload leaves RUNNING/UPLOADING, then lease recovery restores retryable state.
crashed = Operation("company-a", state="RUNNING", local_state="UPLOADING")
check(engine.recover_expired("company-a", crashed) == "RECOVERED", "expired lease not recovered")
check(crashed.state == "RETRY", "expired operation did not return to retry")
check(crashed.local_state == "FAILED_RETRYABLE", "attachment transient state remained stuck")

# A stale worker may finish the remote call but cannot write into the new active company.
stale = Operation("company-a")
engine = Engine("company-a")
check(engine.run("company-a", stale, switch_after_remote=True) == "SESSION_CHANGED", "session switch not detected")
check(stale.state == "RETRY", "stale lease was not released")
check(stale.local_state == "FAILED_RETRYABLE", "stale local state was not recovered")
check(stale.remote_writes == 1, "remote idempotent write disappeared")
check(engine.active_company == "company-b", "test session did not switch")

# The new company's run cannot claim the old company's row.
check(engine.run("company-b", stale) == "SESSION_CHANGED", "cross-company operation was claimed")
check(stale.company == "company-a", "operation ownership changed")

# Two workers in one process: only one enters the unified cycle.
engine = Engine("company-a")
engine.running = True
concurrent = Operation("company-a")
check(engine.run("company-a", concurrent) == "SKIPPED", "concurrent worker was not skipped")
check(concurrent.state == "PENDING", "skipped worker mutated data")

# Process recreation repeats recovery safely without changing a non-running row.
engine.running = False
check(engine.recover_expired("company-a", crashed) == "NOOP", "recovery was not idempotent")
check(crashed.attempts == 1, "idempotent recovery incremented twice")

print(f"v64 unified sync harness: {checks}/{checks} PASS")
