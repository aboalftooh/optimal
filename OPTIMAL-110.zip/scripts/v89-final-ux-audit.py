#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks=[]

def check(label, ok):
    checks.append((label, bool(ok)))
    if not ok:
        print('FAIL:', label)

def read(rel):
    return (ROOT/rel).read_text(encoding='utf-8')

# Production UI inventory and global visual-language audit.
prod=[]
for base in [ROOT/'app/src/main', ROOT/'feature']:
    if not base.exists():
        continue
    for p in base.rglob('*.kt'):
        s=p.as_posix()
        if base.name == 'feature' and '/src/main/' not in s:
            continue
        if '/build/' not in s:
            prod.append(p)
prod=sorted(set(prod))
check('production Kotlin inventory', len(prod) >= 100)
legacy_import=re.compile(r'^import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', re.M)
dp=re.compile(r'\b\d+(?:\.\d+)?\.dp\b')
sp=re.compile(r'\b\d+(?:\.\d+)?\.sp\b')
raw=re.compile(r'Color\s*\(\s*0x[0-9A-Fa-f]+|#[0-9A-Fa-f]{6,8}')
fixed_icons=('Icons.Outlined.ArrowBack','Icons.Outlined.ArrowForward','Icons.Outlined.ChevronLeft','Icons.Outlined.ChevronRight','Icons.Outlined.KeyboardArrowLeft','Icons.Outlined.KeyboardArrowRight','Icons.Outlined.Send')
viol={k:[] for k in ['legacy','dp','sp','raw','fixed','todo']}
for p in prod:
    src=p.read_text(encoding='utf-8')
    rel=str(p.relative_to(ROOT))
    if legacy_import.search(src): viol['legacy'].append(rel)
    if dp.search(src): viol['dp'].append(rel)
    if sp.search(src): viol['sp'].append(rel)
    if raw.search(src): viol['raw'].append(rel)
    if any(x in src for x in fixed_icons): viol['fixed'].append(rel)
    if re.search(r'\b(?:TODO|FIXME|HACK)\b',src): viol['todo'].append(rel)
for key,label in [('legacy','no legacy Design System imports'),('dp','no direct visual dp literals'),('sp','no direct sp literals'),('raw','no raw visual colors'),('fixed','no fixed RTL-sensitive directional icons'),('todo','no TODO/FIXME/HACK in production UI')]:
    check(label, not viol[key])

legacy_dir=ROOT/'core/designsystem/src/main/java/com/optimal/fleet/designsystem/component'
check('retired legacy component source set absent', not [p for p in legacy_dir.glob('*.kt') if p.is_file()])
check('v2 component library exists', (legacy_dir/'v2').is_dir())

# Navigation smoke checks: current IA only, no new routing.
nav=read('app/src/main/java/com/optimal/fleet/navigation/OptimalNavGraph.kt')
for graph in ['homeGraph(','vehiclesGraph(','maintenanceGraph(','financeGraph(','settingsGraph(','vertoGraph()','notificationsGraph(','authGraph(']:
    check('nav graph composed '+graph, graph in nav)
for route in ['MAINTENANCE_CREATE_ROUTE','MAINTENANCE_ROUTE','FINANCE_ROUTE','NOTIFICATIONS_ROUTE','ACCOUNT_ROUTE','AUTH_ROUTE','HOME_ROUTE','VertoDestination.CONVERSATION']:
    check('nav route referenced '+route, route in nav)
check('invoice details route remains wired', 'invoiceDetailsRoute(invoiceId)' in nav)
finance_nav=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/navigation/FinanceNavigation.kt')
check('Finance Dashboard remains production root', 'FinanceDashboardConnected(onInvoiceSelected = onInvoiceSelected)' in finance_nav)
check('Invoice Details remains production destination', 'InvoiceDetailsConnected()' in finance_nav)
check('standalone InvoiceListConnected not silently wired during stabilization', 'InvoiceListConnected' not in finance_nav)

# Dead UI cleanup and documented uncertainty.
maintenance=read('feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsComponents.kt')
check('dead SoftIcon helper removed', 'fun SoftIcon(' not in maintenance)
allprod='\n'.join(p.read_text(encoding='utf-8') for p in prod)
check('SoftIcon has no production reference', 'SoftIcon' not in allprod)
invoice_route=read('feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceListRoute.kt')
check('existing alternate Invoice List entry retained', 'fun InvoiceListConnected(' in invoice_route)

# Final source-of-truth docs.
state=read('docs/design-system/CURRENT-DESIGN-STATE.md')
ledger=read('docs/design-system/MIGRATION-LEDGER.md')
debt=read('docs/design-system/DESIGN-DEBT.md')
catalog=read('docs/design-system/COMPONENT-CATALOG.md')
check('current state is v89', '# CURRENT DESIGN STATE — v89' in state)
check('migration declared complete', 'Migration status:** Complete' in state)
check('v89 stabilization recorded', 'SESSION-89 stabilization' in state)
check('Invoice List navigation status documented', 'DD-89-01' in state)
check('final ledger row migrated', '| Final Audit + Stabilization | Migrated | v89 | No |' in ledger)
for area in ['Foundations','Core Components','App Shell','Home','Vehicles List','Vehicle Details','Vehicle Editor','Maintenance List + History','Maintenance Details + Completion','Create Operation + Follow-up','Finance Dashboard + Invoice List','Invoice Details + Add Cost','Settings + Account + Members + Activity','Auth + Join Company + Notifications','Verto Chat Structure','Verto Chat UX','Global Consistency + Accessibility','Final Audit + Stabilization']:
    line=next((x for x in ledger.splitlines() if f'| {area} |' in x), '')
    check('ledger terminal status '+area, '| Migrated |' in line or '| Exception |' in line)
check('no ledger work left Not started', '| Not started |' not in ledger)
check('no ledger work left In progress', '| In progress |' not in ledger)
check('dead UI debt closed', 'DD-89-02' in debt and 'removed' in debt.lower())
check('inactive Invoice List debt documented', 'DD-89-01' in debt and 'InvoiceListConnected' in debt)
check('Gradle verification blocker documented', 'RV-89-01' in debt and 'gradle-wrapper.jar' in debt)
check('component catalog closes at v89', 'SESSION-89 final audit' in catalog)

# Test-source / DS audit presence.
foundation_test=ROOT/'core/designsystem/src/test/java/com/optimal/fleet/designsystem/FoundationContractTest.kt'
ui_test=ROOT/'core/designsystem/src/androidTest/java/com/optimal/fleet/designsystem/DesignSystemComponentTest.kt'
check('foundation Design System test source exists', foundation_test.is_file())
check('Design System UI test source exists', ui_test.is_file())
check('Design System UI test uses v2', 'component.v2.' in ui_test.read_text(encoding='utf-8'))
for feature in ['auth','finance','home','maintenance','notifications','settings','vehicles','verto']:
    android_test=ROOT/f'feature/{feature}/src/androidTest'
    unit_test=ROOT/f'feature/{feature}/src/test'
    check('feature test source available '+feature, android_test.exists() or unit_test.exists())

# Build-wrapper truthfulness.
check('Gradle wrapper script exists', (ROOT/'gradlew').is_file())
check('Gradle wrapper properties exist', (ROOT/'gradle/wrapper/gradle-wrapper.properties').is_file())
check('missing wrapper JAR remains explicit environment blocker', not (ROOT/'gradle/wrapper/gradle-wrapper.jar').exists())

failed=[x for x,ok in checks if not ok]
print(f'v89 final UX audit: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    for x in failed: print(' -',x)
    raise SystemExit(1)
