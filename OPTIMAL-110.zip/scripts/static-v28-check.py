#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


def transaction_ranges(source: str) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []
    marker = "transactionRunner.run"
    start = 0
    while True:
        pos = source.find(marker, start)
        if pos < 0:
            return ranges
        brace = source.find("{", pos)
        if brace < 0:
            return ranges
        depth = 0
        quote: str | None = None
        escaped = False
        line_comment = False
        block_comment = False
        i = brace
        while i < len(source):
            c = source[i]
            n = source[i + 1] if i + 1 < len(source) else ""
            if line_comment:
                if c == "\n":
                    line_comment = False
                i += 1
                continue
            if block_comment:
                if c == "*" and n == "/":
                    block_comment = False
                    i += 2
                else:
                    i += 1
                continue
            if quote:
                if escaped:
                    escaped = False
                elif c == "\\":
                    escaped = True
                elif c == quote:
                    quote = None
                i += 1
                continue
            if c == "/" and n == "/":
                line_comment = True
                i += 2
                continue
            if c == "/" and n == "*":
                block_comment = True
                i += 2
                continue
            if c in {'"', "'"}:
                quote = c
                i += 1
                continue
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    ranges.append((pos, i + 1))
                    start = i + 1
                    break
            i += 1
        else:
            return ranges


def audits_are_transactional(source: str) -> bool:
    ranges = transaction_ranges(source)
    indexes = [m.start() for m in re.finditer(r"auditPort\.append\(", source)]
    return bool(indexes) and all(any(a <= idx < b for a, b in ranges) for idx in indexes)


required = [
    "docs/sessions/v28.md",
    "docs/atomic-writes-v28.md",
    "docs/verification-scripts-v28.md",
    "docs/source-archive-v28.sha256",
    "scripts/static-v28-check.py",
    "scripts/v28-atomic-contract.py",
    "scripts/v28-atomic-harness.kt",
    "scripts/run-v28-atomic-harness.sh",
    "scripts/verify-v28-static.sh",
    "scripts/verify-v28-regressions.sh",
    "PATCH_MANIFEST-v28.md",
    "CHANGED_FILES-v28.txt",
    "DELETED_FILES-v28.txt",
    "verification-v28.md",
    "docs/verifications/verification-v28.md",
    "core/model/src/main/kotlin/com/optimal/fleet/core/model/transaction/AtomicWriteTransactionRunner.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/transaction/RoomAtomicWriteTransactionRunner.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/transaction/AtomicWriteTransactionModule.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncOutboxEntryFactory.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/sync/LocalWriteVersion.kt",
    "core/database/src/androidTest/java/com/optimal/fleet/core/database/AtomicWriteRollbackV28Test.kt",
    "core/database/src/test/java/com/optimal/fleet/core/database/sync/SyncOutboxEntryFactoryTest.kt",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 23", bool(re.search(r"\bversionCode\s*=\s*23\b", build)))
check("versionName is v28", 'versionName = "0.28.0-v28"' in build)

contract = read("core/model/src/main/kotlin/com/optimal/fleet/core/model/transaction/AtomicWriteTransactionRunner.kt")
room_runner = read("core/database/src/main/java/com/optimal/fleet/core/database/transaction/RoomAtomicWriteTransactionRunner.kt")
module = read("core/database/src/main/java/com/optimal/fleet/core/database/transaction/AtomicWriteTransactionModule.kt")
database_build = read("core/database/build.gradle.kts")
check("atomic transaction contract is infrastructure-free", "interface AtomicWriteTransactionRunner" in contract and "androidx." not in contract and "core.database" not in contract)
check("Room runner uses withTransaction", "database.withTransaction" in room_runner and ": AtomicWriteTransactionRunner" in room_runner)
check("Hilt binds the Room runner", all(token in module for token in ["@Binds", "RoomAtomicWriteTransactionRunner", "AtomicWriteTransactionRunner"]))
check("database can depend on the pure transaction contract", 'implementation(project(":core:model"))' in database_build)

factory = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncOutboxEntryFactory.kt")
version = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/LocalWriteVersion.kt")
check("one central outbox factory exists", "object SyncOutboxEntryFactory" in factory)
check("outbox id equals idempotency key", "id = key" in factory and "idempotencyKey = key" in factory)
check("stable key includes aggregate, operation and version", '"$aggregateType:$aggregateId:$operationType:$localVersion"' in factory)
check("outbox factory does not use random identity", all(token not in factory for token in ["UUID", "randomUUID", "newId("]))
check("outbox timestamps derive from the captured local version", all(token in factory for token in ["createdAtEpochMillis = localVersion", "updatedAtEpochMillis = localVersion"]))
check("local write versions are monotonic", "maxOf(clockMillis, previousVersion + 1L)" in version)
check("local write version prevents overflow", "previousVersion == Long.MAX_VALUE" in version)

queue = read("core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt")
vehicle_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt")
operation_tx = read("core/database/src/main/java/com/optimal/fleet/core/database/maintenance/MaintenanceOperationTransactions.kt")
followup_tx = read("core/database/src/main/java/com/optimal/fleet/core/database/maintenance/MaintenanceFollowUpTransactions.kt")
check("queue keeps IGNORE for logical retry", "suspend fun enqueue(operation" in queue and "OnConflictStrategy.IGNORE" in queue)
required_match = re.search(r"@Insert\(onConflict\s*=\s*OnConflictStrategy\.ABORT\)\s*suspend fun enqueueRequired", queue)
check("atomic writers have an ABORT outbox insert", bool(required_match))
check("vehicle transaction uses ABORT for its outbox", bool(re.search(r"@Insert\(onConflict\s*=\s*OnConflictStrategy\.ABORT\)\s*suspend fun insertSyncOperation", vehicle_dao)))
check("maintenance operation transactions require outbox insertion", operation_tx.count("enqueueRequired") >= 3, str(operation_tx.count("enqueueRequired")))
check("maintenance follow-up transaction requires outbox insertion", "enqueueRequired" in followup_tx)
check("atomic maintenance transactions never call the IGNORE enqueue", "syncQueueDao.enqueue(" not in operation_tx and "syncQueueDao.enqueue(" not in followup_tx)

repo_paths = {
    "vehicles": "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt",
    "maintenance create": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt",
    "maintenance edit": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt",
    "maintenance complete": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt",
    "maintenance follow-up": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt",
    "maintenance import": "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/RoomMaintenanceImportPort.kt",
    "invoice projection": "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomInvoiceProjectionRepository.kt",
    "additional cost": "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomAdditionalCostRepository.kt",
}
repo_sources = {name: read(path) for name, path in repo_paths.items()}
for name, source in repo_sources.items():
    check(f"{name} injects the transaction boundary", "AtomicWriteTransactionRunner" in source and "transactionRunner" in source)
    check(f"{name} unified audit writes are inside the transaction", audits_are_transactional(source))

vehicle_repo = repo_sources["vehicles"]
maintenance_repo = "\n".join(repo_sources[name] for name in [
    "maintenance create", "maintenance edit", "maintenance complete", "maintenance follow-up",
])
invoice_repo = repo_sources["invoice projection"]
cost_repo = repo_sources["additional cost"]
check("vehicle create/update/archive are transaction-wrapped", vehicle_repo.count("transactionRunner.run") >= 2)
check("vehicle identical save is a no-op", "existing.matches(" in vehicle_repo)
check("vehicle write uses monotonic local version", vehicle_repo.count("LocalWriteVersion.next") >= 2)
check("maintenance create/update/complete/convert are transaction-wrapped", maintenance_repo.count("transactionRunner.run") >= 4, str(maintenance_repo.count("transactionRunner.run")))
check("maintenance completion does not re-read after commit", "requireNotNull(maintenanceReadDao.findById" not in maintenance_repo and "completed.toDomain()" in maintenance_repo)
check("maintenance local writes use monotonic versions", maintenance_repo.count("LocalWriteVersion.next") >= 4, str(maintenance_repo.count("LocalWriteVersion.next")))
check("invoice projection captures one clock value per write branch", "val now = clock.millis()" in invoice_repo and "cachedAt = now" in invoice_repo)
check("additional costs remain explicitly local-only", "SYNC_LOCAL_ONLY" in cost_repo)

vehicle_factory = read("feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleSyncOperationFactory.kt")
maintenance_factory = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/MaintenanceSyncOperationFactory.kt")
for name, source in [("vehicle", vehicle_factory), ("maintenance", maintenance_factory)]:
    check(f"{name} outbox factory delegates to the central contract", "SyncOutboxEntryFactory.create" in source)
    check(f"{name} outbox factory has no random queue id", all(token not in source for token in ["queueId", "UUID.randomUUID", "identityFactory.newId"]))

android_test = read("core/database/src/androidTest/java/com/optimal/fleet/core/database/AtomicWriteRollbackV28Test.kt")
unit_test = read("core/database/src/test/java/com/optimal/fleet/core/database/sync/SyncOutboxEntryFactoryTest.kt")
check("Room rollback suite contains at least seven tests", len(re.findall(r"@Test\b", android_test)) >= 7, str(len(re.findall(r"@Test\b", android_test))))
for domain in ["vehicle", "maintenance", "invoice", "additionalCost"]:
    check(f"rollback suite covers {domain}", domain.lower() in android_test.lower())
check("rollback suite intentionally fails data", "dataFailureStopsAuditAndOutbox" in android_test)
check("rollback suite intentionally fails audit", "AuditFailureRollsBack" in android_test)
check("rollback suite intentionally fails outbox", "OutboxFailureRollsBack" in android_test)
check("rollback suite verifies successful all-part commit", "successfulVehicleWriteCommitsDataAuditAndOutboxTogether" in android_test)
check("unit suite validates stable idempotency", "identicalLogicalWriteProducesStableIdAndIdempotencyKey" in unit_test)
check("unit suite validates version monotonicity", "localWriteVersionIsMonotonic" in unit_test)
check("unit suite validates overflow protection", "exhaustedVersionCannotWrap" in unit_test)

schema_dir = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
schema_files = sorted(path.name for path in schema_dir.glob("*.json"))
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
check("Room remains version 1 with only 1.json", "version = 1" in database and schema_files == ["1.json"])
try:
    schema = json.loads((schema_dir / "1.json").read_text(encoding="utf-8"))
except Exception as error:
    schema = {}
    check("Room schema JSON is valid", False, str(error))
else:
    check("Room schema JSON is valid", True)
entities = schema.get("database", {}).get("entities", [])
check("Room schema remains 18 tables", len(entities) == 18, str(len(entities)))
check("Room schema remains 219 columns", sum(len(entity.get("fields", [])) for entity in entities) == 219)
check("Room schema remains 91 indices", sum(len(entity.get("indices", [])) for entity in entities) == 91)
check("Room schema remains 35 foreign keys", sum(len(entity.get("foreignKeys", [])) for entity in entities) == 35)

source_hash = read("docs/source-archive-v28.sha256").strip()
check("v27 source archive SHA-256 is recorded", bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-full-v27\.zip", source_hash)), source_hash)

for script in [
    "scripts/static-v28-check.py",
    "scripts/v28-atomic-contract.py",
    "scripts/static-architecture-check.py",
    "scripts/room-schema-drift-contract.py",
]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid, detail = True, ""
    except py_compile.PyCompileError as error:
        valid, detail = False, str(error)
    check(f"Python syntax valid: {script}", valid, detail)

for script in [
    "scripts/verify-project.sh",
    "scripts/run-v28-atomic-harness.sh",
    "scripts/verify-v28-static.sh",
    "scripts/verify-v28-regressions.sh",
]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result.returncode == 0, result.stderr.strip())

verify_project = read("scripts/verify-project.sh")
check("verify-project invokes v28 gates", "verify-v28-static.sh" in verify_project and "verify-v28-regressions.sh" in verify_project)
check("v28 static gate compiles the focused Kotlin harness", "run-v28-atomic-harness.sh" in read("scripts/verify-v28-static.sh"))
check("verify-project retains Gradle gates", all(command in verify_project for command in [
    "./gradlew clean",
    "./gradlew testDebugUnitTest",
    "./gradlew lintDebug",
    "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV28 atomic-write checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
