#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
python3 scripts/static-architecture-check.py
python3 scripts/static-v34-check.py
python3 scripts/generate-room-baseline.py --check
python3 scripts/room-schema-drift-contract.py
./scripts/run-v34-maintenance-domain-compile.sh
./scripts/run-v34-maintenance-data-compile.sh
./scripts/run-v34-maintenance-presentation-compile.sh
./scripts/run-v34-maintenance-tests-compile.sh
./scripts/run-v34-maintenance-route-syntax-check.sh
