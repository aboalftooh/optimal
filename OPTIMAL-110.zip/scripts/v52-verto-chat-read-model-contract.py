#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v52 local Verto chat read model and screen."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "message_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoMessageDao.kt",
    "attachment_dao": ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto/VertoAttachmentDao.kt",
    "model": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/model/VertoMessage.kt",
    "repository_contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/repository/VertoConversationRepository.kt",
    "repository": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/data/RoomVertoConversationRepository.kt",
    "usecases": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain/usecase/VertoAuthorizationUseCases.kt",
    "contract": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt",
    "viewmodel": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt",
    "screen": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatScreen.kt",
    "entry": ROOT / "feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt",
    "unit": ROOT / "feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoChatContractTest.kt",
}
checks = []

def check(name, condition):
    checks.append((name, bool(condition)))
    if not condition:
        raise AssertionError(name)

def text(key):
    return FILES[key].read_text(encoding="utf-8")

for name, path in FILES.items():
    check(f"exists:{name}", path.is_file())

dao = text("message_dao")
for token in ["observeLatestPage", "observeCount", "LIMIT :limit", "COALESCE(serverCreatedAtEpochMillis, localCreatedAtEpochMillis)", "COALESCE(remoteId, clientMessageId, id)"]:
    check(f"message dao:{token}", token in dao)
check("message paging newest first in SQL", "DESC" in dao)
attachments = text("attachment_dao")
check("conversation attachment observation", "observeForConversation" in attachments)
check("attachment order stable", "createdAtEpochMillis ASC, id ASC" in attachments)

model = text("model")
for token in ["localId", "stableIdentity", "sortTimestampEpochMillis", "VertoMessagePage", "hasOlderMessages", "failureCode"]:
    check(f"model:{token}", token in model)
for token in ["PENDING", "SENDING", "SENT", "FAILED_RETRYABLE", "FAILED_TERMINAL"]:
    check(f"delivery state:{token}", token in model)
for token in ["IMAGE", "VIDEO", "AUDIO", "DOCUMENT"]:
    check(f"attachment kind:{token}", token in model)

contract = text("repository_contract")
check("repository paging contract", "limit: Int" in contract and "Flow<VertoMessagePage>" in contract)
repo = text("repository")
for token in ["observeLatestPage", "observeCount", "observeForConversation", "combine(", "sortedWith", "thenBy { it.stableIdentity }", "VertoMessagePage"]:
    check(f"repository:{token}", token in repo)
read_section = repo.split("override suspend fun refresh", 1)[0]
check("repository read stream stays Room only", all(x not in read_section for x in ["remoteDataSource.pull", "Retrofit", "HttpClient"]))
check("invalid attachment skipped", "mapNotNull(VertoAttachmentEntity::toDomainOrNull)" in repo)
check("no signed URL cached", "remoteObjectPath = dto.signedUrl" not in repo and "publicUrl" not in repo)

usecases = text("usecases")
check("messages require authorization", "VertoChatOperation.OBSERVE_MESSAGES" in usecases)
check("page limit is positive", "limit.coerceAtLeast(1)" in usecases)

ui_contract = text("contract")
for token in ["messages: List<VertoMessage>", "loadingOlder", "hasOlderMessages", "accessDenied", "LoadOlder", "Retry"]:
    check(f"ui contract:{token}", token in ui_contract)

vm = text("viewmodel")
for token in ["PAGE_SIZE = 30", "pageLimit", "flatMapLatest", "ObserveVertoLinkState", "ObserveVertoMessages", "LoadOlder", "hasOlderMessages", "messages.isEmpty()", "CancellationException"]:
    check(f"viewmodel:{token}", token in vm)
check("viewmodel preserves cached messages on error", "it.copy(" in vm and "loadingOlder = false" in vm and "تعذر قراءة الرسائل المحلية." in vm)
check("presentation no DAO", "Dao" not in vm and "core.database" not in vm and ".data." not in vm)

screen = text("screen")
for token in ["VertoChatScreen", "verto-message-list", "verto-load-older", "counterpartyDisplayName", "senderDisplayName", "senderRole", "FAILED_RETRYABLE", "FAILED_TERMINAL", "تحميل رسائل أقدم", "لا توجد رسائل", "إعادة المحاولة", "المحادثة محفوظة محليًا"]:
    check(f"screen:{token}", token in screen)
for token in ["صورة", "فيديو", "رسالة صوتية", "مستند"]:
    check(f"preview:{token}", token in screen)
check("stable LazyColumn key", "key = VertoMessage::stableIdentity" in screen or "key = { it.stableIdentity }" in screen)
check("cached error does not replace list", "state.errorMessage?.let" in screen)
check("screen no network", all(x not in screen for x in ["Retrofit", "Supabase", "HttpClient", "core.database", ".data."]))

entry = text("entry")
check("entry uses chat viewmodel", "VertoChatViewModel" in entry)
check("entry delegates full screen", "VertoChatScreen" in entry)

unit = text("unit")
for token in ["equalTimestampsUseStableIdentity", "cachedPageReportsOlderMessages", "unknownRoleCanRemainBlankForUiFallback", "failedMessageRemainsInReadModel"]:
    check(f"unit:{token}", token in unit)

database_source = (ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt").read_text(encoding="utf-8")
check("Room v2 lineage remains available", "version = 2" in database_source or "version = 3" in database_source)
check("published Room v2 schema remains available", (ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase/2.json").is_file())
check("Android version remains stable", "versionCode = 32" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
check("no v52 database migration", not any((ROOT / "supabase/migrations").glob("*v52*")))
check("v53 does not bypass Room read model", "remoteDataSource" not in vm and "Retrofit" not in vm and "core.network" not in vm)

print(f"v52 Verto chat read-model contract: {len(checks)}/{len(checks)} PASS")
