#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/AuthRemoteDataSource.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthRemoteDataSource.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/OnboardingRemoteDataSource.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseOnboardingRemoteDataSource.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/LocalSessionStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/RoomAuthLocalSessionStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/PendingChallengeStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/AndroidKeystorePendingChallengeStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/RemoteProfileStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/RoomRemoteProfileStore.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/mapper/AuthFailureMapper.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/mapper/OnboardingMapper.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/audit/MembershipAuditPort.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/audit/MembershipAuditWriter.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/RestorePendingOnboardingUseCase.kt",
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/usecase/DiscardPendingOnboardingUseCase.kt",
    "scripts/v31-auth-harness.kt",
    "scripts/run-v31-auth-harness.sh",
    "scripts/static-v31-check.py",
    "scripts/verify-v31-static.sh",
    "scripts/verify-v31-regressions.sh",
    "docs/auth-process-recreation-v31.md",
    "docs/sessions/v31.md",
    "docs/verification-scripts-v31.md",
    "docs/source-archive-v31.sha256",
    "verification-v31.md",
    "docs/verifications/verification-v31.md",
    "PATCH_MANIFEST-v31.md",
    "CHANGED_FILES-v31.txt",
    "DELETED_FILES-v31.txt",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 26", bool(re.search(r"\bversionCode\s*=\s*26\b", build)))
check("versionName is v31", 'versionName = "0.31.0-v31"' in build)

coordinator_path = "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/SupabaseOnboardingRepository.kt"
coordinator = read(coordinator_path)
check("repository is coordinator-sized", len(coordinator.splitlines()) <= 360, str(len(coordinator.splitlines())))
check("coordinator has no Retrofit dependency", "retrofit" not in coordinator.lower())
check("coordinator has no Android Context dependency", "android.content" not in coordinator)
check("coordinator has no Room DAO dependency", not re.search(r"\b[A-Za-z]+Dao\b", coordinator))
check("coordinator delegates auth remote", "AuthRemoteDataSource" in coordinator)
check("coordinator delegates onboarding remote", "OnboardingRemoteDataSource" in coordinator)
check("coordinator delegates local session", "LocalSessionStore" in coordinator)
check("coordinator delegates pending flow", "PendingChallengeStore" in coordinator)
check("coordinator delegates profile persistence", "RemoteProfileStore" in coordinator)
check("legacy in-memory challenge map removed", "ConcurrentHashMap" not in coordinator)

for guard in ["otpRequestInFlight", "otpVerificationInFlight", "completionInFlight"]:
    check(f"in-flight guard exists: {guard}", guard in coordinator and "compareAndSet(false, true)" in coordinator)
check("request duplicate has typed result", "OtpRequestResult.RequestInProgress" in coordinator)
check("verification duplicate has typed result", "OtpVerificationResult.RequestInProgress" in coordinator)
check("completion duplicate has typed result", "OnboardingCompletionResult.RequestInProgress" in coordinator)
check("guards reset in finally", coordinator.count(".set(false)") >= 3 and coordinator.count("finally") >= 3)

models = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/model/OnboardingModels.kt")
contract = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain/repository/OnboardingRepository.kt")
check("pending flow stores challenge and expiry", all(x in models for x in ["challengeId: String?", "expiresAtEpochMillis: Long", "PendingOnboardingStage"]))
check("pending flow stores process stage", all(x in models for x in ["OtpPending", "OtpVerified"]))
check("repository exposes pending restoration", "restorePendingOnboarding" in contract)
check("repository exposes pending discard", "discardPendingOnboarding" in contract)

pending_store = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/AndroidKeystorePendingChallengeStore.kt")
check("pending store uses Android Keystore", all(x in pending_store for x in ["AndroidKeyStore", "KeyGenParameterSpec", "AES/GCM/NoPadding"]))
check("pending payload is encrypted", all(x in pending_store for x in ["Cipher.ENCRYPT_MODE", "doFinal", "KEY_PAYLOAD"]))
check("pending store rejects plaintext fallback", "putString(KEY_PAYLOAD" in pending_store and "Base64.encodeToString(encrypted" in pending_store)
match = re.search(r"private data class PendingChallengeSnapshot\((.*?)\n\s*\)\s*\{", pending_store, re.S)
snapshot = match.group(1) if match else ""
field_names = re.findall(r"\bval\s+([A-Za-z][A-Za-z0-9_]*)\s*:", snapshot)
allowed_fields = {
    "challengeId", "mode", "joinCode", "normalizedPhone", "companyName",
    "expiresAtEpochMillis", "stage",
}
check("pending snapshot parsed", bool(snapshot), "snapshot not found")
check("pending snapshot contains only flow metadata", set(field_names) == allowed_fields, repr(field_names))
check("OTP is never a persisted field", not any(name.lower() in {"otp", "code", "token"} for name in field_names), repr(field_names))
check("password is never a persisted field", not any("password" in name.lower() for name in field_names), repr(field_names))
check("no OTP serialization key", not re.search(r'@SerialName\("(?:otp|code|token|password)"\)', snapshot, re.I))

check("expired pending challenge is cleared", "pending.expiresAtEpochMillis <= clock.millis()" in coordinator and "RestorePendingOnboardingResult.Expired" in coordinator)
check("used challenge id is invalidated", "challengeId = null" in coordinator and "PendingOnboardingStage.OtpVerified" in coordinator)
check("failed verified persistence rolls back auth session", "localSessionStore.clearAuthSession()" in coordinator)
check("pre-membership restore preserves verified auth session", "profile == null && hasUsableVerifiedPendingFlow()" in coordinator and "localSessionStore.clearActiveSession()" in coordinator)
check("verified pending flow requires unexpired null challenge", all(token in coordinator for token in ["pending.stage == PendingOnboardingStage.OtpVerified", "pending.challengeId == null", "pending.expiresAtEpochMillis > clock.millis()"]))
check("completion clears pending flow", "pendingChallengeStore.clear()" in coordinator and "OnboardingCompletionResult.Success" in coordinator)
check("sign-out clears pending and local sessions", "pendingChallengeStore.clear()" in coordinator.split("override suspend fun signOut", 1)[1] and "localSessionStore.clearAll()" in coordinator.split("override suspend fun signOut", 1)[1])

view_model = read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AuthViewModel.kt")
check("ViewModel restores pending flow after session restore", "restorePendingFlow()" in view_model and "restorePendingOnboarding()" in view_model)
check("ViewModel restores OTP screen", "PendingOnboardingStage.OtpPending -> OnboardingStep.Otp" in view_model)
check("ViewModel restores company data screen", "PendingOnboardingStage.OtpVerified -> OnboardingStep.CompanyData" in view_model)
check("restored OTP input is always empty", 'otp = ""' in view_model)
check("back/restart discard pending flow", view_model.count("discardPendingOnboarding()") >= 2)

test = read("feature/auth/src/test/java/com/optimal/fleet/feature/auth/presentation/AuthViewModelTest.kt")
check("process recreation ViewModel test exists", "restoresPendingOtpAfterProcessRecreation" in test)
check("process recreation test proves OTP absence", 'assertEquals("", viewModel.state.value.otp)' in test)
for fake_path in [
    "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/OnboardingUseCasesTest.kt",
    "feature/auth/src/test/java/com/optimal/fleet/feature/auth/domain/usecase/SessionUseCasesTest.kt",
    "feature/auth/src/test/java/com/optimal/fleet/feature/auth/presentation/AuthViewModelTest.kt",
    "app/src/test/java/com/optimal/fleet/session/SessionGateViewModelTest.kt",
    "scripts/v19-domain-harness.kt",
]:
    fake = read(fake_path)
    check(f"repository fake implements pending restore: {fake_path}", "restorePendingOnboarding" in fake)
    check(f"repository fake implements pending discard: {fake_path}", "discardPendingOnboarding" in fake)
harness = read("scripts/v31-auth-harness.kt")
check("auth harness has at least 25 assertions", harness.count("verify(") >= 25, str(harness.count("verify(")))
for scenario in ["request succeeds", "pending flow survives recreation", "verification succeeds", "expired challenge rejected", "duplicate request rejected", "session restored", "sign-out clears"]:
    check(f"harness scenario: {scenario}", scenario in harness)

# Clear responsibility: data files stay focused and remote boundaries own broad catches.
focused_limits = {
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthRemoteDataSource.kt": 160,
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseOnboardingRemoteDataSource.kt": 210,
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/AndroidKeystorePendingChallengeStore.kt": 180,
    "feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/local/RoomRemoteProfileStore.kt": 210,
}
for path, limit in focused_limits.items():
    count = len(read(path).splitlines())
    check(f"single-responsibility size: {path}", count <= limit, f"{count}>{limit}")

remote_sources = [
    read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseAuthRemoteDataSource.kt"),
    read("feature/auth/src/main/java/com/optimal/fleet/feature/auth/data/remote/SupabaseOnboardingRemoteDataSource.kt"),
]
check("remote boundaries preserve cancellation", all("throw cancellation" in x for x in remote_sources))
check("remote boundaries map broad exceptions", all("failureMapper.fromThrowable" in x for x in remote_sources))
check("coordinator has no broad Exception catch", not re.search(r"catch\s*\([^)]*:\s*Exception\)", coordinator))

verify_project = read("scripts/verify-project.sh")
check("project verification invokes v31 static", "./scripts/verify-v31-static.sh" in verify_project)
check("project verification invokes v31 regressions", "./scripts/verify-v31-regressions.sh" in verify_project)
check("full Android gates remain declared", all(cmd in verify_project for cmd in [
    "./gradlew clean", "./gradlew testDebugUnitTest", "./gradlew lintDebug",
    "./gradlew assembleDebug", "./gradlew :core:database:connectedDebugAndroidTest",
]))

for script in ["scripts/static-v31-check.py"]:
    result = subprocess.run([sys.executable, "-m", "py_compile", str(ROOT / script)], capture_output=True, text=True)
    check(f"python syntax: {script}", result.returncode == 0, result.stderr)
for script in ["scripts/run-v31-auth-harness.sh", "scripts/verify-v31-static.sh", "scripts/verify-v31-regressions.sh"]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax: {script}", result.returncode == 0, result.stderr)

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    suffix = f" — {detail}" if detail and not ok else ""
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f"\nV31 auth/process-recreation checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
