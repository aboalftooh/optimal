#!/usr/bin/env python3
"""Validate backend contracts against the checked-in Supabase migrations."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = ROOT / "supabase" / "migrations"


def normalized_sql() -> str:
    parts = []
    for path in sorted(MIGRATIONS.glob("*.sql")):
        parts.append(f"\n-- {path.name}\n{path.read_text(encoding='utf-8').lower()}")
    if not parts:
        raise AssertionError("no Supabase migrations found")
    return "".join(parts)


def expect(name: str, condition: bool, counts: list[int]) -> None:
    counts[1] += 1
    if not condition:
        raise AssertionError(name)
    counts[0] += 1
    print(f"PASS: {name}")


def main() -> None:
    sql = normalized_sql()
    counts = [0, 0]

    expect("RLS is enabled", "enable row level security" in sql, counts)
    expect("company membership is checked", "optimal_members" in sql, counts)
    expect("tenant identity is derived from auth", "auth.uid()" in sql, counts)
    expect("security definer functions pin search_path", "security definer" in sql and "set search_path" in sql, counts)
    expect("public execution is revoked", "revoke all" in sql and "from public" in sql, counts)
    expect("authenticated execution is granted explicitly", "grant execute" in sql and "to authenticated" in sql, counts)
    expect("member capability checks exist", "optimal_member_has_capability" in sql, counts)
    expect("member permission policies exist", "optimal_members_permissions_check" in sql and "create policy" in sql, counts)
    expect("Verto link table is tenant scoped", "optimal_verto_links" in sql and "optimal_company_id" in sql, counts)
    expect("Verto snapshot source version exists", "source_updated_at" in sql, counts)
    expect("stale Verto writes are guarded", bool(re.search(r"source_updated_at\s*(?:>=|>|<=|<)", sql)), counts)
    expect("backend readiness migration exists", "optimal_backend_readiness" in sql, counts)
    expect("direct Verto link migration exists", "optimal_verto_direct_link" in sql, counts)
    expect("permission RLS migration exists", "optimal_member_permissions_rls" in sql, counts)

    print(f"V21 backend SQL contract harness: {counts[0]}/{counts[1]}")


if __name__ == "__main__":
    main()
