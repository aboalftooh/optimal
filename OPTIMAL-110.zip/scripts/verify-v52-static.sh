#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 scripts/v52-verto-chat-read-model-contract.py
./scripts/run-v52-verto-chat-harness.sh
./scripts/run-v52-verto-chat-syntax-check.sh
./scripts/run-v36-test-syntax-check.sh
exec ./scripts/verify-v51-static.sh
