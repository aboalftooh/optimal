#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
mapfile -t FILES < <(find feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation -type f -name '*.kt' | sort)
OUT="$(mktemp)"; JAR="$(mktemp --suffix=.jar)"
trap 'rm -f "$OUT" "$JAR"' EXIT
set +e
timeout 180 kotlinc "${FILES[@]}" -d "$JAR" >"$OUT" 2>&1
STATUS=$?
set -e
if grep -Eiq 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"; then
  grep -Ein 'error: (expecting|unexpected tokens|syntax error|imports are only allowed|parameter name expected|type expected|name expected|property getter or setter expected)' "$OUT"
  exit 1
fi
if [[ $STATUS -eq 124 ]]; then echo "FAIL: Kotlin parser timed out" >&2; exit 1; fi
echo "PASS: Kotlin parser accepted ${#FILES[@]} Verto presentation files; unresolved Android symbols were intentionally ignored without classpath."
