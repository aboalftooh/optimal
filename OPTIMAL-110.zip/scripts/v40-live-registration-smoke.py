#!/usr/bin/env python3
"""Destructive staging-only smoke for v40 registration-code consumption.

Required environment:
  SUPABASE_URL, SUPABASE_ANON_KEY, V40_ACCESS_TOKEN, V40_REGISTRATION_CODE,
  V40_ALLOW_DESTRUCTIVE_TEST=true

The code must be fresh and issued for a disposable Verto client. Two concurrent
requests use the same authenticated user to simulate two devices; both must
resolve to the same company/member because replay is idempotent.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
import sys
import urllib.error
import urllib.request


def required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise SystemExit(f"Missing environment variable: {name}")
    return value


if os.environ.get("V40_ALLOW_DESTRUCTIVE_TEST") != "true":
    raise SystemExit("Refusing destructive smoke: set V40_ALLOW_DESTRUCTIVE_TEST=true on disposable staging only")

base = required("SUPABASE_URL").rstrip("/")
anon = required("SUPABASE_ANON_KEY")
token = required("V40_ACCESS_TOKEN")
code = required("V40_REGISTRATION_CODE")
display_name = os.environ.get("V40_DISPLAY_NAME", "V40 Staging Owner")


def rpc(name: str, payload: dict[str, object], access_token: str | None = None) -> tuple[int, object]:
    body = json.dumps(payload).encode("utf-8")
    headers = {
        "apikey": anon,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    request = urllib.request.Request(
        f"{base}/rest/v1/rpc/{name}",
        data=body,
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8")
            return response.status, json.loads(raw or "null")
    except urllib.error.HTTPError as error:
        raw = error.read().decode("utf-8")
        try:
            parsed: object = json.loads(raw)
        except json.JSONDecodeError:
            parsed = raw
        return error.code, parsed


status, validation = rpc("optimal_validate_verto_company_code", {"p_code": code})
if status != 200 or not isinstance(validation, list) or not validation or validation[0].get("status") != "VALID":
    raise SystemExit(f"Fresh-code validation failed: HTTP {status} {validation!r}")

payload = {"p_code": code, "p_display_name": display_name}
with ThreadPoolExecutor(max_workers=2) as executor:
    responses = list(executor.map(lambda _: rpc("optimal_complete_company_registration", payload, token), range(2)))

for status, body in responses:
    if status != 200 or not isinstance(body, list) or len(body) != 1:
        raise SystemExit(f"Concurrent consume failed: HTTP {status} {body!r}")

profiles = [body[0] for _, body in responses]
identities = {(profile.get("company_id"), profile.get("member_id")) for profile in profiles}
if len(identities) != 1:
    raise SystemExit(f"Duplicate identity produced: {profiles!r}")

retry_status, retry_body = rpc("optimal_complete_company_registration", payload, token)
if retry_status != 200 or not isinstance(retry_body, list) or retry_body[0].get("company_id") != profiles[0].get("company_id"):
    raise SystemExit(f"Idempotent replay failed: HTTP {retry_status} {retry_body!r}")

validation_status, validation_after = rpc("optimal_validate_verto_company_code", {"p_code": code})
if validation_status != 200 or not isinstance(validation_after, list) or validation_after[0].get("status") != "USED":
    raise SystemExit(f"Used-code validation failed: HTTP {validation_status} {validation_after!r}")

print("PASS concurrent same-user consumption produced one company/member")
print("PASS replay returned the original owner profile")
print("PASS code transitioned to USED")
