#!/usr/bin/env python3
"""Executable policy scenarios for OPTIMAL v63."""
from dataclasses import dataclass

checks = 0

def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)

@dataclass(frozen=True)
class Record:
    source: str
    vehicle_id: str
    invoice_total: int
    image_ids: tuple[str, ...]

records = (
    Record("VERTO", "vehicle-a", 150_00, ("img-1", "img-2")),
    Record("MANUAL", "vehicle-a", 90_00, ()),
    Record("VERTO", "vehicle-b", 210_00, ("img-3",)),
)

def history(vehicle_id):
    return [r for r in records if r.vehicle_id == vehicle_id]

def history_money(record):
    return None if record.source == "VERTO" else record.invoice_total

def temporary_access(record, image_id, authorized=True, linked=True):
    if not linked:
        return "NOT_LINKED"
    if not authorized:
        return "DENIED"
    if image_id not in record.image_ids:
        return "REJECTED"
    return {"url": "https://signed.example/image", "expires": 60, "persist": False}

vehicle_a = history("vehicle-a")
check(len(vehicle_a) == 2, "vehicle filter leaked or lost records")
check(all(r.vehicle_id == "vehicle-a" for r in vehicle_a), "cross-vehicle history leak")
check(history("missing") == [], "missing vehicle should be empty")
check(history_money(vehicle_a[0]) is None, "Verto money duplicated in history")
check(history_money(vehicle_a[1]) == 90_00, "manual money unexpectedly hidden")
check(vehicle_a[0].image_ids == ("img-1", "img-2"), "official image order changed")
access = temporary_access(vehicle_a[0], "img-1")
check(isinstance(access, dict), "authorized image access failed")
check(access["url"].startswith("https://"), "signed URL is not HTTPS")
check(access["expires"] > 0, "temporary URL does not expire")
check(access["persist"] is False, "signed URL must not be persisted")
check(temporary_access(vehicle_a[0], "img-1", authorized=False) == "DENIED", "permission denial failed")
check(temporary_access(vehicle_a[0], "img-1", linked=False) == "NOT_LINKED", "inactive link denial failed")
check(temporary_access(vehicle_a[0], "unknown") == "REJECTED", "unknown attachment accepted")
check(records[0].invoice_total == 150_00, "invoice source value changed")
check(history_money(records[0]) is None and records[0].invoice_total > 0, "source-of-truth separation failed")
print(f"v63 invoice/vehicle history harness: {checks}/{checks} PASS")
