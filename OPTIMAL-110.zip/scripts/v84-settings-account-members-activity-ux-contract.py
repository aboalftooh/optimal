#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
paths = {
    'settings_screen': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsScreen.kt',
    'settings_components': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsComponents.kt',
    'account': 'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountRoute.kt',
    'members_route': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersRoute.kt',
    'members_screen': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreen.kt',
    'members_components': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersComponents.kt',
    'members_dialogs': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersDialogs.kt',
    'activity_route': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityRoute.kt',
    'activity_screen': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityScreen.kt',
    'activity_components': 'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityComponents.kt',
    'settings_test': 'feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/SettingsScreenTest.kt',
    'members_test': 'feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/members/MembersScreenV84Test.kt',
    'activity_test': 'feature/settings/src/androidTest/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityScreenV84Test.kt',
    'account_test': 'feature/auth/src/androidTest/java/com/optimal/fleet/feature/auth/presentation/AccountRouteV84Test.kt',
}
text = {name: (root / rel).read_text() for name, rel in paths.items()}
checks = []

def check(label, cond):
    checks.append((label, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + label)

def sha(rel):
    return hashlib.sha256((root / rel).read_bytes()).hexdigest()

def tree(rel):
    h = hashlib.sha256()
    for f in sorted((root / rel).rglob('*.kt')):
        h.update(str(f.relative_to(root)).encode())
        h.update(b'\0')
        h.update(f.read_bytes())
        h.update(b'\0')
    return h.hexdigest()

target_sources = [
    'settings_screen', 'settings_components', 'account', 'members_route', 'members_screen',
    'members_components', 'members_dialogs', 'activity_route', 'activity_screen', 'activity_components',
]
for name in target_sources:
    source = text[name]
    check(f'{name} has no legacy DS import', re.search(r'import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', source) is None)
    check(f'{name} has no AppCard', 'AppCard' not in source)
    check(f'{name} has no direct dp literal', re.search(r'\b\d+(?:\.\d+)?\.dp\b', source) is None)
    check(f'{name} has no raw hex colors', '0xFF' not in source)

for token in ['SettingsCompanySummary', 'OptimalSectionHeader', 'SettingsItem', 'verticalScroll']:
    check(f'settings uses {token}', token in text['settings_screen'])
for tag in ['destination-settings', 'more-members', 'more-activity', 'more-account', 'more-notifications', 'more-help']:
    check(f'settings preserves tag {tag}', f'"{tag}"' in text['settings_screen'])
for event in ['OpenMembers', 'OpenActivity', 'OpenAccount', 'OpenNotifications']:
    check(f'settings preserves event {event}', f'SettingsUiEvent.{event}' in text['settings_screen'])
check('settings rows are flat v2 rows', 'OptimalListRow' in text['settings_components'])
check('settings uses semantic brand container', 'OptimalSemanticColors.brandContainer' in text['settings_components'])
check('settings no legacy company card', 'SettingsCompanyCard' not in text['settings_screen'] + text['settings_components'])

for token in ['OptimalLoadingState', 'OptimalSectionHeader', 'OptimalFormSection', 'OptimalTextField', 'OptimalPrimaryButton', 'OptimalDestructiveButton']:
    check(f'account uses {token}', token in text['account'])
for tag in ['destination-account', 'account-loading', 'account-user-name', 'account-company-name', 'account-workshop-toggle', 'account-save', 'account-sign-out']:
    check(f'account preserves/adds tag {tag}', f'"{tag}"' in text['account'])
for event in ['UserDisplayNameChanged', 'CompanyNameChanged', 'BusinessActivityChanged', 'CompanyAddressChanged', 'VehicleCountChanged', 'EmployeeCountChanged', 'UsesMaintenanceWorkshopChanged', 'MaintenanceWorkshopNameChanged', 'Save', 'SignOut']:
    check(f'account preserves event {event}', f'AccountProfileUiEvent.{event}' in text['account'])
for error in ['UserDisplayName', 'CompanyName', 'VehicleCount', 'EmployeeCount', 'WorkshopName']:
    check(f'account preserves field error {error}', f'AccountProfileFieldError.{error}' in text['account'])
check('account sign out is visually destructive', 'OptimalDestructiveButton' in text['account'] and 'text = "تسجيل الخروج"' in text['account'])
check('account saving disables save', 'enabled = !state.isSaving' in text['account'])

check('members route uses v2 loading', 'component.v2.OptimalLoadingState' in text['members_route'])
check('members loading tag preserved', '"members-loading"' in text['members_route'])
for token in ['OptimalSectionHeader', 'OptimalPrimaryButton', 'OptimalEmptyState', 'GeneratedInviteCodeCard', 'PendingInviteCard', 'MemberCard']:
    check(f'members screen uses {token}', token in text['members_screen'])
for tag in ['members-list', 'invite-member', 'members-empty']:
    check(f'members screen tag {tag}', f'"{tag}"' in text['members_screen'])
for token in ['OptimalListRow', 'OptimalStatusBadge', 'OptimalSecondaryButton', 'OptimalDestructiveButton', 'OptimalFormSection']:
    check(f'members components use {token}', token in text['members_components'])
check('pending invite is warning status', 'OptimalStatusTone.Warning' in text['members_components'])
check('active member is success status', 'OptimalStatusTone.Success' in text['members_components'])
check('revoke invite is destructive', 'text = "إلغاء الدعوة"' in text['members_components'] and 'OptimalDestructiveButton' in text['members_components'])
for tag in ['generated-invite-code', 'revoke-invite-${invite.id}', 'member-status-${member.id}', 'edit-verto-permissions-${member.id}']:
    check(f'members components tag {tag}', f'"{tag}"' in text['members_components'])
for token in ['OptimalDialog', 'OptimalFormSection', 'OptimalTextField']:
    check(f'members dialogs use {token}', token in text['members_dialogs'])
for tag in ['invite-name', 'invite-phone', 'create-invite-code', 'invite-verto-view', 'invite-verto-send', 'save-member-permissions', 'member-verto-view', 'member-verto-send']:
    check(f'member dialog tag {tag}', f'"{tag}"' in text['members_dialogs'])
for event in ['CloseInviteDialog', 'InviteNameChanged', 'InvitePhoneChanged', 'InviteVertoViewChanged', 'InviteVertoSendChanged', 'CreateInvite', 'CloseMemberPermissions', 'SaveMemberPermissions', 'MemberPermissionViewChanged', 'MemberPermissionSendChanged']:
    check(f'member dialog preserves event {event}', f'MembersUiEvent.{event}' in text['members_dialogs'])
for event in ['OpenInviteDialog', 'DismissGeneratedCode', 'DismissMessage', 'ResendInvite', 'RevokeInvite', 'ChangeMemberStatus', 'OpenMemberPermissions']:
    corpus = text['members_screen'] + text['members_components']
    check(f'member screen preserves event {event}', f'MembersUiEvent.{event}' in corpus)

for token in ['OptimalLoadingState', 'OptimalErrorState', 'OptimalEmptyState']:
    check(f'activity route uses {token}', token in text['activity_route'])
for tag in ['activity-loading', 'activity-error', 'activity-empty']:
    check(f'activity route tag {tag}', f'"{tag}"' in text['activity_route'])
check('activity retry event preserved', 'ActivityUiEvent.Retry' in text['activity_route'])
for token in ['LazyColumn', 'OptimalSectionHeader', 'ActivityTimelineItem', 'OptimalSecondaryButton']:
    check(f'activity screen uses {token}', token in text['activity_screen'])
check('activity load more event preserved', 'ActivityUiEvent.LoadMore' in text['activity_screen'])
check('activity load more tag preserved', '"activity-load-more"' in text['activity_screen'])
for token in ['OptimalListRow', 'OptimalStatusBadge', 'OptimalStatusTone.Info', 'IntrinsicSize.Min']:
    check(f'activity timeline uses {token}', token in text['activity_components'])
check('activity timeline keeps changed fields', 'event.changedFieldsLabel' in text['activity_components'])
check('activity timeline keeps source', 'event.sourceLabel' in text['activity_components'])
check('activity timeline keeps timestamp', 'event.timestampLabel' in text['activity_components'])

check('existing settings navigation test preserved', 'membersEntryKeepsItsNavigationContract' in text['settings_test'])
for test_name in ['inviteActionKeepsExistingEventContract', 'inviteDialogUsesExistingCreateEvent', 'revokeInviteRemainsExplicitDestructiveEvent']:
    check(f'members v84 UI test {test_name}', test_name in text['members_test'])
for test_name in ['timelineAndLoadMoreKeepExistingContract', 'errorStateKeepsRetryEvent']:
    check(f'activity v84 UI test {test_name}', test_name in text['activity_test'])
for test_name in ['profileFieldsAndSaveKeepExistingEvents', 'signOutKeepsExistingEventAndDangerHierarchy']:
    check(f'account v84 UI test {test_name}', test_name in text['account_test'])

protected_files = {
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsContract.kt': '50cf4c778109cd388d2115d0ccb557a5542c550d0a425cafa241a2b3b320e1f9',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/SettingsRoute.kt': '2469a63bed2c79f8c81a5f39c3224c5fe5aae2ba755bd8abf90c4c331e3f30c0',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersContract.kt': '683dbf6f76031e07e3797a31c3f986c83047cc23df1d07a515a0324ed8a5b34f',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/members/MembersViewModel.kt': 'f1422597725aedcdab569438448cb37908a850f959c6f58737f3b5671b89fe98',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityContract.kt': '36bcbd177a43be936f716f03019a55cc4071418f3cac39fdfad24b22948e85cd',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/presentation/activity/ActivityViewModel.kt': '6be605a28a5c7089205596801053b22492b2d75b074070afac34571629c21e23',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountProfileContract.kt': '795dae883e2f7a8cde0d52e4f10de5edfd5635eca4388c5432498e3c03dd559a',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/presentation/AccountProfileViewModel.kt': '12e8fb123d924f25aeb61bfa20353bb9332d2b329c4f90e36de819c02084add5',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/navigation/SettingsNavigation.kt': '8861804dfeae111e35eafde1f5ed32df6f4cddb9b1557c009950986f4a479df8',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/navigation/AuthNavigation.kt': '44620ce00b652d9bf83dcc22aca1dcefa3a6c61eaa759893a2500e3ce9845bcf',
}
protected_trees = {
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain': 'bcf34c3f18d22ed6a1d7209347397f9e427c51a528d19a670c73dcc2141ec647',
    'feature/settings/src/main/java/com/optimal/fleet/feature/settings/data': 'ca09349c43da216f8580d30e7da538cc65e94d3ecfaa26f49669e5a7da198e79',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/domain': '8b16d181b8b0231d0c4f6c0b703c91b056a5212102924bfad538c871b61efafa',
    'feature/auth/src/main/java/com/optimal/fleet/feature/auth/data': '39f039d3a2dbf514e678066efdddce297b25dacd5dc92f066f5e0d2616765449',
    'feature/finance/src/main/java/com/optimal/fleet/feature/finance': 'b04e0943df0a1528d62d3b4f51270774cd3f8222120624a81c39c86aa039ae13',
}
for rel, digest in protected_files.items():
    check('protected file unchanged ' + rel, sha(rel) == digest)
for rel, digest in protected_trees.items():
    check('protected tree unchanged ' + rel, tree(rel) == digest)

failed = [item for item in checks if not item[1]]
print(f'v84 Settings + Account + Members + Activity UX contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
