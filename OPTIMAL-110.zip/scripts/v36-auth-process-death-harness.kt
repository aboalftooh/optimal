package com.optimal.fleet.feature.auth.data

import com.optimal.fleet.core.network.supabase.SupabaseAuthSession
import com.optimal.fleet.core.session.ActiveSession
import com.optimal.fleet.core.testing.time.MutableTestClock
import com.optimal.fleet.feature.auth.data.audit.MembershipAuditPort
import com.optimal.fleet.feature.auth.data.local.LocalSessionStore
import com.optimal.fleet.feature.auth.data.local.PendingChallengeStore
import com.optimal.fleet.feature.auth.data.local.PersistedProfile
import com.optimal.fleet.feature.auth.data.local.RemoteProfileStore
import com.optimal.fleet.feature.auth.data.mapper.OnboardingMapper
import com.optimal.fleet.feature.auth.data.remote.AuthRemoteDataSource
import com.optimal.fleet.feature.auth.data.remote.CurrentMemberProfileResult
import com.optimal.fleet.feature.auth.data.remote.InvitePhoneValidationResult
import com.optimal.fleet.feature.auth.data.remote.OnboardingRemoteDataSource
import com.optimal.fleet.feature.auth.data.remote.RemoteMemberProfile
import com.optimal.fleet.feature.auth.data.remote.RemoteOnboardingCompletionResult
import com.optimal.fleet.feature.auth.data.remote.RemoteOtpRequestResult
import com.optimal.fleet.feature.auth.data.remote.RemoteOtpVerificationResult
import com.optimal.fleet.feature.auth.data.remote.RemoteRefreshResult
import com.optimal.fleet.feature.auth.data.remote.RemoteSignOutResult
import com.optimal.fleet.feature.auth.domain.model.JoinCodeValidationResult
import com.optimal.fleet.feature.auth.domain.model.OnboardingMode
import com.optimal.fleet.feature.auth.domain.model.PendingOnboardingFlow
import com.optimal.fleet.feature.auth.domain.model.PendingOnboardingStage
import com.optimal.fleet.feature.auth.domain.model.RestorePendingOnboardingResult
import java.time.Duration
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0
private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}
private fun <T> runSuspend(block: suspend () -> T): T {
    var result: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(value: Result<T>) { result = value }
    })
    return requireNotNull(result).getOrThrow()
}

fun main() {
    val clock = MutableTestClock.atEpochMillis(10_000)
    val pendingStore = MemoryPendingStore()
    val localStore = MemoryLocalSessionStore()
    fun repository() = SupabaseOnboardingRepository(
        authRemote = NoOpAuthRemoteV36,
        onboardingRemote = NoOpOnboardingRemoteV36,
        localSessionStore = localStore,
        pendingChallengeStore = pendingStore,
        remoteProfileStore = NoOpRemoteProfileStoreV36,
        auditWriter = NoOpMembershipAuditV36,
        onboardingMapper = OnboardingMapper(),
        clock = clock,
    )
    fun pending(stage: PendingOnboardingStage, challengeId: String?, expiresAt: Long = clock.millis() + 60_000) =
        PendingOnboardingFlow(challengeId, OnboardingMode.JoinCompany, "12345678", "+249912345678", "شركة", expiresAt, stage)

    val otpPending = pending(PendingOnboardingStage.OtpPending, "challenge-1")
    pendingStore.save(otpPending)
    verify(
        "pending OTP survives repository recreation",
        runSuspend { repository().restorePendingOnboarding() } == RestorePendingOnboardingResult.Restored(otpPending) &&
            runSuspend { repository().restorePendingOnboarding() } == RestorePendingOnboardingResult.Restored(otpPending),
    )

    pendingStore.save(pending(PendingOnboardingStage.OtpPending, "challenge-2", clock.millis() + 1_000))
    clock.advanceBy(Duration.ofSeconds(2))
    verify("expired pending OTP is discarded", runSuspend { repository().restorePendingOnboarding() } == RestorePendingOnboardingResult.Expired && pendingStore.current() == null)

    pendingStore.save(pending(PendingOnboardingStage.OtpPending, null))
    verify("malformed pending OTP is discarded", runSuspend { repository().restorePendingOnboarding() } == RestorePendingOnboardingResult.None && pendingStore.current() == null)

    val verified = pending(PendingOnboardingStage.OtpVerified, null)
    pendingStore.save(verified)
    verify("verified flow without auth session is discarded", runSuspend { repository().restorePendingOnboarding() } == RestorePendingOnboardingResult.None)

    pendingStore.save(verified.copy(expiresAtEpochMillis = clock.millis() + 60_000))
    localStore.saveAuthSession(SupabaseAuthSession("access", "refresh", 3_600, 9_999_999))
    verify("verified flow with auth session is restored", runSuspend { repository().restorePendingOnboarding() } is RestorePendingOnboardingResult.Restored)

    println("V36 auth process-death harness: $checks/$checks")
}

private class MemoryPendingStore : PendingChallengeStore {
    private var value: PendingOnboardingFlow? = null
    override fun current() = value
    override fun save(flow: PendingOnboardingFlow) { value = flow }
    override fun clear() { value = null }
}
private class MemoryLocalSessionStore : LocalSessionStore {
    private var auth: SupabaseAuthSession? = null
    override fun currentAuthSession() = auth
    override fun saveAuthSession(session: SupabaseAuthSession) { auth = session }
    override fun clearAuthSession() { auth = null }
    override suspend fun clearActiveSession() = Unit
    override suspend fun clearAll() { auth = null }
    override suspend fun activeSessionIfTokenValid(authSession: SupabaseAuthSession, nowEpochSeconds: Long): ActiveSession? = null
}
private object NoOpAuthRemoteV36 : AuthRemoteDataSource {
    override val isConfigured = true
    override suspend fun requestOtp(normalizedPhone: String) = RemoteOtpRequestResult.Accepted
    override suspend fun verifyOtp(normalizedPhone: String, code: String) = RemoteOtpVerificationResult.InvalidCode
    override suspend fun refresh(refreshToken: String) = RemoteRefreshResult.Rejected
    override suspend fun signOut() = RemoteSignOutResult.Completed
}
private object NoOpOnboardingRemoteV36 : OnboardingRemoteDataSource {
    override val isConfigured = true
    override suspend fun validateJoinCode(code: String, mode: OnboardingMode) = JoinCodeValidationResult.Invalid
    override suspend fun validateInvitePhone(code: String, normalizedPhone: String) = InvitePhoneValidationResult.Mismatch
    override suspend fun completeOnboarding(mode: OnboardingMode, joinCode: String, userDisplayName: String) = RemoteOnboardingCompletionResult.InvalidInvite
    override suspend fun currentMemberProfile() = CurrentMemberProfileResult.Success(null)
}
private object NoOpRemoteProfileStoreV36 : RemoteProfileStore {
    override suspend fun persist(profile: RemoteMemberProfile): PersistedProfile = error("unused")
}
private object NoOpMembershipAuditV36 : MembershipAuditPort {
    override suspend fun appendIfNew(profile: PersistedProfile) = Unit
}
