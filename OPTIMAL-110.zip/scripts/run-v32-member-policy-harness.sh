#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/com/optimal/fleet/core/common/error" "$TMP_DIR/com/optimal/fleet/core/session"
cat > "$TMP_DIR/com/optimal/fleet/core/common/error/DomainError.kt" <<'KT'
package com.optimal.fleet.core.common.error
open class DomainError
KT
cat > "$TMP_DIR/com/optimal/fleet/core/session/ActiveSession.kt" <<'KT'
package com.optimal.fleet.core.session
data class ActiveSession(val userId: String = "", val companyId: String = "")
KT
kotlinc \
  "$TMP_DIR/com/optimal/fleet/core/common/error/DomainError.kt" \
  "$TMP_DIR/com/optimal/fleet/core/session/ActiveSession.kt" \
  "$ROOT_DIR/core/model/src/main/kotlin/com/optimal/fleet/core/model/access/MemberAccess.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberAccessPolicy.kt" \
  "$ROOT_DIR/feature/settings/src/main/java/com/optimal/fleet/feature/settings/domain/members/MemberModels.kt" \
  "$ROOT_DIR/scripts/v32-member-policy-harness.kt" \
  -include-runtime -d "$TMP_DIR/v32-member-policy.jar"
java -jar "$TMP_DIR/v32-member-policy.jar"
