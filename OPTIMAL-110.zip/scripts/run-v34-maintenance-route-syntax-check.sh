#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_FILE="$(mktemp)"
OUT_FILE="$(mktemp --suffix=.jar)"
trap 'rm -f "$LOG_FILE" "$OUT_FILE"' EXIT
set +e
kotlinc \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsRoute.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsContent.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceCompletionContent.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceEditContent.kt" \
  "$ROOT_DIR/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/presentation/details/MaintenanceDetailsComponents.kt" \
  -d "$OUT_FILE" >"$LOG_FILE" 2>&1
set -e
if grep -Eiq 'expecting|unexpected tokens|syntax error' "$LOG_FILE"; then
  cat "$LOG_FILE"
  echo "FAIL: Kotlin parser error in maintenance details UI" >&2
  exit 1
fi
for name in MaintenanceDetailsRoute MaintenanceDetailsContent MaintenanceCompletionContent MaintenanceEditContent MaintenanceDetailsComponents; do
  echo "PASS: $name parser"
done
echo "V34 maintenance details route parser checks: 5/5"
