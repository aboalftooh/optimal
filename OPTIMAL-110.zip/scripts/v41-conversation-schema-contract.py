#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v41 conversation/message schema."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
V20 = ROOT / "supabase/migrations/20260728002000_optimal_sync_verto.sql"
V40 = ROOT / "supabase/migrations/20260731004000_optimal_verto_registration_compatibility.sql"
V41 = ROOT / "supabase/migrations/20260731004100_optimal_verto_conversation_message_schema.sql"
PREFLIGHT = ROOT / "supabase/tests/v41_verto_conversation_schema_preflight.sql"
SCENARIOS = ROOT / "supabase/tests/v41_verto_conversation_scenarios.sql"
ADR = ROOT / "docs/adr/ADR-verto-integration-v23.md"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
MATRIX = ROOT / "docs/integrations/verto-contract-matrix-v23.md"
APP_GRADLE = ROOT / "app/build.gradle.kts"

checks: list[tuple[str, bool]] = []


def check(name: str, condition: bool) -> None:
    checks.append((name, condition))


def contains_all(text: str, values: list[str]) -> bool:
    return all(value in text for value in values)


def table_block(sql: str, table: str) -> str:
    marker = f"create table if not exists public.{table} ("
    start = sql.find(marker)
    if start < 0:
        return ""
    end = sql.find("\n);", start)
    return "" if end < 0 else sql[start : end + 3]


def function_block(sql: str, function: str) -> str:
    marker = f"function public.{function}()"
    start = sql.find(marker)
    if start < 0:
        return ""
    next_start = sql.find("function public.", start + len(marker))
    return sql[start:] if next_start < 0 else sql[start:next_start]


for path in (V20, V40, V41, PREFLIGHT, SCENARIOS, ADR, CONTRACT, MATRIX, APP_GRADLE):
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())

if not all(path.is_file() for path in (V20, V40, V41, PREFLIGHT, SCENARIOS, ADR, CONTRACT, MATRIX, APP_GRADLE)):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

v20 = V20.read_text(encoding="utf-8")
v40 = V40.read_text(encoding="utf-8")
v41 = V41.read_text(encoding="utf-8")
preflight = PREFLIGHT.read_text(encoding="utf-8")
scenarios = SCENARIOS.read_text(encoding="utf-8")
adr = ADR.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
matrix = MATRIX.read_text(encoding="utf-8")
app_gradle = APP_GRADLE.read_text(encoding="utf-8")

conversation = table_block(v41, "optimal_verto_conversations")
message = table_block(v41, "optimal_verto_messages")
receipt = table_block(v41, "optimal_verto_message_receipts")
state = table_block(v41, "optimal_verto_conversation_states")
ensure_conversation = function_block(v41, "optimal_ensure_verto_conversation_for_link")
touch_conversation = function_block(v41, "optimal_touch_verto_conversation_from_message")

# Migration order and scope.
migrations = sorted(p.name for p in (ROOT / "supabase/migrations").glob("*.sql"))
check("order:v41-after-v40", migrations.index(V41.name) > migrations.index(V40.name))
check("scope:no-room-change", "OptimalDatabase" not in v41 and "Room" not in v41)
check("scope:no-android-version-bump", 'versionCode = 32' in app_gradle and 'versionName = "0.37.0-v37"' in app_gradle)
check("scope:contract-version-stays-22", "set contract_version = 23" not in v41 and "contract_version = 23" not in v41)
check("scope:no-minimum-client-raise", "minimum_android_version_code =" not in v41)
check("scope:no-message-rpc-v41", "optimal_verto_send_message" not in v41 and "optimal_verto_message_feed" not in v41)
check("scope:no-attachment-table-v41", "create table if not exists public.optimal_verto_message_attachments" not in v41)
check("scope:no-hard-delete", not re.search(r"\bdelete\s+from\s+public\.optimal_verto_messages\b", v41, re.IGNORECASE))
check("scope:no-destructive-drop", "drop table" not in v41.lower() and "drop column" not in v41.lower())

# Stable link identity is introduced non-destructively.
check("link:legacy-primary-key-exists", "optimal_company_id uuid primary key" in v20)
check("link:id-column-added", "add column if not exists id uuid" in v41)
check("link:id-backfilled", contains_all(v41, ["set id = extensions.gen_random_uuid()", "where id is null"]))
check("link:id-default", "alter column id set default extensions.gen_random_uuid()" in v41)
check("link:id-not-null", "alter column id set not null" in v41)
check("link:id-unique", "optimal_verto_links_id_key unique (id)" in v41)
check("link:legacy-key-not-dropped", "drop constraint optimal_verto_links_pkey" not in v41)

# Conversation table and one-per-link invariant.
check("conversation:table", bool(conversation))
for field in ("id uuid primary key", "link_id uuid not null", "created_at timestamptz not null", "updated_at timestamptz not null"):
    check(f"conversation:field:{field.split()[0]}", field in conversation)
check("conversation:unique-link", "optimal_verto_conversations_link_id_key unique (link_id)" in conversation)
check("conversation:link-fk", contains_all(conversation, ["references public.optimal_verto_links(id)", "on delete restrict"]))
check("conversation:timestamp-check", "optimal_verto_conversations_timestamps_check" in conversation)
check("conversation:backfill-active", contains_all(v41, ["insert into public.optimal_verto_conversations(link_id)", "where l.is_active = true", "on conflict (link_id) do nothing"]))
check("conversation:trigger-function", bool(ensure_conversation))
check("conversation:trigger-active-only", "if new.is_active then" in ensure_conversation)
check("conversation:trigger-idempotent", "on conflict (link_id) do nothing" in ensure_conversation)
check("conversation:link-trigger", contains_all(v41, ["create trigger optimal_verto_links_ensure_conversation", "after insert or update of is_active on public.optimal_verto_links"]))

# Message identity, sender snapshot and content invariants.
check("message:table", bool(message))
message_fields = [
    "id uuid primary key",
    "conversation_id uuid not null",
    "sender_side text not null",
    "sender_user_id uuid",
    "sender_display_name text not null",
    "sender_role text not null",
    "kind text not null",
    "body_text text",
    "status text not null",
    "client_message_id uuid",
    "idempotency_key uuid not null",
    "server_created_at timestamptz not null",
    "updated_at timestamptz not null",
]
for field in message_fields:
    check(f"message:field:{field.split()[0]}", field in message)
check("message:conversation-restrict", contains_all(message, ["references public.optimal_verto_conversations(id)", "on delete restrict"]))
check("message:sender-sides", contains_all(message, ["'OPTIMAL'", "'VERTO'", "optimal_verto_messages_sender_side_check"]))
check("message:kinds", contains_all(message, ["'TEXT'", "'IMAGE'", "'VIDEO'", "'AUDIO'", "'DOCUMENT'", "optimal_verto_messages_kind_check"]))
check("message:statuses", contains_all(message, ["'ACTIVE'", "'REDACTED'", "optimal_verto_messages_status_check"]))
check("message:text-body-required", contains_all(message, ["kind = 'TEXT'", "body_text is not null", "btrim(body_text)"]))
check("message:audio-body-empty", "kind = 'AUDIO' and body_text is null" in message)
check("message:sender-name-nonblank", "optimal_verto_messages_sender_display_name_check" in message)
check("message:sender-role-nonblank", "optimal_verto_messages_sender_role_check" in message)
check("message:optimal-client-id-required", contains_all(message, ["optimal_verto_messages_optimal_client_id_check", "sender_side <> 'OPTIMAL' or client_message_id is not null"]))
check("message:idempotency-unique", "optimal_verto_messages_conversation_idempotency_key" in message and "unique (conversation_id, idempotency_key)" in message)
check("message:client-id-partial-unique", contains_all(v41, ["create unique index if not exists optimal_verto_messages_client_identity_idx", "on public.optimal_verto_messages(conversation_id, client_message_id)", "where client_message_id is not null"]))
check("message:feed-index", contains_all(v41, ["optimal_verto_messages_feed_idx", "conversation_id, server_created_at, id"]))
check("message:conversation-activity", bool(touch_conversation) and "new.conversation_id" in touch_conversation)

# Per-user read and archive state.
check("receipt:table", bool(receipt))
check("receipt:per-user-pk", "primary key (conversation_id, user_id)" in receipt)
check("receipt:user-fk", "user_id uuid not null references auth.users(id) on delete cascade" in receipt)
check("receipt:cursor-fields", contains_all(receipt, ["last_read_created_at timestamptz", "last_read_message_id uuid"]))
check("receipt:cursor-pair", "optimal_verto_message_receipts_cursor_pair_check" in receipt)
check("receipt:same-conversation-message-fk", contains_all(receipt, ["foreign key (conversation_id, last_read_message_id)", "references public.optimal_verto_messages(conversation_id, id)"]))
check("state:table", bool(state))
check("state:per-user-pk", "primary key (conversation_id, user_id)" in state)
check("state:user-fk", "user_id uuid not null references auth.users(id) on delete cascade" in state)
check("state:cursor-fields", contains_all(state, ["archived_through_created_at timestamptz", "archived_through_message_id uuid"]))
check("state:cursor-pair", "optimal_verto_conversation_states_cursor_pair_check" in state)
check("state:same-conversation-message-fk", contains_all(state, ["foreign key (conversation_id, archived_through_message_id)", "references public.optimal_verto_messages(conversation_id, id)"]))
check("user-state:receipt-index", "optimal_verto_message_receipts_user_idx" in v41)
check("user-state:archive-index", "optimal_verto_conversation_states_user_idx" in v41)

# Isolation: no direct Android access and no permissive policies.
new_tables = [
    "optimal_verto_conversations",
    "optimal_verto_messages",
    "optimal_verto_message_receipts",
    "optimal_verto_conversation_states",
]
for table in new_tables:
    check(f"security:{table}:rls", f"alter table public.{table} enable row level security" in v41)
    check(f"security:{table}:force-rls", f"alter table public.{table} force row level security" in v41)
    check(f"security:{table}:revoke", f"revoke all on table public.{table}" in v41)
    check(f"security:{table}:service-role", f"grant all on table public.{table} to service_role" in v41)
check("security:no-authenticated-policy", "create policy" not in v41.lower())
check("security:trigger-functions-not-executable", contains_all(v41, ["revoke all on function public.optimal_ensure_verto_conversation_for_link()", "revoke all on function public.optimal_touch_verto_conversation_from_message()"]))
check("security:no-public-delete-rpc", "delete_message" not in v41.lower())

# Readiness remains deliberately closed.
check("readiness:chat-explicit-false", contains_all(v41, ["set verto_chat_ready = false", "where singleton = true"]))
check("readiness:not-promoted", "set verto_chat_ready = true" not in v41)
check("readiness:contract-field-exists", "verto_chat_ready" in v40 and "verto_chat_ready" in contract)

# Contract documents agree with implementation.
check("contract:one-conversation", "محادثة واحدة" in adr and "optimal_verto_conversations" in contract)
check("contract:sender-snapshot", "sender_display_name" in contract and "sender_role" in contract)
check("contract:per-user-read", "optimal_verto_message_receipts" in contract)
check("contract:per-user-archive", "optimal_verto_conversation_states" in contract)
check("matrix:message-owner", "feature:verto" in matrix and "optimal_verto_message_feed" in matrix)

# Preflight covers live catalog state without writes.
check("preflight:contract-v22", "v41_must_not_promote_contract_v23" in preflight)
check("preflight:chat-false", "v41_chat_readiness_must_remain_false" in preflight)
check("preflight:all-tables", all(table in preflight for table in new_tables))
check("preflight:rls-and-force", contains_all(preflight, ["relrowsecurity", "relforcerowsecurity"]))
check("preflight:no-direct-privileges", contains_all(preflight, ["has_table_privilege('anon'", "has_table_privilege('authenticated'", "'DELETE'"]))
check("preflight:no-direct-policies", "v41_direct_rls_policy_present_before_rpc" in preflight)
check("preflight:active-link-backfill", "v41_active_link_without_conversation" in preflight)
check("preflight:duplicate-conversation", "v41_duplicate_conversations" in preflight)
check("preflight:identity-indexes", contains_all(preflight, ["optimal_verto_messages_client_identity_idx", "optimal_verto_messages_conversation_idempotency_key"]))

# Transactional staging scenarios cover runtime semantics when PostgreSQL is available.
check("scenarios:transactional", scenarios.lstrip().startswith("--") and "begin;" in scenarios and scenarios.rstrip().endswith("rollback;"))
check("scenarios:requires-two-conversations", "v41_fixture_requires_two_active_conversations" in scenarios)
check("scenarios:unique-conversation", "v41_duplicate_conversation_was_accepted" in scenarios)
check("scenarios:unique-idempotency", "v41_duplicate_idempotency_was_accepted" in scenarios)
check("scenarios:unique-client-message", "v41_duplicate_client_message_id_was_accepted" in scenarios)
check("scenarios:cross-conversation-idempotency", "same key in another conversation" in scenarios)
check("scenarios:sender-snapshot", "v41_sender_snapshot_not_persisted" in scenarios)
check("scenarios:per-user-read", "v41_read_state_leaked_between_users" in scenarios)
check("scenarios:per-user-archive", "v41_archive_state_leaked_between_users" in scenarios)
check("scenarios:authenticated-direct-read-denied", "v41_authenticated_direct_read_was_allowed" in scenarios)
check("scenarios:authenticated-direct-delete-denied", "v41_authenticated_direct_delete_was_allowed" in scenarios)

# Basic SQL sanity where PostgreSQL execution is unavailable.
check("syntax:v41-dollar-quotes-balanced", v41.count("$$") % 2 == 0)
check("syntax:preflight-dollar-quotes-balanced", preflight.count("$$") % 2 == 0)
check("syntax:scenarios-dollar-quotes-balanced", scenarios.count("$$") % 2 == 0)
check("syntax:parentheses-balanced", v41.count("(") == v41.count(")"))
check("syntax:no-merge-markers", not any(token in v41 for token in ("<<<<<<<", "=======", ">>>>>>>")))
check("syntax:ends-with-semicolon", v41.rstrip().endswith(";"))

passed = sum(ok for _, ok in checks)
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
print(f"RESULT {passed}/{len(checks)}")

if passed != len(checks):
    sys.exit(1)
