#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))


required = [
    "docs/sessions/v27.md",
    "docs/data-boundaries-v27.md",
    "docs/verification-scripts-v27.md",
    "docs/source-archive-v27.sha256",
    "scripts/static-v27-check.py",
    "scripts/verify-v27-static.sh",
    "scripts/verify-v27-regressions.sh",
    "PATCH_MANIFEST-v27.md",
    "CHANGED_FILES-v27.txt",
    "DELETED_FILES-v27.txt",
    "verification-v27.md",
    "docs/verifications/verification-v27.md",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceWriteDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceFollowUpDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceAuditDao.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/maintenance/MaintenanceOperationTransactions.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/maintenance/MaintenanceFollowUpTransactions.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceSyncRepository.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceSyncRepository.kt",
    "app/src/test/java/com/optimal/fleet/MaintenanceDataBoundaryArchitectureTest.kt",
]
for path in required:
    check(f"required artifact exists: {path}", (ROOT / path).is_file())

build = read("app/build.gradle.kts")
check("versionCode is 22", bool(re.search(r"\bversionCode\s*=\s*22\b", build)))
check("versionName is v27", 'versionName = "0.27.0-v27"' in build)

old_dao = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceDao.kt"
check("aggregate MaintenanceDao is deleted", not old_dao.exists())

dao_paths = {
    "read": "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceReadDao.kt",
    "write": "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceWriteDao.kt",
    "follow-up": "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceFollowUpDao.kt",
    "audit": "core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceAuditDao.kt",
}
dao_text = {name: read(path) for name, path in dao_paths.items()}
for name, path in dao_paths.items():
    lines = len((ROOT / path).read_text(encoding="utf-8").splitlines())
    check(f"{name} DAO is focused and <=250 lines", lines <= 250, str(lines))
    check(f"{name} DAO is a Room DAO", "@Dao" in dao_text[name])

check("read DAO has no inserts or maintenance updates", "@Insert" not in dao_text["read"] and "UPDATE maintenance_" not in dao_text["read"])
check("write DAO owns operation mutations", all(token in dao_text["write"] for token in ["updateInProgress", "markCompleted", "markRemoteSyncSucceeded"]))
check("follow-up DAO owns follow-up queries and writes", all(token in dao_text["follow-up"] for token in ["observeActive", "findById", "markConverted", "markRemoteSyncSucceeded"]))
check("audit DAO owns audit read and insert", all(token in dao_text["audit"] for token in ["observeForOperation", "suspend fun insert"]))

all_dao_source = "\n".join(dao_text.values())
check("every maintenance query remains company scoped", all(
    "companyId" in block
    for block in re.findall(r"@Query\((.*?)\)\s*(?:suspend\s+)?fun", all_dao_source, flags=re.S)
), "a query block is missing companyId")

database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
module = read("core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt")
for getter, dao in [
    ("maintenanceReadDao()", "MaintenanceReadDao"),
    ("maintenanceWriteDao()", "MaintenanceWriteDao"),
    ("maintenanceFollowUpDao()", "MaintenanceFollowUpDao"),
    ("maintenanceAuditDao()", "MaintenanceAuditDao"),
]:
    check(f"database exposes {dao}", getter in database and dao in database)
    check(f"Hilt provides {dao}", f"provide{dao}" in module)
check("database no longer exposes aggregate maintenance DAO", "maintenanceDao()" not in database and "MaintenanceDao" not in database)

operation_tx = read("core/database/src/main/java/com/optimal/fleet/core/database/maintenance/MaintenanceOperationTransactions.kt")
follow_up_tx = read("core/database/src/main/java/com/optimal/fleet/core/database/maintenance/MaintenanceFollowUpTransactions.kt")
check("operation transaction coordinator preserves Room transactions", "database.withTransaction" in operation_tx and operation_tx.count("database.withTransaction") >= 4)
check("follow-up conversion remains transactional", "database.withTransaction" in follow_up_tx and "convertToOperation" in follow_up_tx)
check("transaction coordinators stay below 250 lines", all(len(text.splitlines()) <= 250 for text in [operation_tx, follow_up_tx]))

sync_contract = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository/MaintenanceSyncRepository.kt")
sync_adapter = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceSyncRepository.kt")
sync_participant = read("app/src/main/java/com/optimal/fleet/coordinator/sync/MaintenanceSyncParticipant.kt")
check("maintenance sync has a pure domain repository contract", "interface MaintenanceSyncRepository" in sync_contract and "core.database" not in sync_contract and "androidx." not in sync_contract)
check("Room sync adapter implements the feature contract", "RoomMaintenanceSyncRepository" in sync_adapter and ": MaintenanceSyncRepository" in sync_adapter)
check("sync coordinator depends on contract, not maintenance DAO", "MaintenanceSyncRepository" in sync_participant and "MaintenanceWriteDao" not in sync_participant and "MaintenanceFollowUpDao" not in sync_participant)

production = [
    path for path in ROOT.rglob("*.kt")
    if "/src/main/" in path.as_posix() and not any(part in {"build", ".gradle"} for part in path.parts)
]
boundary_violations: list[str] = []
for path in production:
    source = path.read_text(encoding="utf-8")
    imports_maintenance_dao = re.search(
        r"^import com\.optimal\.fleet\.core\.database\.dao\.Maintenance(?:Read|Write|FollowUp|Audit)Dao$",
        source,
        flags=re.M,
    )
    if imports_maintenance_dao:
        posix = path.as_posix()
        allowed = "/core/database/src/main/" in posix or "/feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/" in posix
        if not allowed:
            boundary_violations.append(str(path.relative_to(ROOT)))
check("maintenance DAOs are consumed only by database/data adapters", not boundary_violations, ", ".join(boundary_violations))

layer_violations: list[str] = []
for path in production:
    posix = path.as_posix()
    if "/domain/" not in posix and "/presentation/" not in posix and "/ui/" not in posix:
        continue
    source = path.read_text(encoding="utf-8")
    if re.search(r"^import com\.optimal\.fleet\.core\.database\.(?:dao|entity)\.", source, flags=re.M):
        layer_violations.append(str(path.relative_to(ROOT)))
check("domain and presentation do not import DAO/entity", not layer_violations, ", ".join(layer_violations))

repository_contracts = ROOT / "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/repository"
contract_files = sorted(repository_contracts.glob("*.kt"))
check("maintenance repository contracts are explicit", len(contract_files) >= 7, str(len(contract_files)))
check("repository contracts are pure Kotlin", all("core.database" not in path.read_text(encoding="utf-8") for path in contract_files))

schema_dir = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
schema_files = sorted(path.name for path in schema_dir.glob("*.json"))
check("Room remains version 1 with only 1.json", "version = 1" in database and schema_files == ["1.json"])
try:
    schema = json.loads((schema_dir / "1.json").read_text(encoding="utf-8"))
except Exception as error:
    schema = {}
    check("Room schema JSON is valid", False, str(error))
else:
    check("Room schema JSON is valid", True)
entities = schema.get("database", {}).get("entities", [])
check("Room schema remains 18 tables", len(entities) == 18, str(len(entities)))
check("Room schema remains 219 columns", sum(len(entity.get("fields", [])) for entity in entities) == 219)
check("Room schema remains 91 indices", sum(len(entity.get("indices", [])) for entity in entities) == 91)
check("Room schema remains 35 foreign keys", sum(len(entity.get("foreignKeys", [])) for entity in entities) == 35)

android_test_root = ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database"
test_source = "\n".join(path.read_text(encoding="utf-8") for path in android_test_root.glob("*.kt"))
check("v26 DAO contract suite remains present", len(re.findall(r"@Test\b", test_source)) >= 30, str(len(re.findall(r"@Test\b", test_source))))
check("v26 compatibility adapter is test-only", "MaintenanceDaoTestFacade" in test_source and "MaintenanceDaoTestFacade" not in "\n".join(path.read_text(encoding="utf-8") for path in production))

for script in [
    "scripts/static-v27-check.py",
    "scripts/static-architecture-check.py",
    "scripts/generate-room-baseline.py",
    "scripts/room-schema-drift-contract.py",
]:
    try:
        py_compile.compile(str(ROOT / script), doraise=True)
        valid, detail = True, ""
    except py_compile.PyCompileError as error:
        valid, detail = False, str(error)
    check(f"Python syntax valid: {script}", valid, detail)

for script in [
    "scripts/verify-project.sh",
    "scripts/verify-v27-static.sh",
    "scripts/verify-v27-regressions.sh",
]:
    result = subprocess.run(["bash", "-n", str(ROOT / script)], capture_output=True, text=True)
    check(f"shell syntax valid: {script}", result.returncode == 0, result.stderr.strip())

verify_project = read("scripts/verify-project.sh")
check("verify-project invokes v27 gates", "verify-v27-static.sh" in verify_project and "verify-v27-regressions.sh" in verify_project)
check("verify-project retains Gradle gates", all(command in verify_project for command in [
    "./gradlew clean",
    "./gradlew testDebugUnitTest",
    "./gradlew lintDebug",
    "./gradlew assembleDebug",
    "./gradlew :core:database:connectedDebugAndroidTest",
]))

source_hash = read("docs/source-archive-v27.sha256").strip()
check("v26 source archive SHA-256 is recorded", bool(re.fullmatch(r"[0-9a-f]{64}\s{2}OPTIMAL-full-v26\.zip", source_hash)), source_hash)

passed = sum(ok for _, ok, _ in checks)
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail and not ok else ""))
print(f"\nV27 data-boundary checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
