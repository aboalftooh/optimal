#!/usr/bin/env python3
import sqlite3
import tempfile
from pathlib import Path

passed = 0

def verify(name, condition):
    global passed
    if not condition:
        raise AssertionError(name)
    passed += 1
    print(f"PASS: {name}")

with tempfile.TemporaryDirectory() as tmp:
    db_path = Path(tmp) / "optimal-v05.db"
    db = sqlite3.connect(db_path)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript('''
    CREATE TABLE companies (
      id TEXT NOT NULL PRIMARY KEY,
      remoteId TEXT,
      name TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL
    );
    CREATE TABLE local_users (
      id TEXT NOT NULL PRIMARY KEY,
      companyId TEXT NOT NULL,
      remoteId TEXT,
      displayName TEXT NOT NULL,
      phone TEXT,
      isActive INTEGER NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL,
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE UNIQUE INDEX index_local_users_id_companyId ON local_users(id, companyId);
    CREATE TABLE vehicles (
      id TEXT NOT NULL PRIMARY KEY,
      companyId TEXT NOT NULL,
      remoteId TEXT,
      name TEXT NOT NULL,
      plateNumber TEXT NOT NULL,
      normalizedPlateNumber TEXT NOT NULL,
      brand TEXT,
      model TEXT,
      manufactureYear INTEGER,
      odometerKm INTEGER,
      department TEXT,
      driverName TEXT,
      archivedAtEpochMillis INTEGER,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncStatus TEXT NOT NULL,
      FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE RESTRICT
    );
    CREATE UNIQUE INDEX index_vehicles_id_companyId ON vehicles(id, companyId);
    CREATE UNIQUE INDEX index_vehicles_companyId_normalizedPlateNumber ON vehicles(companyId, normalizedPlateNumber);
    ''')

    db.executescript('''
    CREATE TABLE IF NOT EXISTS maintenance_operations (
      id TEXT NOT NULL,
      companyId TEXT NOT NULL,
      vehicleId TEXT NOT NULL,
      remoteId TEXT,
      clientGeneratedId TEXT NOT NULL,
      type TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL,
      startedAtEpochMillis INTEGER NOT NULL,
      completedAtEpochMillis INTEGER,
      odometerKm INTEGER,
      partsCostMinor INTEGER NOT NULL,
      serviceCostMinor INTEGER NOT NULL,
      source TEXT NOT NULL,
      createdByUserId TEXT NOT NULL,
      updatedByUserId TEXT NOT NULL,
      createdAtEpochMillis INTEGER NOT NULL,
      updatedAtEpochMillis INTEGER NOT NULL,
      syncState TEXT NOT NULL,
      PRIMARY KEY(id),
      FOREIGN KEY(companyId) REFERENCES companies(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(vehicleId, companyId) REFERENCES vehicles(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(createdByUserId, companyId) REFERENCES local_users(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT,
      FOREIGN KEY(updatedByUserId, companyId) REFERENCES local_users(id, companyId) ON UPDATE NO ACTION ON DELETE RESTRICT
    );
    CREATE INDEX index_maintenance_operations_companyId ON maintenance_operations(companyId);
    CREATE UNIQUE INDEX index_maintenance_operations_id_companyId ON maintenance_operations(id, companyId);
    CREATE INDEX index_maintenance_operations_vehicleId_companyId ON maintenance_operations(vehicleId, companyId);
    CREATE INDEX index_maintenance_operations_createdByUserId_companyId ON maintenance_operations(createdByUserId, companyId);
    CREATE INDEX index_maintenance_operations_updatedByUserId_companyId ON maintenance_operations(updatedByUserId, companyId);
    CREATE UNIQUE INDEX index_maintenance_operations_remoteId ON maintenance_operations(remoteId);
    CREATE UNIQUE INDEX index_maintenance_operations_clientGeneratedId ON maintenance_operations(clientGeneratedId);
    CREATE INDEX index_maintenance_operations_companyId_status_updatedAtEpochMillis ON maintenance_operations(companyId, status, updatedAtEpochMillis);
    CREATE INDEX index_maintenance_operations_companyId_syncState ON maintenance_operations(companyId, syncState);
    ''')

    for c in ("c1", "c2"):
        db.execute("INSERT INTO companies VALUES (?,?,?,?,?,?)", (c, None, c, 1, 1, "PENDING"))
    db.execute("INSERT INTO local_users VALUES (?,?,?,?,?,?,?,?,?)", ("u1", "c1", None, "U1", None, 1, 1, 1, "PENDING"))
    db.execute("INSERT INTO local_users VALUES (?,?,?,?,?,?,?,?,?)", ("u2", "c2", None, "U2", None, 1, 1, 1, "PENDING"))
    db.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("v1","c1",None,"V1","12","12",None,None,None,None,None,None,None,1,1,"PENDING"))
    db.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("v2","c2",None,"V2","34","34",None,None,None,None,None,None,None,1,1,"PENDING"))
    db.execute("INSERT INTO vehicles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("v3","c1",None,"Archived","56","56",None,None,None,None,None,None,99,1,1,"PENDING"))

    row = ("o1","c1","v1",None,"client-1","FULL_MAINTENANCE","تغيير زيت","IN_PROGRESS",1000,None,10000,12000,5000,"MANUAL","u1","u1",1000,1000,"PENDING")
    db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)
    db.commit()
    verify("valid offline operation persists", db.execute("SELECT COUNT(*) FROM maintenance_operations WHERE id='o1'").fetchone()[0] == 1)
    verify("status stored as in progress", db.execute("SELECT status FROM maintenance_operations WHERE id='o1'").fetchone()[0] == "IN_PROGRESS")
    verify("sync state stored separately", db.execute("SELECT syncState FROM maintenance_operations WHERE id='o1'").fetchone()[0] == "PENDING")
    verify("minor-unit costs preserved", db.execute("SELECT partsCostMinor+serviceCostMinor FROM maintenance_operations WHERE id='o1'").fetchone()[0] == 17000)

    try:
        db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("bad1","c1","v2",None,"client-bad1","PARTS_ONLY","x","IN_PROGRESS",1,None,None,0,0,"MANUAL","u1","u1",1,1,"PENDING"))
        db.commit(); cross_vehicle_blocked=False
    except sqlite3.IntegrityError:
        db.rollback(); cross_vehicle_blocked=True
    verify("cross-company vehicle link blocked", cross_vehicle_blocked)

    try:
        db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("bad2","c1","v1",None,"client-bad2","PARTS_ONLY","x","IN_PROGRESS",1,None,None,0,0,"MANUAL","u2","u1",1,1,"PENDING"))
        db.commit(); cross_actor_blocked=False
    except sqlite3.IntegrityError:
        db.rollback(); cross_actor_blocked=True
    verify("cross-company actor link blocked", cross_actor_blocked)

    try:
        db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("o2","c1","v1",None,"client-1","PARTS_ONLY","x","IN_PROGRESS",1,None,None,0,0,"MANUAL","u1","u1",1,1,"PENDING"))
        db.commit(); duplicate_client_blocked=False
    except sqlite3.IntegrityError:
        db.rollback(); duplicate_client_blocked=True
    verify("client-generated id prevents duplicate offline write", duplicate_client_blocked)

    # Multiple NULL remote ids are valid before sync.
    db.execute("INSERT INTO maintenance_operations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ("o3","c1","v1",None,"client-3","PARTS_ONLY","x","IN_PROGRESS",1,None,None,0,0,"MANUAL","u1","u1",1,1,"PENDING"))
    db.commit()
    verify("multiple unsynced rows allow null remote id", db.execute("SELECT COUNT(*) FROM maintenance_operations WHERE remoteId IS NULL").fetchone()[0] == 2)

    options = db.execute("SELECT id FROM vehicles WHERE companyId='c1' AND archivedAtEpochMillis IS NULL ORDER BY name").fetchall()
    verify("vehicle options exclude archived", options == [("v1",)])
    verify("company-scoped operation count", db.execute("SELECT COUNT(*) FROM maintenance_operations WHERE companyId='c2'").fetchone()[0] == 0)

    try:
        db.execute("DELETE FROM vehicles WHERE id='v1'")
        db.commit(); vehicle_delete_blocked=False
    except sqlite3.IntegrityError:
        db.rollback(); vehicle_delete_blocked=True
    verify("operation protects linked vehicle from deletion", vehicle_delete_blocked)

    db.close()
    reopened = sqlite3.connect(db_path)
    verify("operation survives database reopen", reopened.execute("SELECT description FROM maintenance_operations WHERE id='o1'").fetchone()[0] == "تغيير زيت")
    reopened.close()

print(f"SQLite v05 migration checks: {passed}/{passed}")
