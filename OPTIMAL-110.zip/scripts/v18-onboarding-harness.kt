import com.optimal.fleet.feature.auth.domain.usecase.OnboardingInputPolicy

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

fun main() {
    verify("join code strips separators", OnboardingInputPolicy.normalizeJoinCode("12-34 5678") == "12345678")
    verify("join code caps at eight", OnboardingInputPolicy.normalizeJoinCode("123456789") == "12345678")
    verify("valid join code", OnboardingInputPolicy.isValidJoinCode("12345678"))
    verify("short join code rejected", !OnboardingInputPolicy.isValidJoinCode("1234"))
    verify("Sudan local phone accepted", OnboardingInputPolicy.isValidPhone("0912345678"))
    verify("international phone normalized", OnboardingInputPolicy.normalizePhone("+249 912-345-678") == "+249912345678")
    verify("short phone rejected", !OnboardingInputPolicy.isValidPhone("123"))
    verify("OTP strips separators", OnboardingInputPolicy.normalizeOtp("12 34-56") == "123456")
    verify("valid six digit OTP", OnboardingInputPolicy.isValidOtp("123456"))
    verify("short OTP rejected", !OnboardingInputPolicy.isValidOtp("12345"))
    println("RESULT: $checks/$checks passed")
}
