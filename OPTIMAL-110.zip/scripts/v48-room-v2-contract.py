#!/usr/bin/env python3
"""Static and executable contract gate for OPTIMAL Room v2 Verto storage."""
from __future__ import annotations

import json
from pathlib import Path
import re
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = ROOT / "core/database/schemas/com.optimal.fleet.core.database.OptimalDatabase"
SCHEMA_V1 = SCHEMA_DIR / "1.json"
SCHEMA_V2 = SCHEMA_DIR / "2.json"
MIGRATION_SCHEMA = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/migration/VertoRoomV2Schema.kt"
MIGRATIONS = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/migration/OptimalDatabaseMigrations.kt"
DATABASE = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt"
DATABASE_MODULE = ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt"

NEW_TABLES = {
    "verto_conversations",
    "verto_messages",
    "verto_attachments",
    "verto_conversation_user_states",
    "verto_remote_cursors",
}
EXPECTED_ENTITIES = {
    "VertoConversationEntity",
    "VertoMessageEntity",
    "VertoAttachmentEntity",
    "VertoConversationUserStateEntity",
    "VertoRemoteCursorEntity",
}

checks: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, condition, detail))
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def schema_entities(schema: dict) -> dict[str, dict]:
    return {entity["tableName"]: entity for entity in schema["database"]["entities"]}


def migration_statements() -> list[str]:
    source = read(MIGRATION_SCHEMA)
    statements = re.findall(r'"""\n(.*?)\n"""\.trimIndent\(\)', source, re.S)
    return [statement.strip() for statement in statements]


def install_schema(database: sqlite3.Connection, schema: dict) -> None:
    database.execute("PRAGMA foreign_keys = ON")
    for entity in schema["database"]["entities"]:
        table = entity["tableName"]
        database.execute(entity["createSql"].replace("${TABLE_NAME}", table))
        for index in entity["indices"]:
            database.execute(index["createSql"].replace("${TABLE_NAME}", table))
    database.execute(f"PRAGMA user_version = {schema['database']['version']}")


def table_names(database: sqlite3.Connection) -> set[str]:
    return {
        row[0]
        for row in database.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' AND name NOT IN ('android_metadata','room_master_table')"
        )
    }


def index_shape(database: sqlite3.Connection, table: str) -> dict[str, tuple[bool, tuple[str, ...]]]:
    result: dict[str, tuple[bool, tuple[str, ...]]] = {}
    for _, name, unique, *_ in database.execute(f"PRAGMA index_list(`{table}`)"):
        if name.startswith("sqlite_autoindex_"):
            continue
        columns = tuple(row[2] for row in database.execute(f"PRAGMA index_info(`{name}`)"))
        result[name] = (bool(unique), columns)
    return result


def expected_index_shape(entity: dict) -> dict[str, tuple[bool, tuple[str, ...]]]:
    return {
        index["name"]: (bool(index["unique"]), tuple(index["columnNames"]))
        for index in entity["indices"]
    }


def column_shape(database: sqlite3.Connection, table: str) -> list[tuple[str, str, bool, int]]:
    return [(row[1], row[2], bool(row[3]), int(row[5])) for row in database.execute(f"PRAGMA table_info(`{table}`)")]


def expected_column_shape(entity: dict) -> list[tuple[str, str, bool, int]]:
    primary = set(entity["primaryKey"]["columnNames"])
    return [
        (field["columnName"], field["affinity"], bool(field["notNull"]), 1 if field["columnName"] in primary else 0)
        for field in entity["fields"]
    ]


def reject(database: sqlite3.Connection, sql: str) -> bool:
    try:
        database.execute(sql)
    except sqlite3.IntegrityError:
        return True
    return False


schema1 = json.loads(read(SCHEMA_V1))
schema2 = json.loads(read(SCHEMA_V2))
entities1 = schema_entities(schema1)
entities2 = schema_entities(schema2)

check("v1 schema retained", schema1["database"]["version"] == 1)
check("v2 schema published", schema2["database"]["version"] == 2)
check("v2 has 23 tables", len(entities2) == 23, str(len(entities2)))
check("five Verto tables added", set(entities2) - set(entities1) == NEW_TABLES, str(set(entities2) - set(entities1)))
check("all v1 tables retained", set(entities1).issubset(entities2))
for table, entity in entities1.items():
    check(f"historical table unchanged: {table}", entity == entities2[table])

source = read(DATABASE)
check("database version keeps v2 lineage", "version = 2" in source or "version = 3" in source)
check("all Verto entities registered", all(f"{name}::class" in source for name in EXPECTED_ENTITIES))
check("all Verto DAOs exposed", all(f"abstract fun {name}" in source for name in [
    "vertoConversationDao", "vertoMessageDao", "vertoAttachmentDao", "vertoConversationUserStateDao", "vertoRemoteCursorDao"
]))
check("migration is registered", "OptimalDatabaseMigrations.MIGRATION_1_2" in read(DATABASE_MODULE))
check("destructive fallback absent", "fallbackToDestructiveMigration" not in read(DATABASE_MODULE))
check("migration object is 1 to 2", "object : Migration(1, 2)" in read(MIGRATIONS))

entity_files = list((ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity/verto").glob("*Entity.kt"))
dao_files = list((ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto").glob("*Dao.kt"))
check("baseline Verto entity files retained", all((ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/entity/verto" / f"{name}.kt").is_file() for name in EXPECTED_ENTITIES), str(len(entity_files)))
check("baseline Verto DAO files retained", all((ROOT / "core/database/src/main/java/com/optimal/fleet/core/database/dao/verto" / f"{name}Dao.kt").is_file() for name in ["VertoConversation", "VertoMessage", "VertoAttachment", "VertoConversationUserState", "VertoRemoteCursor"]), str(len(dao_files)))

conversation = entities2["verto_conversations"]
messages = entities2["verto_messages"]
attachments = entities2["verto_attachments"]
states = entities2["verto_conversation_user_states"]
cursors = entities2["verto_remote_cursors"]

check("one conversation per company", any(i["unique"] and i["columnNames"] == ["companyId"] for i in conversation["indices"]))
check("message remote identity unique", any(i["unique"] and i["columnNames"] == ["remoteId"] for i in messages["indices"]))
check("message client identity scoped", any(i["unique"] and i["columnNames"] == ["conversationId", "clientMessageId"] for i in messages["indices"]))
check("message idempotency scoped", any(i["unique"] and i["columnNames"] == ["conversationId", "idempotencyKey"] for i in messages["indices"]))
check("attachment client identity scoped", any(i["unique"] and i["columnNames"] == ["conversationId", "clientAttachmentId"] for i in attachments["indices"]))
check("user state scoped per conversation user", any(i["unique"] and i["columnNames"] == ["conversationId", "userId"] for i in states["indices"]))
check("cursor scoped per company feed", any(i["unique"] and i["columnNames"] == ["companyId", "feedKey"] for i in cursors["indices"]))
check("server cursor tuple stored", {"serverCreatedAtEpochMillis", "remoteId"}.issubset({f["columnName"] for f in messages["fields"]}))
check("read and archive tuples stored", {
    "lastReadCreatedAtEpochMillis", "lastReadMessageRemoteId",
    "archivedThroughCreatedAtEpochMillis", "archivedThroughMessageRemoteId",
}.issubset({f["columnName"] for f in states["fields"]}))
check("signed URL is not persisted", all("signed" not in f["columnName"].lower() for f in attachments["fields"]))

statements = migration_statements()
check("migration has five table statements", sum(s.upper().startswith("CREATE TABLE") for s in statements) == 5)
check("migration has all declared Verto indices", sum(s.upper().startswith("CREATE") and " INDEX " in s.upper() for s in statements) == 31)

with tempfile.TemporaryDirectory(prefix="optimal-v48-room-") as directory:
    path = Path(directory) / "optimal.db"
    database = sqlite3.connect(path)
    try:
        install_schema(database, schema1)
        database.execute(
            "INSERT INTO companies(id,remoteId,name,createdAtEpochMillis,updatedAtEpochMillis,syncStatus,currencyCode,isVertoLinked) "
            "VALUES('company-a','remote-company-a','A',1,1,'SYNCED','SDG',1)"
        )
        database.execute(
            "INSERT INTO companies(id,remoteId,name,createdAtEpochMillis,updatedAtEpochMillis,syncStatus,currencyCode,isVertoLinked) "
            "VALUES('company-b','remote-company-b','B',1,1,'SYNCED','SDG',1)"
        )
        database.execute(
            "INSERT INTO local_users(id,companyId,remoteId,displayName,phone,isActive,createdAtEpochMillis,updatedAtEpochMillis,syncStatus,normalizedPhone,lastActiveAtEpochMillis,role,permissionsJson) "
            "VALUES('user-a','company-a','remote-user-a','A',NULL,1,1,1,'SYNCED','249111111111',1,'OWNER','{}')"
        )
        database.execute(
            "INSERT INTO local_users(id,companyId,remoteId,displayName,phone,isActive,createdAtEpochMillis,updatedAtEpochMillis,syncStatus,normalizedPhone,lastActiveAtEpochMillis,role,permissionsJson) "
            "VALUES('user-b','company-b','remote-user-b','B',NULL,1,1,1,'SYNCED','249222222222',1,'OWNER','{}')"
        )
        for statement in statements:
            database.execute(statement)
        database.execute("PRAGMA user_version = 2")

        check("migrated table set matches v2", table_names(database) == set(entities2), str(table_names(database) ^ set(entities2)))
        for table in NEW_TABLES:
            check(f"columns match schema: {table}", column_shape(database, table) == expected_column_shape(entities2[table]))
            check(f"indices match schema: {table}", index_shape(database, table) == expected_index_shape(entities2[table]))

        check("old company rows preserved", database.execute("SELECT COUNT(*) FROM companies").fetchone()[0] == 2)
        check("old user rows preserved", database.execute("SELECT COUNT(*) FROM local_users").fetchone()[0] == 2)

        database.execute(
            "INSERT INTO verto_conversations VALUES('conversation-a','company-a','remote-conversation-a','remote-link-a','Verto',1,23,1,1)"
        )
        database.execute(
            "INSERT INTO verto_conversations VALUES('conversation-b','company-b','remote-conversation-b','remote-link-b','Verto',1,23,1,1)"
        )
        message_sql = (
            "INSERT INTO verto_messages VALUES('message-a','company-a','conversation-a','remote-message-a',"
            "'client-message-a','idem-message-a','VERTO',NULL,'Agent','AGENT','TEXT','Hello','ACTIVE','SENT',10,10,10,NULL)"
        )
        database.execute(message_sql)
        check("duplicate conversation rejected", reject(database,
            "INSERT INTO verto_conversations VALUES('conversation-a2','company-a','remote-conversation-a2','remote-link-a2','Verto',1,23,1,1)"))
        check("duplicate remote message rejected", reject(database,
            "INSERT INTO verto_messages VALUES('message-b','company-a','conversation-a','remote-message-a','client-message-b','idem-message-b','VERTO',NULL,'Agent','AGENT','TEXT','Hello','ACTIVE','SENT',11,11,11,NULL)"))
        check("cross-company message rejected", reject(database,
            "INSERT INTO verto_messages VALUES('message-c','company-b','conversation-a','remote-message-c','client-message-c','idem-message-c','VERTO',NULL,'Agent','AGENT','TEXT','Hello','ACTIVE','SENT',12,12,12,NULL)"))
        check("foreign keys clean", database.execute("PRAGMA foreign_key_check").fetchall() == [])
        check("sqlite quick check", database.execute("PRAGMA quick_check(1)").fetchone()[0] == "ok")
    finally:
        database.close()

required_tests = [
    ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV2MigrationTest.kt",
    ROOT / "core/database/src/androidTest/java/com/optimal/fleet/core/database/VertoRoomV2ProcessRecreationTest.kt",
]
check("migration and process recreation tests exist", all(path.is_file() for path in required_tests))
test_text = "\n".join(read(path) for path in required_tests)
for token in ["runMigrationsAndValidate", "MIGRATION_1_2", "ProcessRecreation", "company-a", "company-b"]:
    check(f"test coverage token: {token}", token in test_text)

passed = sum(1 for _, ok, _ in checks if ok)
print(f"v48 Room v2 contract: {passed}/{len(checks)} PASS")
