#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]
PRESENTATION = ROOT / 'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation'
FILES = {
    'screen': PRESENTATION / 'VertoChatScreen.kt',
    'chrome': PRESENTATION / 'VertoChatChrome.kt',
    'messages': PRESENTATION / 'VertoChatMessages.kt',
    'attachments': PRESENTATION / 'VertoChatAttachments.kt',
    'composer': PRESENTATION / 'VertoChatComposer.kt',
    'formatting': PRESENTATION / 'VertoChatFormatting.kt',
    'test': ROOT / 'feature/verto/src/test/java/com/optimal/fleet/feature/verto/VertoChatPresentationV87Test.kt',
}
checks = []


def check(label, cond):
    checks.append((label, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + label)


def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def tree(rel):
    h = hashlib.sha256()
    for f in sorted((ROOT / rel).rglob('*')):
        if f.is_file():
            h.update(str(f.relative_to(ROOT)).encode())
            h.update(b'\0')
            h.update(f.read_bytes())
            h.update(b'\0')
    return h.hexdigest()


for name, path in FILES.items():
    check(f'exists {name}', path.is_file())
text = {name: path.read_text() for name, path in FILES.items()}
ui_names = ['screen', 'chrome', 'messages', 'attachments', 'composer', 'formatting']
all_ui = '\n'.join(text[name] for name in ui_names)

# Design System v2 migration: no legacy UI imports, raw visual literals, or raw colors.
for name in ui_names:
    source = text[name]
    check(
        f'{name} has no legacy DS import',
        re.search(r'import com\.optimal\.fleet\.designsystem\.component\.(?!v2\.)', source) is None,
    )
    check(f'{name} has no AppCard/AppTextField', 'AppCard' not in source and 'AppTextField' not in source)
    check(f'{name} has no direct dp literal', re.search(r'\b\d+(?:\.\d+)?\.dp\b', source) is None)
    check(f'{name} has no raw hex color', '0xFF' not in source)

check('screen uses v2 loading state', 'component.v2.OptimalLoadingState' in text['screen'])
check('gate uses v2 empty state', 'OptimalEmptyState(' in text['chrome'])
for token in ['OptimalStatusBadge', 'OptimalIconButton', 'OptimalTertiaryButton', 'OptimalSemanticColors', 'OptimalTypographyRoles']:
    check(f'chrome uses {token}', token in text['chrome'])
check('cached-error presentation preserves local context', 'المحادثة محفوظة محليًا' in text['chrome'])
check('cached-error keeps explicit retry', 'text = "إعادة المحاولة"' in text['chrome'] and 'onClick = onRetry' in text['chrome'])

# Message hierarchy, semantic delivery states, and RTL directional geometry.
for token in ['SenderSnapshot(', 'MessageContent(', 'MessageFooter(', 'deliveryLabelText(', 'deliveryVisual(']:
    check(f'message hierarchy {token[:-1]}', token in text['messages'])
check('outgoing aligns to logical start and incoming to logical end', 'if (outgoing) Arrangement.Start else Arrangement.End' in text['messages'])
check('bubble corners use logical start/end', all(token in text['messages'] for token in ['bottomStart = if (outgoing)', 'bottomEnd = if (outgoing)', 'OptimalRadius.extraSmall']))
check('outgoing bubble uses brand container', 'OptimalSemanticColors.brandContainer' in text['messages'])
for state, label in [
    ('PENDING', 'قيد الانتظار'),
    ('SENDING', 'جارٍ الإرسال'),
    ('SENT', 'تم الإرسال'),
    ('FAILED_RETRYABLE', 'فشل الإرسال'),
    ('FAILED_TERMINAL', 'فشل الإرسال'),
]:
    check(f'delivery state {state} remains explicit', f'VertoDeliveryState.{state}' in text['messages'] and label in text['messages'])
for token in ['OptimalSemanticColors.warning', 'OptimalSemanticColors.info', 'OptimalSemanticColors.success', 'OptimalSemanticColors.danger']:
    check(f'delivery semantics use {token}', token in text['messages'])
check('retry path still uses stable local id', 'onRetryMessage(message.localId)' in text['messages'])
check('retry target remains tagged', 'verto-retry-${message.localId}' in text['messages'])

# Composer UX: IME, insets, touch targets, attachment/audio modes, and stable actions.
for token in ['imePadding()', 'OutlinedTextField(', 'KeyboardOptions(imeAction = ImeAction.Send)', 'KeyboardActions(', 'state.sendEnabled', 'OptimalTouchTarget.comfortable']:
    check(f'composer UX {token}', token in text['composer'])
check('IME send uses existing send callback only when enabled', 'if (state.sendEnabled) onSend()' in text['composer'])
check('send icon is RTL-aware', 'Icons.AutoMirrored.Outlined.Send' in text['composer'])
for token in ['VertoAudioRecordingComposer(', 'VertoAudioDraftComposer(', 'VertoAudioBusyComposer(', 'OptimalIconButton(', 'OptimalSemanticColors.dangerContainer', 'OptimalSemanticColors.brandSubtle']:
    check(f'audio composer presentation {token[:-1] if token.endswith("(") else token}', token in text['composer'])
for callback in ['onTakePhoto', 'onPickImage', 'onPickVideo', 'onPickDocument', 'onRecordAudio', 'onStopAudio', 'onCancelAudio', 'onSendAudio', 'onDiscardAudio']:
    check(f'composer callback preserved {callback}', callback in text['composer'])

# Regression: the v86 duplicate named parameter is removed from the standard composer signature.
signature = re.search(r'internal fun VertoStandardComposerRow\((.*?)\n\)', text['composer'], re.S)
if signature:
    param_names = re.findall(r'^\s*(\w+)\s*:', signature.group(1), re.M)
    check('standard composer has unique parameter names', len(param_names) == len(set(param_names)))
    check('standard composer has one onPickDocument parameter', param_names.count('onPickDocument') == 1)
else:
    check('standard composer signature found', False)

# Attachment/audio presentation states remain explicit and semantic.
for token in ['OptimalStatusBadge(', 'attachmentTransferLabel(', 'attachmentTransferVisual(', 'OptimalStatusTone.Neutral', 'OptimalStatusTone.Info', 'OptimalStatusTone.Success', 'OptimalStatusTone.Warning', 'OptimalStatusTone.Danger']:
    check(f'attachment UX {token[:-1] if token.endswith("(") else token}', token in text['attachments'])
for state, label in [
    ('LOCAL_READY', 'بانتظار الرفع'),
    ('UPLOADING', 'جارٍ الرفع'),
    ('UPLOADED', 'جارٍ التحقق'),
    ('FINALIZING', 'جارٍ التحقق'),
    ('READY', 'جاهز'),
    ('FAILED_RETRYABLE', 'تعذر الرفع مؤقتًا'),
    ('FAILED_TERMINAL', 'تعذر الرفع'),
    ('LOCAL_MISSING', 'تعذر الرفع'),
]:
    check(f'attachment transfer state {state} visible', f'VertoAttachmentTransferState.{state}' in text['attachments'] and label in text['attachments'])
check('audio attachment keeps private playback', 'rememberVertoAudioPlaybackState' in text['attachments'])
check('audio draft keeps private playback', 'rememberVertoAudioPlaybackState' in text['composer'])

# Message/read/attachment protocol invariants from v86 remain in presentation.
for token in ['key = VertoMessage::stableIdentity', 'snapshotFlow', 'VertoMessageCursor(createdAt, remoteId)', 'onMessagesVisible']:
    check(f'read model invariant {token}', token in text['messages'])
for token in [
    'attachment.kind == VertoAttachmentKind.AUDIO',
    'attachment.localPrivatePath != null',
    'attachment.transferState == VertoAttachmentTransferState.READY',
    'VertoAttachmentOpenContract.open(context, attachment)',
    'onOpenRemoteAttachment(remoteAttachmentId)',
]:
    check(f'attachment behavior invariant {token}', token in text['attachments'])
for tag in ['DESTINATION_TAG', 'MESSAGE_LIST_TAG', 'LOAD_OLDER_TAG', 'COMPOSER_TAG', 'SEND_TAG', 'ATTACHMENT_MENU_TAG', 'AUDIO_RECORD_TAG', 'AUDIO_RECORDING_TAG', 'AUDIO_STOP_TAG', 'AUDIO_DRAFT_TAG', 'AUDIO_PREVIEW_TAG', 'AUDIO_DISCARD_TAG', 'AUDIO_SEND_TAG']:
    check(f'stable tag constant preserved {tag}', tag in all_ui)

# Presentation-only boundary.
for name in ui_names:
    source = text[name]
    check(f'{name} has no data import', '.data.' not in source)
    check(f'{name} has no database import', 'core.database' not in source)
    check(f'{name} has no network client', all(token not in source for token in ['core.network', 'Retrofit', 'Supabase', 'HttpClient']))

# Behavior/protocol locks remain byte-identical to v86.
protected_trees = {
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/domain': '4525f4fc8f5dd55a4abf5e2146443de629d052f67c1721405adb133594598540',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/data': 'ba98e90d619d4e2d757c477bb0fd97b1250eeedbe97e127d26407459a9839bd0',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/di': '7267f438a631d304d66e5b1890d152169b7083433bb8292ad9743c90874fc301',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/navigation': '2649832acfeb55e356f70abed9df0ac5955537aff808feb581824b17d0e84352',
}
protected_files = {
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatContract.kt': '65e99bad21d55f9cfb080212abe8d053b5e56d0d79ecd8009316d879259df6d0',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoChatViewModel.kt': 'd160312ae48c1ced85dc0e102f3f9bc87c2f5d9a6c5a468359fa0c768f1469cb',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoConversationEntryRoute.kt': '21c428519492d38413fb5a6b38cbaa1b5cc4ba16c20f3282300df9499db3301c',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentPickerCoordinator.kt': '74aa740467eeb0d9a0b670bbabe70ff286aaef05c4216656845c8489794464c0',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAttachmentOpenContract.kt': 'acd9b82ff9166111dd60b3362c6106a5d53dfe1792c91122e820cc22da93e642',
    'feature/verto/src/main/java/com/optimal/fleet/feature/verto/presentation/VertoAudioPlayback.kt': 'a07ef2c8ebf97dfe6755bdc243ac5b0ae49bd0ce67ceb1499d9996fa90319383',
    'app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncParticipant.kt': '3635ed5aca8688836d029948fd2182e0f2c7a8013eaa29d4143a2d09adcd7cb4',
    'app/src/main/java/com/optimal/fleet/coordinator/sync/VertoMessageSyncSchedulerAdapter.kt': '059c6e208a0bb1e4d733e7b673cfd68dc3195feb4b7084e2825c3f58a4b554b4',
}
for rel, digest in protected_trees.items():
    check('protected tree unchanged ' + rel, tree(rel) == digest)
for rel, digest in protected_files.items():
    check('protected file unchanged ' + rel, sha(rel) == digest)

# Focused v87 source coverage.
for test_name in ['deliveryStatesRemainExplicitAndReadable', 'attachmentTransferStatesRemainExplicitAndReadable']:
    check(f'v87 unit source {test_name}', test_name in text['test'])

failed = [item for item in checks if not item[1]]
print(f'v87 Verto Chat UX contract: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
