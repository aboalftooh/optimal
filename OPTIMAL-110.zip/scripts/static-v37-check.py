#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, bool(ok), detail))


app_build = read("app/build.gradle.kts")
check("versionCode 32", bool(re.search(r"\bversionCode\s*=\s*32\b", app_build)))
check("versionName v37", 'versionName = "0.37.0-v37"' in app_build)
check("release minify", "isMinifyEnabled = true" in app_build)
check("release shrink resources", "isShrinkResources = true" in app_build)

catalog = read("gradle/libs.versions.toml")
root_gradle = read("build.gradle.kts")
for token in [
    'detekt = { id = "io.gitlab.arturbosch.detekt"',
    'ktlint = { id = "org.jlleitschuh.gradle.ktlint"',
    'kover = { id = "org.jetbrains.kotlinx.kover"',
]:
    check(f"catalog {token.split(' = ')[0]}", token in catalog)
for token in [
    'pluginManager.apply("io.gitlab.arturbosch.detekt")',
    'pluginManager.apply("org.jlleitschuh.gradle.ktlint")',
    "ignoreFailures = false",
    'config.setFrom(rootProject.files("config/detekt/detekt.yml"))',
    'tasks.register<Exec>(name)',
    '"architectureCheck"',
    '"securityCheck"',
    '"roomContractCheck"',
    '"backendContractCheck"',
    'tasks.register("staticQualityCheck")',
]:
    check(f"quality configuration {token}", token in root_gradle)

check("detekt configuration exists", (ROOT / "config/detekt/detekt.yml").is_file())
check("detekt maxIssues zero", "maxIssues: 0" in read("config/detekt/detekt.yml"))
check("editorconfig exists", (ROOT / ".editorconfig").is_file())
check("ktlint Android Studio style", "ktlint_code_style = android_studio" in read(".editorconfig"))

workflows = {
    "fast": ".github/workflows/ci-fast.yml",
    "full": ".github/workflows/ci-full.yml",
}
for name, path in workflows.items():
    check(f"{name} workflow exists", (ROOT / path).is_file())
fast = read(workflows["fast"])
full = read(workflows["full"])
for token in ["push:", "pull_request:", "./scripts/ci-fast.sh", "validate-wrappers: true"]:
    check(f"fast CI {token}", token in fast)
for token in [
    "workflow_dispatch:",
    "./scripts/ci-full.sh --without-android",
    "release-gate-output",
    "reactivecircus/android-emulator-runner@v2",
    "./scripts/ci-android.sh",
]:
    check(f"full CI {token}", token in full)

for script in [
    "ci-fast.sh",
    "ci-full.sh",
    "ci-android.sh",
    "security-release-check.py",
    "verify-v37-static.sh",
    "verify-v37-regressions.sh",
    "static-v37-check.py",
]:
    path = ROOT / "scripts" / script
    check(f"gate {script}", path.is_file() and (path.stat().st_mode & 0o111) != 0)

ci_fast = read("scripts/ci-fast.sh")
for token in [":app:compileDebugKotlin", "testDebugUnitTest", "lintDebug", "detekt", "ktlintCheck"]:
    check(f"fast command {token}", token in ci_fast)
ci_full = read("scripts/ci-full.sh")
for token in ["assembleRelease", "bundleRelease", "koverVerify", "lintRelease", "detekt", "ktlintCheck"]:
    check(f"full command {token}", token in ci_full)

proguard = read("app/proguard-rules.pro")
for token in [
    "RuntimeVisibleParameterAnnotations",
    "interface com.optimal.fleet.**.*Api",
    "-assumenosideeffects class android.util.Log",
    "!SourceFile,!LineNumberTable",
]:
    check(f"ProGuard {token}", token in proguard)
check("no broad dontwarn", "-dontwarn **" not in proguard)

manifest = read("app/src/main/AndroidManifest.xml")
for token in [
    'android:allowBackup="false"',
    'android:usesCleartextTraffic="false"',
    'android:networkSecurityConfig="@xml/network_security_config"',
]:
    check(f"Manifest {token}", token in manifest)
network = read("app/src/main/res/xml/network_security_config.xml")
check("system trust only", '<certificates src="system"' in network and 'src="user"' not in network)

for path in [
    "docs/release-readiness-checklist-v37.md",
    "docs/release-shrinker-review-v37.md",
    "docs/final-engineering-assessment-v37.md",
    "docs/final-architecture.md",
    "docs/adr/ADR-001-room-v1-baseline-reset.md",
    "docs/release-notes-v37.md",
    "docs/sessions/v37.md",
    "docs/verifications/verification-v37.md",
    "verification-v37.md",
    "PATCH_MANIFEST-v37.md",
    "CHANGED_FILES-v37.txt",
    "DELETED_FILES-v37.txt",
]:
    check(f"delivery {path}", (ROOT / path).is_file())

readme = read("README.md")
check("README current v37", "0.37.0-v37" in readme and "versionCode 32" in readme)
check("README points to v37 verification", "docs/verifications/verification-v37.md" in readme)

plan = read("docs/implementation-plan.md")
check("plan records v37", "## الحالة الحالية بعد v37" in plan)
changelog = read("docs/implementation-changelog.md")
check("changelog records v37", "## v37 — بوابات الجودة" in changelog)

failed = [(name, detail) for name, ok, detail in checks if not ok]
for name, ok, detail in checks:
    suffix = f" ({detail})" if detail and not ok else ""
    print(f"{'PASS' if ok else 'FAIL'}: {name}{suffix}")
print(f"RESULT: {len(checks) - len(failed)}/{len(checks)}")
if failed:
    print("FAILED: " + ", ".join(name for name, _ in failed), file=sys.stderr)
    sys.exit(1)
