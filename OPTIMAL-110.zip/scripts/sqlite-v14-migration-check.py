#!/usr/bin/env python3
import sqlite3

checks = 0

def verify(name, condition):
    global checks
    if not condition:
        raise AssertionError(name)
    checks += 1
    print(f"PASS: {name}")

connection = sqlite3.connect(":memory:")
connection.execute("PRAGMA foreign_keys = ON")
connection.executescript(
    """
    CREATE TABLE companies(id TEXT NOT NULL PRIMARY KEY);
    INSERT INTO companies VALUES ('c1');
    INSERT INTO companies VALUES ('c2');
    CREATE TABLE notifications (
        id TEXT NOT NULL,
        companyId TEXT NOT NULL,
        eventKey TEXT NOT NULL,
        type TEXT NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        actionLabel TEXT NOT NULL,
        targetType TEXT NOT NULL,
        targetId TEXT,
        occurredAtEpochMillis INTEGER NOT NULL,
        createdAtEpochMillis INTEGER NOT NULL,
        readAtEpochMillis INTEGER,
        deliveredAtEpochMillis INTEGER,
        PRIMARY KEY(id),
        FOREIGN KEY(companyId) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE INDEX index_notifications_companyId ON notifications(companyId);
    CREATE UNIQUE INDEX index_notifications_companyId_eventKey ON notifications(companyId,eventKey);
    CREATE INDEX index_notifications_companyId_readAtEpochMillis_occurredAtEpochMillis ON notifications(companyId,readAtEpochMillis,occurredAtEpochMillis);
    CREATE INDEX index_notifications_companyId_deliveredAtEpochMillis_createdAtEpochMillis ON notifications(companyId,deliveredAtEpochMillis,createdAtEpochMillis);
    CREATE INDEX index_notifications_companyId_targetType_targetId ON notifications(companyId,targetType,targetId);
    """
)
columns = {row[1] for row in connection.execute("PRAGMA table_info(notifications)")}
verify("notification columns", {"eventKey","readAtEpochMillis","deliveredAtEpochMillis","targetType","targetId"}.issubset(columns))
indexes = {row[1] for row in connection.execute("PRAGMA index_list(notifications)")}
verify("company event key index", "index_notifications_companyId_eventKey" in indexes)
verify("read ordering index", "index_notifications_companyId_readAtEpochMillis_occurredAtEpochMillis" in indexes)
verify("delivery ordering index", "index_notifications_companyId_deliveredAtEpochMillis_createdAtEpochMillis" in indexes)
verify("target index", "index_notifications_companyId_targetType_targetId" in indexes)
row = ('n1','c1','follow-up:f1:due','FOLLOW_UP_DUE','مستحقة','رسالة','فتح','FOLLOW_UP','f1',100,100,None,None)
connection.execute("INSERT INTO notifications VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", row)
verify("insert notification", connection.execute("SELECT COUNT(*) FROM notifications").fetchone()[0] == 1)
try:
    connection.execute("INSERT INTO notifications VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", ('n2',)+row[1:])
    duplicate_blocked = False
except sqlite3.IntegrityError:
    duplicate_blocked = True
verify("duplicate event blocked in company", duplicate_blocked)
connection.execute("INSERT INTO notifications VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", ('n3','c2')+row[2:])
verify("same event allowed in another company", connection.execute("SELECT COUNT(*) FROM notifications").fetchone()[0] == 2)
connection.execute("UPDATE notifications SET readAtEpochMillis=200 WHERE companyId='c1' AND id='n1' AND readAtEpochMillis IS NULL")
verify("mark read", connection.execute("SELECT readAtEpochMillis FROM notifications WHERE id='n1'").fetchone()[0] == 200)
connection.execute("UPDATE notifications SET deliveredAtEpochMillis=300 WHERE companyId='c1' AND id='n1' AND deliveredAtEpochMillis IS NULL")
verify("mark delivered", connection.execute("SELECT deliveredAtEpochMillis FROM notifications WHERE id='n1'").fetchone()[0] == 300)
unread_c2 = connection.execute("SELECT COUNT(*) FROM notifications WHERE companyId='c2' AND readAtEpochMillis IS NULL").fetchone()[0]
verify("unread company isolated", unread_c2 == 1)
connection.execute("DELETE FROM companies WHERE id='c1'")
verify("company cascade", connection.execute("SELECT COUNT(*) FROM notifications WHERE companyId='c1'").fetchone()[0] == 0)
verify("other company preserved", connection.execute("SELECT COUNT(*) FROM notifications WHERE companyId='c2'").fetchone()[0] == 1)
foreign_keys = connection.execute("PRAGMA foreign_key_list(notifications)").fetchall()
verify("company foreign key", any(row[2] == 'companies' and row[3] == 'companyId' for row in foreign_keys))
print(f"RESULT: {checks}/{checks} passed")
