import com.optimal.fleet.core.testing.fake.MutableSessionReader
import com.optimal.fleet.core.testing.fake.RecordingAuditPort
import com.optimal.fleet.core.testing.fake.RecordingTransactionRunner
import com.optimal.fleet.core.testing.fixture.CoreFixtures
import com.optimal.fleet.core.testing.fixture.SequenceValues
import com.optimal.fleet.core.testing.time.MutableTestClock
import java.time.Duration
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

private var checks = 0

private fun verify(name: String, condition: Boolean) {
    check(condition) { name }
    checks += 1
    println("PASS: $name")
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var outcome: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) { outcome = result }
    })
    return requireNotNull(outcome).getOrThrow()
}

fun main() {
    val clock = MutableTestClock.atEpochMillis(1_000)
    clock.advanceBy(Duration.ofMillis(500))
    verify("mutable clock advances deterministically", clock.millis() == 1_500L)
    verify("fixture creates tenant session", CoreFixtures.activeSession().companyId == CoreFixtures.COMPANY_A_ID)

    val sessionReader = MutableSessionReader(CoreFixtures.activeSession())
    verify("session fake exposes current value", runSuspend { sessionReader.currentSession() } != null)
    sessionReader.clear()
    verify("session fake clears value", runSuspend { sessionReader.currentSession() } == null)

    val audit = RecordingAuditPort()
    runSuspend { audit.append(CoreFixtures.auditDraft()) }
    verify("audit fake records event", audit.events.single().entityId == CoreFixtures.VEHICLE_A_ID)

    val transaction = RecordingTransactionRunner()
    val value = runSuspend { transaction.run { "committed" } }
    verify("transaction runner executes exactly once", value == "committed" && transaction.runs == 1)

    val values = SequenceValues("id")
    verify("sequence values are deterministic", values.next() == "id-1" && values.next() == "id-2")

    println("V36 testing harness: $checks/$checks")
}
