#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

./scripts/verify-v36-regressions.sh
./scripts/run-v34-maintenance-domain-compile.sh
./scripts/run-v34-maintenance-data-compile.sh
./scripts/run-v34-maintenance-presentation-compile.sh
./scripts/run-v34-maintenance-route-syntax-check.sh
./scripts/run-v34-maintenance-tests-compile.sh
python3 scripts/v35-ui-parity-contract.py
