#!/usr/bin/env python3
"""Static contract gate for OPTIMAL v45 trusted Verto maintenance feed."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
V44 = ROOT / "supabase/migrations/20260731004400_optimal_verto_invoice_feed_v23.sql"
V45 = ROOT / "supabase/migrations/20260731004500_optimal_verto_maintenance_feed_v23.sql"
PREFLIGHT = ROOT / "supabase/tests/v45_verto_maintenance_preflight.sql"
SCENARIOS = ROOT / "supabase/tests/v45_verto_maintenance_scenarios.sql"
PROMOTION = ROOT / "supabase/post_deploy/v45_promote_verto_maintenance_ready.sql"
SESSION = ROOT / "docs/sessions/v45.md"
DEPLOYMENT = ROOT / "docs/integrations/verto-maintenance-feed-deployment-v45.md"
CONTRACT = ROOT / "docs/integrations/verto-backend-contract-v23.md"
MATRIX = ROOT / "docs/integrations/verto-contract-matrix-v23.md"
ROOT_GRADLE = ROOT / "build.gradle.kts"
CI_FAST = ROOT / "scripts/ci-fast.sh"
CI_FULL = ROOT / "scripts/ci-full.sh"
VERIFY_PROJECT = ROOT / "scripts/verify-project.sh"
WRAPPER = ROOT / "scripts/verify-v45-static.sh"

checks: list[tuple[str, bool]] = []

def check(name: str, condition: bool) -> None:
    checks.append((name, condition))

def has(text: str, *values: str) -> bool:
    return all(value in text for value in values)

def block(sql: str, name: str, next_name: str | None = None) -> str:
    marker = f"create or replace function public.{name}("
    start = sql.find(marker)
    if start < 0:
        return ""
    if next_name:
        end = sql.find(f"create or replace function public.{next_name}(", start + len(marker))
        if end >= 0:
            return sql[start:end]
    return sql[start:]

required = [V44, V45, PREFLIGHT, SCENARIOS, PROMOTION, SESSION, DEPLOYMENT,
            CONTRACT, MATRIX, ROOT_GRADLE, CI_FAST, CI_FULL, VERIFY_PROJECT, WRAPPER]
for path in required:
    check(f"exists:{path.relative_to(ROOT)}", path.is_file())
if not all(path.is_file() for path in required):
    for name, ok in checks:
        print(("PASS" if ok else "FAIL"), name)
    sys.exit(1)

v45 = V45.read_text(encoding="utf-8")
preflight = PREFLIGHT.read_text(encoding="utf-8")
scenarios = SCENARIOS.read_text(encoding="utf-8")
promotion = PROMOTION.read_text(encoding="utf-8")
session = SESSION.read_text(encoding="utf-8")
deployment = DEPLOYMENT.read_text(encoding="utf-8")
contract = CONTRACT.read_text(encoding="utf-8")
matrix = MATRIX.read_text(encoding="utf-8")
root_gradle = ROOT_GRADLE.read_text(encoding="utf-8")
ci_fast = CI_FAST.read_text(encoding="utf-8")
ci_full = CI_FULL.read_text(encoding="utf-8")
verify_project = VERIFY_PROJECT.read_text(encoding="utf-8")
wrapper = WRAPPER.read_text(encoding="utf-8")

source_version = block(v45, "optimal_set_verto_maintenance_source_updated_at", "optimal_touch_verto_maintenance_from_image")
media_touch = block(v45, "optimal_touch_verto_maintenance_from_image", "optimal_verto_maintenance_feed_v23")
feed = block(v45, "optimal_verto_maintenance_feed_v23")

migrations = sorted(p.name for p in (ROOT / "supabase/migrations").glob("*.sql"))
check("order:v45-after-v44", migrations.index(V45.name) > migrations.index(V44.name))
check("scope:no-kotlin-production", not any(
    p.suffix in {".kt", ".java"} and "v45" in p.name.lower() for p in ROOT.rglob("*")
))
check("scope:contract-version-not-promoted", "set contract_version = 23" not in v45.lower())
check("scope:maintenance-readiness-false", has(v45, "set verto_maintenance_ready = false", "where singleton = true"))
check("scope:no-source-table-copy", not any(x in v45.lower() for x in (
    "create table public.optimal_verto_maintenance", "maintenance_bridge", "maintenance_snapshot"
)))
check("scope:read-only-feed", "insert into public.maintenance_records" not in feed.lower())
check("scope:no-optimal-write-rpc", "optimal_verto_update_maintenance_v23" not in v45 and "optimal_verto_delete_maintenance_v23" not in v45)

for table in ("public.maintenance_records", "public.maintenance_images", "public.invoices", "public.optimal_sync_records"):
    check(f"source:{table.split('.')[-1]}", table in feed)
for column in ("organization_id", "client_id", "vehicle_id", "invoice_id", "maintenance_date", "mileage", "notes", "created_at", "updated_at"):
    check(f"source:maintenance-column:{column}", column in v45)
for column in ("maintenance_record_id", "mime_type", "file_size"):
    check(f"source:image-column:{column}", column in v45)
check("source:preflight-table-fail-fast", has(v45, "v45_missing_verto_maintenance_records", "v45_missing_verto_maintenance_images"))
check("source:preflight-column-fail-fast", has(v45, "v45_maintenance_records_schema_mismatch", "v45_maintenance_images_schema_mismatch"))

check("source-version:trigger-function", "optimal_set_verto_maintenance_source_updated_at" in source_version)
check("source-version:monotonic", has(source_version, "new.updated_at is null", "old.updated_at is null", "new.updated_at <= old.updated_at"))
check("source-version:clock", "clock_timestamp()" in source_version)
check("source-version:record-trigger", has(v45, "optimal_verto_maintenance_record_source_version", "before update on public.maintenance_records"))
check("source-version:media-trigger", has(v45, "optimal_verto_maintenance_images_touch_record", "on public.maintenance_images"))
check("source-version:old-parent", "old.maintenance_record_id" in media_touch)
check("source-version:new-parent", "new.maintenance_record_id" in media_touch)
check("source-version:moved-image-both-parents", has(media_touch, "tg_op in ('UPDATE', 'DELETE')", "tg_op in ('INSERT', 'UPDATE')", "is distinct from old.maintenance_record_id"))
check("source-version:delete", "tg_op = 'DELETE'" in media_touch)
check("source-version:index-record", "maintenance_records_optimal_feed_idx" in v45)
check("source-version:index-media", "maintenance_images_optimal_feed_idx" in v45)

check("feed:signature", has(feed, "p_after_updated_at timestamptz", "p_after_maintenance_id uuid", "p_limit integer"))
for field in (
    "id uuid", "invoice_id uuid", "optimal_vehicle_remote_id uuid", "vehicle_name_snapshot text",
    "plate_number_snapshot text", "driver_name_snapshot text", "description text", "odometer_km bigint",
    "source_status text", "voided boolean", "completed_at timestamptz", "source_updated_at timestamptz", "media jsonb"
):
    check(f"feed:return:{field}", field in feed)
check("feed:security-definer", has(feed, "security definer", "set search_path = pg_catalog, public, auth"))
check("feed:no-company-payload", "p_company_id" not in feed)
check("feed:server-context", "optimal_verto_current_financial_context()" in feed)
check("feed:cursor-pair", "(p_after_updated_at is null) <> (p_after_maintenance_id is null)" in feed)
check("feed:cursor-error", "maintenance_cursor_pair_required" in feed)
check("feed:composite-cursor", "(t.effective_updated_at, t.id) > (p_after_updated_at, p_after_maintenance_id)" in feed)
check("feed:ordered", feed.count("order by p.effective_updated_at asc, p.id asc") >= 1)
check("feed:no-offset", " offset " not in feed.lower())
check("feed:default-limit-500", "coalesce(p_limit, 500)" in feed)
check("feed:bounded-limit", "least(greatest" in feed and "500" in feed)
check("feed:stable-source-id", re.search(r"select p\.id,\s*p\.invoice_id,\s*p\.vehicle_id", feed, re.S) is not None)
check("feed:authenticated-grant", has(v45, "grant execute on function public.optimal_verto_maintenance_feed_v23(timestamptz, uuid, integer)", "to authenticated"))
check("feed:anon-revoked", has(v45, "revoke all on function public.optimal_verto_maintenance_feed_v23", "from public, anon"))

check("tenant:maintenance-client", "c.verto_client_id = mr.client_id" in feed)
check("tenant:maintenance-org", "c.verto_organization_id = mr.organization_id" in feed)
check("tenant:invoice-client", "inv.client_id = c.verto_client_id" in feed)
check("tenant:invoice-org", "inv.organization_id = c.verto_organization_id" in feed)
check("tenant:invoice-link", "inv.id = mr.invoice_id" in feed)
check("tenant:vehicle-company", "sr.company_id = c.optimal_company_id" in feed)

check("official:vehicle-not-null", "mr.vehicle_id is not null" in feed)
check("official:invoice-not-null", "mr.invoice_id is not null" in feed)
check("official:aggregate-type", "sr.aggregate_type = 'VEHICLE'" in feed)
check("official:aggregate-id", "sr.aggregate_id = mr.vehicle_id::text" in feed)
check("official:exclude-archived", "sr.operation_type <> 'ARCHIVE'" in feed)
check("official:no-manual-text-as-id", not re.search(r"notes\s*::\s*uuid|description\s*::\s*uuid|plate[^\n]*::\s*uuid", feed, re.I))
check("official:no-vehicle-create", "insert into public.optimal_sync_records" not in feed.lower())

for token in ("vehicle_name_snapshot", "plate_number_snapshot", "driver_name_snapshot", "description", "mileage", "source_status", "completed_at"):
    check(f"snapshot:{token}", token in feed)
check("snapshot:historical-source-only", "vehicle_payload" not in feed and "sr.payload" not in feed)
check("snapshot:negative-odometer-null", "p.mileage < 0 then null" in feed)
check("snapshot:status-default", "'COMPLETED'" in feed)
check("snapshot:voided-from-invoice", has(feed, "p.invoice_voided", "false"))
check("snapshot:source-version", "p.effective_updated_at" in feed)

check("media:full-array", has(feed, "jsonb_agg", "jsonb_build_object", "'[]'::jsonb"))
for field in ("'id'", "'kind'", "'attachment_id'", "'mime_type'", "'size_bytes'", "'position'"):
    check(f"media:field:{field}", field in feed)
check("media:image-only", "'kind', 'IMAGE'" in feed)
check("media:parent-filter", "mi.maintenance_record_id = p.id" in feed)
check("media:stable-position", "row_number() over (order by mi.created_at, mi.id) - 1" in feed)
check("media:no-storage-path", "storage_path" not in feed)
check("media:no-thumbnail-path", "thumbnail_path" not in feed)
check("media:no-signed-url", "signed_url" not in feed.lower())
check("media:metadata-id", "'attachment_id', ranked.id::text" in feed)

for token in (
    "v45_missing_maintenance_feed_v23", "v45_maintenance_wire_signature_mismatch",
    "v45_official_vehicle_proof_missing", "v45_tenant_filter_missing", "v45_private_image_path_exposed",
    "v45_missing_record_source_version_trigger", "v45_missing_media_touch_trigger",
    "v45_optimal_write_path_detected", "v45_readiness_promoted_before_live_scenarios"
):
    check(f"preflight:{token}", token in preflight)
for token in (
    "v45_official_vehicle_maintenance_missing", "v45_official_vehicle_identity_changed",
    "v45_private_image_metadata_missing", "v45_private_image_path_leaked", "v45_manual_vehicle_reached_optimal",
    "v45_invoice_less_maintenance_reached_feed", "v45_invoice_without_maintenance_was_synthesized", "v45_cross_tenant_maintenance_leaked",
    "v45_maintenance_update_not_visible", "v45_record_source_version_not_advanced",
    "v45_image_update_not_visible", "v45_page_limit_returned_empty",
    "v45_composite_cursor_lost_equal_time_maintenance", "v45_half_cursor_was_accepted", "rollback;"
):
    check(f"scenario:{token}", token in scenarios)
check("scenario:official-source", "aggregate_type = 'VEHICLE'" in scenarios)
check("scenario:manual-null", has(scenarios, "'vehicle_id', null", "v_manual_id"))
check("scenario:private-path-never-returned", has(scenarios, "private/v45/not-returned.jpg", "v45_private_image_path_leaked"))
check("scenario:two-companies", has(scenarios, "v_member_a", "v_member_b", "v_other_company_id"))
check("scenario:invoice-without-maintenance", has(scenarios, "v_invoice_without_maintenance_id", "v45_invoice_without_maintenance_was_synthesized"))

check("promotion:not-migration", PROMOTION.parent.name == "post_deploy")
check("promotion:gated", has(promotion, "v45_source_version_triggers_missing", "v45_readiness_prerequisites_not_met"))
check("promotion:finance-prerequisite", "verto_finance_v23_ready = true" in promotion)
check("promotion:registration-prerequisite", "verto_registration_ready = true" in promotion)
check("promotion:sets-only-ready", "set verto_maintenance_ready = true" in promotion and "set contract_version" not in promotion.lower())

check("docs:session-scope", has(session, "v45", "الصيانة", "سيارة Optimal"))
check("docs:session-manual-excluded", has(session, "اليدوية", "لا تصل"))
check("docs:deployment-order", has(deployment, "preflight", "scenarios", "post_deploy"))
check("docs:deployment-rollback", "Rollback" in deployment or "التراجع" in deployment)
check("docs:contract-v23", "optimal_verto_maintenance_feed_v23" in contract and "VertoMaintenanceDto" in contract)
check("docs:contract-implemented", "v45" in contract and "منفذ" in contract)
check("docs:matrix-maintenance", "VertoMaintenanceMediaDto" in matrix and "VERTO_MAINTENANCE_V23" in matrix)
check("docs:matrix-status-v45", "حالة التنفيذ بعد v45" in matrix)

check("gradle:gate", has(root_gradle, "vertoMaintenanceFeedContractCheck", "scripts/v45-maintenance-feed-contract.py"))
check("ci-fast:gate", "scripts/v45-maintenance-feed-contract.py" in ci_fast)
check("ci-full:v45-wrapper", any(name in ci_full for name in ("verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh", "verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("verify-project:v45-wrapper", any(name in verify_project for name in ("verify-v45-static.sh", "verify-v46-static.sh", "verify-v47-static.sh", "verify-v48-static.sh", "verify-v49-static.sh", "verify-v55-static.sh", "verify-v56-static.sh", "verify-v57-static.sh", "verify-v58-static.sh", "verify-v59-static.sh", "verify-v60-static.sh", "verify-v61-static.sh", "verify-v62-static.sh", "verify-v63-static.sh")))
check("wrapper:v45-first", wrapper.find("v45-maintenance-feed-contract.py") < wrapper.find("v44-invoice-feed-contract.py"))
check("wrapper:v44-regression", "v44-invoice-feed-contract.py" in wrapper)

for label, text in (("v45", v45), ("preflight", preflight), ("scenarios", scenarios), ("promotion", promotion)):
    check(f"syntax:{label}-dollar-quotes", text.count("$$") % 2 == 0)
    check(f"syntax:{label}-no-merge-markers", not any(x in text for x in ("<<<<<<<", "=======", ">>>>>>>")))
    check(f"syntax:{label}-balanced-parentheses", text.count("(") == text.count(")"))

failed = []
for name, ok in checks:
    print(("PASS" if ok else "FAIL"), name)
    if not ok:
        failed.append(name)
print(f"RESULT {len(checks)-len(failed)}/{len(checks)}")
if failed:
    print("FAILED:", ", ".join(failed))
    sys.exit(1)
