#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

required = [
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceMaintenanceLinkEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceLinkAuditEntity.kt",
    "core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceLinkDao.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/linking/LinkVertoInvoice.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/domain/ports/FinanceProjectionPort.kt",
    "feature/finance/src/main/java/com/optimal/fleet/feature/finance/data/RoomFinanceProjectionPort.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/domain/importing/MaintenanceImportPort.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/ImportedMaintenancePlanner.kt",
    "feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/RoomMaintenanceImportPort.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/matching/VehicleMatcherPort.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/matching/VehicleMatchPolicy.kt",
    "feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/matching/RoomVehicleMatcher.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/verto/VertoInvoiceMaintenanceCoordinator.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/verto/VertoLinkAuditPort.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/verto/VertoLinkTransactionRunner.kt",
    "app/src/main/java/com/optimal/fleet/coordinator/verto/VertoCoordinatorModule.kt",
]
for rel in required:
    check(f"required {rel}", (ROOT / rel).is_file())

read = lambda rel: (ROOT / rel).read_text(encoding="utf-8")
database = read("core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt")
migrations = read("core/database/src/main/java/com/optimal/fleet/core/database/migration/DatabaseMigrations.kt")
vehicle_entity = read("core/database/src/main/java/com/optimal/fleet/core/database/entity/VehicleEntity.kt")
invoice_projection_entity = read("core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceProjectionEntity.kt")
link_entity = read("core/database/src/main/java/com/optimal/fleet/core/database/entity/InvoiceMaintenanceLinkEntity.kt")
link_dao = read("core/database/src/main/java/com/optimal/fleet/core/database/dao/InvoiceLinkDao.kt")
coordinator = read("app/src/main/java/com/optimal/fleet/coordinator/verto/VertoInvoiceMaintenanceCoordinator.kt")
planner = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/ImportedMaintenancePlanner.kt")
maintenance_import = read("feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/importing/RoomMaintenanceImportPort.kt")
matcher = read("feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/domain/matching/VehicleMatchPolicy.kt")
invoice_route = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsRoute.kt")
invoice_vm = read("feature/finance/src/main/java/com/optimal/fleet/feature/finance/presentation/invoices/InvoiceDetailsViewModel.kt")

check("Room version 8 or later", bool(re.search(r"version = (?:[89]|[1-9][0-9]+)", database)))
check("link entities registered", "InvoiceMaintenanceLinkEntity::class" in database and "InvoiceLinkAuditEntity::class" in database)
check("link dao exposed", "abstract fun invoiceLinkDao" in database)
check("migration 7 to 8", "MIGRATION_7_8" in migrations and "Migration(7, 8)" in migrations)
check("migration registered", "MIGRATION_7_8," in migrations)
check("migration adds VIN", "ADD COLUMN `vin`" in migrations and "ADD COLUMN `normalizedVin`" in migrations)
check("migration creates link table", "CREATE TABLE IF NOT EXISTS `verto_invoice_maintenance_links`" in migrations)
check("migration creates link audit", "CREATE TABLE IF NOT EXISTS `verto_invoice_link_audit`" in migrations)
check("VIN fields on vehicle", "val vin: String?" in vehicle_entity and "val normalizedVin: String?" in vehicle_entity)
check("VIN unique per company", 'Index(value = ["companyId", "normalizedVin"], unique = true)' in vehicle_entity)
check("one link per invoice", 'Index(value = ["invoiceProjectionId"], unique = true)' in link_entity)
check("invoice parent composite unique", 'Index(value = ["id", "companyId"], unique = true)' in invoice_projection_entity)
check("link invoice FK is company scoped", 'parentColumns = ["id", "companyId"]' in link_entity and 'childColumns = ["invoiceProjectionId", "companyId"]' in link_entity)
check("link is company scoped", all(x in link_entity for x in ["companyId", "vehicleId", "maintenanceOperationId", "linkedByUserId"]))
check("link preserves method and mode", "linkMethod" in link_entity and "serviceMode" in link_entity)
check("link save marks projection", "markProjectionLinked" in link_dao and "requiresVehicleLink = 0" in link_dao)
check("link insert guarded", "Invoice is already linked" in link_dao)

for port in ["FinanceProjectionPort", "MaintenanceImportPort", "VehicleMatcherPort", "VertoLinkAuditPort"]:
    check(f"coordinator uses {port}", port in coordinator)
check("coordinator uses transaction runner", "VertoLinkTransactionRunner" in coordinator and "transactionRunner.run" in coordinator)
check("coordinator has no DAO", "Dao" not in coordinator)
check("coordinator has no concrete data import", ".data." not in coordinator)
check("coordinator preserves idempotency", "AlreadyLinked" in coordinator and "findLink" in coordinator)
check("coordinator blocks void invoice", "InvoiceVoided" in coordinator and "invoice.voided" in coordinator)
check("trusted odometer gate", "sourceOdometerTrusted" in coordinator and "FULL_MAINTENANCE" in coordinator)
check("manual link supported", "selectManual" in coordinator and "manualVehicleId" in coordinator)
check("auto hints supported", all(x in coordinator for x in ["trustedRemoteId", "vin = command.vin", "plateNumber"]))

check("matching order remote before VIN", matcher.index("trustedRemoteId") < matcher.index("candidates.vin"))
check("matching order VIN before plate", matcher.index("candidates.vin") < matcher.index("candidates.plate"))
check("parts path in progress", "completed = command.mode == ImportedMaintenanceMode.FULL_MAINTENANCE" in planner)
check("parts path assigns total to parts", "partsMinor = sourcePartsMinor ?: totalMinor" in planner)
check("full path keeps total", "val service = sourceServiceMinor ?: max(0, totalMinor - parts)" in planner and "max(0, totalMinor - parts)" in planner)
check("negative money rejected", "Invoice total cannot be negative" in planner)
check("deterministic import ids are company scoped", '"verto-invoice:$companyId:$vertoInvoiceId"' in maintenance_import and '"verto-operation:$companyId:$vertoInvoiceId"' in maintenance_import)

check("invoice UI offers vehicle selection", "اختر السيارة" in invoice_route and "RadioButton" in invoice_route)
check("invoice UI offers parts mode", "قطع فقط" in invoice_route)
check("invoice UI offers maintenance mode", "صيانة كاملة" in invoice_route)
check("invoice UI links once", "linkedMaintenanceOperationId" in invoice_vm and "isLinking" in invoice_vm)
check("Verto values remain read only", "قيم Verto للقراءة فقط" in invoice_route)
check("void invoice hides linking", "!invoice.isVoided" in invoice_route)

# No feature imports another feature. App is the only cross-feature composition root.
violations = []
for path in (ROOT / "feature").rglob("*.kt"):
    owner = path.relative_to(ROOT / "feature").parts[0]
    text = path.read_text(encoding="utf-8")
    for imported in re.findall(r"import com\.optimal\.fleet\.feature\.([a-z]+)\.", text):
        if imported != owner:
            violations.append(f"{path.relative_to(ROOT)} -> {imported}")
check("no feature-to-feature imports", not violations, ", ".join(violations))

# Domain/presentation remain free of database and SDK types.
infra_violations = []
for feature in ["finance", "maintenance", "vehicles"]:
    for path in (ROOT / f"feature/{feature}/src/main/java").rglob("*.kt"):
        posix = path.as_posix()
        if "/domain/" not in posix and "/presentation/" not in posix:
            continue
        text = path.read_text(encoding="utf-8")
        if re.search(r"import .*\.(dao|entity|data)\.", text, re.I) or "OptimalDatabase" in text:
            infra_violations.append(str(path.relative_to(ROOT)))
check("domain and presentation infrastructure clean", not infra_violations, ", ".join(infra_violations))

build = read("app/build.gradle.kts")
check("version v10 or later", bool(re.search(r'versionName = \"0\.(?:1[0-9]|[2-9]\d)\.', build)))
check("version code advanced", bool(re.search(r"versionCode = (?:[6-9]|[1-9][0-9]+)", build)))
check("Room transaction dependency", "implementation(libs.room.ktx)" in build)

required_tests = [
    "feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/domain/matching/VehicleMatchingTest.kt",
    "feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/data/importing/PartsOnlyImportTest.kt",
    "feature/maintenance/src/test/java/com/optimal/fleet/feature/maintenance/data/importing/FullServiceImportTest.kt",
    "app/src/test/java/com/optimal/fleet/coordinator/verto/LinkInvoiceToVehicleTest.kt",
    "app/src/test/java/com/optimal/fleet/coordinator/verto/ImportIdempotencyTest.kt",
    "app/src/test/java/com/optimal/fleet/CrossFeatureArchitectureTest.kt",
]
for rel in required_tests:
    check(f"test {Path(rel).name}", (ROOT / rel).is_file())

for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}" + (f" — {detail}" if detail and not passed else ""))
passed = sum(1 for _, ok, _ in checks if ok)
print(f"\nV10 static checks: {passed}/{len(checks)}")
sys.exit(0 if passed == len(checks) else 1)
