# OPTIMAL v71 — Buildable source archive

بعد فك الضغط من جذر المشروع:

```bash
./gradlew :app:assembleDebug --offline --no-daemon --max-workers=2
```

الناتج:

```text
app/build/outputs/apk/debug/app-debug.apk
```

لبناء Release:

```bash
./gradlew :app:assembleRelease --offline --no-daemon --max-workers=2
```

نسخة Release تحتاج مفتاح توقيع خاصًا خارج الأرشيف. الأرشيف لا يحتوي كاش Gradle أو مخرجات بناء أو APK؛ سيحتاج أول بناء إلى توفر dependencies في كاش Gradle أو اتصال الشبكة لتنزيلها.
