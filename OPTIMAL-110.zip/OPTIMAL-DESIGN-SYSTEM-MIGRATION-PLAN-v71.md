# OPTIMAL — Design System & UX Migration Master Plan

**Baseline:** `OPTIMAL-v71-source-clean.zip`  
**Migration range:** Session 72 → Session 89  
**Platform:** Android / Jetpack Compose / RTL  
**Primary goal:** إعادة بناء Design System موحّد وتحسين UX على كامل التطبيق بدون كسر منطق الأعمال أو المعمارية الحالية.

---

# 0. طريقة استخدام هذا الملف

هذا الملف ليس وصفًا عامًا؛ هو **خطة تنفيذ متسلسلة**.

عند بدء أي جلسة، أعطِ المنفذ:

1. آخر ZIP ناتج من الجلسة السابقة فقط.
2. هذا الملف `OPTIMAL-DESIGN-SYSTEM-MIGRATION-PLAN-v71.md`.
3. اطلب منه صراحة: **"نفّذ SESSION-XX فقط"**.

مثال أول جلسة:

> ابدأ من `OPTIMAL-v71-source-clean.zip`. اقرأ خطة التصميم. نفّذ SESSION-72 فقط. لا تنفذ أي جلسة لاحقة. عند الانتهاء سلّمني `OPTIMAL-v72-source-clean.zip` وجميع ملفات التسليم المطلوبة.

الجلسة التالية:

> ابدأ من `OPTIMAL-v72-source-clean.zip`. اقرأ `CURRENT-DESIGN-STATE.md` و`SESSION-HANDOFF-v72.md` أولًا. ثم نفّذ SESSION-73 فقط. سلّمني `OPTIMAL-v73-source-clean.zip`.

**ممنوع الرجوع إلى v71 بعد إنتاج v72.** كل نسخة تصبح المصدر البرمجي الوحيد للجلسة التالية.

---

# 1. قانون مصدر الحقيقة

لكل SESSION-N:

- **Input code:** `OPTIMAL-v(N-1)-source-clean.zip` فقط.
- **Output code:** `OPTIMAL-vN-source-clean.zip` فقط.
- **لا دمج** مع نسخة أقدم.
- **لا تنفيذ مسبق** لجلسة N+1.
- إذا اكتُشفت مشكلة خارج نطاق الجلسة: تسجل في `DESIGN-DEBT.md` ولا تُعالج إلا إذا كانت تمنع البناء أو الاختبار الحالي.

ترتيب مصادر الحقيقة داخل كل نسخة:

1. الكود الحالي للنسخة.
2. `docs/design-system/CURRENT-DESIGN-STATE.md`.
3. `docs/design-system/MIGRATION-LEDGER.md`.
4. آخر `SESSION-HANDOFF-vXX.md`.
5. هذه الخطة العامة.

إذا تعارض وصف قديم مع الكود الناتج من الجلسة السابقة، **الكود + CURRENT-DESIGN-STATE هما المرجع النهائي**.

---

# 2. ملفات التسليم الإلزامية بعد كل جلسة

يجب أن ينتج المنفذ في نهاية SESSION-N:

- `OPTIMAL-vN-source-clean.zip`
- `BUILD-REPORT-vN.md`
- `CHANGED_FILES-vN.txt`
- `SESSION-HANDOFF-vN.md`
- تحديث `docs/design-system/CURRENT-DESIGN-STATE.md`
- تحديث `docs/design-system/MIGRATION-LEDGER.md`
- تحديث `docs/design-system/DESIGN-DEBT.md` عند الحاجة

ويجب أن يحتوي `SESSION-HANDOFF-vN.md` على:

- ما الذي نُفذ فعلًا.
- ما الذي لم يُنفذ.
- القرارات التصميمية الجديدة.
- المكونات الجديدة/المعدلة/المهجورة.
- الشاشات التي أصبحت Migrated.
- الاختبارات التي شُغلت ونتائجها.
- أي خطر معروف للجلسة التالية.
- نقطة البداية الدقيقة للجلسة التالية.

---

# 3. حدود التغيير

هذه الخطة تخص **Presentation / UX / Design System**.

## مسموح

- `core:designsystem`
- Compose UI داخل features.
- App shell / Scaffold / navigation presentation.
- UI state presentation عند الحاجة لعرض أفضل.
- تفكيك ملفات UI الكبيرة إلى Components.
- تحسين accessibility / semantics / touch targets.
- اختبارات UI وDesign System.

## ممنوع دون ضرورة قاهرة

- تغيير Domain rules.
- تغيير Database schema.
- تغيير Sync semantics.
- تغيير Supabase contracts.
- تغيير Repository behavior.
- إعادة كتابة ViewModels غير المرتبطة مباشرة بمتطلب UX.
- حذف ميزة لأن تصميمها صعب.

إذا تطلب UX تغييرًا وظيفيًا حقيقيًا، يسجل كمقترح في `DESIGN-DEBT.md` ولا يُدمج خلسة.

---

# 4. مبادئ التصميم الجديدة

يجب أن تصبح `core:designsystem` **مصدر الحقيقة الوحيد** للهوية البصرية.

المبادئ:

- RTL أصلي، وليس مجرد قلب تلقائي للعناصر.
- Tajawal هو الخط الأساسي.
- وضوح الهرمية أهم من كثرة البطاقات.
- البطاقة تستخدم فقط عندما توجد حاجة حقيقية لفصل مجموعة محتوى.
- القوائم الأساسية تعتمد Rows/Sections أكثر من Card لكل عنصر.
- الإجراءات الأساسية واضحة، والإجراءات الثانوية لا تنافسها بصريًا.
- الحالات المهمة تستخدم Semantic Colors وليست ألوانًا عشوائية داخل الشاشات.
- Touch target لا يقل عن 48dp.
- لا قيم spacing/radius/color مباشرة في الشاشات الجديدة إلا باستثناء موثق.
- لا Component جديد داخل Feature إذا كان عامًا ويمكن أن يخدم أكثر من شاشة.
- حالات Loading / Empty / Error / Offline يجب أن تكون موحدة.
- كل شاشة لها Primary Task واضح.
- النماذج الطويلة لها تقسيم منطقي وإجراء حفظ واضح الوصول.
- البحث والفلاتر يجب أن تقلل الحمل الذهني، لا أن تضيف طبقات اختيار غير ضرورية.

---

# 5. الشكل المستهدف للـ Design System

## Foundations

- Semantic colors
- Typography roles
- Spacing scale
- Shape/radius scale
- Elevation rules
- Icon sizing
- Touch targets
- Motion durations
- Content width/insets
- State colors

## Primitives

- Button
- IconButton
- TextField
- SearchField
- Chip
- Badge
- Divider
- Avatar/Icon container
- Status indicator
- Money text

## Components

- AppTopBar
- SectionHeader
- ListRow
- MetricCard
- ActionCard
- FilterBar
- SegmentedControl
- EmptyState
- ErrorState
- LoadingState
- OfflineState
- BottomActionBar
- Dialog / Sheet
- FormSection

## Screen Patterns

- Dashboard
- Searchable list
- Detail screen
- Form / editor
- Timeline / history
- Finance summary
- Chat

---

# SESSION-72 — Design Constitution + Foundations

**Input:** v71  
**Output:** v72

## الهدف

تحويل Design System الحالي من مجموعة قيم ومكونات إلى **عقد تصميم رسمي** قبل إعادة تصميم أي شاشة كبيرة.

## التنفيذ

- مراجعة `OptimalColors.kt`, `OptimalTypography.kt`, `OptimalSpacing.kt`, `OptimalShapes.kt`, `OptimalTheme.kt`.
- بناء Semantic Tokens واضحة بدل اعتماد الشاشات على أسماء ألوان خام.
- تعريف أدوار Typography العملية: page title, section title, body, metadata, amount, label.
- تثبيت spacing/radius/touch-target rules.
- تعريف قواعد elevation/surface hierarchy.
- تعريف icon sizing وcontent insets.
- إنشاء `docs/design-system/DESIGN-CONSTITUTION.md`.
- إنشاء `CURRENT-DESIGN-STATE.md`, `MIGRATION-LEDGER.md`, `DESIGN-DEBT.md`.
- إبقاء الشاشات القديمة تعمل؛ لا إعادة تصميم feature كاملة في هذه الجلسة.

## معيار القبول

- Foundations مركزية وقابلة للاستخدام من كل Feature.
- لا تغيير في Domain/Data behavior.
- المشروع يبني والاختبارات الأساسية لا تتراجع بسبب الجلسة.
- جميع القرارات الجديدة موثقة.

---

# SESSION-73 — Core Components v2

**Input:** v72 فقط  
**Output:** v73

## الهدف

بناء مكتبة المكونات التي ستستخدمها كل الشاشات اللاحقة.

## التنفيذ

إنشاء/توحيد:

- Primary / Secondary / Tertiary / Destructive buttons.
- IconButton.
- SearchField.
- TextField / MoneyField / selection fields.
- StatusBadge / Chip / FilterChip.
- SectionHeader.
- ListRow.
- MetricCard.
- ActionCard.
- FormSection.
- Empty / Loading / Error states.
- Dialog / BottomSheet conventions.
- BottomActionBar.
- Preview catalog لكل المكونات الجديدة.

إعادة تصنيف المكونات القديمة إلى:

- Keep.
- Replace.
- Deprecated.

ولا تحذف Deprecated component إذا كانت شاشة غير migrated ما زالت تعتمد عليه.

## معيار القبول

- المكونات العامة الجديدة موجودة في `core:designsystem` وليس Features.
- API naming متناسق.
- previews واختبارات Design System الأساسية تعمل.

---

# SESSION-74 — App Shell + Global Navigation UX

**Input:** v73  
**Output:** v74

## الهدف

جعل الهيكل الذي يحيط بكل الشاشات متسقًا قبل ترحيل أي Feature.

## النطاق

- `OptimalAppScaffold.kt`
- App header/top bar.
- Top-level navigation presentation.
- Back behavior presentation.
- Account / notification actions.
- Offline/sync visual status.
- Global screen padding/insets.

## التنفيذ

- توحيد Header مع Design System بدل بناء Header خاص داخل app.
- إزالة القيم البصرية المباشرة من App Shell.
- توحيد title hierarchy.
- منع ازدواج top bars داخل Features.
- التأكد من RTL والـsafe insets.

## ممنوع

لا تغير Information Architecture أو route contracts إلا إذا كان ذلك لازمًا لإصلاح خلل فعلي.

---

# SESSION-75 — Home UX Redesign

**Input:** v74  
**Output:** v75

## الهدف

إعادة بناء الشاشة الرئيسية كأول شاشة migrated بالكامل.

## التنفيذ

- تحديد Primary task والبيانات الأعلى أولوية.
- التخلص من Card-for-everything.
- بناء sections واضحة.
- توحيد metric/action patterns.
- جعل العناصر المهمة قابلة للمسح البصري السريع.
- توحيد spacing, typography, states.
- عدم تغيير business logic الخاص بالبيانات.

## معيار القبول

- Home لا تستخدم مكونات legacy إلا باستثناء موثق.
- تعتبر الشاشة Reference Screen لبقية التطبيق.

---

# SESSION-76 — Vehicles List UX

**Input:** v75  
**Output:** v76

## الهدف

إعادة تصميم شاشة السيارات والقائمة والبحث والفلاتر.

## التنفيذ

- Toolbar/search hierarchy.
- Filter model بصري أبسط.
- Vehicle row/card الجديد.
- Empty/loading/error states.
- Add vehicle entry point.
- التخلص من التكرار البصري والقيم المباشرة.

## خارج النطاق

Vehicle details/editor يؤجلان للجلسات التالية.

---

# SESSION-77 — Vehicle Details UX

**Input:** v76  
**Output:** v77

## الهدف

بناء شاشة تفاصيل سيارة ذات hierarchy واضحة.

## التنفيذ

- Summary header.
- Key vehicle facts.
- Maintenance/history shortcuts.
- Status presentation.
- Secondary actions.
- Dialogs الخاصة بالتفاصيل.

لا تغير منطق السيارة أو روابط البيانات.

---

# SESSION-78 — Vehicle Editor UX

**Input:** v77  
**Output:** v78

## الهدف

تحسين إضافة/تعديل السيارة كنموذج واضح وقابل للإكمال بسرعة.

## التنفيذ

- Form sections.
- field hierarchy.
- validation presentation.
- persistent/clear save action.
- dialogs/selectors.
- keyboard and focus behavior.

---

# SESSION-79 — Maintenance List + History

**Input:** v78  
**Output:** v79

## الهدف

خفض الحمل الذهني في أكثر شاشات الصيانة ازدحامًا.

## التنفيذ

- إعادة تصميم قائمة الصيانة.
- تبسيط Search + Tabs + Filters.
- تعريف status chips موحدة.
- Maintenance item component.
- History screen بنفس اللغة البصرية.
- pagination/load-more presentation محسنة دون تغيير data contract.

---

# SESSION-80 — Maintenance Details + Completion UX

**Input:** v79  
**Output:** v80

## الهدف

جعل تفاصيل العملية وسير إكمالها مفهومة من النظرة الأولى.

## التنفيذ

- Summary/header.
- status hierarchy.
- cost/time/vehicle information grouping.
- completion UI.
- dialogs/actions.
- error/validation presentation.

---

# SESSION-81 — Create Operation + Follow-up UX

**Input:** v80  
**Output:** v81

## الهدف

تحسين تدفق إنشاء عملية الصيانة والمتابعة دون تعديل قواعد العمل.

## التنفيذ

- Form architecture.
- section grouping.
- action placement.
- follow-up presentation.
- clear progress/status cues.
- keyboard/focus UX.

بعد هذه الجلسة يجب اعتبار `feature:maintenance` migrated بصريًا بالكامل.

---

# SESSION-82 — Finance Dashboard + Invoice List

**Input:** v81  
**Output:** v82

## الهدف

إعادة بناء القراءة المالية بحيث تظهر الأولويات والأرقام المهمة بسرعة.

## التنفيذ

- Finance dashboard hierarchy.
- semantic money styles.
- KPI/metric components.
- Invoice list.
- invoice status presentation.
- search/filter consistency.
- Empty/error/loading states.

---

# SESSION-83 — Invoice Details + Add Cost

**Input:** v82  
**Output:** v83

## الهدف

إكمال ترحيل Finance.

## التنفيذ

- Invoice details hierarchy.
- line items presentation.
- totals/payment states.
- AddCost dialog UX.
- destructive/secondary actions hierarchy.

بعدها يعتبر `feature:finance` migrated.

---

# SESSION-84 — Settings + Account + Members + Activity

**Input:** v83  
**Output:** v84

## الهدف

توحيد الشاشات الإدارية الأقل تكرارًا تحت Pattern واحد.

## التنفيذ

- Settings list pattern.
- Account/profile presentation.
- Members screen.
- member dialogs.
- Activity/audit timeline.
- dangerous actions distinction.

---

# SESSION-85 — Auth + Join Company + Notifications

**Input:** v84  
**Output:** v85

## الهدف

توحيد تجربة الدخول والانضمام والإشعارات مع Design System الجديد.

## التنفيذ

- Auth visual hierarchy.
- onboarding steps presentation.
- Join Company flow presentation.
- validation/error UX.
- Notifications list/components.
- deep-link destination presentation unaffected functionally.

لا تغير Auth protocol أو permissions logic.

---

# SESSION-86 — Verto Chat Structural Refactor

**Input:** v85  
**Output:** v86

## الهدف

تهيئة Verto قبل إعادة تصميمه؛ الملف الحالي `VertoChatScreen.kt` كبير جدًا ويجب ألا يعاد تصميمه ككتلة واحدة.

## التنفيذ

تفكيك Presentation فقط إلى مكونات واضحة، مثل:

- Chat top bar.
- Conversation state/header.
- Message bubble.
- Attachment preview.
- Composer.
- Audio message UI.
- Empty/loading/error states.
- Connection/sync indicators.

## قاعدة صارمة

- لا تغيير message semantics.
- لا تغيير sync behavior.
- لا تغيير attachment protocol.
- الهدف structural + testability أولًا، وليس إنهاء الشكل النهائي.

---

# SESSION-87 — Verto Chat UX Redesign

**Input:** v86  
**Output:** v87

## الهدف

تطبيق Design System الجديد على Chat بعد تفكيكه.

## التنفيذ

- Message hierarchy.
- composer UX.
- attachment/audio states.
- timestamps/status clarity.
- keyboard/insets.
- RTL message layout correctness.
- retry/error/offline presentation.

بعدها يعتبر `feature:verto` migrated بصريًا.

---

# SESSION-88 — Global Consistency + Accessibility + Legacy Cleanup

**Input:** v87  
**Output:** v88

## الهدف

منع بقاء خليط بين النظام القديم والجديد.

## التنفيذ

- فحص كل Presentation modules.
- إزالة المكونات Legacy غير المستخدمة.
- إزالة hardcoded visual values غير المبررة.
- توحيد semantics/content descriptions.
- فحص 48dp touch targets.
- فحص RTL.
- فحص text scaling قدر الإمكان.
- توحيد loading/error/empty/offline states.
- توحيد dialogs/sheets/buttons/forms.
- تحديث UI tests القديمة التي كانت تحمي الشكل السابق.

## معيار القبول

لا توجد شاشة production معروفة تعتمد على Design Language القديم بدون تسجيل استثناء صريح.

---

# SESSION-89 — Final UX Audit + Stabilization

**Input:** v88  
**Output:** v89

## الهدف

إخراج أول نسخة تعتبر Design System migration مكتملة.

## التنفيذ

- full static UI audit.
- build/test sweep.
- navigation smoke checks.
- design-system test sweep.
- feature UI test sweep المتاح.
- dead UI code cleanup.
- final migration ledger.
- final design debt report.
- التأكد أن كل Feature مصنف Migrated أو يحمل استثناء موثقًا.

## ممنوع

لا تبدأ redesign جديدًا هنا. هذه جلسة إغلاق واستقرار فقط.

## الناتج النهائي

`OPTIMAL-v89-source-clean.zip`

ويجب أن يحتوي:

- Design System الجديد.
- كل الشاشات migrated.
- وثائق مصدر الحقيقة النهائية.
- تقرير بما تبقى كـDesign Debt إن وجد.

---

# 6. Migration Ledger المطلوب

`MIGRATION-LEDGER.md` يجب أن يحوي جدولًا مشابهًا:

| Area | Status | Migrated in | Legacy remaining | Notes |
|---|---|---:|---|---|
| Foundations | Done | v72 | No | — |
| Core Components | Done | v73 | Temporary adapters | — |
| App Shell | Done | v74 | No | — |
| Home | Done | v75 | No | — |
| Vehicles List | Done | v76 | — | — |
| ... | ... | ... | ... | ... |

الحالات المسموحة:

- `Not started`
- `In progress`
- `Migrated`
- `Blocked`
- `Exception`

---

# 7. Definition of Done لكل جلسة

لا تعتبر الجلسة منتهية إلا إذا:

1. نُفذ نطاق الجلسة فقط.
2. لا يوجد compile error معروف ناتج عنها.
3. شُغلت الاختبارات المناسبة المتاحة وسجلت نتائجها.
4. لم يتغير Domain/Data behavior بلا سبب موثق.
5. تم تحديث CURRENT-DESIGN-STATE.
6. تم تحديث MIGRATION-LEDGER.
7. تم إنشاء SESSION-HANDOFF.
8. تم إنشاء CHANGED_FILES.
9. تم إنشاء BUILD-REPORT.
10. تم إخراج ZIP نظيف باسم النسخة الجديدة.

إذا تعذر البناء بسبب البيئة، يجب تسجيل ذلك بدقة وعدم الادعاء بنجاح البناء.

---

# 8. قواعد الجودة أثناء التنفيذ

- لا إعادة كتابة واسعة لملف سليم لمجرد توحيد الأسلوب.
- لا تكرر Component عام داخل أكثر من Feature.
- لا تستخدم `Card` كحاوية افتراضية لكل شيء.
- لا تضف Color/Spacing/Radius مباشرًا إذا يوجد Token مناسب.
- لا تضف magic number جديدًا بلا سبب.
- لا تكسر test tags المهمة دون تحديث الاختبارات المعنية.
- حافظ على accessibility semantics.
- حافظ على RTL.
- حافظ على state hoisting الحالي ما أمكن.
- لا تنقل Business Logic إلى Composables.
- لا تجعل ViewModel مسؤولًا عن قرارات شكلية بحتة.
- عند استبدال Component قديم، لا تحذفه قبل إزالة آخر استخدام production له.

---

# 9. ماذا يقرأ المنفذ في بداية كل جلسة؟

قبل لمس الكود في SESSION-N يجب أن يقرأ:

1. هذه الجلسة فقط من الخطة.
2. `CURRENT-DESIGN-STATE.md`.
3. `MIGRATION-LEDGER.md`.
4. `SESSION-HANDOFF-v(N-1).md`.
5. الملفات المرتبطة مباشرة بنطاق الجلسة.

ثم يفحص الاعتماديات قبل التعديل.

لا يبدأ بمسح المشروع كله من الصفر في كل جلسة؛ الجلسة السابقة هي التي سلّمت له السياق.

---

# 10. Prompt ثابت لتشغيل أي جلسة

انسخ النص التالي وغير رقم الجلسة والنسخة فقط:

```text
المشروع المرفق هو مصدر الحقيقة الوحيد.
اقرأ OPTIMAL-DESIGN-SYSTEM-MIGRATION-PLAN-v71.md.
اقرأ docs/design-system/CURRENT-DESIGN-STATE.md وMIGRATION-LEDGER.md وآخر SESSION-HANDOFF موجود.

نفّذ SESSION-XX فقط، ولا تبدأ أي جلسة بعدها.
حافظ على Domain/Data/Sync/Auth behavior إلا إذا كان هناك مانع بناء مباشر.
أي مشكلة خارج النطاق سجّلها في DESIGN-DEBT.md بدل توسيع العمل.

قبل التسليم شغّل ما تستطيع من build/tests وسجّل الحقيقة كما هي دون افتراض نجاح ما لم يُشغّل.

سلّمني:
- OPTIMAL-vXX-source-clean.zip
- BUILD-REPORT-vXX.md
- CHANGED_FILES-vXX.txt
- SESSION-HANDOFF-vXX.md

وتأكد أن داخل المشروع تم تحديث:
- docs/design-system/CURRENT-DESIGN-STATE.md
- docs/design-system/MIGRATION-LEDGER.md
- docs/design-system/DESIGN-DEBT.md عند الحاجة

رقم SESSION يجب أن يطابق رقم النسخة الناتجة.
```

---

# 11. أول أمر فعلي

مع `OPTIMAL-v71-source-clean.zip` استخدم:

```text
نفّذ SESSION-72 فقط حسب الخطة المرفقة.
ابدأ من v71 باعتبارها المصدر الوحيد.
لا تعيد تصميم أي Feature كاملة في هذه الجلسة.
المطلوب تأسيس Design Constitution + Foundations وتسليم OPTIMAL-v72-source-clean.zip مع ملفات التسليم المحددة.
```

بعد استلام v72، **احفظ v71 كأرشيف فقط ولا تستخدمها في التنفيذ مرة أخرى.**
