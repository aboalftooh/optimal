# PATCH MANIFEST — v90

## Session

`90 — Local durable delta state foundation`

## Modified existing files

- `core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/migration/OptimalDatabaseMigrations.kt`

## Added production files

- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullCursorEntity.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncReplicaMetadataEntity.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/DeferredRemoteChangeEntity.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullStateDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/migration/SyncRoomV4Schema.kt`

## Added tests

- `core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncRoomV4MigrationTest.kt`
- `core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncPullStateDaoTest.kt`

## Added contract/state documentation

- `docs/sync/OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96.md`
- `docs/sync/SYNC_EXECUTION_STATE.md`
- `docs/sync/handoffs/SESSION_90.md`
- `verification-v90.md`

No files were deleted. No file outside the Session 90 allowlist was modified.
