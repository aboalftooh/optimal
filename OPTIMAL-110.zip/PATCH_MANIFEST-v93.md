# PATCH MANIFEST — v93

## Session

`93 — Immediate Normal Sync after local commits`

## Added production files

- `core/model/src/main/kotlin/com/optimal/fleet/core/model/sync/SyncKickPort.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/WorkManagerSyncKickPort.kt`

## Modified production files

- `feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt`

## Added tests

- `app/src/test/java/com/optimal/fleet/sync/WorkManagerSyncKickPortTest.kt`
- `feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleImmediateSyncKickTest.kt`

## Modified tests

- `feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryTest.kt` — constructor injection only.
- `feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleRepositoryContractTest.kt` — constructor injection only.

## Sync documentation/state

- `docs/sync/SYNC_EXECUTION_STATE.md`
- `docs/sync/handoffs/SESSION_93.md`
- `PATCH_MANIFEST-v93.md`
- `verification-v93.md`

## Behavior boundary

- Synchronized local writes now request Normal Sync immediately after durable local commit.
- Feature repositories depend only on the pure `SyncKickPort` contract.
- WorkManager remains confined to the app integration layer.
- Scheduler failure is best-effort only and never rolls back a committed Room/Outbox write.
- Periodic 15-minute WorkManager scheduling remains the durability fallback.
