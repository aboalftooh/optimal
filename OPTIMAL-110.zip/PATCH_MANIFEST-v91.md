# PATCH MANIFEST — v91

## Session

`91 — Server delta contract + client Pull transport`

## Added production files

- `core/network/src/main/java/com/optimal/fleet/core/network/sync/SyncPullTransport.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SupabaseSyncPullTransport.kt`
- `backend/supabase/migrations/20260815000100_optimal_sync_delta_feed.sql`

## Modified production files

- `app/src/main/java/com/optimal/fleet/coordinator/sync/remote/OptimalSyncApi.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt`

## Added tests

- `app/src/test/java/com/optimal/fleet/sync/SyncPullTransportContractTest.kt`
- `backend/supabase/tests/optimal_sync_delta_contract.sql`

## Sync documentation/state

- `docs/sync/SYNC_EXECUTION_STATE.md`
- `docs/sync/handoffs/SESSION_91.md`
- `PATCH_MANIFEST-v91.md`
- `verification-v91.md`

## Behavior boundary

- Generic Push/Conflict targets V2 wrappers.
- Pull transport exists but is not integrated into Normal Sync yet.
- No remote row is applied to Room in v91.
- Verto specialized feeds/Realtimes remain unchanged.
