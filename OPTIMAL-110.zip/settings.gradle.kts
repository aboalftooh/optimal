pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "OPTIMAL"

includeBuild("build-logic")

include(":app")
include(":core:model")
include(":core:common")
include(":core:session")
include(":core:database")
include(":core:network")
include(":core:designsystem")
include(":core:testing")
include(":feature:auth")
include(":feature:home")
include(":feature:vehicles")
include(":feature:maintenance")
include(":feature:finance")
include(":feature:notifications")
include(":feature:settings")
include(":feature:verto")
