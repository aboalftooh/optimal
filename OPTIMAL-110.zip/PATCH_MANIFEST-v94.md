# PATCH MANIFEST — v94

## Session

`94 — Instant Sync via tenant-scoped Realtime hints`

## Added production files

- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/OptimalRealtimeHint.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/OptimalRealtimeHintSource.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/SupabaseOptimalRealtimeHintSource.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/RealtimeSyncHintCoordinator.kt`

## Modified production files

- `app/src/main/java/com/optimal/fleet/OptimalApplication.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt`

## Added tests

- `app/src/test/java/com/optimal/fleet/sync/RealtimeSyncHintCoordinatorTest.kt`
- `app/src/test/java/com/optimal/fleet/sync/RealtimeTenantIsolationTest.kt`

## Sync documentation/state

- `docs/sync/SYNC_EXECUTION_STATE.md`
- `docs/sync/handoffs/SESSION_94.md`
- `PATCH_MANIFEST-v94.md`
- `verification-v94.md`

## Behavior boundary

- Realtime subscribes only to INSERT hints for the active remote company on `optimal_sync_change_log`.
- Realtime carries only tenant + revision metadata and invokes the existing authoritative delta Pull coordinator.
- Burst/duplicate hints are coalesced and do not create one WorkManager job per server row.
- Instant Pull failure requests durable Normal Sync; socket failure itself does not alter Normal Sync status.
- Session/company change cancels the old subscription and in-flight instant Pull.
- Existing periodic Normal Sync remains the correctness path when Realtime is unavailable or silent.
