# تقرير البناء والتشغيل — OPTIMAL

**التاريخ:** 2026-08-11
**المشروع:** `com.optimal.fleet` — `0.37.0-v37` / versionCode `32`

## النتيجة

- تم ربط إعدادات البناء مؤقتاً بمشروع Supabase النشط `Verto-app` عبر متغيرات البيئة فقط.
- تم بناء نسخة Debug بنجاح.
- تم تثبيت التطبيق وتشغيله على المحاكي `emulator-5554`.
- التطبيق ظاهر عبر نافذة `scrcpy` بعنوان `OPTIMAL — scrcpy`، وليس عبر نافذة Emulator.
- لا يوجد `FATAL EXCEPTION` عند الإقلاع، و`MainActivity` هي الواجهة النشطة.

## التحقق

| الفحص | النتيجة |
|---|---|
| `:app:assembleDebug` | PASS |
| `:app:testDebugUnitTest` | PASS — 113/113 |
| تثبيت APK عبر ADB | PASS |
| تشغيل التطبيق | PASS |
| فحص بصري عبر scrcpy | PASS — شاشة التسجيل العربية ظاهرة |

الـAPK الناتج:

`app/build/outputs/apk/debug/app-debug.apk`

SHA-256:

`1d230d72cc181dd7947bb6ba6fcecc4731a7af9d8bece09fd75979371306a331`

## التغييرات المحدودة

- استعادة `gradle/wrapper/gradle-wrapper.jar` المفقود، مع الإبقاء على Gradle `8.9` المحدد أصلاً.
- إضافة imports الأيقونات الناقصة في معاينات Design System.
- إزالة imports العامة المتعارضة لـ`Modifier.weight` من شاشات الصيانة والسيارات حتى تتوافق مع Compose الحالي.
- توحيد عنوان سجل الصيانة إلى `سجل نشاط العملية` لإصلاح اختبار التنقل/النشاط.
- لم تتغير طبقات Domain أو Data أو بروتوكول الخادم أو بنية الوحدات.

## الخادم والأسرار

- تم استخدام التوكن المؤقت للتحقق من مشروع Supabase الصحيح فقط.
- لم يتم حفظ التوكن أو مفتاح publishable في المصدر أو في ملف إعداد جديد.
- تم تمرير `SUPABASE_URL` و`SUPABASE_ANON_KEY` إلى Gradle أثناء البناء فقط.
- الأرشيف لا يحتوي على حزمة `supabase/` أو migrations/functions؛ لذلك لم يتم تنفيذ `db push` أو تعديل مخطط الخادم.

## ملاحظات

- توجد تحذيرات غير مانعة عن deprecated icons وFlowPreview وتحذير KSP لفهرس Room.
- توجد نافذة `scrcpy` الخاصة بـOPTIMAL قيد التشغيل حالياً على المحاكي.
