# OPTIMAL Core Components Catalog — v109

**Established:** SESSION-73 / v73  
**Cleanup completed:** SESSION-88 / v88  
**Authority:** `core:designsystem`  
**Rule:** production screens import Core Components v2 from `com.optimal.fleet.designsystem.component.v2`. The legacy component source set was retired in SESSION-88.

## 1. Core Components v2

| Area | v2 API | Purpose |
|---|---|---|
| Buttons | `OptimalPrimaryButton` | Single primary action |
| Buttons | `OptimalSecondaryButton` | Secondary outlined action |
| Buttons | `OptimalTertiaryButton` | Low-emphasis text action |
| Buttons | `OptimalDestructiveButton` | Destructive/irreversible action |
| Buttons | `OptimalIconButton` | Accessible 48dp icon action |
| Buttons | `OptimalHeroButton` | Gradient high-emphasis dashboard action |
| Fields | `OptimalTextField` | Standard text input |
| Fields | `OptimalMoneyField` | Money input with currency suffix and numeric keyboard hint |
| Fields | `OptimalSelectionField` | Read-only selection entry point |
| Fields | `OptimalDropdownMenu` + `OptimalDropdownMenuItem` | Canonical selection-menu overlay paired with selection fields |
| Search | `OptimalSearchField` | Search with explicit clear affordance |
| Chips | `OptimalChip` | Compact neutral label/action |
| Filters | `OptimalFilterChip` | Semantic selected/unselected filter |
| Status | `OptimalStatusBadge` + `OptimalStatusTone` | Text + semantic status color |
| Structure | `OptimalSectionHeader` | Section hierarchy and optional low-emphasis action |
| Structure | `OptimalListRow` | Default list pattern; avoids card-per-row |
| Responsive | `OptimalAdaptiveLayout` | Switch between compact/large-text and regular compositions using shared thresholds |
| Responsive | `OptimalResponsivePair` | Equal-width pair on regular layouts; full-width vertical stack at compact width/fontScale 2.0 |
| Cards | `OptimalSurfaceCard` | Canonical outlined white content/state surface |
| Cards | `OptimalHeroSurface` | Pale reference hero surface for dashboard identity/summary |
| Cards | `OptimalMetricCard` | Numeric/KPI grouping only |
| Cards | `OptimalActionCard` | Explicit action grouping only |
| Forms | `OptimalFormSection` | Logical form grouping without default card chrome |
| States | `OptimalLoadingState` | Unified loading presentation |
| States | `OptimalEmptyState` | Unified empty presentation |
| States | `OptimalErrorState` | Unified recoverable error presentation |
| Dialogs | `OptimalDialog` | Standard modal convention |
| Dialogs | `OptimalConfirmationDialog` | Confirmation/destructive convention |
| Sheets | `OptimalBottomSheet` | Standard modal bottom-sheet convention |
| Actions | `OptimalBottomActionBar` | Persistent form/detail actions with insets/IME handling |
| Segments | `OptimalSegmentedControl` | Small mutually exclusive mode selection |

`OptimalComponentDefaults` centralizes component-owned dimensions. Foundation tokens from v72 remain authoritative for color, spacing, radius, elevation, icon size, touch targets and typography.

## 2. Historical legacy classification — retired in v88

### Former Keep classification

| API | Reason |
|---|---|
| `OptimalMoneyText` | Already narrow and reusable; finance migration may adopt or refine it in SESSION-82/83. |
| `OptimalFeaturePlaceholder` | Compatibility utility; not a visual pattern for migrated production screens. |
| `SegmentOption` | Retained for legacy `Segment`; v2 owns `OptimalSegmentOption`. |

### Former replacement mapping

| Legacy API | v2 replacement |
|---|---|
| legacy `component.OptimalPrimaryButton`, `PrimaryButton` | `component.v2.OptimalPrimaryButton` |
| legacy `component.SecondaryButton` | `component.v2.OptimalSecondaryButton` |
| `AppTextField` | `OptimalTextField` / `OptimalMoneyField` / `OptimalSelectionField` |
| legacy `component.OptimalSearchField`, `SearchField` | `component.v2.OptimalSearchField` |
| `AppFilterChip`, `OptimalFilterChipRow` | `OptimalFilterChip` and feature-appropriate row/flow |
| `StatusBadge` | `OptimalStatusBadge` with `OptimalStatusTone` |
| `Segment` | `OptimalSegmentedControl` |
| `AppDialog`, `ConfirmationDialog` | `OptimalDialog`, `OptimalConfirmationDialog` |
| legacy `component.OptimalLoadingState`, `OptimalEmptyState`, `OptimalErrorState` | same names under `component.v2` |

### Former deprecated patterns — removed in v88

| Legacy API | Disposition |
|---|---|
| `AppCard` | Do not use as a default wrapper in migrated screens. Choose `OptimalListRow`, `OptimalMetricCard`, `OptimalActionCard`, `OptimalFormSection`, or an unadorned layout based on intent. Existing production consumers stay untouched until their feature session. |
| `EmptyStateCard` | Card-shaped empty states are replaced by `OptimalEmptyState`; retain for compatibility. |
| `AppHeader` | Production App Shell replaced it in SESSION-74; retain only for compatibility until cleanup. |
| `BottomNavBar` / `BottomNavItem` | Production App Shell replaced these with v2 navigation in SESSION-74; retain for compatibility until cleanup. |
| `OptimalOfflineStatus` / `OfflineVisualState` | Production App Shell replaced these with v2 sync status in SESSION-74; retain for compatibility until cleanup. |

## 3. Namespace migration rule

Core Components v2 remain under `component.v2` as the canonical production namespace. SESSION-88 removed the retired legacy `component.*` source files; keeping the v2 namespace avoids a repository-wide import-only churn before final stabilization.

## 4. Usage rules for migrated screens

- Prefer `OptimalListRow` + section spacing over `AppCard` for ordinary lists.
- Use `OptimalMetricCard` only for metrics and `OptimalActionCard` only for explicit actions.
- Use semantic status tones; never communicate status with color alone.
- Use `OptimalMoneyField` only for presentation/input affordance; domain validation remains outside the component.
- `OptimalSelectionField` is a presentation entry point; ownership of selected values remains hoisted.
- `OptimalBottomActionBar` owns system/IME insets but not save/business logic.
- Dialogs/sheets receive callbacks and content; they do not own domain decisions.

## 5. App Shell v2 additions — SESSION-74

| Area | v2 API | Purpose |
|---|---|---|
| Top bar | `OptimalAppTopBar` | Global title hierarchy, navigation/action slots, status slot, and status-bar inset handling |
| Navigation | `OptimalBottomNavigation` | Stable top-level navigation presentation using semantic colors and tokenized icon/type roles |
| Navigation model | `OptimalNavigationItem` | Presentation-only item model; route ownership remains in `app` |
| Sync status | `OptimalSyncStatus` + `OptimalSyncVisualState` | Semantic saved/offline/sync/retry presentation with readable text |

App Shell ownership rule: `app` decides **where to navigate**; `core:designsystem` decides **how the shell is presented**. Route contracts and Information Architecture remain outside Design System.

## 6. Home reference-screen usage — SESSION-100

Home is the active visual reference screen for the SESSION-97→110 migration program. Later dashboard-like screens should follow its composition grammar:

- pale `OptimalHeroSurface` for the welcome/identity hero;
- `OptimalHeroButton` for the single dominant dashboard task;
- `OptimalSectionHeader` for section title + low-emphasis navigation action;
- `OptimalListRow` for ordinary records instead of card-per-row;
- `OptimalSurfaceCard` for compact outlined empty/state surfaces;
- `OptimalMetricCard` only for true numeric summaries;
- injected `VertoHomeEntry` uses the same outlined white surface + soft semantic icon/status language;
- semantic status color is always paired with readable status text;
- screen layout values come from foundation tokens, not direct `dp` literals.


## 7. SESSION-88 cleanup status

- All production App/Feature UI imports `component.v2` only.
- Retired legacy component source files were removed after the last consumers migrated.
- Palette-oriented compatibility color aliases were removed; semantic roles are the only color contract.
- `OptimalListRow`, `OptimalSelectionField`, and `OptimalSegmentedControl` now expose explicit interaction roles/selection semantics.
- Directional production icons use AutoMirrored assets where direction carries meaning.

## 8. SESSION-89 final audit

- The v2 catalog remains the canonical production component surface.
- Final static audit found no production legacy Design Language consumer.
- No new component or redesign was introduced during stabilization.
- The only confirmed dead presentation helper found by the final symbol audit (`SoftIcon`) was removed.

## 9. Vehicles pattern reference — SESSION-101

Vehicles is the first complete Searchable List → Details → Form feature migrated under the SESSION-97→110 program:

- `VehiclesScreen` uses `OptimalSearchField`, `OptimalFilterChip`, `OptimalListRow`, and canonical loading/error/empty states.
- `VehicleDetailScreen` uses `OptimalHeroSurface` for identity/status, `OptimalSectionHeader` + `OptimalListRow` for grouped details, and semantic inline error feedback.
- `VehicleEditorScreen` uses `OptimalFormSection`, `OptimalTextField`, field-level validation, and persistent `OptimalBottomActionBar`.
- `ArchiveVehicleDialog` uses `OptimalConfirmationDialog` with destructive semantics.
- `LowerOdometerDialog` uses `OptimalDialog`, `OptimalInlineStatus` with warning tone, and the canonical input field.
- `OptimalInlineStatus` is the canonical compact semantic feedback surface for non-modal warning/error/success information; feature-local banner reimplementations are not required.

## 10. Maintenance discovery reference — SESSION-102

Maintenance discovery now follows the canonical Searchable List / section grammar:

- `MaintenanceListRoute` uses shared status segments, search, filters, unified rows, semantic local-first notice, and canonical loading/error/empty/pagination states.
- `MaintenanceHistoryRoute` preserves vehicle scoping while using canonical search, unified completed-operation rows, and canonical full/append states.
- `MaintenanceFollowUpRoute` uses canonical status filters, semantic status badges, unified rows, canonical loading/error/empty states, and semantic operation-creation feedback while preserving `focusFollowUpId` scrolling.
- `OptimalInlineStatus` now supports an optional low-emphasis action so append errors can retain retry behavior without feature-local banner patterns.

## 11. Maintenance forms/details reference — SESSION-103

Maintenance create/details/edit/completion now completes the Maintenance visual migration:

- `CreateOperationRoute` uses canonical form sections, fields, segmented control, loading/empty states, semantic save feedback, and persistent bottom action.
- `VehicleSelector` pairs `OptimalSelectionField` with canonical `OptimalDropdownMenu` / `OptimalDropdownMenuItem`; selection ownership remains in the feature event contract.
- `MaintenanceDetailsContent` uses `OptimalHeroSurface`, section headers, unified detail rows, metric cards, semantic statuses and inline action feedback.
- details loading/error/not-found use canonical screen-state components.
- completion/edit remain modes of the existing details route and use canonical form sections, validation fields, semantic save feedback and persistent `OptimalBottomActionBar`.
- no field, validation path, amount, attachment, callback, route, or business behavior changed.

## 12. Finance complete reference — SESSION-104

Finance now completes the Dashboard → Details → Searchable List migration under the locked visual constitution:

- `FinanceDashboardScreen` uses `OptimalHeroSurface` for the primary total, `OptimalMetricCard` for secondary financial metrics, `OptimalListRow` for records, and semantic inline status for linked/empty/message states.
- `AddCostDialog` uses `OptimalDialog`, `OptimalFormSection`, `OptimalTextField`, `OptimalMoneyField`, field-level validation and semantic general-error feedback.
- `InvoiceDetailsScreen` uses a canonical hero for invoice identity/status/total, section headers, unified rows, metric cards and semantic Verto/link notices.
- `InvoiceListScreen` uses the Searchable List grammar with hero summary, canonical search/filter controls, unified invoice rows, canonical full states, and semantic append-error retry.
- `FinanceAmountText` always uses `OptimalTypographyRoles.amount`; Finance feature files do not define local monetary typography.
- `InvoiceListScreen` remains unreachable by design; visual migration does not change route reachability.

## 13. Settings / Members / Activity reference — SESSION-105

Settings is now the canonical reference for administrative and audit surfaces:

- `SettingsScreen` uses the Settings grammar: identity `OptimalHeroSurface`, `OptimalSectionHeader`, flat `OptimalListRow` rows and semantic icon wells.
- `JoinCompanyRoute` uses canonical form sections/fields/actions with field-adjacent validation and `OptimalInlineStatus` for domain failure feedback.
- `MembersScreen` uses canonical loading/empty states, list/status/action hierarchy and permission-gated controls without changing membership behavior.
- generated invite-code success uses `OptimalSurfaceCard` plus semantic success status; member messages use `OptimalInlineStatus` rather than a feature-local message row.
- `MembersInviteDialog` and `MemberVertoPermissionsDialog` remain canonical `OptimalDialog` + `OptimalFormSection` forms.
- `ActivityScreen` keeps its timeline semantics while using canonical list rows, status badges, pagination action and semantic append-error feedback.
- unreachable Join Company reachability and the inert Settings Help row are explicitly preserved; visual migration must not create navigation.

## 14. Notifications reference — SESSION-106

Notifications now completes the canonical notification-center migration:

- `NotificationsScreen` uses canonical loading/error/empty states and the shared list/pagination grammar without adding search or filters.
- `NotificationsHeader` keeps unread count, refresh and mark-all-read actions with semantic status and canonical buttons.
- `NotificationRow` uses `OptimalListRow`; read/unread state is exposed through readable `مقروء` / `جديد` status text, semantic badge shape/tone, icon state and accessibility state description rather than color alone.
- center messages and append errors use `OptimalInlineStatus`; no feature-local feedback banner remains.
- notification IDs, target callbacks, action labels, pagination events and ViewModel behavior remain unchanged.
## 15. Verto conversation reference — SESSION-107

Verto completes the last feature-level migration while preserving chat-native behavior:

- `VertoChatScreen` uses canonical loading/empty/gate state components while retaining the existing link/access decision order.
- cached conversation errors and composer errors use `OptimalInlineStatus`; no feature-local feedback banner remains.
- message bubbles retain side alignment and bounded chat width while using the shared OPTIMAL surface/type/color/shape language.
- the composer uses `OptimalTextField`, canonical icon actions and IME send behavior without changing send eligibility.
- `VertoAttachmentMenu` uses `OptimalDropdownMenu` / `OptimalDropdownMenuItem`; the shared menu item now exposes an optional composable leading-icon slot for semantic menus.
- audio recording, draft/playback and busy states retain their existing callbacks and use semantic OPTIMAL surfaces/actions.
- attachment transfer states use `OptimalStatusBadge` with text + icon + semantic tone; attachment opening behavior is unchanged.
- archive, pagination, send/import and attachment-transfer progress keep their existing interaction contracts and stable test tags.


## 16. Responsive / RTL / accessibility certification — SESSION-109

- `OptimalResponsiveLayout` centralizes the compact stacking threshold and accessibility font-scale trigger.
- `OptimalResponsivePair` is the canonical two-item pattern for metrics, paired fields and paired actions that would otherwise compress at 320dp or fontScale 2.0.
- `OptimalSectionHeader`, `OptimalListRow`, `OptimalActionCard` and `OptimalInlineStatus` adapt their competing horizontal content instead of clipping critical text.
- `OptimalDialog` content is scrollable at large text and its confirm/dismiss actions keep the 48dp minimum touch target.
- `OptimalBottomActionBar` keeps IME/navigation insets and uses responsive pairing for dual actions.
- OTP cells use a minimum height rather than a rigid content height.
- Arabic RTL remains owned at the app root; directional navigation assets remain AutoMirrored.
- Accessibility rule: direct action surfaces require role/label/48dp target, switches require explicit labels, and statuses always retain readable text.
