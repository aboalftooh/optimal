# OPTIMAL Design Constitution

**Established:** SESSION-72 / v72  
**Scope:** Android / Jetpack Compose / RTL  
**Authority:** `core:designsystem` is the single visual source of truth for migrated UI.

## 1. Non-negotiable principles

1. RTL is designed intentionally; layout order, alignment, navigation affordances, and reading hierarchy must make sense in Arabic.
2. Tajawal is the product typeface. Feature modules do not introduce competing font families.
3. Hierarchy comes first from typography, spacing, grouping, and surface contrast; `Card` is not the default container.
4. Semantic tokens describe intent. New migrated UI must not choose raw palette colors or arbitrary visual values when a token exists.
5. Interactive targets are at least 48dp.
6. Loading, empty, error, and offline states converge on shared design-system patterns.
7. A reusable visual primitive belongs in `core:designsystem`, not duplicated inside features.
8. Presentation refactors must not move business logic into Composables or silently change Domain/Data/Sync/Auth behavior.
9. Production UI uses only the v2 component language; retired palette aliases and legacy components were removed in SESSION-88.

## 2. Color contract

The canonical role-based API is `OptimalSemanticColors`.

| Role | Intent |
|---|---|
| `brandPrimary` | Primary brand/action emphasis |
| `brandAccent` | Secondary brand emphasis |
| `brandStrong` | Strong brand emphasis on light surfaces |
| `brandContainer` | Soft selected/brand container |
| `brandSubtle` | Very low-emphasis brand surface |
| `canvas` | App/page background |
| `surface` | Standard content surface |
| `surfaceMuted` | Secondary/grouped surface |
| `contentPrimary` | Main readable content |
| `contentSecondary` | Supporting content |
| `contentMuted` | Metadata/de-emphasized content |
| `borderSubtle` | Passive separation |
| `borderStrong` | Stronger boundary/input outline |
| `success` / `successContainer` | Positive/completed state |
| `warning` / `warningContainer` | Attention/pending state |
| `info` / `infoContainer` | Informational state |
| `danger` / `dangerContainer` | Error/destructive state |

`MaterialTheme.colorScheme` is mapped from the same semantic roles. Palette-oriented compatibility aliases were retired in SESSION-88 after the final production consumer migrated.

## 3. Typography contract

`OptimalTypography` remains the Material 3 typography implementation, backed by Tajawal. Migrated screens should think in product roles through `OptimalTypographyRoles`:

- `pageTitle`: screen identity.
- `sectionTitle`: section hierarchy.
- `body`: normal content.
- `metadata`: dates, secondary facts, helper text.
- `amount`: money/important numeric values.
- `label`: compact labels and supporting controls.

Feature-specific `sp` values are not allowed when an existing role satisfies the requirement.

## 4. Spacing and insets

Base spacing scale: `2, 4, 8, 12, 16, 24, 32, 40dp` via `OptimalSpacing`.

Semantic layout insets use `OptimalContentInsets`:

- horizontal: 18dp
- vertical: 12dp
- section gap: 20dp
- bottom safe content: 24dp

Production App/Feature UI uses foundation spacing/inset tokens; direct visual `dp` values are rejected by the SESSION-88 global audit.

## 5. Shape contract

Corner radii come from `OptimalRadius`: `8, 12, 16, 22, 28dp`. `OptimalShapes` maps these to Material 3 shape roles.

Use rounded containers when grouping or interaction requires a boundary. Do not wrap every row in an elevated/rounded card by default.

## 6. Surface and elevation hierarchy

Elevation is deliberately shallow:

- `flat` 0dp: page and ordinary grouped content.
- `raised` 1dp: selectively raised interactive/grouping surface.
- `overlay` 3dp: transient overlay/sheet-like hierarchy.
- `modal` 6dp: modal hierarchy.

Prefer spacing, dividers, typography, and semantic surface colors before adding elevation.

## 7. Icons, touch, motion, width

- Icon sizes: 18 / 24 / 32 / 40dp via `OptimalIconSize`.
- Minimum touch target: 48dp; comfortable target: 56dp via `OptimalTouchTarget`.
- Motion durations: 150 / 250 / 350ms via `OptimalMotionDuration`.
- Width guidance is exposed by `OptimalContentWidth` for compact/readable layouts; screen patterns decide when constraints apply.

Icons must have readable semantics when they communicate an action or meaning not already expressed by adjacent text.

## 8. State colors and status rules

Status is semantic, never feature-picked decoration:

- success → completed/healthy/confirmed.
- warning → pending/attention/limited risk.
- info → neutral progress/information.
- danger → failure/destructive/critical issue.

A status component should pair color with text/icon/semantics; color alone must not carry the meaning.

## 9. Legacy policy after migration

SESSION-88 removed the retired `component.*` compatibility library and palette-oriented aliases after the final production consumers migrated. New production UI must use `component.v2` plus semantic foundations. Reintroducing a legacy visual API requires an explicit design-debt entry and migration rationale.

## 10. Change rule

Any new visual value must answer one of two conditions:

1. It maps to an existing foundation token; or
2. A documented design-system decision adds/changes a token centrally.

Feature-local visual constants are exceptions and must be recorded in `DESIGN-DEBT.md` when unavoidable.
