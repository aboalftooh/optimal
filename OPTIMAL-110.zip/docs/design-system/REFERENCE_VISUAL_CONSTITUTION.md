# OPTIMAL — Reference Visual Constitution

**Frozen by:** SESSION-97  
**Baseline:** OPTIMAL-v96  
**Authority:** Sections 4–6 of `OPTIMAL_FULL_DESIGN_SYSTEM_MIGRATION_MASTER_PLAN_v96.md`.

The material below is copied verbatim from the execution contract so later sessions do not reinterpret the visual system.

# 4. Locked visual constitution

## 4.1 Color tokens

These are the canonical light-theme tokens for this migration:

```text
BrandPrimary          #235AEA
BrandAccent           #356FF2
BrandStrong           #173EBA
BrandContainer        #ECEEFF
BrandSubtle           #F6F8FF
BrandGradientStart    #2F6CF4
BrandGradientEnd      #1F49D9

Canvas                #FBFBFF
Surface               #FFFFFF
SurfaceMuted          #F6F7FB
HeroStart             #FAFCFF
HeroEnd               #F0F5FF

ContentPrimary        #101D4A
ContentSecondary      #737990
ContentMuted          #9AA0B2

BorderSubtle          #E5E8F1
BorderStrong          #D6DCEB

Success               #14965A
SuccessContainer      #EAF8F0
Warning               #A66A00
WarningContainer      #FFF4DE
Danger                #D94A66
DangerContainer       #FFF0F3
Shadow                #1B2E6B
```

No feature file may introduce a competing local palette after migration.

## 4.2 Typography

Font family: **Tajawal only**.

```text
DisplaySmall    34sp / 42sp / ExtraBold
HeadlineMedium  28sp / 36sp / ExtraBold
HeadlineSmall   25sp / 33sp / Bold
TitleLarge      20sp / 28sp / Bold
TitleMedium     16sp / 24sp / Bold
TitleSmall      14sp / 21sp / Medium
BodyLarge       16sp / 25sp / Regular
BodyMedium      14sp / 22sp / Regular
BodySmall       12sp / 18sp / Regular
LabelLarge      14sp / 20sp / Bold
LabelMedium     12sp / 17sp / Medium
LabelSmall      11sp / 16sp / Medium
```

Product roles:

```text
AppBar brand    LabelSmall / Medium
AppBar title    HeadlineMedium
Page title      HeadlineSmall
Hero title      22sp / 30sp / Bold
Section title   TitleLarge
Body            BodyMedium
Metadata        BodySmall
Amount          26sp / 32sp / ExtraBold
Action          LabelLarge
```

## 4.3 Spacing

```text
2 / 4 / 8 / 12 / 16 / 24 / 32 / 40 dp
Screen horizontal inset: 18dp
Screen vertical inset:   12dp
Section gap:              20dp
Bottom safe content:      24dp
```

No arbitrary spacing values in migrated feature presentation unless a documented technical exception is unavoidable.

## 4.4 Shape

```text
XS  8dp
S   12dp
M   16dp
L   22dp
XL  28dp
```

Reference cards and primary hero controls use the **large 22dp** language unless the component contract states otherwise.

## 4.5 Elevation

```text
Flat     0dp
Raised   2dp
Overlay  5dp
Modal    8dp
```

Use borders and soft elevation; avoid heavy Material-default shadows.

## 4.6 Touch and icon sizing

```text
Minimum touch target: 48dp
Comfortable target:   56dp
Icons: 18 / 24 / 32 / 40dp
```

## 4.7 Width behavior

```text
Compact content max: 600dp
Readable content max: 840dp
```

On tablets/large widths, content is centered/bounded; do not stretch forms/cards indefinitely.

---

# 5. Canonical visual patterns

## 5.1 App shell / top bar

Follow the supplied Home reference:

- white/light canvas.
- centered OPTIMAL brand label above the current page title when a top-level page uses the branded shell.
- large navy title.
- account and notification actions in soft circular icon wells.
- global sync status rendered as a compact semantic pill beneath/near the title when present.
- no feature-local custom top bars after its session migrates.

## 5.2 Bottom navigation

- five existing destinations remain unchanged.
- white surface, subtle top separation.
- selected destination: blue icon/label plus pale blue rounded selection background.
- inactive destinations: muted gray.
- preserve existing labels, route mapping, back-stack behavior, and visibility rules.

## 5.3 Dashboard pattern

For Home/Finance and dashboard-like summaries:

- strong page hierarchy.
- primary hero/CTA near the top.
- section title on RTL right, optional existing “عرض الكل” action on left.
- outlined white cards on light canvas.
- semantic icon wells.
- metric cards may use 2-column layout when space permits and collapse to one column when accessibility/width requires it.

## 5.4 Searchable list pattern

Used for Vehicles, Maintenance lists, InvoiceList, Activity, Notifications where appropriate:

`TopBar → search/filter/segments → list → pagination/state`

- search/filter controls use shared DS components.
- rows use shared surface/list language.
- no card-within-card nesting unless content structurally requires it.

## 5.5 Details pattern

`TopBar → summary/hero → grouped facts/content → actions`

- important amount/status/identity first.
- secondary metadata muted.
- grouped sections use clear whitespace rather than excessive containers.

## 5.6 Form pattern

`TopBar → form sections → validation/support text → persistent/clear primary action`

- one dominant primary action.
- fields share one visual contract.
- validation never relies on color alone.
- keyboard/IME and scrolling must keep focused input/action reachable.

## 5.7 Settings pattern

- section headers + clean rows.
- soft icon wells.
- avoid separate card for every single setting.
- permission/status controls align correctly in RTL.

## 5.8 Chat pattern

- keep existing Verto behavior and content.
- header, message list, attachment states, composer and audio states use semantic tokens.
- bubble/composer treatment must belong to the same OPTIMAL language without turning chat into a dashboard.

## 5.9 State pattern

Every Loading / Empty / Error / Success / Offline / Sync / Permission-gate state must use canonical DS state components.

- Loading: clear progress, stable layout where possible.
- Empty: soft icon well + concise title/body + existing action only.
- Error: semantic danger/supporting copy + existing retry/action only.
- Success: semantic success treatment.
- Offline/sync: compact, understandable, non-alarming status.
- no duplicate feature-local spinners/banners/state cards once migrated.

---

# 6. Shared component contract

By the end of SESSION-98 the shared system must expose/standardize at minimum:

### Shell
- `OptimalAppTopBar`
- `OptimalBottomNavigation`
- `OptimalSyncStatus`

### Actions
- `OptimalPrimaryButton`
- `OptimalSecondaryButton`
- `OptimalTertiaryButton`
- `OptimalDestructiveButton`
- `OptimalIconButton`
- `OptimalHeroButton`
- `OptimalBottomActionBar`

### Surfaces
- `OptimalSurfaceCard`
- `OptimalMetricCard`
- `OptimalActionCard`
- `OptimalFormSection`
- `OptimalListRow`
- `OptimalSectionHeader`

### Inputs
- `OptimalTextField`
- `OptimalMoneyField`
- `OptimalSelectionField`
- `OptimalSearchField`
- `OptimalFilterChip`
- `OptimalSegmentedControl`

### Status and feedback
- `OptimalStatusBadge`
- `OptimalLoadingState`
- `OptimalEmptyState`
- `OptimalErrorState`
- semantic inline status/banner primitive if one does not already exist.

### Overlays
- `OptimalDialog`
- `OptimalConfirmationDialog`

No Bottom Sheet is introduced because inventory has **0 production Bottom Sheets**.

---
