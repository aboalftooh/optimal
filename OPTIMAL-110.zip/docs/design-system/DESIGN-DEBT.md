# OPTIMAL Design Debt — Final v89

## Open

### DD-89-01 — Inactive standalone Invoice List entry

`InvoiceListConnected` and its migrated Invoice List presentation exist, but the current production Finance graph enters through `FinanceDashboardConnected` and navigates directly to invoice details. The standalone Invoice List entry is therefore not referenced by production navigation.

**Decision in SESSION-89:** do not remove or wire it during stabilization. Either action changes product Information Architecture or deletes an existing tested presentation path. Confirm intended Finance IA first, then remove the unused entry or add an explicit route in a later product session.

### RV-89-01 — Real Gradle verification unavailable

This is a release-verification/environment blocker, not Design Language debt. `gradle/wrapper/gradle-wrapper.jar` is absent, so Gradle cannot bootstrap. Static gates and parser checks were run; no real Gradle build/unit/UI test success is claimed.

## Closed in v89

### DD-89-02 — Dead `SoftIcon` helper

**Resolution:** removed the unreferenced Maintenance Details presentation helper after repository-wide symbol audit confirmed no caller.

## Closed in v88

- Final production legacy Design System consumers migrated to v2.
- Retired legacy component source set removed.
- Palette-oriented compatibility aliases removed.
- Production App/Feature UI direct visual `dp`/`sp` literals and raw colors eliminated.
- Interaction semantics, minimum touch targets, RTL directional affordances and text-scaling-sensitive controls normalized.

## Historical closed debt

Sessions v72–v87 progressively closed foundation, component, shell, card-per-row, form hierarchy, state handling, finance, admin, auth, notification and Verto Chat migration debt. The final authoritative status is `CURRENT-DESIGN-STATE.md` and `MIGRATION-LEDGER.md` in v89.
