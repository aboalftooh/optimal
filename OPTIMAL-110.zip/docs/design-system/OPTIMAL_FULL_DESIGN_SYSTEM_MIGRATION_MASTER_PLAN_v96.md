# OPTIMAL — Full Design-System Migration Master Plan

**Baseline / Source of Truth:** `OPTIMAL-v96-SOURCE-OF-TRUTH(1).zip`  
**UI Inventory:** `MAX_UI_SCREEN_INVENTORY(2).md` (its content correctly identifies OPTIMAL v96)  
**Visual Authority:** the supplied OPTIMAL Home screenshot  
**Execution range:** `SESSION-97` → `SESSION-110`  
**Final expected package:** `OPTIMAL-v110.zip`

> This document is an execution contract. The agent is not asked to redesign, improvise, add product features, reinterpret flows, or choose styles. It must apply the system defined here and migrate every inventoried production UI item.

---

# 1. Goal

Convert the **entire OPTIMAL production UI** to one visual system derived from the supplied reference screenshot, while preserving all existing content, navigation, business behavior, data contracts, permissions, offline/sync behavior, and feature scope.

The inventory baseline contains:

- **123** documented UI items.
- **27** screens / full-screen modes.
- **5** dialogs.
- **2** transient overlays.
- **1** independent embedded UI component.
- **88** visible states.
- **19** registered Compose Navigation destinations.
- **5** bottom-navigation destinations.
- **2** currently unreachable primary screens.
- **0** production Bottom Sheets.

Final migration means **123/123 items are covered**. A screen is not considered migrated merely because it inherits colors from `MaterialTheme`; its hierarchy, surfaces, spacing, controls, states, and responsive behavior must follow this contract.

---

# 2. Non-negotiable execution chain

Each session is the **only Source of Truth for the next session**.

| Session | Input | Successful output |
|---|---|---|
| 97 | OPTIMAL-v96 | OPTIMAL-v97 |
| 98 | OPTIMAL-v97 | OPTIMAL-v98 |
| 99 | OPTIMAL-v98 | OPTIMAL-v99 |
| 100 | OPTIMAL-v99 | OPTIMAL-v100 |
| 101 | OPTIMAL-v100 | OPTIMAL-v101 |
| 102 | OPTIMAL-v101 | OPTIMAL-v102 |
| 103 | OPTIMAL-v102 | OPTIMAL-v103 |
| 104 | OPTIMAL-v103 | OPTIMAL-v104 |
| 105 | OPTIMAL-v104 | OPTIMAL-v105 |
| 106 | OPTIMAL-v105 | OPTIMAL-v106 |
| 107 | OPTIMAL-v106 | OPTIMAL-v107 |
| 108 | OPTIMAL-v107 | OPTIMAL-v108 |
| 109 | OPTIMAL-v108 | OPTIMAL-v109 |
| 110 | OPTIMAL-v109 | OPTIMAL-v110 |

Rules:

1. Never execute session `N` from anything except the successful output of `N-1`.
2. Never skip a session.
3. If a session cannot satisfy its acceptance gates, output `OPTIMAL-vNN-BLOCKED.zip` plus a blocking report; do **not** pretend it is a successful source package.
4. Fix the blocked session before moving forward.
5. Every successful session updates the migration ledger and verification report.
6. `OPTIMAL-v96` remains the immutable baseline. Any previously produced experimental v97 visual package is **not** the baseline for this plan.

---

# 3. Functional freeze

This program is a **visual-system migration only**.

Forbidden unless explicitly required by a compile fix caused directly by the UI migration:

- ViewModel business logic changes.
- Repository/data/source changes.
- Database/schema changes.
- API/RPC changes.
- authentication behavior changes.
- permission rules changes.
- sync behavior changes.
- notification target changes.
- navigation graph changes.
- adding/removing routes.
- changing which screens are reachable.
- adding product content not already present.
- deleting labels, actions, fields, list items, states, or capabilities.
- inventing new Bottom Sheets, tabs, menus, cards, metrics, or CTAs merely because they look attractive.

The reference screenshot defines **visual language**, not business content.

---

# 4. Locked visual constitution

## 4.1 Color tokens

These are the canonical light-theme tokens for this migration:

```text
BrandPrimary          #235AEA
BrandAccent           #356FF2
BrandStrong           #173EBA
BrandContainer        #ECEEFF
BrandSubtle           #F6F8FF
BrandGradientStart    #2F6CF4
BrandGradientEnd      #1F49D9

Canvas                #FBFBFF
Surface               #FFFFFF
SurfaceMuted          #F6F7FB
HeroStart             #FAFCFF
HeroEnd               #F0F5FF

ContentPrimary        #101D4A
ContentSecondary      #737990
ContentMuted          #9AA0B2

BorderSubtle          #E5E8F1
BorderStrong          #D6DCEB

Success               #14965A
SuccessContainer      #EAF8F0
Warning               #A66A00
WarningContainer      #FFF4DE
Danger                #D94A66
DangerContainer       #FFF0F3
Shadow                #1B2E6B
```

No feature file may introduce a competing local palette after migration.

## 4.2 Typography

Font family: **Tajawal only**.

```text
DisplaySmall    34sp / 42sp / ExtraBold
HeadlineMedium  28sp / 36sp / ExtraBold
HeadlineSmall   25sp / 33sp / Bold
TitleLarge      20sp / 28sp / Bold
TitleMedium     16sp / 24sp / Bold
TitleSmall      14sp / 21sp / Medium
BodyLarge       16sp / 25sp / Regular
BodyMedium      14sp / 22sp / Regular
BodySmall       12sp / 18sp / Regular
LabelLarge      14sp / 20sp / Bold
LabelMedium     12sp / 17sp / Medium
LabelSmall      11sp / 16sp / Medium
```

Product roles:

```text
AppBar brand    LabelSmall / Medium
AppBar title    HeadlineMedium
Page title      HeadlineSmall
Hero title      22sp / 30sp / Bold
Section title   TitleLarge
Body            BodyMedium
Metadata        BodySmall
Amount          26sp / 32sp / ExtraBold
Action          LabelLarge
```

## 4.3 Spacing

```text
2 / 4 / 8 / 12 / 16 / 24 / 32 / 40 dp
Screen horizontal inset: 18dp
Screen vertical inset:   12dp
Section gap:              20dp
Bottom safe content:      24dp
```

No arbitrary spacing values in migrated feature presentation unless a documented technical exception is unavoidable.

## 4.4 Shape

```text
XS  8dp
S   12dp
M   16dp
L   22dp
XL  28dp
```

Reference cards and primary hero controls use the **large 22dp** language unless the component contract states otherwise.

## 4.5 Elevation

```text
Flat     0dp
Raised   2dp
Overlay  5dp
Modal    8dp
```

Use borders and soft elevation; avoid heavy Material-default shadows.

## 4.6 Touch and icon sizing

```text
Minimum touch target: 48dp
Comfortable target:   56dp
Icons: 18 / 24 / 32 / 40dp
```

## 4.7 Width behavior

```text
Compact content max: 600dp
Readable content max: 840dp
```

On tablets/large widths, content is centered/bounded; do not stretch forms/cards indefinitely.

---

# 5. Canonical visual patterns

## 5.1 App shell / top bar

Follow the supplied Home reference:

- white/light canvas.
- centered OPTIMAL brand label above the current page title when a top-level page uses the branded shell.
- large navy title.
- account and notification actions in soft circular icon wells.
- global sync status rendered as a compact semantic pill beneath/near the title when present.
- no feature-local custom top bars after its session migrates.

## 5.2 Bottom navigation

- five existing destinations remain unchanged.
- white surface, subtle top separation.
- selected destination: blue icon/label plus pale blue rounded selection background.
- inactive destinations: muted gray.
- preserve existing labels, route mapping, back-stack behavior, and visibility rules.

## 5.3 Dashboard pattern

For Home/Finance and dashboard-like summaries:

- strong page hierarchy.
- primary hero/CTA near the top.
- section title on RTL right, optional existing “عرض الكل” action on left.
- outlined white cards on light canvas.
- semantic icon wells.
- metric cards may use 2-column layout when space permits and collapse to one column when accessibility/width requires it.

## 5.4 Searchable list pattern

Used for Vehicles, Maintenance lists, InvoiceList, Activity, Notifications where appropriate:

`TopBar → search/filter/segments → list → pagination/state`

- search/filter controls use shared DS components.
- rows use shared surface/list language.
- no card-within-card nesting unless content structurally requires it.

## 5.5 Details pattern

`TopBar → summary/hero → grouped facts/content → actions`

- important amount/status/identity first.
- secondary metadata muted.
- grouped sections use clear whitespace rather than excessive containers.

## 5.6 Form pattern

`TopBar → form sections → validation/support text → persistent/clear primary action`

- one dominant primary action.
- fields share one visual contract.
- validation never relies on color alone.
- keyboard/IME and scrolling must keep focused input/action reachable.

## 5.7 Settings pattern

- section headers + clean rows.
- soft icon wells.
- avoid separate card for every single setting.
- permission/status controls align correctly in RTL.

## 5.8 Chat pattern

- keep existing Verto behavior and content.
- header, message list, attachment states, composer and audio states use semantic tokens.
- bubble/composer treatment must belong to the same OPTIMAL language without turning chat into a dashboard.

## 5.9 State pattern

Every Loading / Empty / Error / Success / Offline / Sync / Permission-gate state must use canonical DS state components.

- Loading: clear progress, stable layout where possible.
- Empty: soft icon well + concise title/body + existing action only.
- Error: semantic danger/supporting copy + existing retry/action only.
- Success: semantic success treatment.
- Offline/sync: compact, understandable, non-alarming status.
- no duplicate feature-local spinners/banners/state cards once migrated.

---

# 6. Shared component contract

By the end of SESSION-98 the shared system must expose/standardize at minimum:

### Shell
- `OptimalAppTopBar`
- `OptimalBottomNavigation`
- `OptimalSyncStatus`

### Actions
- `OptimalPrimaryButton`
- `OptimalSecondaryButton`
- `OptimalTertiaryButton`
- `OptimalDestructiveButton`
- `OptimalIconButton`
- `OptimalHeroButton`
- `OptimalBottomActionBar`

### Surfaces
- `OptimalSurfaceCard`
- `OptimalMetricCard`
- `OptimalActionCard`
- `OptimalFormSection`
- `OptimalListRow`
- `OptimalSectionHeader`

### Inputs
- `OptimalTextField`
- `OptimalMoneyField`
- `OptimalSelectionField`
- `OptimalSearchField`
- `OptimalFilterChip`
- `OptimalSegmentedControl`

### Status and feedback
- `OptimalStatusBadge`
- `OptimalLoadingState`
- `OptimalEmptyState`
- `OptimalErrorState`
- semantic inline status/banner primitive if one does not already exist.

### Overlays
- `OptimalDialog`
- `OptimalConfirmationDialog`

No Bottom Sheet is introduced because inventory has **0 production Bottom Sheets**.

---

# 7. Migration ledger

Create/maintain:

`docs/design-system/FULL_UI_MIGRATION_LEDGER.md`

Allowed row states:

- `UNMIGRATED`
- `IN_PROGRESS`
- `MIGRATED`
- `BLOCKED`

Do not use `REMOVED` in this visual migration because the contract does not authorize deleting unreachable UI.

Initial rows: every inventory item `SCR-*`, `DLG-*`, `OVL-*`, `CMP-*`, `STA-*`.

Final condition:

```text
SCR 27/27 MIGRATED
DLG 5/5 MIGRATED
OVL 2/2 MIGRATED
CMP 1/1 MIGRATED
STA 88/88 MIGRATED
TOTAL 123/123 MIGRATED
BLOCKED 0
UNMIGRATED 0
```

The two currently unreachable screens remain unreachable unless a separate product/navigation task later changes that.

---

# 8. Compliance guard

Create a project-local static check without adding a network dependency.

After a feature is migrated, its production presentation code must fail the guard for:

- raw `Color(0x...)` / local hex palette.
- local font family.
- local `fontSize = ...sp` where a defined typography role should be used.
- arbitrary `RoundedCornerShape(...)` instead of DS shape roles.
- arbitrary spacing `.dp` instead of DS roles, except documented technical constants.
- direct Material `Button/OutlinedButton/TextButton` where an Optimal action exists.
- direct Material `OutlinedTextField/TextField` where an Optimal field exists.
- feature-local reimplementation of a canonical card/list row/state component.
- direct `AlertDialog` outside the approved wrapper.
- non-Tajawal production typography.

During migration, the allowlist contains only feature files not yet migrated. SESSION-110 requires **empty allowlist**.

---

# 9. Session plan

## SESSION-97 — Freeze the visual constitution and coverage baseline

**Input:** OPTIMAL-v96 only  
**Output:** OPTIMAL-v97

### Purpose
Establish the migration infrastructure before changing feature screens.

### Required work

- Copy the 123 inventory rows into `FULL_UI_MIGRATION_LEDGER.md`.
- Add `REFERENCE_VISUAL_CONSTITUTION.md` containing Sections 4–6 of this plan.
- Add compliance guard with initial allowlist covering all feature UI.
- Add/verify Tajawal as the only product typeface.
- Define the exact semantic color, typography, spacing, radius, elevation, touch, icon, and content-width tokens above.
- No feature screen redesign in this session.

### Allowed files

- `core/designsystem/**`
- `docs/design-system/**`
- `scripts/**` or existing project-local verification location.
- design-system tests/previews.

### Forbidden

- `feature/**` production UI changes.
- navigation/domain/data changes.

### Acceptance

- ledger = 123 rows.
- all rows still `UNMIGRATED`.
- exact tokens exist centrally.
- guard runs and reports expected pre-migration violations/allowlist without modifying feature behavior.

---

## SESSION-98 — Build the canonical shared component system + app shell

**Input:** OPTIMAL-v97 only  
**Output:** OPTIMAL-v98

### Coverage

- global app shell.
- `STA-001`.
- `STA-085`–`STA-088`.

### Required work

Implement the full shared component contract from Section 6 and align shell/top-bar/bottom-nav/sync visuals with the reference.

### Allowed files

- `core/designsystem/**`
- `app/src/main/java/com/optimal/fleet/ui/**`
- related DS/app UI tests/previews.
- migration docs/ledger/guard.

### Acceptance

- app shell uses only canonical tokens/components.
- bottom navigation preserves 5 destinations and behavior.
- sync states SavedLocally / WaitingForNetwork / Syncing / TemporaryFailure all visually migrated.
- no route or business change.
- ledger marks only the covered global states migrated.

---

## SESSION-99 — Authentication + Account complete migration

**Input:** OPTIMAL-v98 only  
**Output:** OPTIMAL-v99

### Screens

- `SCR-001` PhoneStep
- `SCR-002` OtpStep
- `SCR-003` JoinCodeStep
- `SCR-004` CompanyDataStep
- `SCR-005` SuccessStep
- `SCR-006` AccountSummary
- `SCR-007` AccountRoute

### States

- `STA-002`–`STA-007`

### Visual rules

- Form pattern.
- pale branded surfaces only where hierarchy needs them.
- one dominant primary CTA.
- OTP boxes use central sizes/shapes/colors.
- success screen uses semantic success treatment.
- account/company sections use `OptimalFormSection`/rows, not ad-hoc cards.

### Allowed production scope

- `feature/auth/**/presentation/**`
- auth presentation tests/previews.
- DS only if a missing generic primitive is proven necessary.
- ledger/guard docs.

### Acceptance

- 7/7 screens migrated.
- 6/6 auth/account states migrated.
- no onboarding step or field removed.
- no auth logic/OTP/business behavior changed.
- auth feature removed from compliance allowlist.

---

## SESSION-100 — Home reference screen + Verto home entry

**Input:** OPTIMAL-v99 only  
**Output:** OPTIMAL-v100

### Screens/components

- `SCR-008` HomeRoute
- `CMP-001` VertoHomeEntry

### States

- `STA-008`–`STA-012`

### Exact visual intent

Home becomes the **reference implementation** for the whole system:

- light canvas.
- reference top hierarchy.
- pale welcome hero surface.
- blue gradient `OptimalHeroButton` for the existing “إضافة عملية” action.
- Verto entry as outlined white surface with soft icon well/status.
- section title right / existing “عرض الكل” left.
- follow-up/current/completed empty cards use canonical outlined state surfaces.
- financial summary uses canonical metric cards.
- no content added or removed to imitate the screenshot.

### Allowed scope

- `feature/home/**/presentation/**`
- `feature/verto/**/presentation/VertoHomeEntry.kt`
- related previews/tests.
- DS only for generic missing pieces.
- ledger/guard.

### Acceptance

- Home matches the supplied screenshot’s visual grammar while preserving real current content.
- `CMP-001` migrated.
- 5 Home states migrated.
- no Home navigation callback or data mapping changed.

---

## SESSION-101 — Vehicles feature complete migration

**Input:** OPTIMAL-v100 only  
**Output:** OPTIMAL-v101

### Screens

- `SCR-009` VehiclesScreen
- `SCR-010` VehicleDetailScreen
- `SCR-011` VehicleEditorScreen

### Dialogs

- `DLG-001` ArchiveVehicleDialog
- `DLG-002` LowerOdometerDialog

### States

- `STA-013`–`STA-021`

### Pattern mapping

- Vehicles list → Searchable List pattern.
- Vehicle details → Details pattern.
- Editor new/edit → Form pattern + `OptimalBottomActionBar`.
- destructive archive → canonical confirmation dialog.
- lower-odometer warning → canonical warning dialog.

### Allowed scope

- `feature/vehicles/**/presentation/**`
- related previews/tests.
- DS only for generic missing primitives.
- ledger/guard.

### Acceptance

- 3/3 screens, 2/2 dialogs, 9/9 states migrated.
- create/edit remain one implementation.
- archive/edit/activity/history callbacks unchanged.
- Vehicles removed from allowlist.

---

## SESSION-102 — Maintenance discovery surfaces

**Input:** OPTIMAL-v101 only  
**Output:** OPTIMAL-v102

### Screens

- `SCR-012` MaintenanceListRoute
- `SCR-014` MaintenanceHistoryRoute
- `SCR-015` MaintenanceFollowUpRoute

### States

- `STA-022`–`STA-035`

### Pattern mapping

- list/history/follow-up use Searchable List/section patterns.
- status filters/segments/chips use canonical DS.
- rows use unified hierarchy for vehicle, operation, date, status and supporting metadata.
- paging/loading/error/empty states use shared state system.

### Allowed scope

- maintenance `presentation/list/**`
- maintenance `presentation/history/**`
- maintenance `presentation/followup/**`
- related previews/tests.
- generic DS additions only if necessary.
- ledger/guard.

### Acceptance

- 3/3 screens migrated.
- 14/14 states migrated.
- focusId and vehicle scoping behavior unchanged.
- Maintenance discovery files removed from allowlist.

---

## SESSION-103 — Maintenance create/details/edit/completion

**Input:** OPTIMAL-v102 only  
**Output:** OPTIMAL-v103

### Screens

- `SCR-013` CreateOperationRoute
- `SCR-016` MaintenanceDetailsContent
- `SCR-017` MaintenanceCompletionContent
- `SCR-018` MaintenanceEditContent

### Overlay

- `OVL-001` VehicleSelector / DropdownMenu

### States

- `STA-036`–`STA-043`

### Pattern mapping

- create/edit/completion → Form pattern.
- details → Details pattern.
- selector overlay inherits DS field/menu surface.
- bottom actions remain persistent and safe above IME/navigation bars.

### Allowed scope

- maintenance `presentation/create/**`
- maintenance `presentation/details/**`
- related previews/tests.
- generic DS additions only if necessary.
- ledger/guard.

### Acceptance

- 4/4 screens, 1/1 overlay, 8/8 states migrated.
- completion/edit remain modes of the existing route; no new route.
- no field, validation path, amount, attachment, or action removed.
- entire Maintenance feature removed from allowlist.

---

## SESSION-104 — Finance complete migration, including unreachable InvoiceList

**Input:** OPTIMAL-v103 only  
**Output:** OPTIMAL-v104

### Screens

- `SCR-019` FinanceDashboardScreen
- `SCR-020` InvoiceDetailsScreen
- `SCR-021` InvoiceListScreen (**currently unreachable; still migrate visually**)

### Dialog

- `DLG-003` AddCostDialog

### States

- `STA-044`–`STA-056`

### Pattern mapping

- Finance dashboard → Dashboard pattern.
- invoice detail → Details pattern.
- InvoiceList → Searchable List pattern.
- add cost → canonical form dialog.
- monetary values use Amount typography role.

### Important constraint

Do not connect `InvoiceListScreen` to navigation and do not delete it. Reachability is outside this visual migration.

### Allowed scope

- `feature/finance/**/presentation/**`
- related previews/tests.
- generic DS additions only if necessary.
- ledger/guard.

### Acceptance

- 3/3 screens, 1/1 dialog, 13/13 states migrated.
- financial semantics/data remain unchanged.
- Finance feature removed from allowlist.

---

## SESSION-105 — Settings, members, join-company, activity

**Input:** OPTIMAL-v104 only  
**Output:** OPTIMAL-v105

### Screens

- `SCR-022` SettingsScreen
- `SCR-023` MembersScreen
- `SCR-024` JoinCompanyRoute (**currently unreachable; still migrate visually**)
- `SCR-025` ActivityScreen

### Dialogs

- `DLG-004` MembersInviteDialog
- `DLG-005` MemberVertoPermissionsDialog

### States

- `STA-057`–`STA-068`

### Pattern mapping

- settings → section headers + rows.
- members → list/status/action hierarchy.
- join-company → Form pattern.
- activity → timeline/list hierarchy.
- member dialogs → canonical dialog forms.

### Important constraints

- Do not add navigation to `settings/join-company`.
- Do not invent a Help screen for the inert Help row.
- preserve permission-dependent visibility/actions.

### Allowed scope

- `feature/settings/**/presentation/**`
- related previews/tests.
- generic DS additions only if necessary.
- ledger/guard.

### Acceptance

- 4/4 screens, 2/2 dialogs, 12/12 states migrated.
- Settings feature removed from allowlist.

---

## SESSION-106 — Notifications complete migration

**Input:** OPTIMAL-v105 only  
**Output:** OPTIMAL-v106

### Screen

- `SCR-026` NotificationsScreen

### States

- `STA-069`–`STA-073`

### Pattern mapping

- Searchable/list-state visual grammar without adding search if the feature does not currently have it.
- notification rows distinguish unread/read/status using typography + shape/weight, never color alone.
- pagination and messages use canonical state/feedback components.

### Allowed scope

- `feature/notifications/**/presentation/**`
- related previews/tests.
- generic DS additions only if necessary.
- ledger/guard.

### Acceptance

- 1/1 screen and 5/5 states migrated.
- notification target navigation unchanged.
- Notifications removed from allowlist.

---

## SESSION-107 — Verto conversation complete migration

**Input:** OPTIMAL-v106 only  
**Output:** OPTIMAL-v107

### Screen

- `SCR-027` VertoChatScreen

### Overlay

- `OVL-002` VertoAttachmentMenu

### States

- `STA-074`–`STA-084`

### Required areas

- conversation header/chrome.
- message list and empty/loading/gate states.
- attachment display/progress.
- composer.
- attachment menu.
- audio recording state.
- audio draft/playback state.
- busy/sending/importing state.
- archive-in-progress state.

### Visual rule

Preserve chat-native spatial behavior; apply the OPTIMAL palette/type/radius/icon/feedback language without forcing dashboard cards into message flow.

### Allowed scope

- `feature/verto/**/presentation/**` excluding already-migrated Home entry unless regression fix is needed.
- related previews/tests.
- generic DS additions only if necessary.
- ledger/guard.

### Acceptance

- 1/1 screen, 1/1 overlay, 11/11 states migrated.
- send/view/link/access/audio/attachment behavior unchanged.
- Verto removed from allowlist.

---

## SESSION-108 — 123-item coverage closure and duplicate-style cleanup

**Input:** OPTIMAL-v107 only  
**Output:** OPTIMAL-v108

### Purpose

This session does **not** redesign. It proves that every inventoried UI item is actually using the new system and removes obsolete **visual duplication only**.

### Required checks

- reconcile ledger against original inventory row by row.
- scan all 81 production Compose UI files from the inventory.
- find any remaining feature-local visual primitives that duplicate DS components.
- replace only visual duplicates; do not delete product functionality.
- verify the two unreachable screens are still present, visually migrated, and still unreachable.
- verify no production Bottom Sheet was invented.

### Allowed scope

- any `*/presentation/**` file only when fixing a migration miss.
- `core/designsystem/**` only for generic fixes.
- tests/previews/docs/guard.

### Acceptance

- ledger reports **123/123 MIGRATED**.
- no missing inventory row.
- no newly created UI outside inventory unless it is a shared primitive/preview and documented.
- compliance allowlist contains no migrated feature file.

---

## SESSION-109 — Responsive + RTL + accessibility certification

**Input:** OPTIMAL-v108 only  
**Output:** OPTIMAL-v109

### No new redesign

Only fix defects revealed by this matrix.

### Required matrix

#### Width
- 320dp
- 360dp
- 412dp
- 600dp
- large width where emulator/test environment permits

#### Font scale
- 1.0
- 1.3
- 2.0

#### Direction/language
- Arabic RTL mandatory.

#### Accessibility
- touch targets >=48dp.
- TalkBack semantics for actionable/icons/status.
- correct traversal/focus order.
- no color-only status communication.
- readable contrast.
- dynamic text does not clip critical content.

#### Interaction resilience
- keyboard/IME.
- back behavior.
- scrolling with large fonts.
- repeated tap does not create duplicate submit because of UI enablement regression.
- dialogs remain dismissible/usable where existing behavior allows it.
- bottom actions remain visible/reachable.

### Acceptance

- no critical clipping/overlap at required compact widths/fontScale 2.0.
- all top-level screens remain usable RTL.
- accessibility defects found by the available toolchain are fixed.
- ledger remains 123/123 migrated.

---

## SESSION-110 — Final regression, build, and design-system lock

**Input:** OPTIMAL-v109 only  
**Output:** OPTIMAL-v110

### Purpose

Final certification. No aesthetic changes except fixes required to pass gates.

### Required verification

1. Re-run original navigation/UI inventory scan.
2. Confirm all 27 screens still exist.
3. Confirm all 5 dialogs still exist.
4. Confirm both overlays still exist.
5. Confirm CMP-001 remains integrated.
6. Confirm all 88 states have a canonical visual path.
7. Confirm 5 bottom-nav destinations unchanged.
8. Confirm 19 registered destinations unchanged unless baseline tooling proves an unrelated pre-existing difference; do not silently alter them.
9. Confirm `InvoiceListScreen` and `JoinCompanyRoute` reachability remains as baseline.
10. Compliance allowlist = empty.
11. 0 raw feature palettes.
12. 0 competing font families.
13. 0 feature-local duplicate canonical buttons/fields/cards/state surfaces/dialog wrappers.
14. 0 unapproved business/navigation/data changes.
15. Run unit/lint/Compose tests already present.
16. Run `assembleDebug` when the environment permits.

### Build honesty rule

If Gradle/device/network limitations prevent a required runtime gate, do not claim full runtime PASS. Produce a precise `BLOCKED_*` report with the exact command that remains to be run. Static completion and runtime certification must be reported separately.

### Final acceptance

```text
Screens                27/27 migrated
Dialogs                  5/5 migrated
Overlays                  2/2 migrated
Embedded components       1/1 migrated
States                   88/88 migrated
TOTAL                   123/123 migrated
Compliance allowlist      0
Legacy visual paths       0
Mixed visual paths        0
Unapproved route changes  0
Unapproved logic changes  0
```

`OPTIMAL-v110.zip` becomes the new visual Source of Truth only after these gates pass.

---

# 10. Required per-session deliverables

Every session must return:

1. `OPTIMAL-vNN.zip` or `OPTIMAL-vNN-BLOCKED.zip`.
2. `SESSION-NN-REPORT.md`.
3. updated `FULL_UI_MIGRATION_LEDGER.md` inside the project.
4. verification output for the session-specific guard/tests.

Each report must contain exactly these sections:

- Input SHA-256.
- Output SHA-256.
- Scope executed.
- Files changed.
- Inventory IDs migrated in this session.
- Functional changes: must say `NONE` unless a compile-only adaptation is explicitly documented.
- Verification performed.
- PASS/BLOCKED verdict.
- Remaining ledger counts.

---

# 11. Agent command contract

When the user sends a package and says only:

```text
افحص الكود جيدًا... نفذ 103
```

The agent must interpret it as:

1. locate this master plan.
2. verify the supplied package is exactly the expected input for SESSION-103.
3. execute **only SESSION-103**.
4. obey its allowed file boundaries.
5. run its acceptance gates.
6. update ledger/report.
7. return the next source package only if PASS.
8. do not execute SESSION-104 in the same turn.

No design decisions are delegated to the execution agent; the visual system, scope, order, screen coverage, state coverage, and acceptance criteria are defined in this plan.

---

# 12. Final coverage map

| Session | Inventory coverage |
|---|---|
| 98 | STA-001, STA-085..088 + app shell |
| 99 | SCR-001..007, STA-002..007 |
| 100 | SCR-008, CMP-001, STA-008..012 |
| 101 | SCR-009..011, DLG-001..002, STA-013..021 |
| 102 | SCR-012, SCR-014..015, STA-022..035 |
| 103 | SCR-013, SCR-016..018, OVL-001, STA-036..043 |
| 104 | SCR-019..021, DLG-003, STA-044..056 |
| 105 | SCR-022..025, DLG-004..005, STA-057..068 |
| 106 | SCR-026, STA-069..073 |
| 107 | SCR-027, OVL-002, STA-074..084 |
| 108 | full 123-row reconciliation |
| 109 | responsive/RTL/accessibility certification |
| 110 | final regression/build/design lock |

Every `SCR`, `DLG`, `OVL`, `CMP`, and `STA` from the v96 inventory is assigned to an execution session. Nothing is intentionally left to “inherit automatically” without verification.
