# OPTIMAL — Full UI Migration Ledger

**Program baseline:** `OPTIMAL-v96-SOURCE-OF-TRUTH(1).zip`  
**Inventory authority:** `MAX_UI_SCREEN_INVENTORY(2).md` (content identifies OPTIMAL v96)  
**Migration contract:** `OPTIMAL_FULL_DESIGN_SYSTEM_MIGRATION_MASTER_PLAN_v96.md`  
**Initialized:** SESSION-97

`Baseline visual classification` records the v96 inventory result. `Migration status` is deliberately reset for the new reference-visual migration and therefore starts as `UNMIGRATED` for all 123 rows, even where v96 was already internally consistent.

Allowed migration states: `UNMIGRATED`, `IN_PROGRESS`, `MIGRATED`, `BLOCKED`.

## Coverage summary

| Type | Total | MIGRATED | UNMIGRATED | BLOCKED |
|---|---:|---:|---:|---:|
| SCR | 27 | 27 | 0 | 0 |
| DLG | 5 | 5 | 0 | 0 |
| OVL | 2 | 2 | 0 | 0 |
| CMP | 1 | 1 | 0 | 0 |
| STA | 88 | 88 | 0 | 0 |
| **TOTAL** | **123** | **123** | **0** | **0** |

## Full inventory ledger

| ID | Type | Display name | Technical name | Feature | Reachability | Baseline visual classification | Migration status | Scheduled session |
|---|---|---|---|---|---|---|---|---|
| SCR-001 | Screen | رقم الهاتف | PhoneStep | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-002 | Screen | تأكيد رقم الهاتف | OtpStep | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-003 | Screen | ربط الحساب بالشركة | JoinCodeStep | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-004 | Screen | بيانات الشركة / بيانات الانضمام | CompanyDataStep | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-005 | Screen | نتيجة التفعيل | SuccessStep | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-006 | Screen | ملخص الحساب | AccountSummary | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-007 | Screen | الحساب | AccountRoute | Auth/Account | Reachable | Current | MIGRATED | SESSION-99 |
| SCR-008 | Screen | الرئيسية | HomeRoute | Home | Reachable | Current | MIGRATED | SESSION-100 |
| SCR-009 | Screen | السيارات | VehiclesScreen | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| SCR-010 | Screen | تفاصيل السيارة | VehicleDetailScreen | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| SCR-011 | Screen | إضافة أو تعديل سيارة | VehicleEditorScreen | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| SCR-012 | Screen | الصيانة | MaintenanceListRoute | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| SCR-013 | Screen | إضافة عملية | CreateOperationRoute | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| SCR-014 | Screen | سجل الصيانة | MaintenanceHistoryRoute | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| SCR-015 | Screen | المتابعة الدورية | MaintenanceFollowUpRoute | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| SCR-016 | Screen | تفاصيل العملية | MaintenanceDetailsContent | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| SCR-017 | Screen | إكمال العملية | MaintenanceCompletionContent | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| SCR-018 | Screen | تعديل العملية | MaintenanceEditContent | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| SCR-019 | Screen | المالية | FinanceDashboardScreen | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| SCR-020 | Screen | تفاصيل الفاتورة | InvoiceDetailsScreen | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| SCR-021 | Screen | قائمة الفواتير | InvoiceListScreen | Finance | Unreachable | Current | MIGRATED | SESSION-104 |
| SCR-022 | Screen | المزيد | SettingsScreen | Settings | Reachable | Current | MIGRATED | SESSION-105 |
| SCR-023 | Screen | الأعضاء والدعوات | MembersScreen | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| SCR-024 | Screen | الانضمام لشركة | JoinCompanyRoute | Settings/Join | Unreachable | Current | MIGRATED | SESSION-105 |
| SCR-025 | Screen | سجل النشاط | ActivityScreen | Settings/Audit | Reachable | Current | MIGRATED | SESSION-105 |
| SCR-026 | Screen | الإشعارات | NotificationsScreen | Notifications | Reachable | Current | MIGRATED | SESSION-106 |
| SCR-027 | Screen | التواصل مع Verto | VertoChatScreen | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| DLG-001 | Dialog | تأكيد أرشفة السيارة | ArchiveVehicleDialog | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| DLG-002 | Dialog | تنبيه قراءة عداد أقل | LowerOdometerDialog | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| DLG-003 | Dialog | إضافة تكلفة | AddCostDialog | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| DLG-004 | Dialog | إنشاء دعوة | MembersInviteDialog | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| DLG-005 | Dialog | صلاحيات Verto للعضو | MemberVertoPermissionsDialog | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| OVL-001 | Overlay | قائمة اختيار السيارة | VehicleSelector / DropdownMenu | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| OVL-002 | Overlay | قائمة المرفقات | VertoAttachmentMenu | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| CMP-001 | Component | بطاقة Verto في الرئيسية | VertoHomeEntryConnected / VertoHomeEntryCard | Verto/Home | Reachable | Current | MIGRATED | SESSION-100 |
| STA-001 | State | تهيئة الجلسة | — | App | Reachable | Current | MIGRATED | SESSION-98 |
| STA-002 | State | إجراء المصادقة جارٍ | — | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| STA-003 | State | خطأ تحقق حقول Onboarding | — | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| STA-004 | State | رسالة المصادقة | — | Auth | Reachable | Current | MIGRATED | SESSION-99 |
| STA-005 | State | تحميل الحساب | — | Account | Reachable | Current | MIGRATED | SESSION-99 |
| STA-006 | State | حفظ الحساب | — | Account | Reachable | Current | MIGRATED | SESSION-99 |
| STA-007 | State | رسالة الحساب نجاح/خطأ | — | Account | Reachable | Current | MIGRATED | SESSION-99 |
| STA-008 | State | تحميل الرئيسية | — | Home | Reachable | Current | MIGRATED | SESSION-100 |
| STA-009 | State | خطأ الرئيسية | — | Home | Reachable | Current | MIGRATED | SESSION-100 |
| STA-010 | State | لا توجد عناصر قيد التنفيذ | — | Home | Reachable | Current | MIGRATED | SESSION-100 |
| STA-011 | State | لا توجد متابعة مستحقة | — | Home | Reachable | Current | MIGRATED | SESSION-100 |
| STA-012 | State | لا توجد عمليات مكتملة حديثًا | — | Home | Reachable | Current | MIGRATED | SESSION-100 |
| STA-013 | State | تحميل السيارات | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-014 | State | خطأ قائمة السيارات | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-015 | State | قائمة السيارات فارغة/لا نتائج | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-016 | State | تحميل المزيد من السيارات | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-017 | State | تحميل تفاصيل السيارة | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-018 | State | السيارة غير موجودة | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-019 | State | رسالة/خطأ إجراء السيارة | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-020 | State | تحميل محرر السيارة | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-021 | State | حفظ/تحقق محرر السيارة | — | Vehicles | Reachable | Current | MIGRATED | SESSION-101 |
| STA-022 | State | تحميل قائمة الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-023 | State | خطأ قائمة الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-024 | State | قائمة الصيانة فارغة/لا نتائج | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-025 | State | تحميل المزيد من الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-026 | State | خطأ تحميل المزيد من الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-027 | State | تحميل سجل الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-028 | State | خطأ سجل الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-029 | State | سجل الصيانة فارغ | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-030 | State | تحميل المزيد من سجل الصيانة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-031 | State | خطأ تحميل المزيد من السجل | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-032 | State | تحميل المتابعة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-033 | State | خطأ عرض المتابعة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-034 | State | المتابعة فارغة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-035 | State | خطأ إنشاء عملية من متابعة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-102 |
| STA-036 | State | تحميل إنشاء العملية | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-037 | State | لا توجد سيارات لإنشاء عملية | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-038 | State | حفظ/تحقق إنشاء العملية | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-039 | State | تحميل تفاصيل العملية | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-040 | State | خطأ تفاصيل العملية | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-041 | State | العملية غير موجودة | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-042 | State | إكمال العملية: حفظ/تحقق | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-043 | State | تعديل العملية: حفظ/تحقق | — | Maintenance | Reachable | Current | MIGRATED | SESSION-103 |
| STA-044 | State | تحميل الملخص المالي | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-045 | State | تحديث المالية | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-046 | State | لا توجد تكاليف إضافية | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-047 | State | لا توجد فواتير Verto | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-048 | State | رسالة المالية | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-049 | State | تحقق/حفظ إضافة تكلفة | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-050 | State | تحميل تفاصيل الفاتورة | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-051 | State | الفاتورة غير متاحة محليًا | — | Finance | Reachable | Current | MIGRATED | SESSION-104 |
| STA-052 | State | تحميل قائمة الفواتير | — | Finance | Unreachable | Current | MIGRATED | SESSION-104 |
| STA-053 | State | خطأ قائمة الفواتير | — | Finance | Unreachable | Current | MIGRATED | SESSION-104 |
| STA-054 | State | قائمة الفواتير فارغة/لا نتائج | — | Finance | Unreachable | Current | MIGRATED | SESSION-104 |
| STA-055 | State | تحميل المزيد من الفواتير | — | Finance | Unreachable | Current | MIGRATED | SESSION-104 |
| STA-056 | State | خطأ تحميل المزيد من الفواتير | — | Finance | Unreachable | Current | MIGRATED | SESSION-104 |
| STA-057 | State | التحقق من كود الانضمام | — | Settings/Join | Unreachable | Current | MIGRATED | SESSION-105 |
| STA-058 | State | خطأ الانضمام لشركة | — | Settings/Join | Unreachable | Current | MIGRATED | SESSION-105 |
| STA-059 | State | تحميل الأعضاء والدعوات | — | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| STA-060 | State | لا يوجد أعضاء/دعوات في قسم | — | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| STA-061 | State | كود دعوة تم إنشاؤه | — | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| STA-062 | State | رسالة الأعضاء | — | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| STA-063 | State | حفظ إجراء الأعضاء | — | Settings/Members | Reachable | Current | MIGRATED | SESSION-105 |
| STA-064 | State | تحميل سجل النشاط | — | Settings/Audit | Reachable | Current | MIGRATED | SESSION-105 |
| STA-065 | State | خطأ سجل النشاط | — | Settings/Audit | Reachable | Current | MIGRATED | SESSION-105 |
| STA-066 | State | سجل النشاط فارغ | — | Settings/Audit | Reachable | Current | MIGRATED | SESSION-105 |
| STA-067 | State | تحميل المزيد من سجل النشاط | — | Settings/Audit | Reachable | Current | MIGRATED | SESSION-105 |
| STA-068 | State | خطأ تحميل المزيد من النشاط | — | Settings/Audit | Reachable | Current | MIGRATED | SESSION-105 |
| STA-069 | State | تحميل الإشعارات | — | Notifications | Reachable | Current | MIGRATED | SESSION-106 |
| STA-070 | State | خطأ الإشعارات | — | Notifications | Reachable | Current | MIGRATED | SESSION-106 |
| STA-071 | State | لا توجد إشعارات | — | Notifications | Reachable | Current | MIGRATED | SESSION-106 |
| STA-072 | State | تحميل/خطأ المزيد من الإشعارات | — | Notifications | Reachable | Current | MIGRATED | SESSION-106 |
| STA-073 | State | رسالة مركز الإشعارات | — | Notifications | Reachable | Current | MIGRATED | SESSION-106 |
| STA-074 | State | تحميل محادثة Verto | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-075 | State | Verto: لا صلاحية عرض | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-076 | State | Verto: غير مربوط | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-077 | State | Verto: لا رسائل | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-078 | State | Verto: خطأ قراءة/تحديث | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-079 | State | Verto: تحميل رسائل أقدم | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-080 | State | Verto: تسجيل صوت | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-081 | State | Verto: مسودة صوت | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-082 | State | Verto: عملية صوتية/إرسال جارٍ | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-083 | State | Verto: أرشفة المحادثة جارٍ | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-084 | State | Verto: تقدم نقل المرفقات | — | Verto | Reachable | Current | MIGRATED | SESSION-107 |
| STA-085 | State | تم الحفظ على الهاتف | — | App/Sync | Reachable | Current | MIGRATED | SESSION-98 |
| STA-086 | State | بانتظار الشبكة | — | App/Sync | Reachable | Current | MIGRATED | SESSION-98 |
| STA-087 | State | جاري المزامنة | — | App/Sync | Reachable | Current | MIGRATED | SESSION-98 |
| STA-088 | State | تعذر مؤقتًا؛ سنعيد المحاولة | — | App/Sync | Reachable | Current | MIGRATED | SESSION-98 |

## SESSION-108 closure reconciliation

- Row-by-row reconciliation confirms 27 SCR + 5 DLG + 2 OVL + 1 CMP + 88 STA = **123/123 MIGRATED**.
- The stale SESSION-107 summary counters were corrected to match the already-migrated row data; no inventory status was changed during this reconciliation.
- The frozen 81-file production Compose/UI source manifest is `SESSION-108-UI-SOURCE-MANIFEST.txt`.
- `SCR-021` and `SCR-024` remain present, visually migrated, and unreachable by the baseline product flow.
- Production Bottom Sheets remain **0**.

## Baseline invariants

- 27 screens/full-screen modes, 5 dialogs, 2 overlays, 1 embedded component, 88 visible states.
- 19 registered Compose Navigation destinations and 5 bottom-navigation destinations.
- `SCR-021` InvoiceListScreen and `SCR-024` JoinCompanyRoute remain unreachable by baseline design.
- 0 production Bottom Sheets.
- SESSION-97 migrates no inventory ID; it only freezes the constitution, tokens, ledger, and compliance infrastructure.

## SESSION-110 final design-system lock

- Final reconciliation remains **27 SCR + 5 DLG + 2 OVL + 1 CMP + 88 STA = 123/123 MIGRATED**.
- Registered Compose Navigation destinations remain **19**; top-level/bottom-navigation destinations remain **5**.
- Compliance allowlist = **0**; legacy visual paths = **0**; mixed visual paths = **0**.
- `CMP-001` remains integrated; `SCR-021` and `SCR-024` preserve their baseline reachability states.
- No production `src/main` source file changed during SESSION-110; certification artifacts only were added/updated.
- Runtime Gradle/Android gates remain `BLOCKED_ENVIRONMENT`; this ledger records static visual migration completion only.

