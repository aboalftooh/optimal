# OPTIMAL — Offline‑First & Sync Hardening Execution Contract
## Sessions v90 → v96

**Contract revision:** R2 — Session 92 VIN completeness correction  
**Baseline:** `optimal-v89.zip`  
**Target:** Reliable Offline‑First, bidirectional multi‑device convergence, with clearly separated Normal Sync and Instant Sync.  
**Execution model:** Agent is an executor only. Architecture and behavior are fully specified in this contract.

---

# 0. How to use this contract

## Bootstrap
For **Session 90 only**, provide:
1. `optimal-v89.zip`
2. This contract file
3. Instruction: `نفذ الجلسة 90`

Session 90 must copy this contract unchanged into:

`docs/sync/OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96.md`

From **Session 91 onward**, only the latest ZIP is required.  
Example:

`optimal-v90.zip` + `نفذ الجلسة 91`

The agent must read, in this order:

1. `docs/sync/OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96.md`
2. `docs/sync/SYNC_EXECUTION_STATE.md`
3. `docs/sync/handoffs/SESSION_<previous>.md`
4. Current source code relevant to the session

The latest completed ZIP is the **only code Source of Truth**.  
The contract is the **design Source of Truth**.

---

# 1. Baseline findings from v89

The current architecture already has strong Offline‑First foundations:

- Room is the UI/local data source.
- Local writes create durable Outbox rows transactionally.
- WorkManager provides periodic/background execution.
- Retry, lease recovery, idempotency, conflict audit and process‑death recovery already exist.
- `UnifiedSyncCoordinator` currently runs:
  1. Outbox
  2. Verto invoice feed
  3. Verto maintenance feed
  4. Verto message pull
- Verto chat Realtime already behaves as a **hint that triggers Pull**, not as direct UI data.
- Feature modules are isolated; no feature→feature dependency is required for this work.

The major missing capability is:

> Local writable OPTIMAL aggregates (`VEHICLE`, `MAINTENANCE`, `FOLLOW_UP`) are pushed to the server but do not have a complete generic server→Room delta Pull path for multi‑device convergence.

A second latency problem exists:

> Local Vehicle/Maintenance writes can wait for periodic WorkManager instead of always requesting immediate background synchronization after the local transaction succeeds.

---

# 2. Scientific / engineering principles adopted

This plan follows the already supplied architecture/Kotlin references and their recurring rules:

- Single Source of Truth: UI reads Room, never Realtime/network payloads.
- Repository/Data boundary: network and persistence details stay outside Presentation/Domain business rules.
- Dependency Inversion: Domain remains independent from Room, Retrofit, WebSocket and WorkManager.
- Single Responsibility / High Cohesion: Push, Pull, Realtime hints, conflict handling and scheduling remain separate responsibilities.
- WorkManager is the durable background synchronization mechanism.
- Coroutines/Flow use structured concurrency and cancellation.
- Realtime is an optimization, not a correctness dependency.
- Idempotent operations and persistent cursors are required for restart safety.
- Cursor advancement must occur atomically with successful local application.
- Multi‑device convergence must be verified, not assumed.

Reference material already available in the project/library includes:
- `Clean Architecture & SOLID Principles for Android in Kotlin.txt`
- `android-architecture-componentsmvvm-with-dagger-retrofit.txt`
- `kotlin-reference.pdf`
- `final-architecture.md`
- prior Offline‑First verification material such as `verification-v12.md`

---

# 3. Non‑negotiable target architecture

```text
                    ┌─────────────────────────┐
                    │        Compose UI       │
                    └────────────┬────────────┘
                                 │ observes only
                                 ▼
                    ┌─────────────────────────┐
                    │          Room           │
                    │  SINGLE SOURCE OF TRUTH │
                    └─────────┬───────┬───────┘
                              │       │
                  local write │       │ remote apply
                              ▼       ▲
                    ┌─────────────────────────┐
                    │ Transactional Outbox    │
                    └────────────┬────────────┘
                                 │
                                 ▼
               ┌──────────────────────────────────┐
               │         NORMAL SYNC              │
               │ WorkManager / startup / retry    │
               │                                  │
               │ 1 Push Outbox                    │
               │ 2 Drain deferred remote changes │
               │ 3 Pull server delta pages        │
               │ 4 Apply transactionally          │
               │ 5 Commit cursor                  │
               └──────────────┬───────────────────┘
                              │
                              ▼
                         ┌──────────┐
                         │  Server  │
                         └────┬─────┘
                              │ change notification only
                              ▼
               ┌──────────────────────────────────┐
               │         INSTANT SYNC             │
               │ Supabase Realtime hint           │
               │ tenant scoped + coalesced        │
               └──────────────┬───────────────────┘
                              │
                              │ triggers same delta pull
                              ▼
                         Normal Pull
```

## Absolute rule

**Realtime MUST NOT:**
- write directly to Vehicle/Maintenance/FollowUp DAOs;
- create a second cache;
- become a second Source of Truth;
- contain conflict resolution;
- contain domain business logic.

Realtime is only:

`Remote change hint → request delta Pull`

---

# 4. Exact separation: Normal Sync vs Instant Sync

## 4.1 Normal Sync — correctness path

Normal Sync is the authoritative synchronization path.

Triggers:
- active session appears;
- app startup/session restoration;
- successful local synchronized write;
- WorkManager periodic execution;
- retry/backoff after failure;
- manual/internal recovery invocation if one already exists.

Normal Sync sequence:

```text
A. Validate active session identity
B. Recover expired Outbox leases
C. Push due Outbox mutations
D. Drain locally deferred remote changes that are now safe
E. Read local company delta cursor
F. Pull remote changes after cursor
G. Validate tenant + ordering + supported aggregate
H. Apply or defer each change inside Room transaction
I. Advance cursor in the SAME transaction
J. Repeat while server page has more data
K. Continue existing Verto invoice/maintenance/message participants
```

Correctness must remain intact if Realtime is disabled forever.

## 4.2 Instant Sync — latency path

Instant Sync exists only while the process/session is alive.

Sequence:

```text
Supabase Realtime event
→ validate active company subscription
→ extract revision if available
→ coalesce burst
→ run delta Pull from local cursor
→ Room transaction
→ UI updates naturally through Flow
```

If WebSocket disconnects, misses events or never connects:
- nothing is lost;
- periodic/startup/normal sync eventually fetches the same server changes.

---

# 5. Sync scope for this contract

Bidirectional generic OPTIMAL sync is limited to the aggregates that v89 already pushes through the generic Outbox:

- `VEHICLE`
- `MAINTENANCE`
- `FOLLOW_UP`

Existing specialized feeds remain specialized:

- Verto invoices
- Verto maintenance projections/import
- Verto conversations/messages/attachments

This contract MUST NOT convert those specialized feeds into the generic delta protocol.

No new product feature is introduced.

---

# 6. Server delta protocol — fixed design

## 6.1 Server change log

Create append‑only table:

`optimal_sync_change_log`

Required conceptual fields:

```text
revision                  BIGINT, monotonically increasing, immutable
company_id                UUID/TEXT tenant identity
aggregate_type            TEXT
aggregate_id              TEXT
operation_type            TEXT
payload                   JSONB
remote_id                 TEXT nullable
remote_version            BIGINT nullable
origin_local_version      BIGINT nullable
idempotency_key           TEXT nullable
deleted_at                TIMESTAMPTZ nullable
changed_at                TIMESTAMPTZ NOT NULL
```

Properties:

- `revision` is generated by the server, never by Android.
- Ordering uses `revision`, never device clock.
- `(company_id, idempotency_key)` is unique when idempotency key is present.
- Read index: `(company_id, revision)`.
- Rows are append‑only.
- Android cannot INSERT/UPDATE/DELETE this table directly.
- RLS/authorization is tenant scoped.

## 6.2 Cursor semantics

Client stores one cursor per company/scope:

```text
companyId
scope = OPTIMAL_MUTABLE_V1
lastAppliedRevision
updatedAtEpochMillis
```

Rules:

- Initial cursor = `0`.
- Pull query = `revision > cursor`.
- Results sorted `revision ASC`.
- Page limit fixed to `100`.
- Cursor advances only after the corresponding changes are safely represented in local Room.
- A deferred change counts as safely represented because its full payload is durably stored locally.
- Never derive cursor from `updated_at`.
- Never use phone/server wall clock as ordering authority.

## 6.3 Server RPC

Add authenticated RPC:

`optimal_pull_sync_changes`

Inputs:

```text
p_company_id
p_after_revision
p_limit
```

Server constraints:

- reject non‑member company access;
- maximum limit = `200`;
- return only the requested company;
- return only supported V1 generic aggregate types;
- order by revision ascending;
- return `has_more` or enough metadata to detect another page.

## 6.4 Existing Push compatibility

The existing v89 Push/Conflict business behavior must remain intact.

The server migration must create versioned wrapper RPCs around the existing RPCs instead of rewriting unknown working server logic:

- `optimal_apply_sync_operation_v2`
- `optimal_resolve_sync_conflict_v2`

The wrappers:
1. invoke the existing v1 RPC;
2. preserve its exact business result;
3. if and only if the operation commits successfully, append exactly one row to `optimal_sync_change_log`;
4. perform operation result + change‑log insertion in one PostgreSQL transaction;
5. use the incoming idempotency key to prevent duplicate change rows.

Android generic Push switches to the V2 wrappers only after the migration source is added.

No existing Verto RPC is changed.

---

# 7. Local Room synchronization metadata — fixed design

Do **not** add sync metadata columns to Vehicle/Maintenance domain entities.

Use sidecar tables to avoid polluting feature models.

## 7.1 `SyncPullCursorEntity`

Table: `sync_pull_cursors`

Fields:

```text
companyId
scope
lastAppliedRevision
updatedAtEpochMillis
```

Composite primary key:

`(companyId, scope)`

## 7.2 `SyncReplicaMetadataEntity`

Table: `sync_replica_metadata`

Fields:

```text
companyId
aggregateType
aggregateId
remoteId
remoteVersion
lastAppliedServerRevision
lastAppliedIdempotencyKey
updatedAtEpochMillis
```

Composite primary key:

`(companyId, aggregateType, aggregateId)`

Purpose:
- idempotent remote application;
- track last server revision per aggregate;
- keep server ordering metadata outside feature entities.

## 7.3 `DeferredRemoteChangeEntity`

Table: `sync_deferred_remote_changes`

Stores the complete remote change when local dirty state makes immediate overwrite unsafe.

Fields mirror the remote change contract sufficiently to replay it without network.

Primary key:

`revision`

Indexes:

- `(companyId, revision)`
- `(companyId, aggregateType, aggregateId)`

---

# 8. Remote apply algorithm — fixed design

For every remote change:

```text
1. Reject if company != active company.
2. Reject/retry if revision is invalid or non-positive.
3. If metadata.lastAppliedServerRevision >= change.revision:
      idempotent skip.
4. Check local Outbox for same company + aggregateType + aggregateId
   in PENDING / RUNNING / RETRY.
5. If local aggregate is dirty:
      persist full change in DeferredRemoteChangeEntity.
      do NOT overwrite local entity.
6. Else:
      apply remote payload through aggregate-specific applier.
      mark local entity synchronized.
      upsert SyncReplicaMetadataEntity.
7. Advance company cursor to change.revision.
8. Steps 5/6/7 happen in one Room transaction.
```

## Deferred replay

Before downloading the next page:

```text
for deferred changes ordered by revision:
    if aggregate still locally dirty:
        keep deferred
    else:
        apply
        update metadata
        delete deferred row
```

A newer deferred revision for the same aggregate supersedes an older one only after deterministic ordering is preserved.  
The implementation may compact older deferred rows only if tests prove no ordering information required by the applier is lost.

---

# 9. Aggregate remote ownership rules

## VEHICLE

Remote payload fields map to existing Vehicle storage fields.

Remote application:
- must preserve `companyId`;
- must use stable `aggregateId`;
- must update `remoteId` when provided;
- must not create an Outbox operation;
- must not append a user-authored audit event;
- may append a system sync audit only if existing audit architecture supports it without feature coupling;
- must set `syncStatus = SYNCED` only when no local pending operation exists.

`ARCHIVE` remains archive semantics.  
This contract does not invent hard delete behavior.

## MAINTENANCE

Remote application:
- must preserve Vehicle FK safety;
- must require referenced Vehicle to exist locally before applying;
- if its Vehicle dependency is not yet locally available in the current page, process by deterministic dependency order or defer until Vehicle is applied;
- must not create Outbox;
- must preserve source ownership rules;
- must set synchronized state only when safe.

## FOLLOW_UP

Remote application:
- requires referenced Vehicle;
- applies after Vehicle and Maintenance changes when a page contains dependencies;
- must not create Outbox.

## Dependency order inside one delta page

When several changes have different revisions, **revision order remains authoritative**.

Dependency handling must therefore not globally reorder cursor semantics.

Allowed method:
- process revision order;
- if a change cannot apply only because a required local parent is missing but a later page/change may supply it, persist it as deferred;
- advance cursor because the full remote change is durably retained;
- replay deferred after parent exists.

---

# 10. Deletion/tombstone policy

The protocol contains `deleted_at` for forward compatibility and convergence safety.

However v89 product behavior has no generic hard-delete contract for these aggregates.

Therefore in v90–v96:

- no new delete UI;
- no physical remote-delete application for Vehicle/Maintenance/FollowUp;
- receiving a non-null unsupported tombstone must be durably deferred/reported and must not silently delete local data;
- archive remains archive;
- hard-delete support requires a future explicit product/data-retention contract.

This prevents accidental destructive semantics.

---

# 11. Scheduling policy

## Periodic
Keep existing WorkManager periodic schedule:

- 15 minutes minimum interval.

## Immediate after local commit
Every successful synchronized local write must request Normal Sync immediately **after** the Room transaction commits.

Never:
- schedule before transaction success;
- schedule on validation failure;
- schedule for unchanged/no-op write;
- make scheduler failure roll back the user’s local write.

Use an abstraction owned outside feature UI so feature modules do not depend on `:app` or WorkManager.

Required pure contract:

`SyncKickPort.request(companyId)`

Implementation in `:app`:

`WorkManagerSyncKickPort → SyncScheduler.scheduleNow(companyId = ...)`

---

# 12. Realtime policy

Realtime subscribes only to the server change-log publication for the currently active remote company.

Requirements:

- subscription scoped to one company;
- cancel old channel immediately on session/company change;
- authenticated WebSocket;
- exponential reconnect delay, bounded approximately 2–30 seconds;
- coalesce bursts;
- never create one WorkManager job per received row;
- hint should contain revision when possible;
- received row payload is not trusted as application data;
- client still Pulls authoritative delta through RPC;
- session identity checked before and after Pull;
- no company data may cross session boundary.

---

# 13. Global architecture restrictions

These restrictions apply to every session.

## Forbidden

- No UI redesign.
- No navigation changes.
- No new product features.
- No feature→feature Gradle dependency.
- No ViewModel→DAO.
- No Domain→Room/Retrofit/OkHttp/WorkManager.
- No direct network result as UI Source of Truth.
- No direct Realtime→Room entity mutation.
- No rewrite of existing Verto chat sync.
- No replacement of WorkManager.
- No changes to authentication behavior except what is strictly necessary to authenticate the new Realtime source using existing session infrastructure.
- No opportunistic refactors.
- No renaming public product concepts.
- No library/version upgrades.
- No Gradle dependency additions unless explicitly allowed in the session.
- No file modification outside that session’s allowlist.

## If an unexpected dependency is required

The agent must:
1. stop that part of execution;
2. record `BLOCKED_SCOPE` in the session handoff;
3. not edit the extra file;
4. never silently expand scope.

---

# 14. Source-of-Truth chain protocol

Every session N must receive version N‑1 and produce version N.

| Session | Required input | Required output |
|---|---|---|
| 90 | v89 + this contract | v90 |
| 91 | v90 | v91 |
| 92 | v91 | v92 |
| 93 | v92 | v93 |
| 94 | v93 | v94 |
| 95 | v94 | v95 |
| 96 | v95 | v96 |

Skipping sessions is forbidden.

## Required state file

Path:

`docs/sync/SYNC_EXECUTION_STATE.md`

It must contain:

```text
CONTRACT = OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96
BASELINE = v89
LAST_COMPLETED_SESSION = <N>
CURRENT_SOURCE_OF_TRUTH = optimal-v<N>.zip
NEXT_SESSION = <N+1 or COMPLETE>
SESSION_STATUS = PASS | BLOCKED_SCOPE
```

## Required handoff

Each session creates:

`docs/sync/handoffs/SESSION_<N>.md`

Required content:
- input version;
- input ZIP SHA-256 if available in execution environment;
- session objective;
- files added;
- files modified;
- files deleted;
- static checks performed;
- tests performed;
- checks unavailable due environment;
- unresolved issues;
- `SOURCE_OF_TRUTH_READY = YES|NO`;
- exact next session.

A later agent must not execute the next session unless:

`SOURCE_OF_TRUTH_READY = YES`

## Environment rule

Internet access, remote Supabase access and a full Gradle build are useful verification but are **not prerequisites for editing the session**.

If unavailable:
- record `ENVIRONMENT_BLOCKED`;
- perform all possible static/source-level verification;
- do not falsely report runtime success.

Environment limitations must not be confused with code failure.

---

# 14.1 R2 recovery rule for the blocked Session 92

This R2 revision exists because the original Session 92 allowlist omitted the existing Vehicle Outbox payload factory even though complete Vehicle bidirectional synchronization requires VIN to be transported.

If Session 92 previously stopped with:

```text
BLOCKED_SCOPE
SOURCE_OF_TRUTH_READY = NO
```

then:

1. `optimal-v91.zip` remains the code Source of Truth.
2. Do **not** execute Session 93.
3. Attach this R2 contract together with `optimal-v91.zip`.
4. Before implementing Session 92, overwrite the embedded canonical contract with this R2 content at:
   `docs/sync/OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96.md`
5. Re-execute **Session 92 only**.
6. On successful completion, produce `optimal-v92.zip`, set `SOURCE_OF_TRUTH_READY = YES`, then continue normally with Session 93.

This amendment does not authorize any other scope expansion.

---

# 15. SESSION 90 — Local durable delta state foundation

## Input
`optimal-v89.zip` + this contract.

## Output
`optimal-v90.zip`

## Objective
Add the local persistence primitives required for restart-safe Pull and deferred remote changes, without changing sync behavior yet.

## Exact implementation

1. Copy this contract to:
   `docs/sync/OPTIMAL_OFFLINE_FIRST_SYNC_EXECUTION_CONTRACT_v90-v96.md`
2. Upgrade Room schema `3 → 4`.
3. Add:
   - `SyncPullCursorEntity`
   - `SyncReplicaMetadataEntity`
   - `DeferredRemoteChangeEntity`
   - `SyncPullStateDao`
4. Register entities/DAO in `OptimalDatabase`.
5. Add explicit `MIGRATION_3_4`.
6. Migration creates all tables and indexes deterministically.
7. Existing data is preserved unchanged.
8. Initial absence of cursor semantically means revision `0`.
9. Add migration/DAO tests.
10. Create Source-of-Truth state + handoff.

## Allowed existing files to modify

- `core/database/src/main/java/com/optimal/fleet/core/database/OptimalDatabase.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/di/DatabaseModule.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/migration/OptimalDatabaseMigrations.kt`

## Allowed new production files

- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullCursorEntity.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncReplicaMetadataEntity.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/DeferredRemoteChangeEntity.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullStateDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/migration/SyncRoomV4Schema.kt`

## Allowed tests/docs

- `core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncRoomV4MigrationTest.kt`
- `core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncPullStateDaoTest.kt`
- `docs/sync/**`
- `PATCH_MANIFEST-v90.md`
- `verification-v90.md`

## Forbidden in Session 90

Everything else.

## Acceptance

- DB version exactly `4`.
- Migration chain contains `1→2→3→4`.
- No destructive migration.
- No sync runtime behavior changed.
- No feature file touched.
- `SOURCE_OF_TRUTH_READY = YES`.

---

# 16. SESSION 91 — Server delta contract + client Pull transport

## Input
`optimal-v90.zip`

## Output
`optimal-v91.zip`

## Objective
Define the server-side durable change feed and Android transport contract, but do not apply remote rows to Room yet.

## Exact implementation

### Backend source
Create:

- append-only `optimal_sync_change_log`;
- indexes and RLS;
- authenticated `optimal_pull_sync_changes`;
- `optimal_apply_sync_operation_v2` wrapper;
- `optimal_resolve_sync_conflict_v2` wrapper;
- grants restricted to authenticated execution;
- direct table mutation denied to Android role.

### Android transport
Add pure Pull models/contract separate from existing Push interface.

Required types conceptually:

```kotlin
data class SyncRemoteChange(...)
data class SyncPullPage(...)
sealed interface SyncPullResult
interface SyncPullTransport
```

`SyncTransport` remains Push/Conflict responsibility.

Implement `SupabaseSyncPullTransport`.

Switch generic Push API endpoint annotations to the V2 wrapper names only.

No coordinator integration yet.

## Allowed existing files to modify

- `app/src/main/java/com/optimal/fleet/coordinator/sync/remote/OptimalSyncApi.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SupabaseSyncTransport.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt` **only if required for Hilt binding**

## Allowed new production files

- `core/network/src/main/java/com/optimal/fleet/core/network/sync/SyncPullTransport.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SupabaseSyncPullTransport.kt`
- `backend/supabase/migrations/20260815000100_optimal_sync_delta_feed.sql`

## Allowed tests/docs

- `app/src/test/java/com/optimal/fleet/sync/SyncPullTransportContractTest.kt`
- `backend/supabase/tests/optimal_sync_delta_contract.sql`
- `docs/sync/**`
- `PATCH_MANIFEST-v91.md`
- `verification-v91.md`

## Server migration safety restrictions

- Do not drop an existing table/function.
- Do not rewrite v1 RPC bodies.
- V2 wrappers must call v1.
- Do not broaden RLS.
- Do not embed service-role secrets.
- Do not require live server access to complete source changes.

## Acceptance

- Pull contract is independent from UI/Domain.
- Generic Push now targets V2 wrappers.
- Existing specialized Verto APIs unchanged.
- No DAO/Room remote application exists yet.
- `SOURCE_OF_TRUTH_READY = YES`.

---

# 17. SESSION 92 — Bidirectional Normal Sync: Pull → Room

## Input
`optimal-v91.zip`

## Output
`optimal-v92.zip`

## Objective
Complete generic server→Room synchronization for Vehicle, Maintenance and FollowUp.

## Exact implementation

Create a coordinator dedicated to delta Pull:

`OptimalDeltaPullCoordinator`

Responsibilities only:
- read cursor;
- drain deferred;
- call `SyncPullTransport`;
- validate page;
- apply/defer changes transactionally;
- advance cursor;
- page until complete;
- session-change abort.

Create aggregate-specific remote appliers in `:app` integration layer:

- `VehicleRemoteChangeApplier`
- `MaintenanceRemoteChangeApplier`
- `FollowUpRemoteChangeApplier`

Why in `:app`:
- `:app` is already Composition/Coordinator boundary;
- prevents feature→feature dependency;
- prevents Domain from depending on remote DTOs;
- avoids contaminating feature ViewModels.

Add a new `UnifiedSyncParticipant` with:

```text
key   = optimal_delta_pull
order = 15
```

Final Normal Sync order becomes:

```text
10 Outbox Push
15 OPTIMAL generic delta Pull
20 Verto invoice feed
30 Verto maintenance feed
40 Verto message pull
```

## Local transaction rules

For every remote row:
- aggregate company must match active session;
- server revision monotonic;
- duplicate revision idempotently ignored;
- if aggregate dirty: store deferred;
- otherwise apply;
- metadata + cursor commit atomically.

## Required DAO additions

`SyncQueueDao`:
- query whether an aggregate has PENDING/RUNNING/RETRY local operation.

Vehicle/Maintenance/FollowUp DAOs:
- remote upsert/update methods that **do not enqueue Outbox**.

No feature repository method should be reused if it creates local user audit/outbox side effects.

## Vehicle VIN completeness correction — mandatory in R2

The existing local Vehicle entity already stores both `vin` and `normalizedVin`, but the v89/v91 Vehicle Outbox payload factory does not include VIN. A bidirectional Vehicle sync is therefore incomplete unless Session 92 corrects the outbound payload as part of the same aggregate contract.

Required behavior:

1. Modify `VehicleSyncOperationFactory` so every new Vehicle UPSERT payload includes:
   - `vin`
2. Do **not** send `normalizedVin` as an authoritative remote field.
3. On remote apply:
   - if `vin` is present with a string value: store it and recompute `normalizedVin` using the existing `VehicleValidator.normalizeVin`;
   - if `vin` is explicitly present as JSON `null`: clear both `vin` and `normalizedVin`;
   - if `vin` is absent from a historical payload: preserve the existing local VIN for an existing aggregate; for a newly materialized aggregate use `null`.
4. A remote VIN collision with another local Vehicle in the same company must not crash the transaction or silently overwrite either Vehicle:
   - durably defer the remote change;
   - leave the cursor rule unchanged because the complete change is durably represented;
   - retain enough detail for deterministic replay after the conflict is resolved.
5. Remote apply must never create a new Outbox operation.
6. This correction is transport completeness only. It must not change VIN validation rules, UI, matching priority, or product behavior.

Required VIN tests:

1. outbound Vehicle payload contains `vin`;
2. outbound `vin = null` is represented explicitly;
3. pulled VIN updates `vin` and recomputes `normalizedVin`;
4. explicit remote null clears both VIN fields;
5. historical payload with missing VIN does not erase an existing VIN;
6. same-company normalized VIN collision is deferred, not overwritten;
7. VIN handling remains tenant scoped.

## Allowed existing files to modify

- `app/src/main/java/com/optimal/fleet/coordinator/sync/UnifiedSyncCoordinator.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullStateDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/dao/VehicleDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceWriteDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/dao/MaintenanceFollowUpDao.kt`
- `feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/VehicleSyncOperationFactory.kt`

## Allowed new production files

- `app/src/main/java/com/optimal/fleet/coordinator/sync/OptimalDeltaPullCoordinator.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/RemoteChangeApplier.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/VehicleRemoteChangeApplier.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/MaintenanceRemoteChangeApplier.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/FollowUpRemoteChangeApplier.kt`

If one additional small mapper file is strictly required, it may be added only under:

`app/src/main/java/com/optimal/fleet/coordinator/sync/remoteapply/`

and must be listed in the handoff.

## Allowed tests/docs

- `app/src/test/java/com/optimal/fleet/sync/OptimalDeltaPullCoordinatorTest.kt`
- `app/src/test/java/com/optimal/fleet/sync/RemoteChangeApplierTest.kt`
- `app/src/test/java/com/optimal/fleet/sync/DeferredRemoteChangeTest.kt`
- `app/src/test/java/com/optimal/fleet/sync/UnifiedSyncCoordinatorTest.kt`
- `core/database/src/androidTest/java/com/optimal/fleet/core/database/SyncPullApplyTransactionTest.kt`
- `feature/vehicles/src/test/java/com/optimal/fleet/feature/vehicles/data/VehicleSyncOperationFactoryTest.kt`
- existing `feature/vehicles` repository tests only if strictly required to verify VIN payload compatibility
- `docs/sync/**`
- `PATCH_MANIFEST-v92.md`
- `verification-v92.md`

## Required test scenarios

1. empty cursor → first page.
2. duplicate page → no duplicate state.
3. process death before Room commit → cursor unchanged.
4. commit succeeds → cursor advances.
5. dirty local aggregate → remote row deferred.
6. dirty clears → deferred row applies.
7. wrong company row → not applied.
8. Vehicle remote change visible through existing Room Flow.
9. missing parent → deferred, not lost.
10. session switches mid‑pull → abort safely.

## Acceptance

The app is now **bidirectional Offline‑First through Normal Sync**, even with Realtime completely absent.

Vehicle synchronization is not accepted unless `vin` is complete in both directions and `normalizedVin` is deterministically recomputed locally.

`SOURCE_OF_TRUTH_READY = YES`.

---

# 18. SESSION 93 — Immediate Normal Sync after local commits

## Input
`optimal-v92.zip`

## Output
`optimal-v93.zip`

## Objective
Remove avoidable 15-minute latency for locally created/edited synchronized records.

## Design

Add pure non-Android port:

```kotlin
interface SyncKickPort {
    fun request(companyId: String)
}
```

Implementation:

```text
WorkManagerSyncKickPort
→ SyncScheduler.scheduleNow(companyId = companyId)
```

Feature repositories depend only on the pure port.

Kick happens **after** successful local transaction.

Scheduler failure must never invalidate the already committed local write.

## Writes that must kick

### Vehicles
- create
- update
- archive

### Maintenance
- create
- edit
- complete

### FollowUp
- create/update/conversion paths that enqueue a FollowUp sync operation

Only paths that actually create a generic Outbox mutation must kick.

## Allowed existing files to modify

- `feature/vehicles/src/main/java/com/optimal/fleet/feature/vehicles/data/RoomVehicleRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCreateRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceEditRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceCompleteRepository.kt`
- `feature/maintenance/src/main/java/com/optimal/fleet/feature/maintenance/data/RoomMaintenanceFollowUpRepository.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt`

## Allowed new production files

- `core/model/src/main/java/com/optimal/fleet/core/model/sync/SyncKickPort.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/WorkManagerSyncKickPort.kt`

If the actual `core:model` source root uses a different existing package root, preserve the module’s established path/package convention without modifying any additional file.

## Allowed tests/docs

Existing tests for the modified repositories may be changed only where constructor injection requires the new fake/no-op port.

New:
- `app/src/test/java/com/optimal/fleet/sync/WorkManagerSyncKickPortTest.kt`
- feature repository tests directly required to prove post‑commit kick behavior
- `docs/sync/**`
- `PATCH_MANIFEST-v93.md`
- `verification-v93.md`

## Required behavioral tests

- commit success → one kick.
- duplicate/no-op save → no kick.
- validation failure → no kick.
- transaction failure → no kick.
- kick exception/failure → committed local write remains valid.
- no WorkManager import inside feature modules.

## Acceptance

Local write latency path becomes:

`Room commit → Outbox durable → immediate WorkManager request`

Periodic WorkManager remains fallback.

`SOURCE_OF_TRUTH_READY = YES`.

---

# 19. SESSION 94 — Instant Sync via tenant‑scoped Realtime hints

## Input
`optimal-v93.zip`

## Output
`optimal-v94.zip`

## Objective
Add low-latency multi-device refresh without making Realtime a correctness dependency.

## Exact behavior

On active session:
1. resolve the company remote identity using existing local company mapping;
2. subscribe to `optimal_sync_change_log` for that company only;
3. receive INSERT hints;
4. parse only minimal metadata (`revision`, tenant);
5. coalesce bursts;
6. invoke `OptimalDeltaPullCoordinator`;
7. never pass the Realtime payload to aggregate appliers;
8. on pull failure, request Normal Sync through `SyncScheduler`;
9. on session change, cancel subscription and in-flight instant pull.

## Realtime lifecycle

A new coordinator is started by `OptimalApplication` using its existing application CoroutineScope.

Do not create a second global unmanaged scope if avoidable.

Required conceptual classes:

- `OptimalRealtimeHint`
- `OptimalRealtimeHintSource`
- `SupabaseOptimalRealtimeHintSource`
- `RealtimeSyncHintCoordinator`

## Allowed existing files to modify

- `app/src/main/java/com/optimal/fleet/OptimalApplication.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/SyncModule.kt`

No Verto Realtime file may be edited in this session.

## Allowed new production files

- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/OptimalRealtimeHint.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/OptimalRealtimeHintSource.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/SupabaseOptimalRealtimeHintSource.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/RealtimeSyncHintCoordinator.kt`

If Hilt requires a dedicated module:
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/OptimalRealtimeModule.kt`

## Allowed tests/docs

- `app/src/test/java/com/optimal/fleet/sync/RealtimeSyncHintCoordinatorTest.kt`
- `app/src/test/java/com/optimal/fleet/sync/RealtimeTenantIsolationTest.kt`
- `docs/sync/**`
- `PATCH_MANIFEST-v94.md`
- `verification-v94.md`

## Required tests

1. hint triggers Pull.
2. 100 rapid hints are coalesced; no 100 independent sync jobs.
3. duplicate revision is harmless.
4. hint never directly calls DAO.
5. session switch cancels old subscription.
6. company A event cannot update company B.
7. disconnected Realtime does not mark normal sync failed.
8. failed instant pull schedules durable Normal Sync fallback.
9. no hint received → periodic normal sync still converges.

## Acceptance

Instant Sync is now an **optional acceleration layer** over the same authoritative delta Pull.

`SOURCE_OF_TRUTH_READY = YES`.

---

# 20. SESSION 95 — Convergence, conflict and failure hardening

## Input
`optimal-v94.zip`

## Output
`optimal-v95.zip`

## Objective
Prove the synchronization model under multi-device, retry, duplicated events and process-death scenarios and close only defects revealed inside the sync scope.

## Critical invariants

### Invariant A
A server change is never considered consumed unless:
- it is applied to an entity, or
- its complete payload is durably deferred.

### Invariant B
Cursor never moves ahead of durable local representation.

### Invariant C
A dirty local aggregate is never silently overwritten by Pull.

### Invariant D
A missed Realtime event cannot cause permanent divergence.

### Invariant E
Outbox Push is idempotent.

### Invariant F
Server revision is ordering only.  
Never compare `serverRevision` numerically with device `localVersion`.

### Invariant G
Existing Push conflict behavior remains isolated from Pull cursor ordering.

## Test harness

Create a deterministic fake server change-feed model capable of representing two clients.

Required scenarios:

1. Device A offline creates Vehicle → reconnect → Device B pulls it.
2. Device A edits synced Vehicle → Device B receives Realtime hint → Pull → converges.
3. Realtime disabled on B → periodic Normal Sync → same final result.
4. duplicate server page → same final state.
5. duplicate hint → same final state.
6. A has dirty local edit while B edit arrives → B change deferred on A.
7. A pushes/resolves → deferred processing leaves deterministic final state.
8. process death after network response but before Room commit → cursor unchanged.
9. process death after Room commit → replay idempotent.
10. session company changes during Pull → no cross-tenant writes.
11. Pull page contains missing parent → durable deferred replay succeeds later.
12. server returns descending/invalid revision → page rejected; cursor unchanged.
13. RPC timeout after server commit → retry does not duplicate change-log row.
14. expired Outbox lease + delta pull → recovered without duplicate mutation.
15. permanent Realtime outage → Normal Sync remains correct.

## Allowed existing production files to modify

Only if a failing test proves a defect, and only these:

- `app/src/main/java/com/optimal/fleet/coordinator/sync/OptimalDeltaPullCoordinator.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/VehicleRemoteChangeApplier.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/MaintenanceRemoteChangeApplier.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/FollowUpRemoteChangeApplier.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/RealtimeSyncHintCoordinator.kt`
- `app/src/main/java/com/optimal/fleet/coordinator/sync/realtime/SupabaseOptimalRealtimeHintSource.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncPullStateDao.kt`
- `core/database/src/main/java/com/optimal/fleet/core/database/sync/SyncQueueDao.kt`

No other production file is permitted.

## Allowed test/docs files

- `app/src/test/java/com/optimal/fleet/sync/**`
- `core/database/src/androidTest/java/com/optimal/fleet/core/database/**Sync*.kt`
- `backend/supabase/tests/optimal_sync_delta_contract.sql`
- `docs/sync/**`
- `PATCH_MANIFEST-v95.md`
- `verification-v95.md`

## Acceptance

All deterministic convergence scenarios are represented in tests.  
Any environment-unrunnable tests are documented accurately, not reported as passing.

`SOURCE_OF_TRUTH_READY = YES`.

---

# 21. SESSION 96 — Architecture gates, final verification and freeze

## Input
`optimal-v95.zip`

## Output
`optimal-v96.zip`

## Objective
Freeze the completed design with enforceable architecture rules and produce the final Source of Truth.

## Required architecture assertions

Add/extend static/unit architecture checks proving:

1. UI/ViewModels do not import `OptimalSyncApi`, `SyncPullTransport`, WebSocket source or DAO.
2. Domain does not import Android/Room/Retrofit/OkHttp/WorkManager.
3. Feature modules do not depend on another feature implementation.
4. Realtime source/coordinator has no direct aggregate DAO mutation path.
5. `OptimalDeltaPullCoordinator` is the only generic remote→Room delta coordinator.
6. `UnifiedSyncCoordinator` order is:
   - 10 Outbox
   - 15 Delta Pull
   - 20 Invoice
   - 30 Maintenance feed
   - 40 Messages
7. WorkManager periodic fallback still exists.
8. immediate local write kick still exists.
9. cursor/deferred tables remain sidecars; feature domain entities do not gain server cursor fields.
10. Verto specialized Realtime remains independent and unchanged by the generic sync implementation.
11. tenant checks are present at server contract and Android apply boundary.
12. no secret/service-role key added.

## Final documentation

Create:

`docs/sync/FINAL_SYNC_ARCHITECTURE_v96.md`

It must document, in plain language:

### Normal Sync
- purpose;
- triggers;
- execution order;
- retry behavior;
- cursor;
- deferred remote changes;
- guarantees.

### Instant Sync
- purpose;
- lifecycle;
- Realtime hint;
- tenant scoping;
- coalescing;
- fallback;
- guarantees and non-guarantees.

### Offline behavior matrix

| Situation | Expected behavior |
|---|---|
| No internet, local write | Room updates immediately; Outbox retains operation |
| Internet returns | Normal Sync pushes then pulls |
| Other device writes | Realtime hint accelerates Pull |
| Realtime unavailable | periodic/startup Normal Sync catches up |
| Process killed | cursor/outbox/deferred state survives |
| Duplicate Push | idempotency prevents duplicate mutation |
| Duplicate Pull | revision metadata makes apply idempotent |
| Local dirty + remote update | remote change deferred, local work not overwritten |
| Account/company switch | old sync/subscription cancelled |

## Allowed existing files to modify

- `app/src/test/java/com/optimal/fleet/sync/SyncArchitectureTest.kt`
- `app/src/test/java/com/optimal/fleet/sync/UnifiedSyncCoordinatorTest.kt`
- existing static architecture verification script **only if one is already responsible for sync architecture checks**

No production behavior file may be modified in Session 96.

## Allowed new files

- `docs/sync/FINAL_SYNC_ARCHITECTURE_v96.md`
- `docs/sync/**`
- `PATCH_MANIFEST-v96.md`
- `verification-v96.md`
- one sync-specific static verification script under `scripts/` if necessary and if no suitable existing script exists.

## Final acceptance

The final report must state separately:

```text
OFFLINE_FIRST_LOCAL = PASS|FAIL
NORMAL_SYNC_PUSH = PASS|FAIL
NORMAL_SYNC_PULL = PASS|FAIL
MULTI_DEVICE_CONVERGENCE_CONTRACT = PASS|FAIL
INSTANT_SYNC_HINT_LAYER = PASS|FAIL
REALTIME_OPTIONAL_FOR_CORRECTNESS = PASS|FAIL
TENANT_ISOLATION_CONTRACT = PASS|FAIL
PROCESS_DEATH_RECOVERY_CONTRACT = PASS|FAIL
ARCHITECTURE_BOUNDARIES = PASS|FAIL
SOURCE_OF_TRUTH_READY = YES|NO
```

If runtime/server/build verification is unavailable, it must also state:

```text
LIVE_SERVER_VERIFIED = NO_ENVIRONMENT
FULL_GRADLE_VERIFIED = NO_ENVIRONMENT
```

Those environment statuses do not convert unexecuted checks into PASS.

At completion:

```text
LAST_COMPLETED_SESSION = 96
CURRENT_SOURCE_OF_TRUTH = optimal-v96.zip
NEXT_SESSION = COMPLETE
```

---

# 22. Files permanently protected throughout v90–v96

Unless explicitly listed in a session allowlist, do not modify:

- all Presentation/UI screens;
- all Navigation files;
- authentication feature;
- finance feature;
- settings feature;
- notifications feature;
- home feature;
- Verto feature implementation;
- design system;
- Gradle/version catalog;
- application permissions/manifest;
- existing business use cases;
- existing Verto invoice/maintenance/message contracts.

---

# 23. What the agent must NOT decide

The executing agent has no authority to decide:

- whether Realtime writes directly to Room — **forbidden**;
- whether timestamp replaces revision — **forbidden**;
- whether cursor advances before Room commit — **forbidden**;
- whether dirty local state can be overwritten — **forbidden**;
- whether to add generic delete behavior — **forbidden**;
- whether to merge Verto specialized feeds into generic delta sync — **forbidden**;
- whether to add new modules — **forbidden**;
- whether to change UI — **forbidden**;
- whether to expand per-session file scope — **forbidden**;
- whether to skip a session — **forbidden**.

If implementation details not explicitly material to these decisions are required, choose the smallest implementation consistent with existing project conventions.

---

# 24. Expected final result after v96

OPTIMAL will have two clearly separated synchronization layers:

## Normal Sync

**Durable, authoritative, bidirectional and recoverable.**

```text
Local Room write
→ Transactional Outbox
→ WorkManager Push
→ Server
→ Delta Pull
→ Room
```

It guarantees eventual convergence without depending on Realtime.

## Instant Sync

**Low-latency acceleration only.**

```text
Server change
→ Realtime hint
→ Delta Pull
→ Room
```

It does not own data, conflict policy or durability.

## Final architectural property

> **Room remains the single local Source of Truth; Normal Sync guarantees correctness; Instant Sync only reduces propagation latency.**

This is the architecture to preserve in all future features.
