# OPTIMAL Final Sync Architecture — v96

This document freezes the generic OPTIMAL offline-first synchronization architecture completed in Sessions 90–96. Realtime is an acceleration layer only; correctness belongs to Room + Outbox + Normal Sync + durable Pull state.

## 1. Normal Sync

### Purpose
Normal Sync is the correctness path. It pushes durable local work, then pulls authoritative remote deltas, then runs the existing specialized feeds in a stable order.

### Triggers
Normal Sync can be started by:
- application/session startup when an active session is observed;
- immediate local-write kick through `SyncKickPort`;
- the periodic WorkManager fallback;
- a Realtime-hint Pull failure that schedules Normal Sync;
- existing callers that request the unified sync worker.

All WorkManager sync requests require network connectivity. The periodic fallback remains every 15 minutes.

### Execution order
`UnifiedSyncCoordinator` sorts participants by `order`, then by key. The frozen production order is:

1. `10` — Outbox: local messages/attachments and generic pending operations.
2. `15` — `OptimalDeltaPullCoordinator`: generic remote delta Pull into Room.
3. `20` — Verto invoice feed.
4. `30` — Verto maintenance feed.
5. `40` — Verto message Pull.

The coordinator verifies the active session before and after participants. A session/company switch stops the remaining work.

### Retry behavior
Participants return `Completed`, `RetryRequired`, or `SessionChanged`.
- Retryable failures are aggregated and cause the worker to retry using WorkManager backoff.
- A session change terminates the run and suppresses retry under the old session.
- Outbox rows remain durable until they are successfully resolved.
- Duplicate Push is protected by server idempotency keys.
- Pull application is idempotent by durable server revision metadata.

### Cursor
The generic Pull cursor is stored in the Room sidecar table `sync_pull_cursors`, scoped by company and sync scope. It is not stored in feature domain entities.

The cursor advances only after a remote change has been durably represented locally by one of these outcomes:
- applied to the aggregate and replica metadata;
- recorded as a durable deferred remote change;
- recognized as already applied/idempotent.

Invalid, non-positive, descending, or wrong-tenant pages are rejected rather than advancing the cursor.

### Deferred remote changes
Incoming remote changes are kept in `sync_deferred_remote_changes` when they cannot safely overwrite local work or cannot yet be applied because a dependency is missing. Replica metadata is stored separately in `sync_replica_metadata`.

Deferred rows are replayed later. This preserves local dirty state and keeps generic server revision/cursor concerns outside feature domain models.

### Guarantees
Normal Sync guarantees, at the contract level:
- local-first writes survive offline periods through Room + Outbox;
- deterministic participant order;
- durable cursor/outbox/deferred state across process death;
- idempotent duplicate Push and Pull handling;
- no blind remote overwrite of local dirty aggregates;
- tenant checks on server selection and Android apply boundaries;
- eventual catch-up without Realtime, assuming the server and network become available.

It does not guarantee that a device is synchronized while it has no network, or that every device observes a remote change instantly.

## 2. Instant Sync

### Purpose
Instant Sync reduces the delay between a remote write and the next generic Pull. It is not a second write/apply pipeline.

### Lifecycle
`RealtimeSyncHintCoordinator` runs in application scope and observes the active session. `collectLatest` cancels the old subscription when account/company identity changes.

For the active company, the coordinator resolves the remote company id and subscribes to Realtime hints from the generic change log.

### Realtime hint
`SupabaseOptimalRealtimeHintSource` listens for INSERT events on `optimal_sync_change_log`. A hint carries a server revision and remote company id.

A valid hint invokes `OptimalDeltaPullCoordinator`. Realtime does not mutate Vehicle, Maintenance, or Follow-up DAOs directly.

### Tenant scoping
The Realtime subscription includes `company_id=eq.<remoteCompanyId>`. Parsed hints are rejected if their company id differs from the expected remote company. The authoritative Pull page is also rejected if any change belongs to another company.

### Coalescing
Hints are debounced for 150 ms and conflated. Revisions at or below the highest already handled revision are ignored. Realtime therefore acts as a coalesced “pull now” signal rather than a per-row apply channel.

### Fallback
If the hint-triggered Pull returns `RetryRequired`, Normal Sync is scheduled. If Realtime is disconnected, unavailable, delayed, or permanently down, startup and periodic Normal Sync remain responsible for eventual convergence.

### Guarantees and non-guarantees
Instant Sync guarantees only acceleration of the authoritative Pull path when a valid hint is received.

It does not guarantee:
- delivery of every hint;
- exactly-once hint delivery;
- correctness without Normal Sync;
- direct database mutation from WebSocket payloads;
- immediate convergence while the device is offline.

Realtime is therefore optional for correctness.

## 3. Verto specialized Realtime

The existing Verto message Realtime implementation remains independent from the generic sync implementation. It continues to use its own `VertoRealtimeHintSource` and `optimal_verto_messages` subscription. Generic sync does not replace or route through that specialized implementation.

## 4. Offline behavior matrix

| Situation | Expected behavior |
|---|---|
| No internet, local write | Room updates immediately; Outbox retains operation |
| Internet returns | Normal Sync pushes then pulls |
| Other device writes | Realtime hint accelerates Pull |
| Realtime unavailable | periodic/startup Normal Sync catches up |
| Process killed | cursor/outbox/deferred state survives |
| Duplicate Push | idempotency prevents duplicate mutation |
| Duplicate Pull | revision metadata makes apply idempotent |
| Local dirty + remote update | remote change deferred, local work not overwritten |
| Account/company switch | old sync/subscription cancelled |

## 5. Frozen architecture boundaries

The v96 architecture gates enforce all of the following:
- UI/ViewModels cannot import generic sync API/transport/WebSocket source or DAOs.
- Domain cannot import Android, Room, Retrofit, OkHttp, or WorkManager.
- Feature implementation modules cannot depend on each other.
- Generic Realtime cannot mutate aggregate DAOs directly.
- `OptimalDeltaPullCoordinator` is the sole generic remote-to-Room delta coordinator.
- the unified participant order is frozen at 10/15/20/30/40.
- periodic fallback and immediate local-write kicks must remain present.
- generic cursor/deferred/replica metadata remain Room sidecars.
- specialized Verto Realtime remains independent.
- tenant checks must remain at server and Android boundaries.
- service-role material and secret keys are forbidden from Android/client production source.

The executable gate is `scripts/v96-sync-architecture-contract.py`.
