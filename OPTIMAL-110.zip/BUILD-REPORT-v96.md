# OPTIMAL v96 — Build Report

Date: 2026-08-15

## Result

- `assembleDebug --offline`: PASS
- Gradle: local Gradle 8.9 distribution from `~/.gradle/wrapper/dists`
- Dependencies: local Gradle cache only; no Gradle/dependency download was used
- Tasks: `398 actionable tasks: 398 executed`
- Duration: `3m 6s`
- APK: `OPTIMAL-v96-debug.apk`
- APK SHA-256: `0a279782d45ea79b6fbf5f9040a8a7d95743ba47e18d3eab99de591a1e960adb`
- APK size: `21,350,571` bytes

## Server and SQL

- Supabase project: `Verto-app` (`madkfvggyolmdberzmtb`)
- Project URL used for the APK: `https://madkfvggyolmdberzmtb.supabase.co`
- The supplied management token was used transiently for project discovery, public-key retrieval, and SQL execution. It was not written to source, Gradle properties, the APK, or this archive.
- Applied: `backend/supabase/migrations/20260815000100_optimal_sync_delta_feed.sql` — HTTP 201
- Verified: `backend/supabase/tests/optimal_sync_delta_contract.sql` — HTTP 201, no SQL error
- No service-role token was embedded in the Android client.

## Verification

- `scripts/v96-sync-architecture-contract.py`: PASS `12/12`
- `scripts/static-architecture-check.py`: `23/24`; the sole failure detected generated `.gradle`/`build` output created by the successful local build. Those paths are excluded from the source archive.
- Gradle unit/instrumentation tests were not claimed; the requested build task was run.

## Source of truth archive

`OPTIMAL-v96-SOURCE-OF-TRUTH.zip` contains source, Gradle configuration, backend SQL, documentation, and this report. It excludes APKs, Gradle caches, generated `build` directories, and other generated artifacts. It intentionally contains no APK copy.
