# OPTIMAL v71 — Company registration and profile update

## Implemented

- Added the required company-registration form after validating the join code.
- Company name is required and read-only during registration; it is populated from the validated Verto company code.
- Required manager name.
- Optional business activity, company address, vehicle count, and employee count.
- Optional maintenance-workshop relationship; workshop name becomes required when enabled.
- Added an in-app account/company profile editor.
- OWNER and MANAGER can edit company data and their personal name.
- Other employees can edit only their personal name; repository enforcement prevents company changes even if UI restrictions are bypassed.
- Company/profile edits are recorded as business activity.
- User activity queries exclude synchronization, conflict-resolution, and technical authorization events.
- Removed user-facing development/storage wording such as local-device and backend implementation messages.
- Added `.gitignore` protection for secrets and generated outputs.

## Persistence boundary

The supplied archive contains the Android project but no Supabase migrations/functions package. The existing registration RPC accepts only the code and display name. Therefore:

- company name and member identity continue through the existing Verto/Supabase registration flow;
- the new optional company-profile fields are persisted in the Android application;
- server-wide/cross-device persistence for those new fields requires a matching Supabase migration and RPC contract update in the separate server package.

No server schema or production data was guessed or modified.

## Verification

- Company profile acceptance contract: `27/27 PASS`.
- Architecture checks: `24/24 PASS`.
- Security release checks: `45/45 PASS`.
- Room source/schema baseline: `PASS` — 26 tables.
- Room drift contract: `4/4 PASS`.
- Kotlin source lexical gate: `11/11 PASS`.
- Member remote focused compilation: `2/2 PASS`.
- Member mapper focused compilation: `1/1 PASS`.
- UI and affected-source parser checks: `PASS`.

## Build status

`./gradlew help --offline --no-daemon --stacktrace` could not start because Gradle 8.9 is not cached and this environment cannot reach `services.gradle.org` (`UnknownHostException`). Therefore no APK or full Gradle test result is claimed.
