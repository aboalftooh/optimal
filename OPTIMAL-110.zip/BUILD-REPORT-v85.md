# BUILD REPORT — v85

**Session:** SESSION-85 — Auth + Join Company + Notifications  
**Input:** `OPTIMAL-v84-source-clean.zip`  
**Output:** `OPTIMAL-v85-source-clean.zip`

## Scope verification

SESSION-85 only was implemented.

- Auth onboarding now uses Core Components v2 hierarchy, fields, status, actions, and field-adjacent validation presentation.
- Auth `AccountSummary` now uses v2 list/form structure; sign-out is visually destructive while keeping the same event contract.
- Join Company now uses v2 hierarchy/form/field/action components, presents validation beside the code field, keeps loading-submit gating, and retains error reference text.
- Notifications now use v2 loading/error/empty states, flat list rows, semantic unread/read state, and v2 action hierarchy.
- Notification stable item-id opening, refresh, mark-all-read, load-more, navigation, deep-link and tap handling remain unchanged.
- Auth/Join/Notifications contracts and ViewModels, their Domain/Data trees, Settings/Auth/Notifications navigation, app notification deep-link handlers, and Finance were SHA/tree locked to v84.

## Verification results

| Check | Result | Detail |
|---|---|---|
| SESSION-85 static contract | PASS | `162/162` checks |
| Changed Kotlin parser check | PASS | `10/10` changed Kotlin/test files |
| SESSION-84 admin regression | PASS | `181/181` |
| SESSION-83 Finance regression | PASS | `101/101` |
| Security release checks | PASS | `45/45` |
| Notification policy harness | PASS | `20/20` |
| Verto Home entry regression | PASS | `82/82` |
| Architecture static checks | BASELINE BLOCKER | `23/24`; only missing `gradle/wrapper/gradle-wrapper.jar` |
| Real Gradle Auth/Settings/Notifications build/tests | BLOCKED | wrapper bootstrap JAR is absent |

## Real Gradle attempt

Attempted:

```text
./gradlew :feature:auth:testDebugUnitTest :feature:settings:testDebugUnitTest \
  :feature:notifications:testDebugUnitTest :feature:auth:assembleDebug \
  :feature:settings:assembleDebug :feature:notifications:assembleDebug
```

Result:

```text
Error: Could not find or load main class org.gradle.wrapper.GradleWrapperMain
Caused by: java.lang.ClassNotFoundException: org.gradle.wrapper.GradleWrapperMain
```

No Android unit, instrumentation, assemble, or runtime test is claimed as executed successfully.

## UI coverage added

Six focused Compose UI cases were added in v85:

- Auth phone validation is field-adjacent and preserves `RequestOtp`.
- Auth join-code step preserves `SubmitJoinCode` and `Back`.
- Join Company preserves `Submit`.
- Join Company validation is presented beside the code field.
- Notifications mark-all-read preserves `MarkAllRead`.
- Notifications error retry preserves `Refresh`.

These source tests were parser-checked but not executed by Gradle because the wrapper bootstrap JAR is unavailable.

## Legacy harness note

`scripts/run-v31-auth-harness.sh` is stale against the current Auth API and fails before execution because its harness signatures predate later Auth changes. It was not used as a SESSION-85 acceptance gate. The current Auth contracts/ViewModel/Domain/Data were SHA/tree locked unchanged from v84.

## Acceptance conclusion

SESSION-85 meets its static acceptance target. Auth, Join Company, and Notifications are migrated to Design System v2 without changing behavior, permission, navigation, sync, or deep-link contracts. SESSION-86 owns the Verto Chat structural presentation refactor.
